package com.eprut.db.repositories;

import com.eprut.db.entities.ImportLogEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ImportLogsRepository extends JpaRepository<ImportLogEntity, Long> {

    /**
     * Намира всички грешки, свързани с конкретен импорт.
     *
     * @param importId
     * @return List<ImportLogEntity>
     */
    @Query("""
                select ile
                from ImportLogEntity ile
                join fetch NImportMessageTypeEntity nimte on ile.msgTypeId = nimte.id
                where ile.importId = :importId and (nimte.code = 'ERROR' or nimte.code = 'WARNING')
                order by ile.dateAdded desc
            """)
    List<ImportLogEntity> findImportErrorsByImportId(@Param("importId") Long importId);

    /**
     * Връща журнала, свързан с конкретен импорт.
     *
     * @param importId
     * @return List<ImportLogEntity>
     */
    @Query("""
                select ile
                from ImportLogEntity ile
                join fetch NImportMessageTypeEntity nimte on ile.msgTypeId = nimte.id
                where ile.importId = :importId and (nimte.code != 'ERROR' and nimte.code != 'WARNING')
                order by ile.dateAdded desc
            """)
    List<ImportLogEntity> findImportJournalByImportId(@Param("importId") Long importId);

    /**
     * Връща странициран журнал, свързан с конкретен импорт.
     *
     * @param importId
     * @param pageable
     * @return Page<ImportLogEntity>
     */
    @Query("""
                select ile
                from ImportLogEntity ile
                join fetch NImportMessageTypeEntity nimte on ile.msgTypeId = nimte.id
                where ile.importId = :importId and (nimte.code != 'ERROR' and nimte.code != 'WARNING')
            """)
    Page<ImportLogEntity> findImportJournalByImportId(@Param("importId") Long importId, Pageable pageable);
}
