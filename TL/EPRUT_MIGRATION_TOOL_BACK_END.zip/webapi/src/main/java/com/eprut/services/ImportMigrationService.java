package com.eprut.services;

import com.eprut.db.views.out.ImportMigrationStateOutView;
import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.StatusNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;

public interface ImportMigrationService {

    /**
     * Стартира миграция на конкретен импорт.
     * @param registerCode
     * @param importId
     * @return ImportMigrationStateOutView
     */
    ImportMigrationStateOutView startImportMigration(String registerCode, Long importId)
            throws ImportNotFoundException, StatusNotFoundException, UnauthorizedAccessException;
}
