package com.eprut.controllers;

import com.eprut.db.entities.NImportStatusEntity;
import com.eprut.services.StatusLoaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/import/registers/statuses")
public class StatusLoaderController {

    @Autowired
    private StatusLoaderService statusLoaderService;

    /**
     * Връща лист с обекти от тип NImportStatusEntity - всички статуси.
     * @return ResponseEntity<List<NImportStatusEntity>>
     */
    @GetMapping("")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<NImportStatusEntity>> getAllStatuses() {
        List<NImportStatusEntity> res = statusLoaderService.getAllStatuses();
        return ResponseEntity.ok(res);
    }
}
