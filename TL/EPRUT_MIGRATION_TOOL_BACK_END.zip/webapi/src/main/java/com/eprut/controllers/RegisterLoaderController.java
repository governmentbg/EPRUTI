package com.eprut.controllers;

import com.eprut.db.views.out.RegisterOutView;
import com.eprut.exceptions.RegisterTypeNotFoundException;
import com.eprut.services.RegisterLoaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Locale;

@RestController
@RequestMapping("/import/registers")
public class RegisterLoaderController {

    @Autowired
    private RegisterLoaderService registerLoaderService;

    /**
     * Връща лист с обекти от тип RegisterOutView. Връща всички регистри, спрямо текущата локализация.
     * @return ResponseEntity<List<RegisterOutView>>
     */
    @GetMapping("")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<RegisterOutView>> getAllRegistersForCurrentLocale() {
        Locale locale = LocaleContextHolder.getLocale();
        List<RegisterOutView> res = registerLoaderService.getAllRegistersForCurrentLocale(locale);
        return ResponseEntity.ok(res);
    }

    /**
     * Връща регистър по подаден код на регистър, спрямо текущата локализация.
     * @param registerCode
     * @return ResponseEntity<RegisterOutView>
     * @throws RegisterTypeNotFoundException
     */
    @GetMapping("/description/{registerCode}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<RegisterOutView> getRegisterByCode(@PathVariable("registerCode") String registerCode)
            throws RegisterTypeNotFoundException {
        Locale locale = LocaleContextHolder.getLocale();
        RegisterOutView res = registerLoaderService.getRegisterByCode(registerCode, locale);
        return ResponseEntity.ok(res);
    }
}
