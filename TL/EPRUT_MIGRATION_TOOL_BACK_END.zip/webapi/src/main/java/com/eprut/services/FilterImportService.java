package com.eprut.services;

import com.eprut.db.views.BasicPageableView;
import com.eprut.db.views.out.ImportOutView;
import com.eprut.exceptions.RegisterTypeNotFoundException;
import org.springframework.data.domain.Pageable;

import java.time.Instant;
import java.util.Locale;

public interface FilterImportService {

    /**
     * Намира всички импортирани записи за даден регистър и текущ потребител.
     * Връща списък с всички импортирани записи в зависимост от зададените критерии.
     * Резултатите се връщат страницирани.
     * @param registerCode
     * @param startDate
     * @param endDate
     * @param status
     * @param pageable
     * @return Page<ImportOutView>
     */
    BasicPageableView<ImportOutView> findAllImportsByRegisterTypeAndCurrentUser(String registerCode, Locale locale, Instant startDate,
                                                                                Instant endDate, String status, Pageable pageable)
            throws RegisterTypeNotFoundException;
}
