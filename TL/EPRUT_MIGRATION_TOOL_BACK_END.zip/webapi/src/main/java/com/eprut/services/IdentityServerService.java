package com.eprut.services;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface IdentityServerService extends UserDetailsService {

}
