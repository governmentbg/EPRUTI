package com.eprut.db.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "v_n_reg_act_reg", schema = "staging")
@Data
public class VNRegActRegEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "reg_code", length = 50, nullable = false)
    private String regCode;

    @Column(name = "reg_act_code", length = 50, nullable = false)
    private String regActCode;
}
