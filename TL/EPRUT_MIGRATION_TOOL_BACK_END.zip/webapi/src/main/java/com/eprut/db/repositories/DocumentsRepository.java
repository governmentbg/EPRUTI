package com.eprut.db.repositories;

import com.eprut.db.entities.DocumentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentsRepository extends JpaRepository<DocumentEntity, Long> {

    /**
     * Връща броя на прикачените документи за конкретен импорт.
     * @param impId
     * @return Long
     */
    @Query("""
        select count(doc)
        from DocumentEntity doc
        where doc.impId = :impId
    """)
    Long countDocumentsByImportId(@Param("impId") Long impId);
}
