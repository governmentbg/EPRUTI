package com.eprut.controllers;

import com.eprut.beans.ErrorModel;
import com.eprut.exceptions.BaseException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.Locale;

@RestControllerAdvice
public class ExceptionHandlerController {


    private static final int STATUS = 500;
    @Autowired
    private MessageSource messageSource;

    @ExceptionHandler(BaseException.class)
    public ErrorModel handleIosDownloadException(
            BaseException ex, HttpServletRequest request,
            HttpServletResponse response, Locale locale) {

        String errorMessage = messageSource.getMessage(ex.getCode(), new Object[]{}, locale);

        ErrorModel errorModel = new ErrorModel();
        errorModel.setDateTime(Instant.now());
        errorModel.setMessage(errorMessage);
        errorModel.setUuid(request.getAttribute("uuid").toString());
        errorModel.setSystemMessage(ex.getMessage());
        errorModel.setMethod(request.getMethod());
        errorModel.setPath(request.getRequestURL().toString());
        response.setStatus(ex.getStatus());
        return errorModel;
    }


    @ExceptionHandler(Exception.class)
    public ErrorModel handleIosDownloadException(
            Exception ex, HttpServletRequest request,
            HttpServletResponse response, Locale locale) {

//        String errorMessage = messageSource.getMessage(ex.getCode(), new Object[]{}, locale);

        ErrorModel errorModel = new ErrorModel();
        errorModel.setDateTime(Instant.now());
//        errorModel.setMessage(errorMessage);
        errorModel.setUuid(request.getAttribute("uuid").toString());
        errorModel.setSystemMessage(ex.getMessage());
        errorModel.setMethod(request.getMethod());
        errorModel.setPath(request.getRequestURL().toString());
        response.setStatus(STATUS);
        return errorModel;
    }
}
