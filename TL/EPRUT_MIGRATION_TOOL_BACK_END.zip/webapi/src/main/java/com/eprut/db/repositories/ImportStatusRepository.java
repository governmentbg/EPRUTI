package com.eprut.db.repositories;

import com.eprut.db.entities.NImportStatusEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ImportStatusRepository extends JpaRepository<NImportStatusEntity, Long> {

    /**
     * Намира статус под код.
     * @param statusCode
     * @return NImportStatusEntity
     */
    @Query("""
        select is
        from NImportStatusEntity is
        where is.code = :statusCode
    """)
    Optional<NImportStatusEntity> findByStatusCode(@Param("statusCode") String statusCode);

    /**
     * Намира статус по описание/пълно наименование.
     * @param statusDescription
     * @return NImportStatusEntity
     */
    @Query("""
        select isе
        from NImportStatusEntity isе
        where isе.description = :statusDescription
    """)
    NImportStatusEntity findByStatusDescription(@Param("statusDescription") String statusDescription);
}
