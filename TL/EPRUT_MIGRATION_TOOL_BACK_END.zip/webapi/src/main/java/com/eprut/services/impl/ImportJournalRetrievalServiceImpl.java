package com.eprut.services.impl;

import com.eprut.beans.IdentityServerModel;
import com.eprut.db.entities.ImportEntity;
import com.eprut.db.entities.ImportLogEntity;
import com.eprut.db.repositories.ImportLogsRepository;
import com.eprut.db.repositories.ImportRepository;
import com.eprut.db.views.ImportJournalPageableView;
import com.eprut.db.views.out.ImportLogOutView;
import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;
import com.eprut.services.ImportJournalRetrievalService;
import com.opencsv.CSVWriter;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Service
@Slf4j
public class ImportJournalRetrievalServiceImpl implements ImportJournalRetrievalService {

    @Autowired
    private ImportLogsRepository importLogsRepository;

    @Autowired
    private ImportRepository importRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public byte[] generateCSVforImportJournal(String registerCode, Long importId)
            throws IOException, ImportNotFoundException, UnauthorizedAccessException {
        String logId = UUID.randomUUID().toString();
        log.info("{}: generateCSVforImportJournal started", logId);
        log.debug("{}: params: importId {}", logId, importId);
        try {
            IdentityServerModel
                    principal = (IdentityServerModel) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            ImportEntity imp = importRepository.findByRegisterCodeAndImportId(registerCode, importId)
                    .orElseThrow(() -> new ImportNotFoundException("Import with id: " + importId + " and register code: " + registerCode + " not found."));

            if (!Objects.equals(imp.getUserId(), principal.getId())) {
                throw new UnauthorizedAccessException("User with id: " + principal.getId() + " is not authorized to perform this action.");
            }

            List<ImportLogEntity> journal = importLogsRepository.findImportJournalByImportId(importId);

            StringWriter writer = new StringWriter();
            log.info("{}: generating csv file started", logId);
            writer.write("\uFEFF");
            try (CSVWriter csvWriter = new CSVWriter(writer, ',', CSVWriter.NO_QUOTE_CHARACTER, CSVWriter.DEFAULT_ESCAPE_CHARACTER, "\n")) {
                String[] header = {"Date added", "Message type", "Message"};
                csvWriter.writeNext(header);
                for (ImportLogEntity ile : journal) {
                    String[] row = {
                            ile.getDateAdded().toString(),
                            ile.getMsgType().getDescription(),
                            ile.getMsg()
                    };
                    csvWriter.writeNext(row);
                }
            } catch (Exception e) {
                log.error("{}: error generating csv file: {}", logId, e.getMessage(), e);
                throw e;
            } finally {
                log.info("{}: generating csv file finished", logId);
            }
            return writer.toString().getBytes(StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.error("{}: generateCSVforImportJournal error", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: generateCSVforImportJournal finished", logId);
        }
    }

    @Override
    public ImportJournalPageableView<ImportLogOutView> loadImportJournalByImportId(String registerCode, Long importId, Pageable pageable)
            throws ImportNotFoundException, UnauthorizedAccessException {
        String logId = UUID.randomUUID().toString();
        log.info("{}: loadImportJournalByImportId started", logId);
        log.debug("{}: params: importId {}", logId, importId);
        try {
            IdentityServerModel
                    principal = (IdentityServerModel) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            ImportEntity imp = importRepository.findByRegisterCodeAndImportId(registerCode, importId)
                    .orElseThrow(() -> new ImportNotFoundException("Import with id: " + importId + " and register code: " + registerCode + " not found."));

            if (!Objects.equals(imp.getUserId(), principal.getId())) {
                throw new UnauthorizedAccessException("User with id: " + principal.getId() + " is not authorized to perform this action.");
            }

            Page<ImportLogEntity> journal = importLogsRepository.findImportJournalByImportId(importId, pageable);

            if (journal.isEmpty()) {
                log.warn("{}: No journal information for importId: {}", logId, importId);
                return new ImportJournalPageableView<>(imp.getStatus().getCode(), false, new ArrayList<>(), pageable, journal.getTotalElements());
            }

            List<ImportLogOutView> journalList = journal.getContent().stream().map(j -> {
                        ImportLogOutView ilov = modelMapper.map(j, ImportLogOutView.class);
                        ilov.setUploadDate(j.getDateAdded());
                        ilov.setMsgType(j.getMsgType().getDescription());
                        ilov.setMessage(j.getMsg());
                        return ilov;
                    }
            ).toList();

            Boolean isLast = imp.getStatus().getIsLast();
            ImportJournalPageableView<ImportLogOutView> res = new ImportJournalPageableView<>(imp.getStatus().getCode(), isLast, journalList, pageable, journal.getTotalElements());
            log.info("{}: successfully retrieved {} messages", logId, res.getTotalElements());
            return res;
        } catch (Exception e) {
            log.debug("{}: error loadImportJournalByImportId error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: loadImportJournalByImportId finished", logId);
        }
    }
}
