package com.eprut.services;

import com.eprut.db.views.out.RegisterOutView;
import com.eprut.exceptions.RegisterTypeNotFoundException;

import java.util.List;
import java.util.Locale;

public interface RegisterLoaderService {

    /**
     * Намира и връща списък на всички регистри за текущата локализация.
     * @param locale
     * @return List<RegisterOutView>
     */
    List<RegisterOutView> getAllRegistersForCurrentLocale(Locale locale);

    /**
     * Намира и връща регистър по даден код на регистъра.
     * @param registerCode
     * @param locale
     * @return RegisterOutView
     */
    RegisterOutView getRegisterByCode(String registerCode, Locale locale) throws RegisterTypeNotFoundException;
}
