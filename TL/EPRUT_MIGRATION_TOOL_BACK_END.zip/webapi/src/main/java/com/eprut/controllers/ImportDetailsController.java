package com.eprut.controllers;

import com.eprut.db.views.out.ImportDetailsOutView;
import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;
import com.eprut.services.ImportDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/import/registers/import-file")
public class ImportDetailsController {

    @Autowired
    private ImportDetailsService importDetailsService;

    /**
     * Връща детайлна информация за конкретен импорт.
     * @param importId
     * @return ResponseEntity<ImportDetailsOutView>
     * @throws ImportNotFoundException
     */
    @GetMapping("/{registerCode}/details/{importId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ImportDetailsOutView> getImportDetails(@PathVariable("registerCode") String registerCode,
                                                                 @PathVariable("importId") Long importId)
            throws ImportNotFoundException, UnauthorizedAccessException {
        ImportDetailsOutView res = importDetailsService.getImportDetails(registerCode, importId);
        return ResponseEntity.ok(res);
    }
}
