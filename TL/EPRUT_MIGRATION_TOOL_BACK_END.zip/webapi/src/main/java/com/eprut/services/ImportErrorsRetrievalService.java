package com.eprut.services;

import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;

import java.io.IOException;

public interface ImportErrorsRetrievalService {

    /**
     * Генериране на CSV файл, който съдържа всички грешки за конкретен импорт.
     * @param importId
     * @return byte[]
     */
    byte[] generateCSVforImportErrors(String registerCode, Long importId)
            throws IOException, ImportNotFoundException, UnauthorizedAccessException;
}
