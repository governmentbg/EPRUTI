package com.eprut.db.repositories;

import com.eprut.db.entities.ImportEntity;
import com.eprut.db.entities.VImportEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.Optional;

@Repository
public interface ImportRepository extends JpaRepository<ImportEntity, Long> {

//    @Query("""
//                select i
//                from ImportEntity i
//                join fetch NImportStatusEntity is on i.statusId = is.id
//                join fetch ImportFilesEntity ifiles on i.fileId = ifiles.id
//                where i.registerCode = :registerCode and i.userId = :userId
//                      and (cast(:startDate as date) is null or i.uploadDate >= :startDate)
//                      and (cast(:endDate as date) is null or i.uploadDate <= :endDate)
//                      and (:statusCode is null or is.code = :statusCode)
//            """)
//    Page<ImportEntity> findAllImportsByRegisterTypeAndCurrentUser(@Param("registerCode") String registerCode,
//                                                                  @Param("userId") String userId,
//                                                                  @Param("startDate") Instant startDate,
//                                                                  @Param("endDate") Instant endDate,
//                                                                  @Param("statusCode") String statusCode,
//                                                                  Pageable pageable);
    /**
     * Намира всички импорти, свързани с конкретен регистър и потребител, с възможност
     * за филтриране по начална/крайна дата и статус.
     * @param registerCode
     * @param userId
     * @param startDate
     * @param endDate
     * @param statusCode
     * @param pageable
     * @return Page<VImportEntity>
     */
    @Query("""
        select i
        from VImportEntity i
        where i.registerCode = :registerCode and i.userId = :userId
              and (cast(:startDate as date) is null or i.uploadDate >= :startDate)
              and (cast(:endDate as date) is null or i.uploadDate <= :endDate)
              and (:statusCode is null or i.statusCode = :statusCode)
    """)
    Page<VImportEntity> findAllImportsByRegisterTypeAndCurrentUser(@Param("registerCode") String registerCode,
                                                                   @Param("userId") String userId,
                                                                   @Param("startDate") Instant startDate,
                                                                   @Param("endDate") Instant endDate,
                                                                   @Param("statusCode") String statusCode,
                                                                   Pageable pageable);

    /**
     * Връща обект от тип ImportEntity, който отговаря на конкретен код на регистър и импорт id.
     * @param registerCode
     * @param importId
     * @return Optional<ImportEntity>
     */
    @Query("""
        select i
        from ImportEntity i
        where i.registerCode = :registerCode and i.id = :importId
    """)
    Optional<ImportEntity> findByRegisterCodeAndImportId(@Param("registerCode") String registerCode,
                                                         @Param("importId") Long importId);
}
