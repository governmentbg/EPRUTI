package com.eprut.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Data
@AllArgsConstructor
@EqualsAndHashCode
public class IdentityServerModel implements UserDetails {

    private final String requestId;
    private final String id;
    private final String username;
    private final String password;
    private final List<? extends GrantedAuthority> authorities;

    /**
     * This is the default constructor for the user model.
     *
     * @param requestId   the id of the request;
     * @param id          id of the user
     * @param username    username
     * @param authorities list of authorities
     */
    public IdentityServerModel(String requestId, String id, String username, List<String> authorities) {
        this.requestId = requestId;
        this.id = id;
        this.username = username;
        this.password = "null";
        ArrayList<SimpleGrantedAuthority> tmpAuth = new ArrayList<>();
        for (String authority : authorities) {
            tmpAuth.add(new SimpleGrantedAuthority(authority));
        }
        this.authorities = Collections.unmodifiableList(tmpAuth);
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public String getPassword() {
        return password;
    }
}
