package com.eprut.controllers;

import com.eprut.db.views.ImportJournalPageableView;
import com.eprut.db.views.out.ImportLogOutView;
import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;
import com.eprut.services.ImportJournalRetrievalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@RestController
@RequestMapping("/import/registers/import-file")
public class ImportJournalRetrievalController {

    @Autowired
    private ImportJournalRetrievalService importJournalRetrievalService;

    /**
     * Извлича журнала за конкретен импорт и връща CSV файл с подробната информация.
     * @param registerCode
     * @param importId
     * @return ResponseEntity<byte[]>
     * @throws IOException
     */
    @GetMapping("/{registerCode}/details/{importId}/download-journal")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<byte[]> downloadCSVforImportJournal(@PathVariable("registerCode") String registerCode,
                                                              @PathVariable("importId") Long importId)
            throws IOException, ImportNotFoundException, UnauthorizedAccessException {
        byte[] csvBytes = importJournalRetrievalService.generateCSVforImportJournal(registerCode, importId);
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String filename = String.format("import_journal_%s_%s_%s.csv", registerCode, importId, timestamp);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("text/csv"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .body(csvBytes);
    }

    /**
     * Връща странициран журнал, свързан с конкретен импорт.
     * @param importId
     * @param pageable
     * @return ResponseEntity<ImportJournalPageableView<ImportLogOutView>>
     */
    @GetMapping("/{registerCode}/details/{importId}/import-journal")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ImportJournalPageableView<ImportLogOutView>> loadImportJournalByImportId(@PathVariable("registerCode") String registerCode,
                                                                                                   @PathVariable("importId") Long importId,
                                                                                                   Pageable pageable)
            throws ImportNotFoundException, UnauthorizedAccessException {
        ImportJournalPageableView<ImportLogOutView> res = importJournalRetrievalService.loadImportJournalByImportId(registerCode, importId, pageable);
        return ResponseEntity.ok(res);
    }
}
