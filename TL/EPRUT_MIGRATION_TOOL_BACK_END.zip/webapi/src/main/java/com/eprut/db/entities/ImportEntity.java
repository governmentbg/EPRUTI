package com.eprut.db.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "import", schema = "staging")
@Data
@EntityListeners(AuditingEntityListener.class)
public class ImportEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "user_id", nullable = false)
    @CreatedBy
    private String userId;

    @Column(name = "upload_date", nullable = false)
    @CreatedDate
    private Instant uploadDate;

    @Column(name = "status_id", nullable = false)
    private Long statusId;

    @Column(name = "filename", nullable = false)
    private String filename;

    @Column(name = "file_id", nullable = false)
    private Long fileId;

    @Column(name = "register_code", length = 20, nullable = false)
    private String registerCode;

    @Column(name = "file_signature_id", nullable = false)
    private Long fileSignatureId;

    @Column(name = "trace_id", nullable = false)
    private UUID traceId;

    @Column(name = "fatal_stacktrace")
    private String fatalStackTrace;

    @Column(name = "uploader_ip", nullable = false)
    private String uploaderIp;

    @Column(name = "server_identifier")
    private String serverIdentifier;

    @Column(name = "import_type", nullable = false)
    private String importType;

    @Version
    @Column(name = "version", columnDefinition = "integer default 0", nullable = false)
    private int version;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "status_id", insertable = false, updatable = false)
    private NImportStatusEntity status;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "file_id", insertable = false, updatable = false)
    private ImportFilesEntity file;
}
