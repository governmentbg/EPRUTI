package com.eprut.services;

import com.eprut.db.views.VersionResponse;

public interface SysVersionService {

    /**
     * Връща текущата версия на системата.
     * @return String
     */
    VersionResponse getVersion();
}
