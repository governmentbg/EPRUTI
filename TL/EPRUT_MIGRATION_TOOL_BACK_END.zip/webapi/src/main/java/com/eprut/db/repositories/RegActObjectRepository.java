package com.eprut.db.repositories;

import com.eprut.db.entities.RegActObjectEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface RegActObjectRepository extends JpaRepository<RegActObjectEntity, Long> {

    /**
     * Връща броя на обектите за конкретен импорт.
     * @param impId
     * @return Long
     */
    @Query("""
        select count(rao)
        from RegActObjectEntity rao
        where rao.impId = :impId and rao.isValid = true
    """)
    Long countObjectsByImportId(@Param("impId") Long impId);
}
