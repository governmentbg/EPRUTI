package com.eprut.services.impl;

import com.eprut.config.CustomLocaleResolver;
import com.eprut.db.entities.VNRegActEntity;
import com.eprut.db.entities.VRegisterEntity;
import com.eprut.db.repositories.RegActTypesRepository;
import com.eprut.db.repositories.RegisterRepository;
import com.eprut.db.views.out.RegActOutView;
import com.eprut.exceptions.RegisterTypeNotFoundException;
import com.eprut.services.RegisterActTypeLoaderService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

@Service
@Slf4j
public class RegisterActTypeLoaderServiceImpl implements RegisterActTypeLoaderService {

    @Autowired
    private RegActTypesRepository regActTypesRepository;

    @Autowired
    private RegisterRepository registerRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private CustomLocaleResolver customLocaleResolver;

    @Autowired
    private HttpServletRequest httpServletRequest;

    @Override
    public List<RegActOutView> getAllActTypesForRegister(String registerCode, Locale locale)
            throws RegisterTypeNotFoundException {
        String logId = UUID.randomUUID().toString();
        String language = locale.getLanguage();
        log.info("{}: getAllActTypesForRegister started", logId);
        log.debug("{}: locale: {} language: {}", logId, locale, language);
        try {
            VRegisterEntity register = registerRepository.findByCode(registerCode, language)
                    .orElseThrow(() -> new RegisterTypeNotFoundException("Register with code: " + registerCode + " not found."));
            List<VNRegActEntity> vnRegActEntities = regActTypesRepository.findAllByRegisterCodeAndLocale(registerCode, language);
            List<RegActOutView> res = modelMapper.map(vnRegActEntities, new TypeToken<List<RegActOutView>>() {
            }.getType());
            log.info("{}: successfully retrieved {} vnRegActEntities", logId, vnRegActEntities.size());
            return res;
        } catch (Exception e) {
            log.error("{}: getAllActTypesForRegister error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: getAllActTypesForRegister finished", logId);
        }
    }
}
