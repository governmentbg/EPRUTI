package com.eprut.db.repositories;

import com.eprut.db.entities.VNRegActEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RegActTypesRepository extends JpaRepository<VNRegActEntity, Long> {

    /**
     * Намира и връща списък на всички типове актове, които се отнасят към конкретен регистър.
     * Връщат се резултатите за текущата локализация.
     * @param registerCode
     * @param langCode
     * @return List<VNRegActEntity>
     */
    @Query("""
        select vnra
        from VNRegActRegEntity vnrar join VNRegActEntity vnra on vnrar.regActCode = vnra.code
        where vnrar.regCode = :registerCode and vnra.langCode = :langCode
    """)
    List<VNRegActEntity> findAllByRegisterCodeAndLocale(@Param("registerCode") String registerCode, @Param("langCode") String langCode);
}