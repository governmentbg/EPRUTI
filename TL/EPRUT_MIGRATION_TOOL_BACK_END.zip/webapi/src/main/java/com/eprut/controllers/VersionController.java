package com.eprut.controllers;

import com.eprut.db.views.VersionResponse;
import com.eprut.services.SysVersionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/sys-version")
public class VersionController {

    @Autowired
    private SysVersionService sysVersionService;

    /**
     * Връща текущата версия на системата.
     * @return ResponseEntity<VersionResponse>
     */
    @GetMapping("")
    public ResponseEntity<VersionResponse> getVersion() {
        VersionResponse res = sysVersionService.getVersion();
        return ResponseEntity.ok(res);
    }
}
