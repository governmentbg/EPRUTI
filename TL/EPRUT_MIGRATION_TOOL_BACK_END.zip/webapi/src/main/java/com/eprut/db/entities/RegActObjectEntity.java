package com.eprut.db.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "reg_actobject", schema = "staging")
@Data
public class RegActObjectEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "imp_id", nullable = false)
    private Long impId;

    @Column(name = "op_id")
    private Long opId;

    @Column(name = "reg_act_id", nullable = false)
    private Long regActId;

    @Column(name = "cadastre", length = 200)
    private String cadastre;

    @Column(name = "local_place", length = 1000)
    private String localPlace;

    @Column(name = "regulation_district", length = 100)
    private String regulationDistrict;

    @Column(name = "upi", length = 50)
    private String upi;

    @Column(name = "plan_region", length = 500)
    private String planRegion;

    @Column(name = "plan_number", length = 500)
    private String planNumber;

    @Column(name = "kvs_territory", length = 500)
    private String kvsTerritory;

    @Column(name = "kvs_number", length = 500)
    private String kvsNumber;

    //todo името на колоната е сгрешено в базата
    @Column(name = "teritory_type", length = 50)
    private String territoryType;

    //todo името на колоната е сгрешено в базата
    @Column(name = "protected_teritory", length = 2000)
    private String protectedTerritory;

    @Column(name = "description", length = 1000)
    private String description;

    //todo името на колоната е сгрешено в базата
    @Column(name = "adress_id", nullable = false)
    private Long addressId;

    @Column(name = "is_valid", nullable = false)
    private Boolean isValid;
}
