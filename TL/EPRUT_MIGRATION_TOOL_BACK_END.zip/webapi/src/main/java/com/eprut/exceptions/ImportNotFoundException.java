package com.eprut.exceptions;

public class ImportNotFoundException extends BaseException {

    public static final int STATUS = 404;
    private static final String EXP = "IMPORT.NOT.FOUND";

    @Override
    public int getStatus() {
        return STATUS;
    }

    public ImportNotFoundException() {
        super(EXP);
    }

    public ImportNotFoundException(String message) {
        super(EXP, message);
    }

    public ImportNotFoundException(String message, Throwable cause) {
        super(EXP, message, cause);
    }

    public ImportNotFoundException(Throwable cause) {
        super(EXP, cause);
    }

    public ImportNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(EXP, message, cause, enableSuppression, writableStackTrace);
    }
}
