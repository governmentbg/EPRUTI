package com.eprut.controllers;

import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;
import com.eprut.services.ImportErrorsRetrievalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@RestController
@RequestMapping("/import/registers/import-file")
public class ImportErrorsRetrievalController {

    @Autowired
    private ImportErrorsRetrievalService importErrorsRetrievalService;

    /**
     * Извлича всички грешки за конкретен импорт и връща CSV файл с подробната информация.
     *
     * @param registerCode
     * @param importId
     * @return ResponseEntity<byte[]>
     * @throws IOException
     */
    @GetMapping("/{registerCode}/details/{importId}/import-errors")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<byte[]> downloadCSVforImportErrors(@PathVariable("registerCode") String registerCode,
                                                             @PathVariable("importId") Long importId)
            throws IOException, ImportNotFoundException, UnauthorizedAccessException {
        byte[] csvBytes = importErrorsRetrievalService.generateCSVforImportErrors(registerCode, importId);
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String filename = String.format("import_errors_%s_%s_%s.csv", registerCode, importId, timestamp);
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("text/csv"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .body(csvBytes);
    }
}
