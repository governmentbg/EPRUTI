package com.eprut.services;

import com.eprut.db.views.ImportJournalPageableView;
import com.eprut.db.views.out.ImportLogOutView;
import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;
import org.springframework.data.domain.Pageable;

import java.io.IOException;

public interface ImportJournalRetrievalService {

    /**
     * Генериране на CSV файл, който съдържа журнала за конкретен импорт.
     * @param importId
     * @return byte[]
     */
    byte[] generateCSVforImportJournal(String registerCode, Long importId)
            throws IOException, ImportNotFoundException, UnauthorizedAccessException;

    /**
     * Връща странициран журнал за конкретен импорт.
     * @param importId
     * @return ImportJournalPageableView<ImportLogOutView>
     */
    ImportJournalPageableView<ImportLogOutView> loadImportJournalByImportId(String registerCode, Long importId, Pageable pageable)
            throws ImportNotFoundException, UnauthorizedAccessException;
}
