package com.eprut.config;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.i18n.AcceptHeaderLocaleResolver;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

@Configuration
public class CustomLocaleResolver extends AcceptHeaderLocaleResolver {

    private static final List<Locale> LOCALES = Arrays.asList(
            Locale.ENGLISH,
            Locale.of("bg"));

    @Override
    public Locale resolveLocale(HttpServletRequest request) {
        String headerLanguage = request.getHeader("Accept-Language");
        return headerLanguage == null || headerLanguage.isEmpty() ? Locale.getDefault() : Locale.lookup(Locale.LanguageRange.parse(headerLanguage), LOCALES);
    }
}
