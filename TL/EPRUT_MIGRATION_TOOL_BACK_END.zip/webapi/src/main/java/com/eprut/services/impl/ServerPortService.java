package com.eprut.services.impl;

import lombok.Getter;
import org.springframework.boot.web.servlet.context.ServletWebServerInitializedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.net.InetAddress;
import java.net.UnknownHostException;

@Service
@Getter
public class ServerPortService {
    private int port;

    private String ip;

    private String signature;

    /**
     * Gets the current port in the initialization step.
     *
     * @param event the event;
     */
    @EventListener
    public void onApplicationEvent(final ServletWebServerInitializedEvent event) throws UnknownHostException {
        port = event.getWebServer().getPort();
        ip = InetAddress.getLocalHost().getHostAddress();
        signature = ip + ":" + port;
    }
}
