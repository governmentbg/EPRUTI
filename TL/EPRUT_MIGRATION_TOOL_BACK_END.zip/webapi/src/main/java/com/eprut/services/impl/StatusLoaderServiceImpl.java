package com.eprut.services.impl;

import com.eprut.db.entities.NImportStatusEntity;
import com.eprut.db.repositories.ImportStatusRepository;
import com.eprut.services.StatusLoaderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@Slf4j
public class StatusLoaderServiceImpl implements StatusLoaderService {

    @Autowired
    private ImportStatusRepository importStatusRepository;

    @Override
    public List<NImportStatusEntity> getAllStatuses() {
        String logId = UUID.randomUUID().toString();
        log.info("{}: getAllStatuses", logId);
        try {
            List<NImportStatusEntity> statuses = importStatusRepository.findAll();
            log.info("{}: successfully loaded {} statuses", logId, statuses.size());
            return statuses;
        } catch (Exception e) {
            log.error("{}: getAllStatuses error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: getAllStatuses finished", logId);
        }
    }
}
