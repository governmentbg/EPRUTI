package com.eprut.db.repositories;

import com.eprut.db.entities.ImportFilesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ImportFilesRepository extends JpaRepository<ImportFilesEntity, Long> {


}
