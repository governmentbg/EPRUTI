package com.eprut.db.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

import java.time.Instant;

@Entity
@Table(name = "v_import", schema = "staging")
@Data
public class VImportEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private String userId;

    @Column(name = "upload_date", nullable = false)
    private Instant uploadDate;

    @Column(name = "filename", nullable = false)
    private String filename;

    @Column(name = "status_id", nullable = false)
    private Long statusId;

    @Column(name = "status_code", nullable = false)
    private String statusCode;

    @Column(name = "status_description", nullable = false)
    private String statusDescription;

    @Column(name = "register_code", nullable = false)
    private String registerCode;

    @Column(name = "register_description", nullable = false)
    private String registerDescription;
}
