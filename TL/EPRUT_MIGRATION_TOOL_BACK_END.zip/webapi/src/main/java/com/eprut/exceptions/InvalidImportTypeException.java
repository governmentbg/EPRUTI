package com.eprut.exceptions;

public class InvalidImportTypeException extends BaseException {

    public static final int STATUS = 400;
    private static final String EXP = "INVALID.IMPORT.TYPE";

    @Override
    public int getStatus() {
        return STATUS;
    }

    public InvalidImportTypeException() {
        super(EXP);
    }

    public InvalidImportTypeException(String message) {
        super(EXP, message);
    }

    public InvalidImportTypeException(String message, Throwable cause) {
        super(EXP, message, cause);
    }

    public InvalidImportTypeException(Throwable cause) {
        super(EXP, cause);
    }

    public InvalidImportTypeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(EXP, message, cause, enableSuppression, writableStackTrace);
    }
}
