package com.eprut.services.impl;

import com.eprut.beans.IdentityServerModel;
import com.eprut.services.IdentityServerService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class IdentityServerServiceImpl implements IdentityServerService {


    @Value("${identityserver.userinfo.endpoint.url:parameter is not set}")
    private String identityServerUserInfoEndpointUrl;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        List<String> authorities = new ArrayList<>();
        authorities.add("DEFAULT_ROLE");
        return new IdentityServerModel(UUID.randomUUID().toString(), String.valueOf(username.hashCode()), username, authorities);
    }
}
