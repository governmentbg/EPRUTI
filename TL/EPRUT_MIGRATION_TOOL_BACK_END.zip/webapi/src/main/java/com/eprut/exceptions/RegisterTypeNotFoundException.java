package com.eprut.exceptions;

public class RegisterTypeNotFoundException extends BaseException {
  public static final int STATUS = 404;
  private static final String EXP = "REGISTER.NOT.FOUND";

  @Override
  public int getStatus() {
    return STATUS;
  }

  public RegisterTypeNotFoundException() {
    super(EXP);
  }

  public RegisterTypeNotFoundException(String message) {
    super(EXP, message);
  }

  public RegisterTypeNotFoundException(String message, Throwable cause) {
    super(EXP, message, cause);
  }

  public RegisterTypeNotFoundException(Throwable cause) {
    super(EXP, cause);
  }

  public RegisterTypeNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(EXP, message, cause, enableSuppression, writableStackTrace);
  }
}
