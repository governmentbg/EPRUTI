package com.eprut.controllers;

import com.eprut.db.views.out.FileImportStateOutView;
import com.eprut.exceptions.InvalidImportTypeException;
import com.eprut.exceptions.InvalidZipStructureException;
import com.eprut.exceptions.StatusNotFoundException;
import com.eprut.services.FileImportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

@RestController
@RequestMapping("/import/registers/import-file")
public class FileImportController {

    @Autowired
    private FileImportService fileImportService;

    /**
     * Връща информация за файла, който се качва. - id, status и userId.
     * @param registerCode
     * @param file
     * @return FileImportStateOutView
     * @throws IOException
     * @throws NoSuchAlgorithmException
     */
    @PostMapping(value = "/{registerCode}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<FileImportStateOutView> uploadFile(@PathVariable("registerCode") String registerCode,
                                                             @RequestParam("file") MultipartFile file)
            throws IOException, NoSuchAlgorithmException, InvalidZipStructureException, InvalidImportTypeException,
            StatusNotFoundException {
        FileImportStateOutView res = fileImportService.uploadFile(registerCode, file);
        return ResponseEntity.ok(res);
    }
}
