package com.eprut.services.impl;

import com.eprut.db.views.VersionResponse;
import com.eprut.services.SysVersionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SysVersionServiceImpl implements SysVersionService {

    @Value("${project.version:no_version}")
    private String version;

    @Override
    public VersionResponse getVersion() {
        return new VersionResponse(version);
    }
}
