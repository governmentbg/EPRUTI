package com.eprut.controllers;

import com.eprut.db.views.BasicPageableView;
import com.eprut.db.views.out.ImportOutView;
import com.eprut.exceptions.RegisterTypeNotFoundException;
import com.eprut.services.FilterImportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.Locale;

@RestController
@RequestMapping("/import/registers/import-file")
public class FilterImportController {

    @Autowired
    private FilterImportService filterImportService;


    /**
     * Връща обекти от тип ImportOutView в странициран вид. Връща всички импорти, които отговарят на подадени критерии.
     *
     * @param registerCode
     * @param startDate
     * @param endDate
     * @param statusCode
     * @param pageable
     * @return ResponseEntity<BasicPageableView<ImportOutView>>
     */
    @GetMapping("/{registerCode}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<BasicPageableView<ImportOutView>> findAllImportsByRegisterTypeAndCurrentUser(@PathVariable("registerCode") String registerCode,
                                                                                                       @RequestParam(value = "startDate", required = false)
                                                                                                       @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant startDate,
                                                                                                       @RequestParam(value = "endDate", required = false)
                                                                                                       @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant endDate,
                                                                                                       @RequestParam(value = "statusCode", required = false) String statusCode,
                                                                                                       @PageableDefault Pageable pageable)
            throws RegisterTypeNotFoundException {
        Locale locale = LocaleContextHolder.getLocale();
        BasicPageableView<ImportOutView> res = filterImportService.findAllImportsByRegisterTypeAndCurrentUser(registerCode, locale, startDate, endDate, statusCode, pageable);
        return ResponseEntity.ok(res);
    }
}
