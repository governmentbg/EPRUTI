package com.eprut.beans;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.time.Instant;

@Data
public class ErrorModel {


    @JsonProperty("uuid")
    private String uuid;
    @JsonProperty("message")
    private String message;
    @JsonProperty("systemMessage")
    private String systemMessage;
    @JsonProperty("dateTime")
    private Instant dateTime;
    @JsonProperty("method")
    private String method;
    @JsonProperty("path")
    private String path;
}
