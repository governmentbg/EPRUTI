package com.eprut.controllers;

import com.eprut.db.views.out.RegActOutView;
import com.eprut.exceptions.RegisterTypeNotFoundException;
import com.eprut.services.RegisterActTypeLoaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Locale;

@RestController
@RequestMapping("/import/registers")
public class RegisterActTypeLoaderController {

    @Autowired
    private RegisterActTypeLoaderService registerActTypeLoaderService;

    /**
     * Намира и връща списък на всички типове актове, които се отнасят към конкретен регистър.
     * Връщат се резултатите за текущата локализация.
     * @param registerCode
     * @return ResponseEntity<List<RegActOutView>>
     */
    @GetMapping("/{registerCode}/info")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<RegActOutView>> getAllActTypesForRegister(@PathVariable("registerCode") String registerCode)
            throws RegisterTypeNotFoundException {
        Locale locale = LocaleContextHolder.getLocale();
        List<RegActOutView> res = registerActTypeLoaderService.getAllActTypesForRegister(registerCode, locale);
        return ResponseEntity.ok(res);
    }
}
