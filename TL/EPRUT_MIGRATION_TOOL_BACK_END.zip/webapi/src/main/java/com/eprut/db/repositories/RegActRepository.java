package com.eprut.db.repositories;

import com.eprut.db.entities.RegActEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface RegActRepository extends JpaRepository<RegActEntity, Long> {

    /**
     * Връща броя на актовете за конкретен импорт.
     * @param impId
     * @return Long
     */
    @Query("""
        select count(ra)
        from RegActEntity ra
        where ra.impId = :impId and ra.isValid = true
    """)
    Long countActsByImportId(@Param("impId") Long impId);
}
