package com.eprut.db.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Table(name = "reg_act", schema = "staging")
@Data
public class RegActEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "imp_id", nullable = false)
    private Long impId;

    @Column(name = "op_id")
    private Long opId;

    @Column(name = "number", length = 50, nullable = false)
    private String number;

    @Column(name = "type", length = 50, nullable = false)
    private String type;

    @Column(name = "act_date", nullable = false)
    private LocalDateTime actDate;

    @Column(name = "message_date")
    private LocalDateTime messageDate;

    @Column(name = "message_type", length = 50)
    private String messageType;

    @Column(name = "issued_date")
    private LocalDateTime issuedDate;

    @Column(name = "status", length = 50, nullable = false)
    private String status;

    @Column(name = "change_date")
    private LocalDateTime changeDate;

    @Column(name = "validity_date", nullable = false)
    private LocalDateTime validityDate;

    @Column(name = "fact_reason")
    private String factReason;

    @Column(name = "legal_reason")
    private String legalReason;

    @Column(name = "administration", length = 50, nullable = false)
    private String administration;

    @Column(name = "administrative_unit", length = 50, nullable = false)
    private String administrativeUnit;

    @Column(name = "adm_popular", length = 50, nullable = false)
    private String admPopular;

    @Column(name = "object_identification", length = 512)
    private String objectIdentification;

    @Column(name = "is_valid", nullable = false)
    private Boolean isValid;
}
