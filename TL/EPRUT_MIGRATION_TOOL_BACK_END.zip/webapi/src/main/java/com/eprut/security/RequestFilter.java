package com.eprut.security;


import com.eprut.beans.IdentityServerModel;
import com.eprut.exceptions.AuthenticationException;
import com.eprut.services.IdentityServerService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;


@Component
@Order(1)
public class RequestFilter extends OncePerRequestFilter {

    private static final String TOKEN_HEADER = "Authorization";
    private static final String TOKEN_PREFIX = "Bearer ";

    private final IdentityServerService identityServerService;

    /**
     * This is the constructor for the request filter.
     *
     * @param identityServerService identity service for extracting info from token. Oauth.
     */
    @Autowired
    public RequestFilter(IdentityServerService identityServerService) {
        this.identityServerService = identityServerService;
    }

    @SneakyThrows
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
        AbstractAuthenticationToken authentication = null;
        try {
            authentication = getAuthentication(request);
        } catch (Exception e) {
            logger.error("TOKEN ERROR: token:", e);
            throw new AuthenticationException();
        }
        SecurityContextHolder.getContext().setAuthentication(authentication);
        filterChain.doFilter(request, response);
    }

    private AbstractAuthenticationToken getAuthentication(HttpServletRequest request) throws Exception {
        String token = request.getHeader(TOKEN_HEADER);
        IdentityServerModel userDetails;
        if (StringUtils.hasText(token) && token.startsWith(TOKEN_PREFIX)) {
            String accessToken = token.replace(TOKEN_PREFIX, "");
            if (StringUtils.hasText(token)) {
                userDetails = (IdentityServerModel) this.identityServerService.loadUserByUsername(accessToken);
                request.setAttribute("uuid", userDetails.getRequestId());
                return new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
            }
        }
//        userDetails = new IdentityServerModel(UUID.randomUUID().toString(), (long) "anon_user".hashCode(), "anon_user", List.of("ANONYMOUS_ROLE"));
//        request.setAttribute("uuid", userDetails.getRequestId());
//        return new AnonymousAuthenticationToken(
//                userDetails.getRequestId(),
//                userDetails,
//                userDetails.getAuthorities()
//        );
        return null;
    }
}
