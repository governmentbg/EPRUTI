package com.eprut.exceptions;

public class StatusNotFoundException extends BaseException {

    public static final int STATUS = 404;
    private static final String EXP = "STATUS.NOT.FOUND";

    @Override
    public int getStatus() {
        return STATUS;
    }

    public StatusNotFoundException() {
        super(EXP);
    }

    public StatusNotFoundException(String message) {
        super(EXP, message);
    }

    public StatusNotFoundException(String message, Throwable cause) {
        super(EXP, message, cause);
    }

    public StatusNotFoundException(Throwable cause) {
        super(EXP, cause);
    }

    public StatusNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(EXP, message, cause, enableSuppression, writableStackTrace);
    }
}
