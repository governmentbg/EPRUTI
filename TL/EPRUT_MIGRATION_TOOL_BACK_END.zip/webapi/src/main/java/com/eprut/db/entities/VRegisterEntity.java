package com.eprut.db.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "v_n_registers", schema = "staging")
@Data
public class VRegisterEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private short id;

    @Column(name = "lang_code", length = 20, nullable = false)
    private String langCode;

    @Column(name = "code", length = 20, nullable = false)
    private String code;

    @Column(name = "description", length = 200, nullable = false)
    private String description;
}
