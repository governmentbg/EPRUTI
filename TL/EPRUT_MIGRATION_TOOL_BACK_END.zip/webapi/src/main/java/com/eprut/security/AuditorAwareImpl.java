package com.eprut.security;

import com.eprut.beans.IdentityServerModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;

@EnableJpaAuditing(modifyOnCreate = false, auditorAwareRef = "auditorProvider")
@Configuration
@Slf4j
public class AuditorAwareImpl implements AuditorAware<String> {

    /**
     * Provides AuditAware implementation.
     *
     * @return AuditorAware;
     */
    @Bean
    public AuditorAware<String> auditorProvider() {
        return new AuditorAwareImpl();
    }

    @Override
    public Optional<String> getCurrentAuditor() {
        try {
            if (SecurityContextHolder.getContext().getAuthentication() == null) {
                return Optional.empty();
            }
            IdentityServerModel p = (IdentityServerModel) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            return Optional.of(p.getId());

        } catch (Exception e) {
            log.error("Error while getting user for audit log!!!", e);
        }
        return Optional.empty();
    }
}
