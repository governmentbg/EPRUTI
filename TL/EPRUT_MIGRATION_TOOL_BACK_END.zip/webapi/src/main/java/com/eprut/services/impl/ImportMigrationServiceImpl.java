package com.eprut.services.impl;

import com.eprut.beans.IdentityServerModel;
import com.eprut.db.entities.ImportEntity;
import com.eprut.db.entities.NImportStatusEntity;
import com.eprut.db.repositories.ImportRepository;
import com.eprut.db.repositories.ImportStatusRepository;
import com.eprut.db.views.out.ImportMigrationStateOutView;
import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.StatusNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;
import com.eprut.services.ImportMigrationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.UUID;

@Service
@Slf4j
public class ImportMigrationServiceImpl implements ImportMigrationService {

    private static final String MIGRATION_STATUS = "TRANSFER_ACCEPTED";

    @Autowired
    private ImportRepository importRepository;

    @Autowired
    private ImportStatusRepository importStatusRepository;

    @Override
    public ImportMigrationStateOutView startImportMigration(String registerCode, Long importId)
            throws ImportNotFoundException, StatusNotFoundException, UnauthorizedAccessException {
        String logId = UUID.randomUUID().toString();
        log.info("{}: startImportMigration started", logId);
        log.debug("{}: params: registerCode: {}", logId, registerCode);
        log.debug("{}: params: importId: {}", logId, importId);
        try {
            IdentityServerModel principal = (IdentityServerModel) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            ImportEntity imp = importRepository.findByRegisterCodeAndImportId(registerCode, importId)
                    .orElseThrow(() -> new ImportNotFoundException("Import with id: " + importId + " and register code: " + registerCode + " not found."));

            if (!Objects.equals(imp.getUserId(), principal.getId())) {
                throw new UnauthorizedAccessException("User with id: " + principal.getId() + " is not authorized to perform this action.");
            }

            NImportStatusEntity status = importStatusRepository.findByStatusCode(MIGRATION_STATUS)
                    .orElseThrow(() -> new StatusNotFoundException("Status with code: " + MIGRATION_STATUS + " not found."));

            imp.setStatusId(status.getId());
            importRepository.save(imp);

            ImportMigrationStateOutView importMigrationStateOutView = new ImportMigrationStateOutView();
            importMigrationStateOutView.setId(imp.getId());
            importMigrationStateOutView.setStatusId(imp.getStatusId());
            importMigrationStateOutView.setStatusCode(MIGRATION_STATUS);

            return importMigrationStateOutView;
        } catch (Exception e) {
            log.error("{}: startImportMigration error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: startImportMigration finished", logId);
        }
    }
}
