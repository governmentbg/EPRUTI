package com.eprut.services.impl;

import com.eprut.beans.IdentityServerModel;
import com.eprut.db.entities.ImportEntity;
import com.eprut.db.entities.ImportLogEntity;
import com.eprut.db.repositories.ImportLogsRepository;
import com.eprut.db.repositories.ImportRepository;
import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;
import com.eprut.services.ImportErrorsRetrievalService;
import com.opencsv.CSVWriter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Service
@Slf4j
public class ImportErrorsRetrievalServiceImpl implements ImportErrorsRetrievalService {

    @Autowired
    private ImportLogsRepository importLogsRepository;

    @Autowired
    private ImportRepository importRepository;

    @Override
    public byte[] generateCSVforImportErrors(String registerCode, Long importId)
            throws IOException, ImportNotFoundException, UnauthorizedAccessException {
        String logId = UUID.randomUUID().toString();
        log.info("{}: generateCSVforImportErrors started", logId);
        log.debug("{}: params: importId {}", logId, importId);
        try {
            IdentityServerModel principal = (IdentityServerModel) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            ImportEntity imp = importRepository.findByRegisterCodeAndImportId(registerCode, importId)
                    .orElseThrow(() -> new ImportNotFoundException("Import with id: " + importId + " and register code: " + registerCode + " not found."));

            if (!Objects.equals(imp.getUserId(), principal.getId())) {
                throw new UnauthorizedAccessException("User with id: " + principal.getId() + " is not authorized to perform this action.");
            }

            List<ImportLogEntity> errors = importLogsRepository.findImportErrorsByImportId(importId);

            StringWriter writer = new StringWriter();
            log.info("{}: generating csv file started", logId);
            writer.write("\uFEFF");
            try (CSVWriter csvWriter = new CSVWriter(writer, ',', CSVWriter.NO_QUOTE_CHARACTER, CSVWriter.DEFAULT_ESCAPE_CHARACTER, "\n")) {
                String[] header = {"Date added", "Message type", "Message"};
                csvWriter.writeNext(header);
                for (ImportLogEntity error : errors) {
                    String[] row = {
                            error.getDateAdded().toString(),
                            error.getMsgType().getDescription(),
                            error.getMsg()
                    };
                    csvWriter.writeNext(row);
                }
            } catch (Exception e) {
                log.error("{}: error generating csv file: {}", logId, e.getMessage(), e);
                throw e;
            } finally {
                log.info("{}: generating csv file finished", logId);
            }
            return writer.toString().getBytes(StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.error("{}: generateCSVforImportErrors error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: generateCSVforImportErrors finished", logId);
        }
    }
}
