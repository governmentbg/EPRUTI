package com.eprut.db.views;

import lombok.Getter;
import org.springframework.data.domain.Pageable;

import java.util.List;

@Getter
public class BasicPageableView<T> {

    private final List<T> content;
    private final int size;
    private final int pageNumber;
    private final long totalElements;

    /**
     * Create of pageable basic view.
     *
     * @param content
     * @param pageable
     * @param totalElements
     */
    public BasicPageableView(List<T> content, Pageable pageable, long totalElements) {
        this.content = content;
        this.size = pageable.getPageSize();
        this.pageNumber = pageable.getPageNumber();
        this.totalElements = totalElements;
    }
}
