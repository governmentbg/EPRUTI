package com.eprut.controllers;

import com.eprut.db.views.out.ImportMigrationStateOutView;
import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.StatusNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;
import com.eprut.services.ImportMigrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/import/registers/import-file")
public class ImportMigrationController {

    @Autowired
    private ImportMigrationService importMigrationService;

    /**
     * Стартира миграция на конкретен импорт.
     * @param registerCode
     * @param importId
     * @return ResponseEntity<ImportMigrationStateOutView>
     * @throws ImportNotFoundException
     * @throws StatusNotFoundException
     */
    @PostMapping("/{registerCode}/details/{importId}/import-migration")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ImportMigrationStateOutView> startImportMigration(@PathVariable("registerCode") String registerCode,
                                                                            @PathVariable("importId") Long importId)
            throws ImportNotFoundException, StatusNotFoundException, UnauthorizedAccessException {
        ImportMigrationStateOutView res = importMigrationService.startImportMigration(registerCode, importId);
        return ResponseEntity.ok(res);
    }
}
