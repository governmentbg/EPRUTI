package com.eprut.exceptions;

public class InvalidZipStructureException extends BaseException {
    public static final int STATUS = 400;
    private static final String EXP = "INVALID.ZIP.STRUCTURE";

    @Override
    public int getStatus() {
        return STATUS;
    }

    public InvalidZipStructureException() {
        super(EXP);
    }

    public InvalidZipStructureException(String message) {
        super(EXP, message);
    }

    public InvalidZipStructureException(String message, Throwable cause) {
        super(EXP, message, cause);
    }

    public InvalidZipStructureException(Throwable cause) {
        super(EXP, cause);
    }

    public InvalidZipStructureException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(EXP, message, cause, enableSuppression, writableStackTrace);
    }
}
