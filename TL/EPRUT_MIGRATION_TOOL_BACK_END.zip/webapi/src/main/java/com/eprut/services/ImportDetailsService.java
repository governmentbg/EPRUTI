package com.eprut.services;

import com.eprut.db.views.out.ImportDetailsOutView;
import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;

public interface ImportDetailsService {

    /**
     * Връща детайлна информация за конкретен импорт.
     * @param registerCode
     * @param importId
     * @return ImportDetailsOutView
     */
    ImportDetailsOutView getImportDetails(String registerCode, Long importId)
            throws ImportNotFoundException, UnauthorizedAccessException;
}
