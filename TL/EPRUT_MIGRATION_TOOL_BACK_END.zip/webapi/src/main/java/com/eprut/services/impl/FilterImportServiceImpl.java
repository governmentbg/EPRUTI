package com.eprut.services.impl;

import com.eprut.beans.IdentityServerModel;
import com.eprut.db.entities.VImportEntity;
import com.eprut.db.repositories.ImportRepository;
import com.eprut.db.repositories.RegisterRepository;
import com.eprut.db.views.BasicPageableView;
import com.eprut.db.views.out.ImportOutView;
import com.eprut.exceptions.RegisterTypeNotFoundException;
import com.eprut.services.FilterImportService;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

@Service
@Slf4j
public class FilterImportServiceImpl implements FilterImportService {

    @Autowired
    private ImportRepository importRepository;


    @Autowired
    private RegisterRepository registerRepository;


    @Autowired
    private ModelMapper modelMapper;

    @Override
    public BasicPageableView<ImportOutView> findAllImportsByRegisterTypeAndCurrentUser(String registerCode,
                                                                                       Locale locale,
                                                                                       Instant startDate,
                                                                                       Instant endDate,
                                                                                       String status,
                                                                                       Pageable pageable)
            throws SecurityException, RegisterTypeNotFoundException {
        String logId = UUID.randomUUID().toString();
        String language = locale.getLanguage();
        log.info("{}: findAllImportsByRegisterTypeAndCurrentUser started", logId);
        log.debug("{}: params: locale: {}", logId, locale);
        log.debug("{}: params: registerCode: {}", logId, registerCode);
        log.debug("{}: params: startDate: {}", logId, startDate);
        log.debug("{}: params: endDate: {}", logId, endDate);
        log.debug("{}: params: status: {}", logId, status);
        try {
            IdentityServerModel principal = (IdentityServerModel) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

            if (endDate != null) {
                endDate = endDate.plus(1, ChronoUnit.DAYS).minusNanos(1);
            }

            Page<VImportEntity> imports =
                    importRepository.findAllImportsByRegisterTypeAndCurrentUser(registerCode, principal.getId(), startDate, endDate,
                            status, pageable);

            if (imports.isEmpty()) {
                log.warn("{}: No imports found for registerCode {}", logId, registerCode);
                return new BasicPageableView<>(new ArrayList<>(), pageable, imports.getTotalElements());
            }

            List<ImportOutView> importList = modelMapper.map(imports.getContent(), new TypeToken<List<ImportOutView>>() {
            }.getType());

            BasicPageableView<ImportOutView> res = new BasicPageableView<>(importList, pageable, imports.getTotalElements());
            log.info("{}: successfully retrieved {} imports", logId, res.getTotalElements());
            return res;
        } catch (Exception e) {
            log.error("{}: findAllImportsByRegisterTypeAndCurrentUser error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: findAllImportsByRegisterTypeAndCurrentUser finished", logId);
        }
    }
}
