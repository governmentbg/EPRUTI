package com.eprut.db.repositories;

import com.eprut.db.entities.VRegisterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RegisterRepository extends JpaRepository<VRegisterEntity, Long> {

    /**
     * Намира всички регистри за даден езиков код.
     * @param langCode
     * @return List<VRegisterEntity>
     */
    @Query("""
        select r
        from VRegisterEntity r
        where r.langCode = :langCode
    """)
    List<VRegisterEntity> findAllByLangCode(@Param("langCode") String langCode);

    /**
     * Намира регистър по код.
     * @param code
     * @param langCode
     * @return VRegisterEntity
     */
    @Query("""
        select r
        from VRegisterEntity r
        where r.code = :code and r.langCode = :langCode
    """)
    Optional<VRegisterEntity> findByCode(@Param("code") String code, @Param("langCode") String langCode);
}
