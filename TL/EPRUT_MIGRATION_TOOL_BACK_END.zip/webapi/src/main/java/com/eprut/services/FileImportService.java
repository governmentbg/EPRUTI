package com.eprut.services;

import com.eprut.db.views.out.FileImportStateOutView;
import com.eprut.exceptions.InvalidImportTypeException;
import com.eprut.exceptions.InvalidZipStructureException;
import com.eprut.exceptions.StatusNotFoundException;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public interface FileImportService {

    /**
     * Обработва качването на файл за импорт за даден регистър.
     * Връща състоянието на операцията за импортиране.
     * @param registerCode
     * @param file
     * @return FileImportStateOutView
     * @throws IOException
     * @throws NoSuchAlgorithmException
     */
    FileImportStateOutView uploadFile(String registerCode, MultipartFile file)
            throws IOException, NoSuchAlgorithmException, InvalidZipStructureException, InvalidImportTypeException,
            StatusNotFoundException;
}
