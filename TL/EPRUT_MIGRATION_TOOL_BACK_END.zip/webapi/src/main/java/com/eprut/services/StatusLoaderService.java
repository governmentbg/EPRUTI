package com.eprut.services;

import com.eprut.db.entities.NImportStatusEntity;

import java.util.List;

public interface StatusLoaderService {

    /**
     * Намира и връща списък с всички статуси.
     * @return List<NImportStatusEntity>
     */
    List<NImportStatusEntity> getAllStatuses();
}
