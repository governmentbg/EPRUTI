package com.eprut.services;

import com.eprut.db.views.out.RegActOutView;
import com.eprut.exceptions.RegisterTypeNotFoundException;

import java.util.List;
import java.util.Locale;

public interface RegisterActTypeLoaderService {

    /**
     * Намира и връща списък на всички типове актове, които се отнасят към конкретен регистър.
     * Връщат се резултатите за текущата локализация.
     * @param registerCode
     * @param locale
     * @return List<RegActOutView>
     */
    List<RegActOutView> getAllActTypesForRegister(String registerCode, Locale locale)
            throws RegisterTypeNotFoundException;
}
