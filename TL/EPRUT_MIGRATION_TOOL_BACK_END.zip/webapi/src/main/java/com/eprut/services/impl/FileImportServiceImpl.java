package com.eprut.services.impl;

import com.eprut.db.entities.ImportEntity;
import com.eprut.db.entities.ImportFilesEntity;
import com.eprut.db.entities.NImportStatusEntity;
import com.eprut.db.repositories.ImportFilesRepository;
import com.eprut.db.repositories.ImportRepository;
import com.eprut.db.repositories.ImportStatusRepository;
import com.eprut.db.views.out.FileImportStateOutView;
import com.eprut.exceptions.InvalidImportTypeException;
import com.eprut.exceptions.InvalidZipStructureException;
import com.eprut.exceptions.StatusNotFoundException;
import com.eprut.services.FileImportService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.tika.Tika;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.system.ApplicationTemp;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.HexFormat;
import java.util.UUID;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

@Service
@Slf4j
public class FileImportServiceImpl implements FileImportService {

    private static final String ZIP_MIME_TYPE = "application/zip";
    private static final String XML_MIME_TYPE = "application/xml";
    private static final String XLSX_MIME_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    private static final String XLS_MIME_TYPE = "application/vnd.ms-excel";
    private static final String XML_UPLOAD_STATUS = "XML_UPLOADED";
    private static final String EXCEL_UPLOAD_STATUS = "EX_UPLOADED";
    private static final int DEFAULT_BUFFER_SIZE = 8192;

    @Autowired
    private ImportRepository importRepository;

    @Autowired
    private ImportFilesRepository importFilesRepository;

    @Autowired
    private ImportStatusRepository importStatusRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private HttpServletRequest request;

    @Value("${system.tmp.dir:}")
    private String tmpDir;

    private final ApplicationTemp appTemp;


    /**
     * Constructor.
     */
    public FileImportServiceImpl() {
        appTemp = new ApplicationTemp();
        if (tmpDir == null || tmpDir.isBlank()) {
            tmpDir = appTemp.getDir().getAbsolutePath();
        }
    }

    @Override
    @Transactional(readOnly = false)
    public FileImportStateOutView uploadFile(String registerCode, MultipartFile file)
            throws IOException, NoSuchAlgorithmException, InvalidZipStructureException, InvalidImportTypeException,
            StatusNotFoundException {
        String logId = UUID.randomUUID().toString();
        log.info("{}: uploadFile started", logId);
        log.debug("{}: params: registerCode: {}", logId, registerCode);
        log.debug("{}: params: file: {}", logId, file.getOriginalFilename());

        String userIp = request.getHeader("X-Forwarded-For");
        if (userIp == null) {
            userIp = request.getRemoteAddr();
        }
        try {
            File pathToFile = storeFileAndGetUrl(file);
            long fileSize = file.getSize();

            String fileType = null;
            String detectMimeType = null;
            NImportStatusEntity is = null;

            Tika tika = new Tika();

            try (FileInputStream fis = new FileInputStream(pathToFile)) {
                detectMimeType = tika.detect(fis);
                if (!ZIP_MIME_TYPE.equals(detectMimeType)) {
                    throw new InvalidImportTypeException(
                            "Unsupported MIME type: " + detectMimeType + ". Only ZIP files are supported.");
                }
            }

            try (FileInputStream fis = new FileInputStream(pathToFile);
                 ZipArchiveInputStream zis = new ZipArchiveInputStream(fis)) {

                ZipArchiveEntry entry;
                while ((entry = zis.getNextEntry()) != null) {
                    if (!entry.isDirectory()) {
                        String entryName = entry.getName();
                        if (entryName.contains("/") || entryName.contains("\\")) {
                            continue;
                        }

                        String mimeType = tika.detect(zis, entryName);

                        if (XML_MIME_TYPE.equals(mimeType)) {
                            fileType = "XML";
                            is = importStatusRepository.findByStatusCode(XML_UPLOAD_STATUS)
                                    .orElseThrow(() -> new StatusNotFoundException("Status with code: " + XML_UPLOAD_STATUS + " not found."));
                            break;
                        } else if (XLS_MIME_TYPE.equals(mimeType) || XLSX_MIME_TYPE.equals(mimeType)) {
                            fileType = "EXCEL";
                            is = importStatusRepository.findByStatusCode(EXCEL_UPLOAD_STATUS)
                                    .orElseThrow(() -> new StatusNotFoundException("Status with code: " + EXCEL_UPLOAD_STATUS + " not found."));
                            break;
                        }
                    }
                }
            }

            if (fileType == null) {
                throw new InvalidZipStructureException("The ZIP file does not contain a XML or EXCEL file at top level.");
            }

            byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (FileInputStream fis = new FileInputStream(pathToFile);
                 DigestInputStream digestInputStream = new DigestInputStream(fis, digest)) {
                while (digestInputStream.read(buffer) != -1) {
                }
            }

            String sha256 = HexFormat.of().formatHex(digest.digest());
            log.info("{}: file uploaded to {}", logId, pathToFile);

            ImportFilesEntity importFile = new ImportFilesEntity();
            importFile.setFilename(pathToFile.getName());
            importFile.setMimeType(detectMimeType);
            importFile.setSize(fileSize);
            importFile.setSha256(sha256);
            importFile.setUrl(pathToFile.getAbsolutePath());
            importFilesRepository.save(importFile);

            ImportEntity importEntity = new ImportEntity();
            importEntity.setUploadDate(Instant.now());
            importEntity.setStatusId(is.getId());
            importEntity.setFilename(importFile.getFilename());
            importEntity.setFileId(importFile.getId());
            importEntity.setRegisterCode(registerCode);
            //importEntity.setFileSignatureId(); //TODO
            importEntity.setTraceId(UUID.randomUUID());
            importEntity.setUploaderIp(userIp);
            importEntity.setImportType(fileType);
            importRepository.save(importEntity);

            return modelMapper.map(importEntity, FileImportStateOutView.class);
        } catch (Exception e) {
            log.error("{}: uploadFile error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: uploadFile finished", logId);
        }
    }

    private File storeFileAndGetUrl(MultipartFile file) throws IOException {
        Path targetLocation = Paths.get(tmpDir, UUID.randomUUID().toString(), file.getOriginalFilename());
        File f = new File(targetLocation.toAbsolutePath().toString());
        f.getParentFile().mkdirs();
        File currParent = f.getParentFile();
        while (currParent != null) {
            currParent.setReadable(true, false);
            currParent.setWritable(true, false);
            currParent.setExecutable(true, false);
            currParent = currParent.getParentFile();
        }
        try {
            f.createNewFile();
        } catch (IOException e) {
            //ignore
        }
        f.setReadable(true, false);
        f.setWritable(true, false);
        Files.copy(file.getInputStream(), targetLocation.toAbsolutePath(), REPLACE_EXISTING);
        return targetLocation.toAbsolutePath().toFile();
    }
}
