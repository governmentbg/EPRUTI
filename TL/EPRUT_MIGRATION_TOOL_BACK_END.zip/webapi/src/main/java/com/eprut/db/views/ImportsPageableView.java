package com.eprut.db.views;

import lombok.Getter;
import org.springframework.data.domain.Pageable;

import java.util.List;

@Getter
public class ImportsPageableView<T> {

    private final String registerDescription;
    private final List<T> content;
    private final int size;
    private final int pageNumber;
    private final long totalElements;

    /**
     * Create of import pageable view.
     * @param registerDescription
     * @param content
     * @param pageable
     * @param totalElements
     */
    public ImportsPageableView(String registerDescription, List<T> content, Pageable pageable, long totalElements) {
        this.registerDescription = registerDescription;
        this.content = content;
        this.size = pageable.getPageSize();
        this.pageNumber = pageable.getPageNumber();
        this.totalElements = totalElements;
    }
}
