package com.eprut.services.impl;

import com.eprut.config.CustomLocaleResolver;
import com.eprut.db.entities.VRegisterEntity;
import com.eprut.db.repositories.RegisterRepository;
import com.eprut.db.views.out.RegisterOutView;
import com.eprut.exceptions.RegisterTypeNotFoundException;
import com.eprut.services.RegisterLoaderService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

@Service
@Slf4j
public class RegisterLoaderServiceImpl implements RegisterLoaderService {

    @Autowired
    private RegisterRepository registerRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private CustomLocaleResolver customLocaleResolver;

    @Autowired
    private HttpServletRequest httpServletRequest;

    @Override
    public List<RegisterOutView> getAllRegistersForCurrentLocale(Locale locale) {
        String logId = UUID.randomUUID().toString();
        String language = locale.getLanguage();
        log.info("{}: getAllRegistersForCurrentLocale started", logId);
        log.debug("{}: locale: {} language: {}", logId, locale, language);
        try {
            List<VRegisterEntity> vRegisterEntities = registerRepository.findAllByLangCode(language);
            List<RegisterOutView> res = modelMapper.map(vRegisterEntities, new TypeToken<List<RegisterOutView>>() {
            }.getType());
            log.info("{}: successfully retrieved {} VRegisterEntities", logId, vRegisterEntities.size());
            return res;
        } catch (Exception e) {
            log.error("{}: getAllRegistersForCurrentLocale error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: getAllRegistersForCurrentLocale finished", logId);
        }
    }

    @Override
    public RegisterOutView getRegisterByCode(String registerCode, Locale locale) throws RegisterTypeNotFoundException {
        String logId = UUID.randomUUID().toString();
        String language = locale.getLanguage();
        log.info("{}: getRegisterByCode started", logId);
        log.debug("{}: registerCode: {}", logId, registerCode);
        log.debug("{}: locale: {} language: {}", logId, locale, language);
        try {
            VRegisterEntity register = registerRepository.findByCode(registerCode, language)
                    .orElseThrow(() -> new RegisterTypeNotFoundException("Register with code: " + registerCode + " not found."));
            RegisterOutView res = modelMapper.map(register, RegisterOutView.class);
            return res;
        } catch (Exception e) {
            log.error("{}: getRegisterByCode error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: getRegisterByCode finished", logId);
        }
    }
}
