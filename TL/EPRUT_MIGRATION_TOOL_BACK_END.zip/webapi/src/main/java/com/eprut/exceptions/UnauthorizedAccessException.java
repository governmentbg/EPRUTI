package com.eprut.exceptions;

public class UnauthorizedAccessException extends BaseException {
    public static final int STATUS = 401;
    private static final String EXP = "UNAUTHORIZED.ACCESS_DENIED";

    @Override
    public int getStatus() {
        return STATUS;
    }

    public UnauthorizedAccessException() {
        super(EXP);
    }

    public UnauthorizedAccessException(String message) {
        super(EXP, message);
    }

    public UnauthorizedAccessException(String message, Throwable cause) {
        super(EXP, message, cause);
    }

    public UnauthorizedAccessException(Throwable cause) {
        super(EXP, cause);
    }

    public UnauthorizedAccessException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(EXP, message, cause, enableSuppression, writableStackTrace);
    }
}
