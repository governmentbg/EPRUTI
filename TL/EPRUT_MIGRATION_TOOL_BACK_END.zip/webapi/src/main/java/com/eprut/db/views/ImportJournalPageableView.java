package com.eprut.db.views;

import lombok.Getter;
import org.springframework.data.domain.Pageable;

import java.util.List;

@Getter
public class ImportJournalPageableView<T> {
    private final String statusCode;
    private final Boolean isLast;
    private final List<T> content;
    private final int size;
    private final int pageNumber;
    private final long totalElements;

    /**
     * Create of import details pageable view.
     * @param statusCode
     * @param content
     * @param pageable
     * @param totalElements
     */
    public ImportJournalPageableView(String statusCode, Boolean isLast, List<T> content, Pageable pageable, long totalElements) {
        this.statusCode = statusCode;
        this.isLast = isLast;
        this.content = content;
        this.size = pageable.getPageSize();
        this.pageNumber = pageable.getPageNumber();
        this.totalElements = totalElements;
    }
}
