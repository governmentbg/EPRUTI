package com.eprut.exceptions;

public class AuthenticationException extends BaseException {

    public static final int STATUS = 401;
    private static final String EXP = "USER.NOT.AUTHENTICATED";

    @Override
    public int getStatus() {
        return STATUS;
    }

    public AuthenticationException() {
        super(EXP);
    }

    public AuthenticationException(String message) {
        super(EXP, message);
    }

    public AuthenticationException(String message, Throwable cause) {
        super(EXP, message, cause);
    }

    public AuthenticationException(Throwable cause) {
        super(EXP, cause);
    }

    public AuthenticationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(EXP, message, cause, enableSuppression, writableStackTrace);
    }
}
