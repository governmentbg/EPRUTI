//import com.eprut.db.entities.ImportEntity;
//import com.eprut.db.entities.ImportFilesEntity;
//import com.eprut.db.entities.NImportStatusEntity;
//import com.eprut.db.repositories.ImportFilesRepository;
//import com.eprut.db.repositories.ImportRepository;
//import com.eprut.db.repositories.ImportStatusRepository;
//import com.eprut.db.views.out.FileImportStateOutView;
//import com.eprut.exceptions.InvalidImportTypeException;
//import com.eprut.exceptions.InvalidZipContentException;
//import com.eprut.services.impl.FileImportServiceImpl;
//import jakarta.servlet.http.HttpServletRequest;
//import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
//import org.apache.tika.Tika;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockedStatic;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.modelmapper.ModelMapper;
//import org.springframework.boot.system.ApplicationTemp;
//import org.springframework.mock.web.MockMultipartFile;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContext;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.web.multipart.MultipartFile;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.security.NoSuchAlgorithmException;
//import java.time.Instant;
//import java.util.Collections;
//import java.util.UUID;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.ArgumentMatchers.eq;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.mockStatic;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//@ExtendWith(MockitoExtension.class)
//public class FileImportServiceTest {
//
//    @Mock
//    private ImportRepository importRepository;
//
//    @Mock
//    private ImportFilesRepository importFilesRepository;
//
//    @Mock
//    private ImportStatusRepository importStatusRepository;
//
//    @Mock
//    private ModelMapper modelMapper;
//
//    @Mock
//    private HttpServletRequest httpServletRequest;
//
//    @Mock
//    private Tika tika;
//
//    @Mock
//    private ApplicationTemp applicationTemp;
//
//    @InjectMocks
//    private FileImportServiceImpl fileImportServiceImpl;
//
//    private static final String TEST_USER_ID = "test_user_id";
//    private UserDetails userDetails;
//    private Authentication authentication;
//
//    private MultipartFile xmlZipFile;
//    private MultipartFile excelZipFile;
//
//    @BeforeEach
//    void setUp() {
//        //Create mock user details
//        userDetails = User.withUsername(TEST_USER_ID)
//                .password("password")
//                .authorities(Collections.emptyList())
//                .build();
//        //Create authentication token
//        authentication = new UsernamePasswordAuthenticationToken(
//                userDetails,
//                userDetails.getPassword(),
//                userDetails.getAuthorities());
//
//        //Prepare Multipart files
//        xmlZipFile = new MockMultipartFile("file", "test_xml.zip", "application/zip", "Mock XML Zip Content".getBytes());
//        excelZipFile = new MockMultipartFile("file", "test_excel.zip", "application/zip", "Mock Excel Content".getBytes());
//    }
//
//    @Test
//    void testUploadXmlFile_success()
//            throws IOException, InvalidZipContentException, InvalidImportTypeException, NoSuchAlgorithmException {
//        try (MockedStatic<SecurityContextHolder> securityContextHolderMocked = mockStatic(
//                SecurityContextHolder.class)) {
//            //Mock security context
//            SecurityContext securityContext = mock(SecurityContext.class);
//            when(securityContext.getAuthentication()).thenReturn(authentication);
//            when(SecurityContextHolder.getContext()).thenReturn(securityContext);
//
//            String registerCode = "R01";
//
//            //Mock request IP
//            when(httpServletRequest.getHeader("X-Forwarded-For")).thenReturn(null);
//            when(httpServletRequest.getRemoteAddr()).thenReturn("127.0.0.1");
//
//            //Mock Tika MIME type detection
//            when(tika.detect(any(FileInputStream.class))).thenReturn("application/zip");
//            when(tika.detect(any(ZipArchiveInputStream.class), anyString())).thenReturn("application/vnd.ms-excel");
//
//            //Mock import status
//            NImportStatusEntity mockStatus = new NImportStatusEntity();
//            mockStatus.setId(1L);
//            mockStatus.setCode("XML_UPLOADED");
//            mockStatus.setDescription("Зареден XML файл");
//            when(importStatusRepository.findByStatusCode("XML_UPLOADED")).thenReturn(mockStatus);
//
//            //Mock file storing
//            File mockTempFile = mock(File.class);
//            when(mockTempFile.getName()).thenReturn(xmlZipFile.getOriginalFilename());
//            when(mockTempFile.getAbsolutePath()).thenReturn("/temp/mock-path");
//
//            //Prepare mock ImportFilesEntity
//            ImportFilesEntity mockImportFilesEntity = new ImportFilesEntity();
//            mockImportFilesEntity.setId(1L);
//            mockImportFilesEntity.setFilename(mockTempFile.getName());
//            mockImportFilesEntity.setMimeType(xmlZipFile.getContentType());
//            mockImportFilesEntity.setSize(xmlZipFile.getSize());
//            mockImportFilesEntity.setSha256("mockedSha256");
//            mockImportFilesEntity.setUrl(mockTempFile.getAbsolutePath());
//            when(importFilesRepository.save(any(ImportFilesEntity.class))).thenReturn(mockImportFilesEntity);
//
//            //Prepare mock ImportEntity
//            ImportEntity mockImportEntity = new ImportEntity();
//            mockImportEntity.setId(1L);
//            mockImportEntity.setUploadDate(Instant.now());
//            mockImportEntity.setStatusId(mockStatus.getId());
//            mockImportEntity.setUserId(TEST_USER_ID);
//            mockImportEntity.setFilename(mockImportFilesEntity.getFilename());
//            mockImportEntity.setFileId(mockImportFilesEntity.getId());
//            mockImportEntity.setRegisterCode(registerCode);
//            mockImportEntity.setTraceId(UUID.randomUUID());
//            mockImportEntity.setUploaderIp(httpServletRequest.getRemoteAddr());
//            mockImportEntity.setImportType("XML");
//            when(importRepository.save(any(ImportEntity.class))).thenReturn(mockImportEntity);
//
//            //Prepare mock FileImportStateOutView
//            FileImportStateOutView mockOutView = new FileImportStateOutView();
//            mockOutView.setId(1L);
//            mockOutView.setStatusId(mockImportEntity.getStatusId());
//            mockOutView.setUserId(mockImportEntity.getUserId());
//            when(modelMapper.map(any(), eq(FileImportStateOutView.class))).thenReturn(mockOutView);
//
//            FileImportStateOutView res = fileImportServiceImpl.uploadFile(registerCode, xmlZipFile);
//
//            assertNotNull(res);
//            assertEquals(1L, res.getId());
//            assertEquals(TEST_USER_ID, res.getUserId());
//
//            verify(importStatusRepository).findByStatusCode("XML_UPLOADED");
//            verify(importFilesRepository).save(any(ImportFilesEntity.class));
//            verify(importRepository).save(any(ImportEntity.class));
//        }
//    }
//}
