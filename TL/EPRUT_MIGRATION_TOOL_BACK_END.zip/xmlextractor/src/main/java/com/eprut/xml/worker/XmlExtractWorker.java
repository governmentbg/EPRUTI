package com.eprut.xml.worker;

import com.eprut.db.impl.WorkBean;
import com.eprut.xml.db.XmlExtractDb;
import lombok.extern.slf4j.Slf4j;
import tl.abstractWorkers.AbstractQueueWorker;

import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Slf4j
public class XmlExtractWorker extends AbstractQueueWorker<WorkBean> {

    private XmlExtractDb database;

    /**
     * Initialize abstract que with some number of threads and delays.
     *
     * @param nThreads             number of treads
     * @param initialDelay         delay in see {@link  TimeUnit}.
     * @param periodOfQueueRefresh refresh period in see {@link  TimeUnit}.
     * @param timeUnit             time unit.
     */
    public XmlExtractWorker(int nThreads, Long initialDelay, Long periodOfQueueRefresh,
                            TimeUnit timeUnit, XmlExtractDb database) {
        super(nThreads, initialDelay, periodOfQueueRefresh, timeUnit);
        this.database = database;
    }

    @Override
    protected void updateWorkerQueue() {
        String logId = UUID.randomUUID().toString();
        try {
            database.getReadyToStart(logId).stream().distinct().filter(e -> !queue.contains(e)).forEach(queue::addLast);
        } catch (Exception e) {
            log.error("{}: updateWorkerQueue error", logId, e);
        }
    }

    @Override
    protected void workerExecutedMethod(String logId, WorkBean firstElementFromQueue) {
        boolean doWork = true;
        try {
            if (database.checkIfNotStarted(logId, firstElementFromQueue)) {
                try {
                    database.start(logId, firstElementFromQueue);
                } catch (Exception e) {
                    if (database.checkIfNotStarted(logId, firstElementFromQueue)) {
                        throw e;
                    } else {
                        doWork = false;
                    }
                }
                if (doWork) {
                    // do ctual work
                    // extract zip

                    //validate xml
                    database.finishedPreparing(logId, firstElementFromQueue);

                    //load beans

                    //load database

                    //finish

                    database.finish(logId, firstElementFromQueue);
                }
            }
        } catch (Exception e) {
            try {
//                database.error(logId, firstElementFromQueue, e);
            } catch (Exception ex) {
                try {
                    database.logErrorMessage(logId, firstElementFromQueue, "Възникна грешка при опит за стартиране на оброботка.", ex);
                } catch (Exception e1) {
                    //ignore.
                }
                this.workerExceptionHandling(logId, firstElementFromQueue, ex);
            }
        }
    }

    //    }
    @Override
    protected void workerExceptionHandling(String logId, WorkBean firstElementFromQueue, Exception e) {
        log.error("{} - XmlExtractWorker with WorkBean : {} ERROR {}", logId, firstElementFromQueue, e, e);
    }

    @Override
    protected void workerStarted(String logId, WorkBean firstElementFromQueue) {
        log.debug("{} - XmlExtractWorker with WorkBean : {} has STARTED working", logId, firstElementFromQueue);
    }

    @Override
    protected void workerFinished(String logId, WorkBean firstElementFromQueue) {
        log.debug("{} - XmlExtractWorker with WorkBean : {} has FINISHED working", logId, firstElementFromQueue);
    }


}

