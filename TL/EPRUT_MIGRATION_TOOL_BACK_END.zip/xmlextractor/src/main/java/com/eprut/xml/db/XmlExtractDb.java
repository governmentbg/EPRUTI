package com.eprut.xml.db;

import com.eprut.db.config.IpInfoConfig;
import com.eprut.db.impl.DatabaseManager;
import com.eprut.db.impl.WorkBean;
import com.eprut.xml.constants.States;

import java.util.List;

public class XmlExtractDb extends DatabaseManager {

    /**
     * Get predefined work items.
     *
     * @param logId
     * @return work item.
     * @throws Exception
     */
    public List<WorkBean> getReadyToStart(String logId) throws Exception {
        return super.getReadyToStart(logId, States.XML_UPLOADED.name());
    }

    @Override
    public WorkBean start(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.XML_PREPARING.name(), IpInfoConfig.getSignature());
    }

    @Override
    public boolean checkIfNotStarted(String logId, WorkBean work) throws Exception {
        return checkIfNotStarted(logId, work, States.XML_UPLOADED.name());
    }

    @Override
    public WorkBean finishedPreparing(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.XML_WORKING.name());
    }

    @Override
    public WorkBean finish(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.DATA_UPLOADED.name());
    }

    @Override
    public WorkBean error(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.XML_ERROR.name());
    }

    @Override
    public WorkBean error(String logId, WorkBean work, Exception e) throws Exception {
        return changeStatusToError(logId, work, States.XML_ERROR.name(), e);
    }
}
