package com.eprut.xml.constants;

public enum States {

    XML_UPLOADED,
    XML_PREPARING,
    XML_WORKING,
    DATA_UPLOADED,
    XML_ERROR
}
