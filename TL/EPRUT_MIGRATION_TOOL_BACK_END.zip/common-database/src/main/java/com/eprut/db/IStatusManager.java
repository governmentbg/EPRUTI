package com.eprut.db;

import com.eprut.db.impl.WorkBean;

import java.util.List;

public interface IStatusManager {

    /**
     * Returns list of ids ready to start.
     *
     * @return list of id ready to start work.
     * @throws Exception if db exception occurs.
     */
    List<WorkBean> getReadyToStart(String logId) throws Exception;

    /**
     * Changes the status to starting work of specified id.
     *
     * @param work the id of the working import row.
     * @return the id of the record.
     * @throws Exception if db exception occurs.
     */
    WorkBean start(String logId, WorkBean work) throws Exception;


    /**
     * Checks if the work hasn't been started.
     *
     * @param work the id of the working import row.
     * @return true/false. True if not started false if already started.
     * @throws Exception if db exception occurs.
     */
    boolean checkIfNotStarted(String logId, WorkBean work) throws Exception;

    /**
     * Changes the status to starting work of specified id.
     *
     * @param work the id of the working import row.
     * @return the id of the record.
     * @throws Exception if db exception occurs.
     */
    WorkBean finishedPreparing(String logId, WorkBean work) throws Exception;


    /**
     * Changes the status to starting work of specified id.
     *
     * @param work the id of the working import row.
     * @return the id of the record.
     * @throws Exception if db exception occurs.
     */
    WorkBean finish(String logId, WorkBean work) throws Exception;

    /**
     * Changes the status to starting work of specified id.
     *
     * @param work the id of the working import row.
     * @return the id of the record.
     * @throws Exception if db exception occurs.
     */
    WorkBean error(String logId, WorkBean work) throws Exception;

    /**
     * Changes the status to starting work of specified id.
     *
     * @param work the id of the working import row.
     * @return the id of the record.
     * @throws Exception if db exception occurs.
     */
    WorkBean error(String logId, WorkBean work, Exception e) throws Exception;


}
