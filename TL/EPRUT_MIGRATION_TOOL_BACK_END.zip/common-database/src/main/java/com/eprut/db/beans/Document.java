package com.eprut.db.beans;

import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
public class Document {
    public Long id;                             //Уникален идентификатор
    public Long impId;                          //Идентификатор на импорт
    @Size(max = 255, message = "File Name must not exceed 255 characters.")
    public String fileName;                     //Име на файл
    @Size(max = 255, message = "Mime Type must not exceed 255 characters.")
    public String mimeType;                     //Разширение на файл
    public Long fileSize;                       //Размер на файла
    @Size(max = 255, message = "Sha256 must not exceed 255 characters.")
    public String sha256;                       //Размер на файла в байтове
    @Size(max = 255, message = "URL must not exceed 255 characters")
    public String url;                          //Съдържание на файл
}
