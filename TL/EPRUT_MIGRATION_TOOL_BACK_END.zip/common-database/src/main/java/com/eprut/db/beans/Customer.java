package com.eprut.db.beans;

import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


@Data
@ToString
@EqualsAndHashCode
public class Customer {
    public Long id;                //Уникален идентификатор
    public Long impId;             //Уникален идентификатор на импорт
    public Long opId;              //Уникален идентификатор в оперативните данни
    public int excelRow;           //Номер на ред в excel
    public Long regActId;          //Идентификатор на акта
    @Size(max = 50, message = "Identifier Type must not exceed 50 characters.")
    public String identifierType;  //Вид на идентификатор
    @Size(max = 50, message = "Identifier must not exceed 50 characters.")
    public String identifier;      //Публичен идентификатор
    @Size(max = 50, message = "Customer type must not exceed 50 characters.")
    public String customerType;    //Вид на заявителя
    @Size(max = 255, message = "Unit name must not exceed 255 characters.")
    public String unitName;        //Наименование Отключено при избор Булстат или ЕИК от поле Вид на идентификатора
    @Size(max = 255, message = "First name must not exceed 255 characters.")
    public String firstName;       //Име
    @Size(max = 255, message = "Middle name must not exceed 255 characters.")
    public String middleName;      //Презиме
    @Size(max = 255, message = "Last name must not exceed 255 characters.")
    public String lastName;        //Фамилия
    @Size(max = 255, message = "Email must not exceed 255 characters.")
    public String email;           //Електронен адрес
    @Size(max = 20, message = "Phone must not exceed 20 characters.")
    public String phone;           //Телефон
    @Size(max = 255, message = "Capacity must not exceed 255 characters.")
    public String capacity;        //Качество
    public Long addressId;         //Връзка към адрес
    public String numAct;          //Номер на акта
    public Boolean isValid;
}
