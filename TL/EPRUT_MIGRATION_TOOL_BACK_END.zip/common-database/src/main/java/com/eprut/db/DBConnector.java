package com.eprut.db;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.sql.Connection;
import java.util.Objects;

public class DBConnector {

    private static DataSource datasource;

    /**
     * Returns the connection from initialized DS.
     *
     * @return Connection
     * @throws Exception
     */
    public static Connection getConnection() throws Exception {
        Connection connection = datasource.getConnection();
        connection.setAutoCommit(false);
        return connection;
    }

    /**
     * Returns an DataSource while getting the factory type from system property.
     *
     * @param jndiName of the jdni connection.
     * @return DataSource.
     * @throws Exception
     */
    public static synchronized DataSource initDataSource(String jndiName) throws Exception {
        if (datasource == null) {
            Objects.requireNonNull(jndiName, "The property jndiConnName must not be null");

            String patternJndi = "java:comp/env/.*";
            String preffixJndi = "java:comp/env/";

            if (!jndiName.matches(patternJndi)) {
                jndiName = preffixJndi + jndiName;
            }

            InitialContext ic = new InitialContext();
            datasource = (DataSource) ic.lookup(jndiName);
        }
        return datasource;
    }

    public static DataSource getDatasource() {
        return datasource;
    }
}
