package com.eprut.db.constants;

public class Messages {

    public static final String STATE_CHANGE = "Промяна на статус към '%s'";
}
