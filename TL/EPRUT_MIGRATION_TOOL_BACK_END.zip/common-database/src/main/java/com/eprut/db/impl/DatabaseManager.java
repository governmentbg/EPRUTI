package com.eprut.db.impl;

import com.eprut.db.ILogManager;
import com.eprut.db.IStatusManager;
import com.eprut.db.constants.MessageTypes;
import com.eprut.db.constants.Messages;
import lombok.extern.slf4j.Slf4j;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.eprut.db.DBConnector.getConnection;

@Slf4j
public abstract class DatabaseManager implements IStatusManager, ILogManager {

    private static final String GET_ALL_BY_STATE = """
            select i.id, i.version from staging.import i
            join staging.n_import_status state on i.status_id = state.id
            where state.code = ?
            """;


    private static final String CHANGE_STATE_TO = """
            update staging.import i
            set status_id = (select k.id from staging.n_import_status k where k.code = ?),
                version   = i.version + 1
            where i.id = ?
              and i.version = ?
            """;

    private static final String CHANGE_STATE_TO_WITH_SIGNATURE = """
            update staging.import i
            set status_id = (select k.id from staging.n_import_status k where k.code = ?),
                version   = i.version + 1,
                server_identifier = ?
            where i.id = ?
              and i.version = ?
            """;

    private static final String CHANGE_STATE_TO_ERROR = """
            update staging.import i
            set status_id = (select k.id from staging.n_import_status k where k.code = ?),
                version   = i.version + 1,
                fatal_stacktrace = ?
            where i.id = ?
              and i.version = ?
            """;

    private static final String CHECK_IF_NOT_STARTED = """
            select i.id
            from staging.import i
                     join staging.n_import_status state on i.status_id = state.id
            where i.id = ? and i.version = ? and state.code = ?
            """;

    private static final String INSERT_MESSAGE = """
            insert into staging.import_log(import_id, date_added, msg_type_id, msg)
            VALUES (?, clock_timestamp(), (select k.id from staging.n_imp_msg_type k where k.code = ?), ?)
            """;

    private static final String NOTIFY_SERVER_UP = """
            update staging.import t
            set status_id = (select k.id from staging.n_import_status k where k.code = (?))
            where t.server_identifier = ? and t.status_id in (select k.id from staging.n_import_status k where k.code in (?, ?));
            """;

    private static final String GET_STATUS_NAME = """
            select t.description
            from staging.n_import_status t
            where t.code = ?
            """;

    private static final String CHANGE_TO_STATE_IMPL = """
            update staging.import i
            set status_id = (select k.id from staging.n_import_status k where k.code = ?)
            where i.id = ?
            """;

    private static final String GET_ZIP_ARCHIVE_PATH = """
            select imp_files.url
            from staging.import_files imp_files
            join staging.import i on imp_files.id = i.file_id
            where i.id = ?
            """;

    /**
     * Updates records that are in working status to be changed to READY.
     *
     * @param c         connection.
     * @param signature server signature.
     */
    public void notifyDbServerIsUp(Connection c, String signature, String statusError, String statusToSet, String statusPreparing, String statusWorking) throws SQLException {
        String logId = UUID.randomUUID().toString();
        log.info("{}: notifyDbServerIsUp - started", logId);
        log.trace("{}: notifyDbServerIsUp: signature: {}; ", logId, signature);
        try (CallableStatement cs = c.prepareCall(NOTIFY_SERVER_UP)) {
            int i = 1;
            cs.setString(i++, statusToSet);
            cs.setString(i++, signature);
            cs.setString(i++, statusPreparing);
            cs.setString(i++, statusWorking);
            cs.executeUpdate();
        } catch (SQLException e) {
            log.error("{}: notifyDbServerIsUp - error", logId, e);
            throw e;
        } finally {
            log.info("{}: notifyDbServerIsUp - finished", logId);
        }
    }

    protected List<WorkBean> getReadyToStart(String logId, String statusCode) throws Exception {
        log.info("{}: getReadyToStart - started", logId);
        log.trace("{}: statusCode: {}", logId, statusCode);
        List<WorkBean> res = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ALL_BY_STATE, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)) {
                int i = 1;
                cs.setString(i++, statusCode);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        res.add(new WorkBean(rs.getBigDecimal("id"), rs.getBigDecimal("version")));
                    }
                }
            }
            return res;
        } catch (Exception e) {
            log.error("{}: getReadyToStart - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getReadyToStart - finished", logId);
        }
    }

    protected final boolean checkIfNotStarted(String logId, WorkBean work, String statusCode) throws Exception {
        log.info("{}: checkIfNotStarted - started", logId);
        log.trace("{}: workPackage: {}; statusCode: {}", logId, work, statusCode);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(CHECK_IF_NOT_STARTED, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY)) {
                int i = 1;
                cs.setBigDecimal(i++, work.getId());
                cs.setBigDecimal(i++, work.getVersion());
                cs.setString(i++, statusCode);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        return true;
                    }
                }
            }
            return false;
        } catch (Exception e) {
            log.error("{}: checkIfNotStarted - error", logId, e);
            throw e;
        } finally {
            log.info("{}: checkIfNotStarted - finished", logId);
        }
    }

    protected final WorkBean changeStatusTo(String logId, WorkBean work, String statusCode) throws Exception {
        log.info("{}: changeStatusTo - started", logId);
        log.trace("{}: workPackage: {}; statusCode: {}", logId, work, statusCode);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(CHANGE_STATE_TO)) {
                int i = 1;
                cs.setString(i++, statusCode);
                cs.setBigDecimal(i++, work.getId());
                cs.setBigDecimal(i++, work.getVersion());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Invalid transition 0 updates");
                }
                logStageMessage(c, logId, work, statusCode);
                c.commit();
            }
            work.incrementVersion();
            return work;
        } catch (Exception e) {
            log.error("{}: changeStatusTo - error", logId, e);
            throw e;
        } finally {
            log.info("{}: changeStatusTo - finished", logId);
        }
    }

    protected final WorkBean changeStatusTo(String logId, WorkBean work, String statusCode, String serverSignature) throws Exception {
        log.info("{}: changeStatusTo - started", logId);
        log.trace("{}: workPackage: {}; statusCode: {}", logId, work, statusCode);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(CHANGE_STATE_TO_WITH_SIGNATURE)) {
                int i = 1;
                cs.setString(i++, statusCode);
                cs.setString(i++, serverSignature);
                cs.setBigDecimal(i++, work.getId());
                cs.setBigDecimal(i++, work.getVersion());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Invalid transition 0 updates");
                }
                logStageMessage(c, logId, work, statusCode);
                c.commit();
            }
            work.incrementVersion();
            return work;
        } catch (Exception e) {
            log.error("{}: changeStatusTo - error", logId, e);
            throw e;
        } finally {
            log.info("{}: changeStatusTo - finished", logId);
        }
    }

    protected final WorkBean changeStatusToError(String logId, WorkBean work, String statusCode, Exception ex) throws Exception {
        log.info("{}: changeStatusTo - started", logId);
        log.trace("{}: workPackage: {}; statusCode: {}", logId, work, statusCode);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(CHANGE_STATE_TO_ERROR)) {
                int i = 1;
                cs.setString(i++, statusCode);
                cs.setString(i++, ex.getMessage());
                cs.setBigDecimal(i++, work.getId());
                cs.setBigDecimal(i++, work.getVersion());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Invalid transition 0 updates");
                }
                logStageMessage(c, logId, work, statusCode);
                c.commit();
            }
            work.incrementVersion();
            return work;
        } catch (Exception e) {
            log.error("{}: changeStatusTo - error", logId, e);
            throw e;
        } finally {
            log.info("{}: changeStatusTo - finished", logId);
        }
    }

    protected void logMessage(String logId, WorkBean work, String type, String msg) throws Exception {
        log.info("{}: logMessage - started", logId);
        log.trace("{}: workPackage: {}; type: {}; msg: {}", logId, work, type, msg);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(INSERT_MESSAGE)) {
                int i = 1;
                cs.setBigDecimal(i++, work.getId());
                cs.setString(i++, type);
                cs.setString(i++, msg);
                cs.execute();
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: logMessage - error", logId, e);
            throw e;
        } finally {
            log.info("{}: logMessage - started", logId);
        }
    }

    protected void logMessage(Connection c, String logId, WorkBean work, String type, String msg) throws Exception {
        log.info("{}: logMessage - started", logId);
        log.trace("{}: workPackage: {}; type: {}; msg: {}", logId, work, type, msg);
        try (CallableStatement cs = c.prepareCall(INSERT_MESSAGE)) {
            int i = 1;
            cs.setBigDecimal(i++, work.getId());
            cs.setString(i++, type);
            cs.setString(i++, msg);
            cs.execute();
        } catch (Exception e) {
            log.error("{}: logMessage - error", logId, e);
            throw e;
        } finally {
            log.info("{}: logMessage - finished", logId);
        }
    }


    protected String getStatusName(Connection c, String logId, String type) throws SQLException {
        log.info("{}: getStatusName - started", logId);
        log.trace("{}: type: {};", logId, type);
        try (CallableStatement cs = c.prepareCall(GET_STATUS_NAME)) {
            int i = 1;
            cs.setString(i++, type);
            cs.execute();
            try (ResultSet rs = cs.getResultSet()) {
                if (rs.next()) {
                    return rs.getString("description");
                }
            }
            return "NO_DESCR_ERROR";
        } catch (Exception e) {
            log.error("{}: getStatusName - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getStatusName - finished", logId);
        }
    }

    protected String getZipArchivePath(String logId, WorkBean work) throws Exception {
        log.info("{}: getZipArchivePath - started", logId);
        log.trace("{}: workPackage: {};", logId, work);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ZIP_ARCHIVE_PATH)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        return rs.getString("url");
                    }
                }
            }
            return null;
        } catch (Exception e) {
            log.error("{}: getZipArchivePath - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getZipArchivePath - finished", logId);
        }
    }

    @Override
    public void logErrorMessage(String logId, WorkBean work, String msg, Exception ex) throws Exception {
        this.logMessage(logId, work, MessageTypes.ERROR.name(), msg);
    }

    @Override
    public void logErrorMessage(String logId, WorkBean work, String msg) throws Exception {
        this.logMessage(logId, work, MessageTypes.ERROR.name(), msg);
    }

    @Override
    public void logWarningMessage(String logId, WorkBean work, String msg) throws Exception {
        this.logMessage(logId, work, MessageTypes.WARNING.name(), msg);
    }

    @Override
    public void logSysMessage(String logId, WorkBean work, String msg) throws Exception {
        this.logMessage(logId, work, MessageTypes.SYS.name(), msg);
    }

    protected void logStageMessage(Connection c, String logId, WorkBean work, String statusCode) throws Exception {
        String stateDescr = getStatusName(c, logId, statusCode);
        String msg = String.format(Messages.STATE_CHANGE, stateDescr);
        this.logMessage(c, logId, work, MessageTypes.STATE.name(), msg);
    }

    @Override
    public void logInfoMessage(String logId, WorkBean work, String msg) throws Exception {
        this.logMessage(logId, work, MessageTypes.INFO.name(), msg);
    }
}
