package com.eprut.db.beans;

import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@ToString
@EqualsAndHashCode
public class RegAct {
    public Long id;                            //Уникален идентификатор
    public Long impId;                         //Идентификатор на импорт
    public int excelRow;                       //Номер на ред в excel
    public Long opId;                          //Идентификатор в оперативните данни?
    @Size(max = 255, message = "Act number must not exceed 255 characters.")
    public String actNum;                      //Номер на акта
    @Size(max = 255, message = "Act type must not exceed 255 characters.")
    public String actType;                     //Вид на акта - номенклатура
    public LocalDateTime actDate;              //Дата на акта
    public LocalDateTime messageDate;          //Дата на съобщаване на акта
    @Size(max = 255, message = "Message type must not exceed 255 characters.")
    public String messageType;                 //Вид на съобщаване - номенклатура
    public LocalDateTime issuedDate;           //Дата на влизане в сила
    public String status;                      //Състояние - номенклатура
    public LocalDateTime changeDate;           //Дата на промяна
    public LocalDateTime validityDate;         //Валиден до
    @Size(max = 255, message = "Fact reason must not exceed 255 characters.")
    public String factReason;                  //Фактическо основание
    @Size(max = 255, message = "Legal reason must not exceed 255 characters.")
    public String legalReason;                 //Правно основание
    @Size(max = 255, message = "Administration must not exceed 255 characters.")
    public String administration;              //Администрация - номенклатура
    @Size(max = 255, message = "Administrative unit must not exceed 255 characters.")
    public String administrativeUnit;          //Административен орган - номенклатура
    @Size(max = 255, message = "Adm popular must not exceed 255 characters.")
    public String admPopular;                  //Територия на компетентност - номенклатура
    @Size(max = 512, message = "Object identification must not exceed 512 characters.")
    public String objectIdentification;        //Описание/Наименование на обект
    public Boolean isValid;
}
