package com.eprut.db;

import com.eprut.db.impl.WorkBean;

public interface ILogManager {

    /**
     * Log INFO message.
     *
     * @param msg
     * @throws Exception
     */
    void logInfoMessage(String logId, WorkBean work, String msg) throws Exception;


    /**
     * Log SYS message.
     *
     * @param msg
     * @throws Exception
     */
    void logSysMessage(String logId, WorkBean work, String msg) throws Exception;


    /**
     * Log WARNING message.
     *
     * @param msg
     * @throws Exception
     */
    void logWarningMessage(String logId, WorkBean work, String msg) throws Exception;

    /**
     * Log ERROR message.
     *
     * @param msg
     * @throws Exception
     */
    void logErrorMessage(String logId, WorkBean work, String msg) throws Exception;

    /**
     * Log ERROR message.
     *
     * @param msg
     * @throws Exception
     */
    void logErrorMessage(String logId, WorkBean work, String msg, Exception ex) throws Exception;
}
