package com.eprut.db.beans;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
public class RegActDocumentTwo {
    public Long id;                             //Уникален идентификатор
    public Long impId;                          //Идентификатор на импорт
    public int excelRow;                        //Номер на ред в excel
    public Long opId;                           //Идентификатор в оперативните данни
    public Long regActId;                       //Идентификатор на акта
    public Long documentId;                     //Графична част на оспорване
    public Boolean isValid;
}
