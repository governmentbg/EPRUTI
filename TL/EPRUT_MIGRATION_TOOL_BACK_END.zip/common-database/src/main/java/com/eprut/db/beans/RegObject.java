package com.eprut.db.beans;

import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
public class RegObject {
    public Long id;                     //Уникален идентификатор
    public Long impId;                  //Уникален идентификатор на импорт
    public int excelRow;                //Номер на ред в excel
    public Long opId;                   //Уникален идентификатор в оперативните данни
    public Long regActId;               //Идентификатор на акта
    @Size(max = 50, message = "Cadastre must not exceed 50 characters.")
    public String cadastre;             //Идентификатор по кадастрална карта
    @Size(max = 50, message = "Local Place must not exceed 50 characters.")
    public String localPlace;           //'Наименование на местност – в урбанизирани територии това е наименованието на плана,
                                        // а в неурбанизирани – наименование на местност по КВСДанни от регулационен файл - Местност'
    @Size(max = 50, message = "Regulation District must not exceed 50 characters.")
    public String regulationDistrict;   //Квартал по регулация
    @Size(max = 50, message = "UPI description must not exceed 50 characters.")
    public String upi;                  //УПИ
    @Size(max = 50, message = "Plan Region must not exceed 50 characters.")
    public String planRegion;           //Планоснимачен район
    @Size(max = 50, message = "Plan Number must not exceed 50 characters.")
    public String planNumber;           //Планоснимачен номер - Номер по кадастрален план
    @Size(max = 50, message = "KVS Territory must not exceed 50 characters.")
    public String kvsTerritory;         //Местност КВС
    @Size(max = 50, message = "KVS Number must not exceed 50 characters")
    public String kvsNumber;
    @Size(max = 50, message = "Territory Type must not exceed 50 characters.")
    public String territoryType;        //Вид територия
    @Size(max = 50, message = "ProtectedTerritory must not exceed 50 characters.")
    public String protectedTerritory;   //Защитена територия
    @Size(max = 512, message = "Description must not exceed 512 characters.")
    public String description;          //Описание/Наименование на обект
    public Long addressId;              //Връзка към адрес
    public String numAct;
    public Boolean isValid;
}
