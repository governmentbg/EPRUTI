package com.eprut.db.beans;

import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
public class Address {
    public Long id;                //Уникален идентификатор
    public Long importId;          //Идентификатор на импорт
    public int excelRow;           //Номер на ред в excel
    public Long opId;              //Идентификатор в оперативните данни?
    @Size(max = 15, message = "Country must not exceed 15 characters.")
    public String country;         //Държава
    @Size(max = 15, message = "District must not exceed 15 characters.")
    public String district;        //Област - ЕКАТТЕ
    @Size(max = 15, message = "Municipality must not exceed 15 characters.")
    public String municipality;    //Община - ЕКАТТЕ
    @Size(max = 15, message = "Settlement must not exceed 15 characters.")
    public String settlement;      //Идентификатор на населено място - ЕКАТТЕ
    @Size(max = 15, message = "Village must not exceed 15 characters.")
    public String village;         //Идентификатор на селищно образувание - ЕКАТТЕ
    @Size(max = 15, message = "Region must not exceed 15 characters.")
    public String region;          //Район - ЕКАТТЕ
    @Size(max = 40, message = "Floor must not exceed 40 characters.")
    public String floor;          //Етаж

    @Size(max = 10, message = "Flat entrance must not exceed 10 characters.")
    public String flatEntrance;    //Вход
    @Size(max = 40, message = "Apartment must not exceed 40 characters.")
    public String apartment;       //Апартамент/Ателие №
    @Size(max = 500, message = "Square name must not exceed 500 characters.")
    public String squareName;      //Площад
    @Size(max = 40, message = "Square number must not exceed 40 characters.")
    public String squareNum;       //Площад №
    @Size(max = 500, message = "Apartment complex name must not exceed 500 characters.")
    public String appComplexName;  //Жилищен комплекс
    @Size(max = 40, message = "Apartment complex number must not exceed 40 characters.")
    public String appComplexNum;   //Жилищен комплекс №
    @Size(max = 200, message = "Quarter must not exceed 200 characters.")
    public String quarter;         //Квартал
    @Size(max = 500, message = "Street name must not exceed 500 characters.")
    public String streetName;      //Улица
    @Size(max = 40, message = "Street number must not exceed 40 characters.")
    public String streetNum;       //Улица №
    @Size(max = 40, message = "Flat number must not exceed 40 characters.")
    public String flatNumber;      //Блок №
    @Size(max = 500, message = "Other localization unit name must not exceed 500 characters.")
    public String otherluname;     //Друга локализационна единица
    @Size(max = 40, message = "Other localization unit number must not exceed 40 characters.")
    public String otherlunum;      //Друга локализационна единица - №
    @Size(max = 500, message = "Address place name must not exceed 500 characters.")
    public String addrPlaceName;   //Местност
    @Size(max = 40, message = "Address place number must not exceed 40 characters.")
    public String addrPlaceNum;    //Местност №
    public Boolean isValid;
}
