package com.eprut.db.config;

import javax.management.MBeanServer;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;
import javax.management.Query;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Set;

public class IpInfoConfig {

    private static String port;
    private static String hostAddress;

    public static String getSignature() {
        return hostAddress + ":" + port;
    }

    /**
     * Init the portAdress combination for signature.
     *
     * @throws Exception
     */
    public void onApplicationEvent() throws Exception {
        try {
            MBeanServer beanServer = ManagementFactory.getPlatformMBeanServer();

            Set<ObjectName> objectNames = beanServer.queryNames(new ObjectName("*:type=Connector,*"),
                    Query.match(Query.attr("protocol"), Query.value("HTTP/*")));

            IpInfoConfig.port = objectNames.iterator().next().getKeyProperty("port");
            IpInfoConfig.hostAddress = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException | MalformedObjectNameException e) {
            throw new Exception("Cannot determine starting ip and host", e);
        }
    }
}
