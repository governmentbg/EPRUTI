package com.eprut.db.impl;

import lombok.Getter;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
@ToString
public class WorkBean {

    private final BigDecimal id;
    private BigDecimal version;

    /**
     * Work bean constructor.
     *
     * @param id      the id of the work.
     * @param version version field of the work.
     */
    public WorkBean(BigDecimal id, BigDecimal version) {
        this.id = id;
        this.version = version;
    }

    /**
     * This method increments the version field.
     */
    public void incrementVersion() {
        version = version.add(BigDecimal.ONE);
    }
}
