package com.eprut.db.beans;

import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
public class RegAppTwoDocument {
    public Long id;                             //Уникален идентификатор
    public Long impId;                          //Идентификатор на импорт
    public int excelRow;                        //Номер на ред в excel
    public Long opId;                           //Идентификатор в оперативните данни
    public Long regActId;                       //Идентификатор на акта
    public Long documentId;                     //Графична част на оспорване
    @Size(max = 50, message = "Type must not exceed 50 characters.")
    public String type;                         //Основна категория
    @Size(max = 50, message = "SubType must not exceed 50 characters.")
    public String subType;                      //Подкатегория
    public Boolean isValid;
}
