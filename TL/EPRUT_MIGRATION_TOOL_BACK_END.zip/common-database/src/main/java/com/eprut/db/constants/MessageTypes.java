package com.eprut.db.constants;

public enum MessageTypes {

    INFO,
    SYS,
    STATE,
    WARNING,
    ERROR
}
