package com.eprut.validator.constants;

public enum States {

    DATA_UPLOADED,
    DATA_PREPARING,
    DATA_VALIDATING,
    TRANSFER_READY,
    DATA_ERROR
}
