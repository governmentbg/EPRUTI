package com.eprut.validator.worker;

import com.eprut.db.beans.Address;
import com.eprut.db.beans.Customer;
import com.eprut.db.beans.RegAct;
import com.eprut.db.beans.RegAppOneDocument;
import com.eprut.db.beans.RegAppTwoDocument;
import com.eprut.db.beans.RegObject;
import com.eprut.db.impl.WorkBean;
import com.eprut.validator.db.ValidatorDb;
import lombok.extern.slf4j.Slf4j;
import tl.abstractWorkers.AbstractQueueWorker;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Slf4j
public class ValidatorWorker extends AbstractQueueWorker<WorkBean> {

    private ValidatorDb database;

    /**
     * Initialize abstract que with some number of threads and delays.
     *
     * @param nThreads             number of treads
     * @param initialDelay         delay in see {@link  TimeUnit}.
     * @param periodOfQueueRefresh refresh period in see {@link  TimeUnit}.
     * @param timeUnit             time unit.
     */
    public ValidatorWorker(int nThreads, Long initialDelay, Long periodOfQueueRefresh,
                           TimeUnit timeUnit, ValidatorDb database) {
        super(nThreads, initialDelay, periodOfQueueRefresh, timeUnit);
        this.database = database;
    }

    @Override
    protected void updateWorkerQueue() {
        String logId = UUID.randomUUID().toString();
        try {
            database.getReadyToStart(logId).stream().distinct().filter(e -> !queue.contains(e)).forEach(queue::addLast);
        } catch (Exception e) {
            log.error("{}: updateWorkerQueue error", logId, e);
        }
    }

    @Override
    protected void workerExecutedMethod(String logId, WorkBean firstElementFromQueue) {
        boolean doWork = true;
        try {
            if (database.checkIfNotStarted(logId, firstElementFromQueue)) {
                try {
                    database.start(logId, firstElementFromQueue);
                } catch (Exception e) {
                    if (database.checkIfNotStarted(logId, firstElementFromQueue)) {
                        throw e;
                    } else {
                        doWork = false;
                    }
                }
                if (doWork) {
                    List<RegAct> regActs = database.getRegActsByImportId(logId, firstElementFromQueue);

                    if (regActs.isEmpty()) {
                        database.logErrorMessage(logId, firstElementFromQueue, "Няма актове за валидиране.");
                        throw new IllegalArgumentException("Няма актове за валидиране.");
                    }

                    String registerCode = database.getRegisterCodeByImportId(logId, firstElementFromQueue);
                    List<RegObject> regObjects = database.getRegActObjectsByImportId(logId, firstElementFromQueue);
                    Map<Long, Address> addresses = database.getRegActAddressesByImportId(logId, firstElementFromQueue);
                    List<Customer> customers = database.getRegActCustomersByImportId(logId, firstElementFromQueue);
                    List<RegAppOneDocument> appOneDocuments =
                            database.getRegActAppOneDocsByImportId(logId, firstElementFromQueue);
                    List<RegAppTwoDocument> appTwoDocuments =
                            database.getRegActAppTwoDocsByImportId(logId, firstElementFromQueue);

                    database.finishedPreparing(logId, firstElementFromQueue);

                    List<Long> validRegActs = validateRegActs(logId, firstElementFromQueue, regActs, registerCode);
                    database.logInfoMessage(logId, firstElementFromQueue, "Брой валидни актове: " + validRegActs.size());

                    List<Long> validRegObjects = validateRegObjects(logId, firstElementFromQueue, validRegActs, regObjects, addresses);
                    database.logInfoMessage(logId, firstElementFromQueue, "Брой валидни обекти: " + validRegObjects.size());

                    List<Long> validCustomers = validateCustomers(logId, firstElementFromQueue, validRegActs, customers, addresses);
                    database.logInfoMessage(logId, firstElementFromQueue, "Брой валидни заявители/възложители: " + validCustomers.size());

                    //todo validate app one and two

                    //load database

                    //finish

                    if (database.hasErrorWarningMessages(logId, firstElementFromQueue)) {
                        throw new Exception("Открити са грешки или предупреждения при обработката.");
                    }

                    database.finish(logId, firstElementFromQueue);
                }
            }
        } catch (Exception e) {
            try {
                database.error(logId, firstElementFromQueue, e);
            } catch (Exception ex) {
                try {
                    database.logErrorMessage(logId, firstElementFromQueue,
                            "Възникна грешка при опит за стартиране на оброботка.", ex);
                } catch (Exception e1) {
                    //ignore.
                }
                this.workerExceptionHandling(logId, firstElementFromQueue, ex);
            }
        }
    }

    private List<Long> validateRegActs(String logId, WorkBean work, List<RegAct> regActs, String registerCode)
            throws Exception {
        List<String> actTypes = database.getRegActTypesByRegisterCode(logId, work, registerCode);
        List<String> actMessageTypes = database.getAnnouncementTypes(logId, work);
        List<String> actStatusTypes = database.getStatuses(logId, work);
        List<String> actAdministrationTypes = database.getAdministrationTypes(logId, work);
        List<String> ekatte = database.getEkatte(logId, work);
        List<String> actAdministrativeUnits = database.getIssuer(logId, work);
        List<Long> validRegActs = new ArrayList<>();

        for (RegAct regAct : regActs) {
            String regActType = regAct.getActType();
            if (regActType != null && !actTypes.contains(regAct.getActType())) {
                database.updateRegActValidity(logId, work, regAct);
                database.logWarningMessage(logId, work, "За Акт: " + regAct.getActType() + " " + regAct.getActNum() + ". Невалидна стойност за номенклатура - Вид на Акт");
                continue;
            }

            String regActMessageType = regAct.getMessageType();
            if (regActMessageType != null && !actMessageTypes.contains(regActMessageType)) {
                database.updateRegActValidity(logId, work, regAct);
                database.logWarningMessage(logId, work, "За Акт: " + regAct.getActType() + " " + regAct.getActNum() + ".Невалидна стойност за номенклатура - Вид на Съобщаване");
                continue;
            }

            String regActStatus = regAct.getStatus();
            if (regActStatus != null && !actStatusTypes.contains(regAct.getStatus())) {
                database.updateRegActValidity(logId, work, regAct);
                database.logWarningMessage(logId, work, "За Акт: " + regAct.getActType() + " " + regAct.getActNum() + ".Невалидна стойност за номенклатура - Състояние");
                continue;
            }

            String regActAdministrationType = regAct.getAdministration();
            if (regActAdministrationType != null && !actAdministrationTypes.contains(regAct.getAdministration())) {
                database.updateRegActValidity(logId, work, regAct);
                database.logWarningMessage(logId, work, "За Акт: " + regAct.getActType() + " " + regAct.getActNum() + ".Невалидна стойност за номенклатура - Администрация");
                continue;
            }

            String regActEkatte = regAct.getAdmPopular();
            if (regActEkatte != null && !ekatte.contains(regAct.getAdmPopular())) {
                database.updateRegActValidity(logId, work, regAct);
                database.logWarningMessage(logId, work, "За Акт: " + regAct.getActType() + " " + regAct.getActNum() + ".Невалидна стойност за номенклатура - Територия на компетентност");
                continue;
            }

            String regActAdministrativeUnit = regAct.getAdministrativeUnit();
            if (regActAdministrativeUnit != null && !actAdministrativeUnits.contains(regAct.getAdministrativeUnit())) {
                database.updateRegActValidity(logId, work, regAct);
                database.logWarningMessage(logId, work, "За Акт: " + regAct.getActType() + " " + regAct.getActNum() + ".Невалидна стойност за номенклатура - Административен орган");
                continue;
            }

            validRegActs.add(regAct.getId());
        }


        return validRegActs;
    }

    private List<Long> validateRegObjects(String logId, WorkBean work, List<Long> validRegActs, List<RegObject> regObjects, Map<Long, Address> addresses)
            throws Exception {
        List<Long> validRegObjects = new ArrayList<>();
        List<String> territoryTypes = database.getTerritoryType(logId, work);

        for (RegObject regObject : regObjects) {
            if (!validRegActs.contains(regObject.getRegActId())) {
                database.updateRegActObjectValidity(logId, work, regObject);
                database.logWarningMessage(logId, work, "Обекта на ред: " + regObject.getExcelRow() + ", не свързан към валиден Акт");
                continue;
            }

            String territoryType = regObject.getTerritoryType();
            if (territoryType != null && !territoryTypes.contains(territoryType)) {
                database.updateRegActObjectValidity(logId, work, regObject);
                database.logWarningMessage(logId, work, "За Обект, на ред: " + regObject.getExcelRow() + ",е въведена невалидна стойност за номенклатура - Вид на територия");
                continue;
            }

            if (regObject.getAddressId() != null) {
                boolean isAddressValid = validateAddress(logId, work, addresses.get(regObject.getAddressId()));
                if (!isAddressValid) {
                    database.updateRegActObjectValidity(logId, work, regObject);
                    database.logWarningMessage(logId, work, "За Обект, на ред: " + regObject.getExcelRow() + ", е въведен невалиден Адрес");
                }
            }

            validRegObjects.add(regObject.getId());
        }

        return validRegObjects;
    }

    private List<Long> validateCustomers(String logId, WorkBean work, List<Long> validRegActs, List<Customer> customers, Map<Long, Address> addresses)
            throws Exception {
        List<Long> validCustomers = new ArrayList<>();
        List<String> applicants = database.getApplicant(logId, work);
        List<String> identifierTypes = database.getIdentifierType(logId, work);

        for (Customer customer : customers) {
            if (!validRegActs.contains(customer.getRegActId())) {
                database.updateCustomerValidity(logId, work, customer);
                database.logWarningMessage(logId, work, "Заявител/Възложител, на ред: " + customer.getExcelRow() + ", не свързан към валиден Акт");
                continue;
            }
            String customerType = customer.getCustomerType();
            if (customerType != null && !applicants.contains(customer.getCustomerType())) {
                database.updateCustomerValidity(logId, work, customer);
                database.logWarningMessage(logId, work, "За Заявител/Възложител, на ред: " + customer.getExcelRow() + ", е въведена невалидна стойност за номенклатура - Вид на заявител");
                continue;
            }

            //todo качество на заявител - няма информация в базата

            String customerIdentifierType = customer.getIdentifierType();
            if (customerIdentifierType != null && !identifierTypes.contains(customer.getIdentifierType())) {
                database.updateCustomerValidity(logId, work, customer);
                database.logWarningMessage(logId, work, "За Заявител/Възложител, на ред: " + customer.getExcelRow() + ", е въведена невалидна стойност за номенклатура - Вид на идентификатор");
                continue;
            }

            if (customer.getAddressId() != null) {
                boolean isAddressValid = validateAddress(logId, work, addresses.get(customer.getAddressId()));
                if (!isAddressValid) {
                    database.updateCustomerValidity(logId, work, customer);
                    database.logWarningMessage(logId, work, "За Заявител/Възложител, на ред: " + customer.getExcelRow() + ", е въведен невалиден Адрес");
                }
            }
            validCustomers.add(customer.getId());
        }

        return validCustomers;
    }

    private Boolean validateAddress(String logId, WorkBean work, Address address) throws Exception {
        List<String> countries = database.getCountry(logId, work);
        List<String> provinces = database.getProvince(logId, work);
        List<String> municipalities = database.getMunicipality(logId, work);
        List<String> settlements = database.getEkatte(logId, work);
        List<String> regions = database.getRegion(logId, work);

        String country = address.getCountry();
        if (country != null && !countries.contains(country)) {
            database.updateAddressValidity(logId, work, address);
            database.logWarningMessage(logId, work, "За Адрес, на ред: " + address.getExcelRow() + ", е въведена невалидна стойност за номенклатура - Държава");
            return false;
        }

        String province = address.getDistrict();
        if (province != null && !provinces.contains(province)) {
            database.updateAddressValidity(logId, work, address);
            database.logWarningMessage(logId, work, "За Адрес, на ред: " + address.getExcelRow() + ", е въведена невалидна стойност за номенклатура - Област");
            return false;
        }

        String municipality = address.getMunicipality();
        if (municipality != null && !municipalities.contains(municipality)) {
            database.updateAddressValidity(logId, work, address);
            database.logWarningMessage(logId, work, "За Адрес, на ред: " + address.getExcelRow() + ", е въведена невалидна стойност за номенклатура - Община");
            return false;
        }

        String settlement = address.getSettlement();
        if (settlement != null && !settlements.contains(settlement)) {
            database.updateAddressValidity(logId, work, address);
            database.logWarningMessage(logId, work, "За Адрес, на ред: " + address.getExcelRow() + ", е въведена невалидна стойност за номенклатура - Населено място");
            return false;
        }

        String region = address.getRegion();
        if (region != null && !regions.contains(region)) {
            database.updateAddressValidity(logId, work, address);
            database.logWarningMessage(logId, work, "За Адрес, на ред: " + address.getExcelRow() + ", е въведена невалидна стойност за номенклатура - Район");
            return false;
        }

        //todo селищно образование нямаме, или поне не намираме

        return true;
    }


    @Override
    protected void workerExceptionHandling(String logId, WorkBean firstElementFromQueue, Exception e) {
        log.error("{} - ValidatorWorker with WorkBean : {} ERROR {}", logId, firstElementFromQueue, e, e);
    }

    @Override
    protected void workerStarted(String logId, WorkBean firstElementFromQueue) {
        log.debug("{} - ValidatorWorker with WorkBean : {} has STARTED working", logId, firstElementFromQueue);
    }

    @Override
    protected void workerFinished(String logId, WorkBean firstElementFromQueue) {
        log.debug("{} - ValidatorWorker with WorkBean : {} has FINISHED working", logId, firstElementFromQueue);
    }


}

