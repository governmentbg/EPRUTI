package com.eprut.validator.db;

import com.eprut.db.beans.Address;
import com.eprut.db.beans.Customer;
import com.eprut.db.beans.RegAct;
import com.eprut.db.beans.RegAppOneDocument;
import com.eprut.db.beans.RegAppTwoDocument;
import com.eprut.db.beans.RegObject;
import com.eprut.db.config.IpInfoConfig;
import com.eprut.db.impl.DatabaseManager;
import com.eprut.db.impl.WorkBean;
import com.eprut.validator.constants.States;
import lombok.extern.slf4j.Slf4j;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.eprut.db.DBConnector.getConnection;

@Slf4j
public class ValidatorDb extends DatabaseManager {

    private static final String GET_REG_ACTS_BY_IMPORT_ID = """
            select *
            from staging.reg_act
            where imp_id = ?
            """;

    private static final String GET_REG_ACT_OBJECTS_BY_IMPORT_ID = """
            select *
            from staging.reg_actobject
            where imp_id = ?
            """;

    private static final String GET_REG_ACT_ADDRESSES_BY_IMPORT_ID = """
            select *
            from staging.address
            where imp_id = ?
            """;

    private static final String GET_REG_ACT_CUSTOMERS_BY_IMPORT_ID = """
            select *
            from staging.customer
            where imp_id = ?
            """;

    private static final String GET_REG_ACT_APP_ONE_DOCS_BY_IMPORT_ID = """
            select *
            from staging.reg_app01_documents
            where imp_id = ?
            """;

    private static final String GET_REG_ACT_APP_TWO_DOCS_BY_IMPORT_ID = """
            select *
            from staging.reg_app02_documents
            where imp_id = ?
            """;

    private static final String GET_REGISTER_CODE_BY_IMPORT_ID = """
            select *
            from staging.import
            where id = ?
            """;

    private static final String GET_REG_ACT_TYPES = """
            select *
            from staging.v_n_reg_act_reg
            where reg_code = ?
            """;

    private static final String UPDATE_REG_ACT_VALIDITY = """
            update staging.reg_act
            set is_valid = ?
            where id = ?
            """;

    private static final String UPDATE_REG_ACT_OBJECT_VALIDITY = """
            update staging.reg_actobject
            set is_valid = ?
            where id = ?
            """;

    private static final String UPDATE_CUSTOMER_VALIDITY = """
            update staging.customer
            set is_valid = ?
            where id = ?
            """;

    private static final String UPDATE_ADDRESS_VALIDITY = """
            update staging.address
            set is_valid = ?
            where id = ?
            """;

    private static final String GET_ANNOUNCEMENT_TYPE = """
            select *
            from regmigrate.nannouncementtype
            """;

    private static final String GET_STATUSES = """
            select * from regmigrate.nstatus
            """;

    private static final String GET_ADMINISTRATION_TYPES = """
            select * from regmigrate.nadministrationtype
            """;

    private static final String GET_EKATTE = """
            select * from bnd.ekatte
            """;

    private static final String GET_ISSUER = """
            select * from regmigrate.nissuer
            """;

    private static final String GET_PROVINCE = """
            select * from bnd.province
            """;

    private static final String GET_MUNICIPALITY = """
            select * from bnd.municipality
            """;

    private static final String GET_REGION = """
            select * from bnd.region
            """;

    private static final String GET_APPLICANT = """
            select * from regmigrate.ncusttype
            """;

    private static final String GET_IDENTIFIER_TYPE = """
            select * from regmigrate.ncustidenttype
            """;

    private static final String GET_COUNTRY = """
            select * from bnd.country
            """;

    private static final String GET_TERRITORY_TYPE = """
            select * from regmigrate.nterritorytype
            """;

    //returns if there are any error or warning messages
    private static final String HAS_ERROR_WARNING_MESSAGES = """
            select exists (
                select 1
                from staging.import_log il
                join staging.n_imp_msg_type nimt on il.msg_type_id = nimt.id
                where (nimt.code = 'WARNING' OR nimt.code = 'ERROR') and import_id = ?
            );
            """;

    /**
     * Get predefined work items.
     *
     * @param logId
     * @return work item.
     * @throws Exception
     */
    public List<WorkBean> getReadyToStart(String logId) throws Exception {
        return super.getReadyToStart(logId, States.DATA_UPLOADED.name());
    }

    @Override
    public WorkBean start(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.DATA_PREPARING.name(), IpInfoConfig.getSignature());
    }

    @Override
    public boolean checkIfNotStarted(String logId, WorkBean work) throws Exception {
        return checkIfNotStarted(logId, work, States.DATA_UPLOADED.name());
    }

    @Override
    public WorkBean finishedPreparing(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.DATA_VALIDATING.name());
    }

    @Override
    public WorkBean finish(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.TRANSFER_READY.name());
    }

    @Override
    public WorkBean error(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.DATA_ERROR.name());
    }

    @Override
    public WorkBean error(String logId, WorkBean work, Exception e) throws Exception {
        return changeStatusToError(logId, work, States.DATA_ERROR.name(), e);
    }

    /**
     * Returns list of all reg acts for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegAct>
     */
    public List<RegAct> getRegActsByImportId(String logId, WorkBean work) {
        log.info("{}: getRegActsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegAct> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REG_ACTS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegAct currentRegAct = new RegAct();
                        currentRegAct.setId(rs.getLong("id"));
                        currentRegAct.setImpId(rs.getLong("imp_id"));
                        currentRegAct.setExcelRow(rs.getInt("excel_row"));
                        currentRegAct.setOpId(rs.getLong("op_id"));
                        currentRegAct.setActNum(rs.getString("number"));
                        currentRegAct.setActType(rs.getString("type"));
                        Timestamp actDate = rs.getTimestamp("act_date");
                        if (actDate != null) {
                            currentRegAct.setActDate(actDate.toLocalDateTime());
                        }
                        Timestamp messageDate = rs.getTimestamp("message_date");
                        if (messageDate != null) {
                            currentRegAct.setMessageDate(messageDate.toLocalDateTime());
                        }
                        currentRegAct.setMessageType(rs.getString("message_type"));
                        Timestamp issuedDate = rs.getTimestamp("issued_date");
                        if (issuedDate != null) {
                            currentRegAct.setIssuedDate(issuedDate.toLocalDateTime());
                        }
                        currentRegAct.setStatus(rs.getString("status"));
                        Timestamp changeDate = rs.getTimestamp("change_date");
                        if (changeDate != null) {
                            currentRegAct.setChangeDate(changeDate.toLocalDateTime());
                        }
                        Timestamp validityDate = rs.getTimestamp("validity_date");
                        if (validityDate != null) {
                            currentRegAct.setValidityDate(validityDate.toLocalDateTime());
                        }
                        currentRegAct.setFactReason(rs.getString("fact_reason"));
                        currentRegAct.setLegalReason(rs.getString("legal_reason"));
                        currentRegAct.setAdministration(rs.getString("administration"));
                        currentRegAct.setAdministrativeUnit(rs.getString("administrative_unit"));
                        currentRegAct.setAdmPopular(rs.getString("adm_popular"));
                        currentRegAct.setObjectIdentification(rs.getString("object_identification"));
                        currentRegAct.setIsValid(rs.getBoolean("is_valid")); //todo check in db
                        result.add(currentRegAct);
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getRegActsByImportId - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getRegActsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all reg act objects for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegObject>
     */
    public List<RegObject> getRegActObjectsByImportId(String logId, WorkBean work) {
        log.info("{}: getRegActObjectsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegObject> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REG_ACT_OBJECTS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegObject currentRegObject = new RegObject();
                        currentRegObject.setId(rs.getLong("id"));
                        currentRegObject.setImpId(rs.getLong("imp_id"));
                        currentRegObject.setOpId(rs.getLong("op_id"));
                        currentRegObject.setExcelRow(rs.getInt("excel_row"));
                        currentRegObject.setRegActId(rs.getLong("reg_act_id"));
                        currentRegObject.setCadastre(rs.getString("cadastre"));
                        currentRegObject.setLocalPlace(rs.getString("local_place"));
                        currentRegObject.setRegulationDistrict(rs.getString("regulation_district"));
                        currentRegObject.setUpi(rs.getString("upi"));
                        currentRegObject.setPlanRegion(rs.getString("plan_region"));
                        currentRegObject.setPlanNumber(rs.getString("plan_number"));
                        currentRegObject.setKvsTerritory(rs.getString("kvs_territory"));
                        currentRegObject.setKvsNumber(rs.getString("kvs_number"));
                        currentRegObject.setTerritoryType(rs.getString("teritory_type"));
                        currentRegObject.setProtectedTerritory(rs.getString("protected_teritory"));
                        currentRegObject.setDescription(rs.getString("description"));
                        currentRegObject.setAddressId(rs.getLong("adress_id"));
                        currentRegObject.setIsValid(rs.getBoolean("is_valid"));
                        result.add(currentRegObject);
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getRegActObjectsByImportId - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getRegActObjectsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all reg act addresses for the current import id.
     *
     * @param logId
     * @param work
     * @return Map<Long, Address>
     */
    public Map<Long, Address> getRegActAddressesByImportId(String logId, WorkBean work) {
        log.info("{}: getRegActObjectAddressByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<Long, Address> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REG_ACT_ADDRESSES_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        Address currentAddress = new Address();
                        currentAddress.setId(rs.getLong("id"));
                        currentAddress.setImportId(rs.getLong("imp_id"));
                        currentAddress.setExcelRow(rs.getInt("excel_row"));
                        currentAddress.setOpId(rs.getLong("op_id"));
                        currentAddress.setCountry(rs.getString("country"));
                        currentAddress.setDistrict(rs.getString("district"));
                        currentAddress.setMunicipality(rs.getString("municipality"));
                        currentAddress.setSettlement(rs.getString("settlement"));
                        currentAddress.setVillage(rs.getString("village"));
                        currentAddress.setRegion(rs.getString("region"));
                        currentAddress.setFloor(rs.getString("floor"));
                        currentAddress.setFlatEntrance(rs.getString("flatentrance"));
                        currentAddress.setApartment(rs.getString("apartment"));
                        currentAddress.setSquareName(rs.getString("squarename"));
                        currentAddress.setSquareNum(rs.getString("squarenum"));
                        currentAddress.setAppComplexName(rs.getString("appcomplexname"));
                        currentAddress.setAppComplexNum(rs.getString("appcomplexnum"));
                        currentAddress.setQuarter(rs.getString("quarter"));
                        currentAddress.setStreetName(rs.getString("streetname"));
                        currentAddress.setStreetNum(rs.getString("streetnum"));
                        currentAddress.setFlatNumber(rs.getString("flatnum"));
                        currentAddress.setOtherluname(rs.getString("otherluname"));
                        currentAddress.setOtherlunum(rs.getString("otherlunum"));
                        currentAddress.setAddrPlaceName(rs.getString("addrplacename"));
                        currentAddress.setAddrPlaceNum(rs.getString("addrplacenum"));
                        currentAddress.setIsValid(rs.getBoolean("is_valid"));
                        result.put(currentAddress.getId(), currentAddress);
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getRegActObjectAddressByImportId - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getRegActObjectAddressByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all reg act customers for the current import id.
     *
     * @param logId
     * @param work
     * @return List<Customers>
     */
    public List<Customer> getRegActCustomersByImportId(String logId, WorkBean work) {
        log.info("{}: getRegActCustomersByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<Customer> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REG_ACT_CUSTOMERS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        Customer currentCustomer = new Customer();
                        currentCustomer.setId(rs.getLong("id"));
                        currentCustomer.setImpId(rs.getLong("imp_id"));
                        currentCustomer.setExcelRow(rs.getInt("excel_row"));
                        currentCustomer.setOpId(rs.getLong("op_id"));
                        currentCustomer.setRegActId(rs.getLong("reg_act_id"));
                        currentCustomer.setIdentifierType(rs.getString("identifier_type"));
                        currentCustomer.setIdentifier(rs.getString("identifier"));
                        currentCustomer.setCustomerType(rs.getString("customer_type"));
                        currentCustomer.setUnitName(rs.getString("unit_name"));
                        currentCustomer.setFirstName(rs.getString("first_name"));
                        currentCustomer.setMiddleName(rs.getString("middle_name"));
                        currentCustomer.setLastName(rs.getString("last_name"));
                        currentCustomer.setEmail(rs.getString("email"));
                        currentCustomer.setPhone(rs.getString("phone"));
                        currentCustomer.setCapacity(rs.getString("capacity"));
                        currentCustomer.setAddressId(rs.getLong("adress_id"));
                        currentCustomer.setIsValid(rs.getBoolean("is_valid"));
                        result.add(currentCustomer);
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getRegActCustomersByImportId - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getRegActCustomersByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all reg act application one documents for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegAppOneDocument>
     */
    public List<RegAppOneDocument> getRegActAppOneDocsByImportId(String logId, WorkBean work) {
        log.info("{}: getRegActAppOneDocsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegAppOneDocument> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REG_ACT_APP_ONE_DOCS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegAppOneDocument currentRegAppOneDocument = new RegAppOneDocument();
                        currentRegAppOneDocument.setId(rs.getLong("id"));
                        currentRegAppOneDocument.setImpId(rs.getLong("imp_id"));
                        currentRegAppOneDocument.setExcelRow(rs.getInt("excel_row"));
                        currentRegAppOneDocument.setOpId(rs.getLong("op_id"));
                        currentRegAppOneDocument.setRegActId(rs.getLong("reg_act_id"));
                        currentRegAppOneDocument.setDocumentId(rs.getLong("document_id"));
                        currentRegAppOneDocument.setType(rs.getString("type"));
                        currentRegAppOneDocument.setSubType(rs.getString("subtype"));
                        currentRegAppOneDocument.setIsValid(rs.getBoolean("is_valid"));
                        result.add(currentRegAppOneDocument);
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getRegActAppOneDocsByImportId - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getRegActAppOneDocsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all reg act application two documents for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegAppTwoDocument>
     */
    public List<RegAppTwoDocument> getRegActAppTwoDocsByImportId(String logId, WorkBean work) {
        log.info("{}: getRegActAppTwoDocsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegAppTwoDocument> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REG_ACT_APP_TWO_DOCS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegAppTwoDocument currentRegAppOneDocument = new RegAppTwoDocument();
                        currentRegAppOneDocument.setId(rs.getLong("id"));
                        currentRegAppOneDocument.setImpId(rs.getLong("imp_id"));
                        currentRegAppOneDocument.setExcelRow(rs.getInt("excel_row"));
                        currentRegAppOneDocument.setOpId(rs.getLong("op_id"));
                        currentRegAppOneDocument.setRegActId(rs.getLong("reg_act_id"));
                        currentRegAppOneDocument.setDocumentId(rs.getLong("document_id"));
                        currentRegAppOneDocument.setType(rs.getString("type"));
                        currentRegAppOneDocument.setSubType(rs.getString("subtype"));
                        currentRegAppOneDocument.setIsValid(rs.getBoolean("is_valid"));
                        result.add(currentRegAppOneDocument);
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getRegActAppTwoDocsByImportId - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getRegActAppTwoDocsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Get register code by import id.
     *
     * @param logId
     * @param work
     * @return String
     */
    public String getRegisterCodeByImportId(String logId, WorkBean work) {
        log.info("{}: getRegisterCodeByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        String result = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REGISTER_CODE_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        result = rs.getString("register_code");
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getRegisterCodeByImportId - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getRegisterCodeByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List < String>
     */
    public List<String> getRegActTypesByRegisterCode(String logId, WorkBean work, String registerCode) {
        log.info("{}: getRegActTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REG_ACT_TYPES)) {
                int i = 1;
                cs.setString(i++, registerCode);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("reg_act_code"));
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getRegActTypes - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getRegActTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     */
    public List<String> getAnnouncementTypes(String logId, WorkBean work) {
        log.info("{}: getAnnouncementTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ANNOUNCEMENT_TYPE)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getAnnouncementTypes - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getAnnouncementTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     */
    public List<String> getStatuses(String logId, WorkBean work) {
        log.info("{}: getStatuses - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_STATUSES)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getStatuses - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getStatuses - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     */
    public List<String> getAdministrationTypes(String logId, WorkBean work) {
        log.info("{}: getGetAdministrationTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ADMINISTRATION_TYPES)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getGetAdministrationTypes - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getGetAdministrationTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     */
    public List<String> getEkatte(String logId, WorkBean work) {
        log.info("{}: getEkatte - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_EKATTE)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("ekatte"));
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getEkatte - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getEkatte - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     */
    public List<String> getIssuer(String logId, WorkBean work) {
        log.info("{}: getIssuer - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ISSUER)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("cust_order"));
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getIssuer - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getIssuer - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     */
    public List<String> getProvince(String logId, WorkBean work) {
        log.info("{}: getProvince - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_PROVINCE)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("nsicode"));
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getProvince - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getProvince - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     */
    public List<String> getMunicipality(String logId, WorkBean work) {
        log.info("{}: getMunicipality - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_MUNICIPALITY)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("nsicode"));
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getMunicipality - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getMunicipality - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     */
    public List<String> getRegion(String logId, WorkBean work) {
        log.info("{}: getRegion - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REGION)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("nsicode"));
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getRegion - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getRegion - finished", logId);
        }
        return result;
    }

//    /**todo
//     * Get register act types by register code.
//     *
//     * @param logId
//     * @param work
//     * @return List<String>
//     */
//    public List<String> getCadident(String logId, WorkBean work) {
//        log.info("{}: getCadident - started", logId);
//        log.trace("{}: work: {}", logId, work);
//        List<String> result = new ArrayList<>();
//        try (Connection c = getConnection()) {
//            try (CallableStatement cs = c.prepareCall(GET_SETTLEMENT)) {
//                int i = 1;
//                cs.execute();
//                try (ResultSet rs = cs.getResultSet()) {
//                    if (rs.next()) {
//                        result.add(rs.getString("nsicode"));
//                    }
//                }
//            }
//        } catch (Exception e) {
//            //todo fix log
//            log.error("{}: getCadident - error", logId, e);
//            //throw e; //todo remove throw here
//        } finally {
//            log.info("{}: getCadident - finished", logId);
//        }
//        return result;
//    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     */
    public List<String> getTerritoryType(String logId, WorkBean work) {
        log.info("{}: getTerritoryType - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_TERRITORY_TYPE)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getTerritoryType - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getTerritoryType - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     */
    public List<String> getApplicant(String logId, WorkBean work) {
        log.info("{}: getApplicant - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_APPLICANT)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getApplicant - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getApplicant - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     */
    public List<String> getIdentifierType(String logId, WorkBean work) {
        log.info("{}: getIdentifierType - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_IDENTIFIER_TYPE)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getIdentifierType - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getIdentifierType - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     */
    public List<String> getCountry(String logId, WorkBean work) {
        log.info("{}: getCountry - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_COUNTRY)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            //todo fix log
            log.error("{}: getCountry - error", logId, e);
            //throw e; //todo remove throw here
        } finally {
            log.info("{}: getCountry - finished", logId);
        }
        return result;
    }

    /**
     * Change validity of act.
     * @param logId
     * @param work
     * @param regAct
     * @throws Exception
     */
    public void updateRegActValidity(String logId, WorkBean work, RegAct regAct) throws Exception {
        log.info("{}: updateRegActValidity - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: regAct: {}", logId, regAct);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(UPDATE_REG_ACT_VALIDITY)) {
                int i = 1;
                cs.setBoolean(i++, false);
                cs.setLong(i++, regAct.getId());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Invalid transition 0 updates");
                }
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: updateRegActValidity - error", logId, e);
            //throw e;
            //todo log
        } finally {
            log.info("{}: updateRegActValidity - finished", logId);
        }
    }

    /**
     * Change validity of act.
     * @param logId
     * @param work
     * @param regObject
     * @throws Exception
     */
    public void updateRegActObjectValidity(String logId, WorkBean work, RegObject regObject) throws Exception {
        log.info("{}: updateRegActObjectValidity - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: regAct: {}", logId, regObject);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(UPDATE_REG_ACT_OBJECT_VALIDITY)) {
                int i = 1;
                cs.setBoolean(i++, false);
                cs.setLong(i++, regObject.getId());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Invalid transition 0 updates");
                }
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: updateRegActObjectValidity - error", logId, e);
            //throw e;
            //todo log
        } finally {
            log.info("{}: updateRegActObjectValidity - finished", logId);
        }
    }

    /**
     * Change validity of act.
     * @param logId
     * @param work
     * @param customer
     * @throws Exception
     */
    public void updateCustomerValidity(String logId, WorkBean work, Customer customer) throws Exception {
        log.info("{}: updateCustomerValidity - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: regAct: {}", logId, customer);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(UPDATE_CUSTOMER_VALIDITY)) {
                int i = 1;
                cs.setBoolean(i++, false);
                cs.setLong(i++, customer.getId());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Invalid transition 0 updates");
                }
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: updateCustomerValidity - error", logId, e);
            //throw e;
            //todo log
        } finally {
            log.info("{}: updateCustomerValidity - finished", logId);
        }
    }

    /**
     * Change validity of act.
     * @param logId
     * @param work
     * @param address
     * @throws Exception
     */
    public void updateAddressValidity(String logId, WorkBean work, Address address) throws Exception {
        log.info("{}: updateAddressValidity - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: regAct: {}", logId, address);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(UPDATE_ADDRESS_VALIDITY)) {
                int i = 1;
                cs.setBoolean(i++, false);
                cs.setLong(i++, address.getId());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Invalid transition 0 updates");
                }
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: updateAddressValidity - error", logId, e);
            //throw e;
            //todo log
        } finally {
            log.info("{}: updateAddressValidity - finished", logId);
        }
    }

    /**
     * Returns if there are any error/warning messages for import.
     * @param logId
     * @param work
     * @return Boolean
     * @throws Exception
     */
    public Boolean hasErrorWarningMessages(String logId, WorkBean work) throws Exception {
        log.info("{}: hasErrorWarningMessages - started", logId);
        log.trace("{}: work: {}", logId, work);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(HAS_ERROR_WARNING_MESSAGES)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        return rs.getBoolean(1);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: hasErrorWarningMessages - error", logId, e);
            throw e;
        } finally {
            log.info("{}: hasErrorWarningMessages - finished", logId);
        }
        return false;
    }
}
