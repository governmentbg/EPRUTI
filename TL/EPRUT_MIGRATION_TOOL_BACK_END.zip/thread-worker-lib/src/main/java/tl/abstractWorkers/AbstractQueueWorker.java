package tl.abstractWorkers;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Created by dbyalev on 22/02/2019.
 **/
public abstract class AbstractQueueWorker<T> {
    private final Logger logger = Logger.getLogger(AbstractQueueWorker.class.getName());
    private final int nThreads;
    private final List<PoolWorker> threads;
    protected final ConcurrentLinkedDeque<T> queue = new ConcurrentLinkedDeque<>();
    private ScheduledExecutorService execService = Executors.newScheduledThreadPool(1);


    /**
     * Initialize abstract que with some number of threads and delays.
     *
     * @param nThreads             number of treads
     * @param initialDelay         delay in see {@link  TimeUnit}.
     * @param periodOfQueueRefresh refresh period in see {@link  TimeUnit}.
     * @param timeUnit             time unit.
     */
    public AbstractQueueWorker(int nThreads, Long initialDelay, Long periodOfQueueRefresh, TimeUnit timeUnit) {
        this.nThreads = nThreads;

        threads = new ArrayList<>();
        for (int i = 0; i < nThreads; i++) {
            threads.add(new PoolWorker());
            threads.get(i).setName("QueueWorker No " + (i + 1));
            threads.get(i).start();
        }
        execute(initialDelay, periodOfQueueRefresh, timeUnit);
    }

    private void execute(Long initialDelay, Long periodOfQueueRefresh, TimeUnit timeUnit) {
        //The repetitive task, say to update Database
        execService.scheduleAtFixedRate(() -> {
            try {
                synchronized (queue) {
                    updateWorkerQueue();
                    queue.notifyAll();
                }
            } catch (Exception e) {
                System.out.println("Updating queue exception: " + e);
            }
        }, initialDelay, periodOfQueueRefresh, timeUnit);
    }

    private final class PoolWorker extends Thread {

        private volatile boolean hasToWork = true;

        public void run() {
            T firstElementFromQueue = null;
            String uuid = UUID.randomUUID().toString();
            while (hasToWork) {
                synchronized (queue) {
                    try {
                        while (queue.isEmpty()) {
                            queue.wait();
                        }
                        firstElementFromQueue = queue.removeFirst();
                    } catch (InterruptedException ignored) {
                        if (!hasToWork) {
                            break;
                        }
                    }
                }
                if (firstElementFromQueue == null) {
                    continue;
                }
                if (!Thread.interrupted()) {
                    try {
                        workerStarted(uuid, firstElementFromQueue);
                        workerExecutedMethod(uuid, firstElementFromQueue);
                        workerFinished(uuid, firstElementFromQueue);
                    } catch (RuntimeException e) {
                        workerExceptionHandling(uuid, firstElementFromQueue, e);
                    }
                }

            }
        }

        public void stopTheThreadWorker() {
            this.hasToWork = false;
        }
    }

    /**
     * The method is called when the queue is updated
     * this method need to add elements to the queue otherwise the workers wont work.
     */
    protected abstract void updateWorkerQueue();

    /**
     * This method needs to be overridden to show what work has to be done with the element.
     *
     * @param uuid                  - log id
     * @param firstElementFromQueue - The element from Queue that is currently working
     */
    protected abstract void workerExecutedMethod(String uuid, T firstElementFromQueue);

    /**
     * This method is called after the worker encountered error.
     *
     * @param uuid                  - log id
     * @param firstElementFromQueue - The element from Queue that is currently working
     * @param e                     - exception
     */
    protected void workerExceptionHandling(String uuid, T firstElementFromQueue, Exception e) {
        logger.log(Level.SEVERE, String.format("%s - ERROR : %s", uuid, firstElementFromQueue.toString()), e);
    }

    /**
     * This method is called after the work is started successfully.
     *
     * @param uuid                  - log id
     * @param firstElementFromQueue - The element from Queue that is currently working
     */
    protected void workerStarted(String uuid, T firstElementFromQueue) {
        logger.log(Level.FINE, String.format("%s - Started : %s", uuid, firstElementFromQueue.toString()));
    }

    /**
     * This method is called after the work is finished successfully.
     *
     * @param uuid                  - log id
     * @param firstElementFromQueue - The element from Queue that is currently working
     */
    protected void workerFinished(String uuid, T firstElementFromQueue) {
        logger.log(Level.FINE, String.format("%s - Finished : %s", uuid, firstElementFromQueue.toString()));
    }

    /**
     * The method need to be called when the Worker implementation is destroyed.
     * otherwise the threads might not close
     *
     * @throws Exception
     */
    public final void destroy() throws Exception {
        try {
            execService.shutdown();
            for (PoolWorker thread : threads) {
                thread.stopTheThreadWorker();
                thread.interrupt();
            }
        } catch (Exception e) {
            throw new Exception(e);
        }
    }

    public int getNumberOfWorkers() {
        return nThreads;
    }

}
