//package tl.abstractWorkers;
//
//import java.math.BigDecimal;
//import java.util.concurrent.TimeUnit;
//
////public class ExampleQueWorker extends AbstractQueueWorker<BigDecimal> {
////
////    /**
////     * Initialize abstract que with some number of threads and delays.
////     *
////     * @param nThreads             number of treads
////     * @param initialDelay         delay in see {@link  TimeUnit}.
////     * @param periodOfQueueRefresh refresh period in see {@link  TimeUnit}.
////     * @param timeUnit             time unit.
////     */
////    public ExampleQueWorker(int nThreads, Long initialDelay, Long periodOfQueueRefresh,
////                            TimeUnit timeUnit) {
////        super(nThreads, initialDelay, periodOfQueueRefresh, timeUnit);
////    }
////
////    @Override
////    protected void updateWorkerQueue() {
////        //dataBase.getIdsForImportExcel().stream().distinct().filter(e -> !queue.contains(e)).forEach(queue::addLast);
////        //dataBase.getIdsForImportXml().stream().distinct().filter(e -> !queue.contains(e)).forEach(queue::addLast);
////        //dataBase.getIdsForImportData().stream().distinct().filter(e -> !queue.contains(e)).forEach(queue::addLast);
////        //dataBase.getIdsForImportTransfer().stream().distinct().filter(e -> !queue.contains(e)).forEach(queue::addLast)
////    }
////
////    @Override
////    protected void workerExecutedMethod(String uuid, BigDecimal firstElementFromQueue) {
////        BigDecimal currentId = new BigDecimal(-1);
//        boolean doWork = true;
//        try {
//            if (dataBase.getIsJrDataReadyToPrint(firstElementFromQueue).equalsIgnoreCase("Y")) {
//                try {
//                    dataBase.massPrintSetStatusStartGenerating(firstElementFromQueue, IpInfoConfig.getSignature());
//                } catch (Exception e) {
//                    if (dataBase.getIsJrDataReadyToPrint(firstElementFromQueue).equalsIgnoreCase("Y")) {
//                        throw e;
//                    } else {
//                        doWork = false;
//                    }
//                }
//                if (doWork) {
//                 // do ctual work
//                }
//            }
//        } catch (RuntimeException | DBGeoResException e) {
//            try {
//                dataBase.massPrintSetStatusStartErrorWhileGenerating(firstElementFromQueue, IpInfoConfig.getSignature());
//            } catch (Exception ex) {
//                try {
//                    massPrintService.logServiceError(new SecurityBean(), uuid, System.currentTimeMillis(), errorMsg);
//                } catch (IOException e1) {
//                }
//                this.workerExceptionHandling(uuid, firstElementFromQueue, ex);
//            }
//        }
//    }
////    }
//@Override
//    protected void workerExceptionHandling(String uuid, BigDecimal firstElementFromQueue, Exception e) {
//        logger.error(String.format("%s - MassPrint with mapDataId : %s ERROR %s", uuid, firstElementFromQueue, e), e);
//    }
//
//    @Override
//    protected void workerStarted(String uuid, BigDecimal firstElementFromQueue) {
//        logger.debug(String.format("%s - MassPrint with mapDataId : %s has STARTED working", uuid, firstElementFromQueue));
//    }
//
//    @Override
//    protected void workerFinished(String uuid, BigDecimal firstElementFromQueue) {
//        logger.debug(String.format("%s - MassPrint with mapDataId : %s has FINISHED working", uuid, firstElementFromQueue));
//    }
////}
