package com.eprut.transfer;

import com.eprut.db.DBConnector;
import com.eprut.db.config.IpInfoConfig;
import com.eprut.transfer.constants.States;
import com.eprut.transfer.db.TransferDb;
import com.eprut.transfer.worker.TransferWorker;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import lombok.extern.slf4j.Slf4j;
import tl.abstractWorkers.AbstractQueueWorker;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

@Slf4j
public class TransferWrapper implements ServletContextListener {


    private final int nThreads;
    private final long initialDelay;
    private final long periodOfWaitTime;
    private DataSource dataSource;
    private TransferDb database;

    private String jndiName;
    private AbstractQueueWorker worker;

    /**
     * Initialzation of worker for extracting xml from the zip; validating the content; loading it into db.
     *
     * @throws Exception
     */
    public TransferWrapper() throws Exception {
        Properties env = new Properties();
        try {
            env.load(TransferWrapper.class.getClassLoader().getResourceAsStream("default.properties"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        this.nThreads = Integer.parseInt(env.getProperty("worker.threads"));
        this.initialDelay = Long.parseLong(env.getProperty("worker.initialWaitTime"));
        this.periodOfWaitTime = Long.parseLong(env.getProperty("worker.periodOfWaitTime"));
        jndiName = env.getProperty("jndi.name");


        dataSource = DBConnector.initDataSource(jndiName);
        database = new TransferDb();
        worker = new TransferWorker(nThreads, initialDelay, periodOfWaitTime, TimeUnit.MINUTES, database);
    }


    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContextListener.super.contextInitialized(sce);
        IpInfoConfig ipInfoConfig = new IpInfoConfig();
        try {
            ipInfoConfig.onApplicationEvent();
            try (Connection connDocStore = DBConnector.getConnection()) {
                database.notifyDbServerIsUp(connDocStore, IpInfoConfig.getSignature(), States.TRANSFER_ERROR.name(), States.TRANSFER_ACCEPTED.name(), States.TRANSFER_PREPARING.name(),
                        States.TRANSFER_WORKING.name());
                if (connDocStore == null) {
                    log.error("can not open db connection Error while notifying the server is UP to the DB");
                }
                connDocStore.commit();
            } catch (SQLException e) {
                log.error("Error while notifying the server is UP to the DB", e);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        try {
            worker.destroy();
        } catch (Exception e) {
            log.error("Error while destroying context", e);
        }
    }


}
