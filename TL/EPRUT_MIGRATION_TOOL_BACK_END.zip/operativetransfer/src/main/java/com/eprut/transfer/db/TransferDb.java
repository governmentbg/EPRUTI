package com.eprut.transfer.db;

import com.eprut.db.config.IpInfoConfig;
import com.eprut.db.impl.DatabaseManager;
import com.eprut.db.impl.WorkBean;
import com.eprut.transfer.constants.States;

import java.util.List;

public class TransferDb extends DatabaseManager {

    /**
     * Get predefined work items.
     *
     * @param logId
     * @return work item.
     * @throws Exception
     */
    public List<WorkBean> getReadyToStart(String logId) throws Exception {
        return super.getReadyToStart(logId, States.TRANSFER_ACCEPTED.name());
    }

    @Override
    public WorkBean start(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.TRANSFER_PREPARING.name(), IpInfoConfig.getSignature());
    }

    @Override
    public boolean checkIfNotStarted(String logId, WorkBean work) throws Exception {
        return checkIfNotStarted(logId, work, States.TRANSFER_ACCEPTED.name());
    }

    @Override
    public WorkBean finishedPreparing(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.TRANSFER_WORKING.name());
    }

    @Override
    public WorkBean finish(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.TRANSFER_DONE.name());
    }

    @Override
    public WorkBean error(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.TRANSFER_ERROR.name());
    }

    @Override
    public WorkBean error(String logId, WorkBean work, Exception e) throws Exception {
        return changeStatusToError(logId, work, States.TRANSFER_ERROR.name(), e);
    }
}
