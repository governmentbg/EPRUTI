package com.eprut.transfer.constants;

public enum States {

    TRANSFER_ACCEPTED,
    TRANSFER_PREPARING,
    TRANSFER_WORKING,
    TRANSFER_DONE,
    TRANSFER_ERROR
}
