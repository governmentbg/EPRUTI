package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum ApplicationTwoColumns {
    NUM_ACT(0, "Номер на акта *"),                           //Номер на акта
    DOC_TYPE(1, "Вид на акта*"),                             //Вид на акта
    APPLICATION_TWO_DOCUMENT_COPIES(2,
            "Приложения 2 (Копия на документи (административни актове, становища и други), " +
                    "които са основание за издаване на административния) *"), //Приложения 2
    SUBCATEGORY_FOR_APPROVED_INVESTMENT_PLAN(3, "Подкатегория само при одобрен инвестиционен проект"),
    FILE_NAME(4, "Име на файл *");                           //Име на файл

    private final int index;
    private final String columnName;

    ApplicationTwoColumns(int index, String columnName) {
        this.index = index;
        this.columnName = columnName;
    }
}
