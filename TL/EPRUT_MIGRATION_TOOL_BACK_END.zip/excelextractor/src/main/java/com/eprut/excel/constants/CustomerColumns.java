package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum CustomerColumns implements ColumnsEnum {
    NUM_ACT(0, "Номер на акта *", "numAct", "string"),                           //Номер на акта
    CUST_TYPE(1, "Вид на заявителя *", "customerType", "nomenclature"),          //Вид на заявителя
    CUST_QUALITY(2, "Качество на заявителя", "capacity", "nomenclature"),        //Качество на заявителя
    ID_TYPE(3, "Вид на идентификатора *", "identifierType", "nomenclature"),     //Вид на идентификатора
    PUBLIC_ID(4, "Публичен идентификатор", "identifier", "string"),              //Публичен идентификатор
    CUST_ALIAS(5, "Наименование", "unitName", "string"),                         //Наименование - отключено при избор Булстат/ЕИК от поле Вид на идентификатор
    FIRSTNAME(6, "Име", "firstName", "string"),                                  //Име
    SURNAME(7, "Презиме", "middleName", "string"),                               //Презиме
    LASTNAME(8, "Фамилия", "lastName", "string"),                                //Фамилия
    EMAIL(9, "Електронен адрес", "email", "string"),                             //Имейл
    PHONE(10, "Телефон", "phone", "string"),                                     //Телефон
    COUNTRY(11, "Държава", "country", "nomenclature"),                           //Държава
    DISTRICT(12, "Област", "district", "string"),                                //Област
    MUNICIPALITY(13, "Община", "municipality", "string"),                        //Община
    SETTLEMENT(14, "Населено място", "settlement", "string"),                    //Населено място
    REGION(15, "Район", "region", "string"),                                     //Район - ЕКАТТЕ
    VILLAGE(16, "Селищно образувание", "village", "string");                     //Селищно образувание

    private final int index;
    private final String columnName;
    private final String field;
    private final String type;

    CustomerColumns(int index, String columnName, String field, String type) {
        this.index = index;
        this.columnName = columnName;
        this.field = field;
        this.type = type;
    }
}
