package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum ContestingColumns {
    NUM_ACT(0, "Номер на акта *", "actNum"),                                  //Номер на акта
    TEXT_CONTESTING(1, "Текстова част на оспорването", "contestingDesc"),     //Текстова част на оспорването
    GRAPHICAL_CONTESTING(2, "Графична част на оспорването", null);            //Графична част на оспорването

    private final int index;
    private final String columnName;
    private final String field;

    ContestingColumns(int index, String columnName, String field) {
        this.index = index;
        this.columnName = columnName;
        this.field = field;
    }
}
