package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum MandatorySheets {
    ACT_SHEET("Акт", 2),
    OBJECT_SHEET("Обект", 1),
    CONTESTING_SHEET("Оспорване", 1),
    CUSTOMER_SHEET("ЗаявителВъзложител", 2),
    SETTLEMENT("Населено място", 0),
    VILLAGE("Селищно образувание", 0);

    private final String sheetName;
    private final int columnNameRow;

    MandatorySheets(String sheetName, int columnNameRow) {
        this.sheetName = sheetName;
        this.columnNameRow = columnNameRow;
    }

}
