package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum ApplicationOneColumns {
    NUM_ACT(0, "Номер на акта *"),                                      //Номер на акта
    DOC_TYPE(1, "Вид на акта*"),                                        //Вид на акта
    LAYOUT_PLANS_PROJECTS(2, "Проекти на устройствени планове"),        //Проекти на устройствени планове
    APPLICATION_ONE_SUBCATEGORY(3, "Приложения 1 (подкатегорая) *"),    //Приложения 1 (подкатегорая)
    FILE_NAME(4, "Име на файл *");                                      //Име на файл

    private final int index;
    private final String columnName;

    ApplicationOneColumns(int index, String columnName) {
        this.index = index;
        this.columnName = columnName;
    }

}
