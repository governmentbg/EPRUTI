package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum OptionalSheets {

    APPLICATION_ONE_SHEET("Приложение 1", 0),
    APPLICATION_TWO_SHEET("Приложение 2", 0);

    private final String sheetName;
    private final int columnNameRow;

    OptionalSheets(String sheetName, int columnNameRow) {
        this.sheetName = sheetName;
        this.columnNameRow = columnNameRow;
    }
}
