package com.eprut.excel.constants;

public enum States {

    EX_UPLOADED,
    EX_PREPARING,
    EX_WORKING,
    DATA_UPLOADED,
    EX_ERROR
}
