package com.eprut.excel.constants;

public interface ColumnsEnum {
    /**
     * Get index of enumeration.
     * @return int
     */
    int getIndex();

    /**
     * Get field of enumeration.
     * @return String
     */
    String getField();

    /**
     * Get type of enumeration.
     * @return String
     */
    String getType();

    /**
     * Get name of column.
     * @return String
     */
    String getColumnName();
}
