package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum ObjectColumns implements ColumnsEnum {
    NUM_ACT(0, "Номер на акта *", "numAct", "string"),                                              //Номер на акта
    DISTRICT(1, "Област", "district", "string"),                                                    //Област
    MUNICIPALITY(2, "Община", "municipality", "string"),                                            //Община
    SETTLEMENT(3, "Населено място", "settlement", "string"),                                        //Населено място
    REGION(4, "Район", "region", "string"),                                                         //Район
    VILLAGE(5, "Селищно образувание", "village", "string"),                                         //Селищно образувание
    CADIDENT(6, "Кадастрален идентификатор", "cadastre", "string"),                                 //Кадастрален идентификатор
    LOCAL_PLACE(7, "Местност", "localPlace", "string"),                                             //Местност
    REG_DISTRICT(8, "Квартал по регулация", "regulationDistrict", "string"),                        //Квартал по регулация
    UPI(9, "УПИ", "upi", "string"),                                                                 //УПИ
    CAD_REGION(10, "Планоснимачен район", "planRegion", "string"),                                  //Планоснимачен район
    CAD_NUMBER(11, "Планоснимачен номер", "planNumber", "string"),                                  //Планоснимачен номер
    RPM_PLACENAME(12, "Местност КВС", "kvsTerritory", "string"),                                    //Местност КВС
    RPM_NUMBER(13, "Номер КВС", "kvsNumber", "string"),                                             //Номер КВС
    TERRITORY_TYPE(14, "Вид територия", "territoryType", "nomenclature"),                           //Вид територия
    PROTECTED_AREA(15, "Защитена територия", "protectedTerritory", "string"),                       //Защитена територия
    ADDITIONAL_DESCRIPTION(16, "Допълнително описание на обекта", "description", "string");         //Допълнително описание на обекта

    private final int index;
    private final String columnName;
    private final String field;
    private final String type;

    ObjectColumns(int index, String columnName, String field, String type) {
        this.index = index;
        this.columnName = columnName;
        this.field = field;
        this.type = type;
    }
}
