package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum ActColumns {
    ACT_TYPE(0, "Вид на акта *", "actType", "nomenclature"),                                                    //Вид на акта
    NUM_ACT(1, "Номер на акта *", "actNum", "string"),                                                          //Номера на акта
    CREATE_DATE(2, "Дата на акта *", "actDate", "date"),                                                        //Дата на акта
    MESSAGE_DATE(3, "Дата на съобщаване на акта", "messageDate", "date"),                                       //Дата на съобщаване
    MESSAGE_TYPE(4, "Вид на съобщаване", "messageType", "nomenclature"),                                        //Вид на съобщаване
    ISSUED_DATE(5, "Дата влязъл в сила", "issuedDate", "date"),                                                 //Дата на влизане в сила
    DOC_STATUS(6, "Състояние *", "status", "nomenclature"),                                                     //Състояние
    CHANGE_DATE(7, "Дата на промяна", "changeDate", "date"),                                                    //Дата на промяна
    FACT_REASON(8, "Фактическо основание", "factReason", "string"),                                             //Фактическо основание
    LEGAL_REASON(9, "Правно основание", "legalReason", "string"),                                               //Правно основание
    VALIDITY_DATE(10, "Валиден до *", "validityDate", "date"),                                                  //Валиден до
    DESCRIPTION(11, "Описание/Наименование на обект*", "objectIdentification", "string"),                       //Описание/Наименование на обект
    ADMINISTRATION(12, "Администрация  *", "administration", "nomenclature"),                                   //Администрация
    TERRITORY(13, "Територия на компетентност  *", "admPopular", "string"),                                     //Територия на компетентност
    ADMINISTRATIVE_UNIT(14, "Административен орган *", "administrativeUnit", "nomenclature"),                   //Административен орган
    DOCUMENT_ONE(15, "Документ 1 (Копие на административен акт със заличени данни)  *", null, "file"),          //Документ 1(Копие на административен акт със заличени данни)
    DOCUMENT_TWO(16, "Документ 2 (Копие на административен акт)  *", null, "file"),                             //Документ 2(Копие на административен акт)
    APPLICATION_ONE(17, "Приложения 1 (Проекти на устройствени планове)", null, "nomenclature"),                //Приложения 1 (Проекти на устройствени планове)
    CONCATENATION(18, "", null, "string");

    private final int index;
    private final String columnName;
    private final String field;
    private final String type;

    ActColumns(int index, String columnName, String field, String type) {
        this.index = index;
        this.columnName = columnName;
        this.field = field;
        this.type = type;
    }
}
