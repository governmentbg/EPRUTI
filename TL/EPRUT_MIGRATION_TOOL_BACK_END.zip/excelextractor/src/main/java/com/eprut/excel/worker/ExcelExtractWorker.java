package com.eprut.excel.worker;

import com.eprut.db.beans.Address;
import com.eprut.db.beans.Customer;
import com.eprut.db.beans.Document;
import com.eprut.db.beans.RegAct;
import com.eprut.db.beans.RegActDocumentOne;
import com.eprut.db.beans.RegActDocumentTwo;
import com.eprut.db.beans.RegAppOneDocument;
import com.eprut.db.beans.RegAppTwoDocument;
import com.eprut.db.beans.RegContDocument;
import com.eprut.db.beans.RegObject;
import com.eprut.db.impl.WorkBean;
import com.eprut.excel.constants.ActColumns;
import com.eprut.excel.constants.AddressDetailsColumns;
import com.eprut.excel.constants.ApplicationOneColumns;
import com.eprut.excel.constants.ApplicationTwoColumns;
import com.eprut.excel.constants.ColumnsEnum;
import com.eprut.excel.constants.ContestingColumns;
import com.eprut.excel.constants.CustomerColumns;
import com.eprut.excel.constants.MandatorySheets;
import com.eprut.excel.constants.NomenclatureSheets;
import com.eprut.excel.constants.ObjectColumns;
import com.eprut.excel.constants.OptionalSheets;
import com.eprut.excel.db.ExcelExtractDb;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.SheetVisibility;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.tika.Tika;
import tl.abstractWorkers.AbstractQueueWorker;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
public class ExcelExtractWorker extends AbstractQueueWorker<WorkBean> {

    private ExcelExtractDb database;

    private static final String XLSX_EXTENSION = ".xlsx";
    private static final String XLS_EXTENSION = ".xls";

    private static final int MIN_SHEETS = 6;
    private static final int MAX_SHEETS = 8;
    private static final String PUP_VALUE = "Подробен устройствен план (ПУП) или изменение на такъв";
    private static final String OUP_MUNICIPALITY_VALUE =
            "Общ устройствен план на община и на част от община (ОУП) или изменение на такъв";
    private static final String OUP_CITY_VALUE =
            "Общ устройствен план на град със землището му и на селищно образувание с национално значение (ОУП) или изменение на такъв";
    private static final int ACT_SHEET = 0;
    private static final int OBJECT_SHEET = 1;
    private static final int CONTESTING_SHEET = 2;
    private static final int CUSTOMER_SHEET = 3;
    private static final String APPLICATION_ONE_SHEET = "Приложение 1";
    private static final String APPLICATION_TWO_SHEET = "Приложение 2";
    private static final int ROWS = 4999;
    private static final int DEFAULT_BUFFER_SIZE = 8192;

    /**
     * Initialize abstract que with some number of threads and delays.
     *
     * @param nThreads             number of treads
     * @param initialDelay         delay in see {@link  TimeUnit}.
     * @param periodOfQueueRefresh refresh period in see {@link  TimeUnit}.
     * @param timeUnit             time unit.
     */
    public ExcelExtractWorker(int nThreads, Long initialDelay, Long periodOfQueueRefresh,
                              TimeUnit timeUnit, ExcelExtractDb database) {
        super(nThreads, initialDelay, periodOfQueueRefresh, timeUnit);
        this.database = database;
    }

    @Override
    protected void updateWorkerQueue() {
        String logId = UUID.randomUUID().toString();
        try {
            database.getReadyToStart(logId).stream().distinct().filter(e -> !queue.contains(e)).forEach(queue::addLast);
        } catch (Exception e) {
            log.error("{}: updateWorkerQueue error", logId, e);
        }
    }

    @Override
    protected void workerExecutedMethod(String logId, WorkBean firstElementFromQueue) {
        boolean doWork = true;
        try {
            if (database.checkIfNotStarted(logId, firstElementFromQueue)) {
                try {
                    database.start(logId, firstElementFromQueue);
                } catch (Exception e) {
                    if (database.checkIfNotStarted(logId, firstElementFromQueue)) {
                        throw e;
                    } else {
                        doWork = false;
                    }
                }
                if (doWork) {
                    String archivePath = database.getZipArchivePath(logId, firstElementFromQueue);

                    if (archivePath == null) {
                        database.logErrorMessage(logId, firstElementFromQueue,
                                "Възникна грешка при намирането на път към архив.");
                        throw new IllegalStateException(
                                "Archive path is null for WorkBean with id: " + firstElementFromQueue.getId());
                    }

                    File archive = new File(archivePath);
                    if (!archive.exists()) {
                        database.logErrorMessage(logId, firstElementFromQueue,
                                "Възникна грешка при намирането на архив.");
                        throw new FileNotFoundException();
                    }
                    Set<String> visibleSheetNames = new HashSet<>();

                    Workbook workbook = extractExcelFile(logId, firstElementFromQueue, archive); // extract zip

                    validateExcelRegisterType(logId, firstElementFromQueue, workbook);
                    validateExcelStructure(logId, firstElementFromQueue, workbook,
                            visibleSheetNames); //validate excel structure
                    validateExcelSheetColumns(logId, firstElementFromQueue, workbook,
                            visibleSheetNames); //validate excel sheet columns

                    database.finishedPreparing(logId, firstElementFromQueue);

                    Map<String, Long> actIds =
                            processActExcelSheet(logId, workbook, firstElementFromQueue, archivePath);
                    processObjectExcelSheet(logId, workbook, firstElementFromQueue, actIds);
                    processContestingExcelSheet(logId, workbook, firstElementFromQueue, archivePath, actIds);
                    processCustomerExcelSheet(logId, workbook, firstElementFromQueue, actIds);

                    if (visibleSheetNames.contains(APPLICATION_ONE_SHEET)) {
                        processApplicationOneExcelSheet(logId, workbook, firstElementFromQueue, archivePath, actIds);
                    }

                    if (visibleSheetNames.contains(APPLICATION_TWO_SHEET)) {
                        processApplicationTwoExcelSheet(logId, workbook, firstElementFromQueue, archivePath, actIds);
                    }

                    database.finish(logId, firstElementFromQueue);
                }
            }
        } catch (Exception e) {
            try {
                database.error(logId, firstElementFromQueue, e);
            } catch (Exception ex) {
                try {
                    database.logErrorMessage(logId, firstElementFromQueue,
                            "Възникна грешка при опит за стартиране на оброботка.", ex);
                } catch (Exception e1) {
                    //ignore.
                }
                this.workerExceptionHandling(logId, firstElementFromQueue, ex);
            }
        }
    }

    private Workbook extractExcelFile(String logId, WorkBean work, File archive) throws Exception {
        log.info("{}: extractExcelFile - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: archive: {}", logId, archive);
        try (FileInputStream fis = new FileInputStream(archive);
             ZipArchiveInputStream zis = new ZipArchiveInputStream(fis);
             ByteArrayOutputStream xlsxBuffer = new ByteArrayOutputStream()) {

            ZipArchiveEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                String entryName = entry.getName();
                if (!entry.isDirectory() && (entryName.endsWith(XLS_EXTENSION) || entryName.endsWith(XLSX_EXTENSION))) {
                    zis.transferTo(xlsxBuffer);
                    //# Кръпка!
                    try (InputStream is = new ByteArrayInputStream(xlsxBuffer.toByteArray())) {
                        return WorkbookFactory.create(is);
                    }
                }
            }
            database.logErrorMessage(logId, work, "Възникна грешка при отварянето на excel файла.");
            log.error("{} extractExcelFile - error: {}", logId, "could not open the excel file.");
            throw new IllegalStateException("No Excel file found in the archive.");
        } finally {
            log.info("{}: extractExcelFile - finished", logId);
        }
    }

    private void validateExcelRegisterType(String logId, WorkBean work, Workbook workbook) throws Exception {
        log.info("{}: validateExcelRegisterType - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: workbook: {}", logId, workbook);
        try {
            Sheet registerTypeSheet = workbook.getSheet(NomenclatureSheets.REG_TYPE_SHEET.getSheetName());
            Row row = registerTypeSheet.getRow(0);
            if (row == null) {
                throw new IllegalStateException("Excel sheet is empty or does not contain the required row.");
            }

            Cell registerTypeCell = row.getCell(0);
            if (registerTypeCell != null && registerTypeCell.getCellType() != CellType.BLANK) {
                String registerCode = database.getImportRegisterCode(logId, work);
                if (!registerCode.equals(registerTypeCell.getStringCellValue())) {
                    String errorMessage = "Възникна грешка - excel шаблонът не е за този регистър.";
                    database.logErrorMessage(logId, work, errorMessage);
                    log.error("{}: validateExcelRegisterType - {}", logId, errorMessage);
                    throw new IllegalStateException("The excel is not for register with code: " + registerCode);
                }
            }
            database.logInfoMessage(logId, work, "Валидиран тип на регистър.");
        } catch (Exception e) {
            log.error("{}: validateExcelRegisterType - error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: validateExcelRegisterType - finished", logId);
        }
    }


    private void validateExcelStructure(String logId, WorkBean work, Workbook workbook, Set<String> visibleSheetNames)
            throws Exception {
        log.info("{}: validateExcelStructure - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: workbook: {}", logId, workbook);
        List<String> sheetNames = new ArrayList<>();
        for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
            if (workbook.getSheetVisibility(i) == SheetVisibility.VISIBLE) {
                visibleSheetNames.add(workbook.getSheetName(i));
            }
            sheetNames.add(workbook.getSheetName(i));
        }

        int visibleSheets = visibleSheetNames.size();
        if (visibleSheets < MIN_SHEETS || visibleSheets > MAX_SHEETS) {
            database.logErrorMessage(logId, work, "Възникна грешка - невалиден брой работни листове.");
            throw new IllegalStateException("Invalid number of sheets: " + visibleSheets);
        }

        Set<String> mandatorySheetNames = Arrays.stream(MandatorySheets.values())
                .map(MandatorySheets::getSheetName)
                .collect(Collectors.toSet());
        if (!visibleSheetNames.containsAll(mandatorySheetNames)) {
            Set<String> missingSheets = new HashSet<>(mandatorySheetNames);
            missingSheets.removeAll(visibleSheetNames);
            database.logErrorMessage(logId, work,
                    "Възникна грешка - липсват задължителни работни листове: " + missingSheets);
            throw new IllegalArgumentException("Missing mandatory sheets: " + missingSheets);
        }

        Set<String> optionalSheetNames = Arrays.stream(OptionalSheets.values())
                .map(OptionalSheets::getSheetName)
                .collect(Collectors.toSet());
        Set<String> remainingSheets = new HashSet<>(visibleSheetNames);
        remainingSheets.removeAll(mandatorySheetNames);
        if (!optionalSheetNames.containsAll(remainingSheets)) {
            Set<String> invalidSheets = new HashSet<>(remainingSheets);
            invalidSheets.removeAll(optionalSheetNames);
            database.logErrorMessage(logId, work, "Възникна грешка - невалидни работни листове: " + invalidSheets);
            throw new IllegalArgumentException("Invalid optional sheets: " + invalidSheets);
        }

        Set<String> invalidNomenclatureSheets = new HashSet<>();
        List<NomenclatureSheets> nomenclatureSheets = Arrays.asList(NomenclatureSheets.values());
        for (NomenclatureSheets nomenclatureSheet : nomenclatureSheets) {
            if (nomenclatureSheet.getIsMandatory() && !sheetNames.contains(nomenclatureSheet.getSheetName())) {
                invalidNomenclatureSheets.add(nomenclatureSheet.getSheetName());
            }
        }

        if (!invalidNomenclatureSheets.isEmpty()) {
            database.logErrorMessage(logId, work,
                    "Възникна грешка - липсват работни листове с номенклатури: " + invalidNomenclatureSheets);
            throw new IllegalArgumentException(
                    "Invalid number of nomenclature sheets. Missing nomenclature sheets: " + invalidNomenclatureSheets);
        }

        if (visibleSheetNames.contains(APPLICATION_ONE_SHEET)) {
            Set<String> missingApplicationOneNomenclatures = new HashSet<>();
            List<NomenclatureSheets> applicationOneNomenclatures = Arrays.asList(NomenclatureSheets.PUP_SHEET,
                    NomenclatureSheets.OUP_MUNICIPALITY_SHEET,
                    NomenclatureSheets.OUP_CITY_SHEET,
                    NomenclatureSheets.LAYOUT_PROJECTS_SHEET);
            for (NomenclatureSheets nomenclatureSheet : applicationOneNomenclatures) {
                if (!sheetNames.contains(nomenclatureSheet.getSheetName())) {
                    missingApplicationOneNomenclatures.add(nomenclatureSheet.getSheetName());
                }
            }

            if (!missingApplicationOneNomenclatures.isEmpty()) {
                database.logErrorMessage(logId, work, "Възникна грешка - липсват работни листове с номенклатури: " +
                        missingApplicationOneNomenclatures);
                throw new IllegalArgumentException(
                        "Invalid number of nomenclature sheets for application one. Missing nomenclature sheets: " +
                                missingApplicationOneNomenclatures);
            }
        }

        if (visibleSheetNames.contains(APPLICATION_TWO_SHEET)) {
            Set<String> missingApplicationTwoNomenclatures = new HashSet<>();
            List<NomenclatureSheets> applicationTwoNomenclatures =
                    Arrays.asList(NomenclatureSheets.DOCUMENT_COPIES_SHEET,
                            NomenclatureSheets.INVEST_PLAN_SHEET);
            for (NomenclatureSheets nomenclatureSheet : applicationTwoNomenclatures) {
                if (!sheetNames.contains(nomenclatureSheet.getSheetName())) {
                    missingApplicationTwoNomenclatures.add(nomenclatureSheet.getSheetName());
                }
            }

            if (!missingApplicationTwoNomenclatures.isEmpty()) {
                database.logErrorMessage(logId, work, "Възникна грешка - липсват работни листове с номенклатури: " +
                        missingApplicationTwoNomenclatures);
                throw new IllegalArgumentException(
                        "Invalid number of nomenclature sheets for application two. Missing nomenclature sheets: " +
                                missingApplicationTwoNomenclatures);
            }
        }

        database.logInfoMessage(logId, work, "Валидирана структура на листовете в ексел шаблона.");
    }

    private void validateExcelSheetColumns(String logId, WorkBean work, Workbook workbook,
                                           Set<String> visibleSheetNames) throws Exception {
        Sheet actSheet = workbook.getSheetAt(ACT_SHEET);
        Row actHeaderRow = actSheet.getRow(MandatorySheets.ACT_SHEET.getColumnNameRow());
        List<String> invalidActColumnNames = new ArrayList<>();
        List<ActColumns> actColumns = Arrays.asList(ActColumns.values());
        for (int i = ActColumns.ACT_TYPE.getIndex(); i <= ActColumns.APPLICATION_ONE.getIndex(); i++) {
            if (!actHeaderRow.getCell(i).getStringCellValue().equals(actColumns.get(i).getColumnName())) {
                invalidActColumnNames.add(actColumns.get(i).getColumnName());
            }
        }

        List<String> actColumnNames = Arrays.stream(ActColumns.values())
                .map(ActColumns::getColumnName)
                .toList();
        if (!invalidActColumnNames.isEmpty()) {
            database.logErrorMessage(logId, work,
                    "Възникна грешка - невалидна структура на колони в работния лист \"Акт\": " + actColumnNames);
            throw new IllegalArgumentException("Invalid act column names: " + invalidActColumnNames);
        }

        Sheet objectSheet = workbook.getSheetAt(OBJECT_SHEET);
        Row objectHeaderRow = objectSheet.getRow(MandatorySheets.OBJECT_SHEET.getColumnNameRow());
        List<String> invalidObjectColumnNames = new ArrayList<>();
        for (ObjectColumns objectColumn : ObjectColumns.values()) {
            if (!objectHeaderRow.getCell(objectColumn.getIndex()).getStringCellValue()
                    .equals(objectColumn.getColumnName())) {
                invalidObjectColumnNames.add(objectColumn.getColumnName());
            }
        }

        for (AddressDetailsColumns addressDetailsColumn : AddressDetailsColumns.values()) {
            if (!objectHeaderRow.getCell(addressDetailsColumn.getIndex()).getStringCellValue()
                    .equals(addressDetailsColumn.getColumnName())) {
                invalidObjectColumnNames.add(addressDetailsColumn.getColumnName());
            }
        }

        List<String> objectColumnNames = Arrays.stream(ObjectColumns.values())
                .map(ObjectColumns::getColumnName)
                .toList();
        List<String> addressDetailsColumnNames = Arrays.stream(AddressDetailsColumns.values())
                .map(AddressDetailsColumns::getColumnName)
                .toList();
        if (!invalidObjectColumnNames.isEmpty()) {
            database.logErrorMessage(logId, work,
                    "Възникна грешка - невалидна структура на колони в работния лист \"Обект\": "
                            + objectColumnNames + ", "
                            + addressDetailsColumnNames);
            throw new IllegalArgumentException("Missing object columns: " + invalidObjectColumnNames);
        }

        Sheet contestingSheet = workbook.getSheetAt(CONTESTING_SHEET);
        Row contestingHeaderRow = contestingSheet.getRow(MandatorySheets.CONTESTING_SHEET.getColumnNameRow());
        List<String> invalidContestingColumnNames = new ArrayList<>();
        for (ContestingColumns contestingColumn : ContestingColumns.values()) {
            if (!contestingHeaderRow.getCell(contestingColumn.getIndex()).getStringCellValue()
                    .equals(contestingColumn.getColumnName())) {
                invalidContestingColumnNames.add(contestingColumn.getColumnName());
            }
        }

        List<String> contestingColumnNames = Arrays.stream(ContestingColumns.values())
                .map(ContestingColumns::getColumnName)
                .toList();
        if (!invalidContestingColumnNames.isEmpty()) {
            database.logErrorMessage(logId, work,
                    "Възникна грешка - невалидна структура на колони в работния лист \"Оспорване\": " +
                            contestingColumnNames);
            throw new IllegalArgumentException("Missing contesting columns: " + invalidContestingColumnNames);
        }

        Sheet customerSheet = workbook.getSheetAt(CUSTOMER_SHEET);
        Row customerHeaderRow = customerSheet.getRow(MandatorySheets.CUSTOMER_SHEET.getColumnNameRow());
        List<String> invalidCustomerColumnNames = new ArrayList<>();
        for (CustomerColumns customerColumn : CustomerColumns.values()) {
            if (!customerHeaderRow.getCell(customerColumn.getIndex()).getStringCellValue()
                    .equals(customerColumn.getColumnName())) {
                invalidCustomerColumnNames.add(customerColumn.getColumnName());
            }
        }

        for (AddressDetailsColumns addressDetailsColumn : AddressDetailsColumns.values()) {
            if (!customerHeaderRow.getCell(addressDetailsColumn.getIndex()).getStringCellValue()
                    .equals(addressDetailsColumn.getColumnName())) {
                invalidCustomerColumnNames.add(addressDetailsColumn.getColumnName());
            }
        }

        List<String> customerColumnNames = Arrays.stream(CustomerColumns.values())
                .map(CustomerColumns::getColumnName)
                .toList();
        if (!invalidCustomerColumnNames.isEmpty()) {
            database.logErrorMessage(logId, work,
                    "Възникна грешка - невалидна структура на колони в работния лист \"ЗаявителВъзложител\": "
                            + customerColumnNames + ", "
                            + addressDetailsColumnNames);
            throw new IllegalArgumentException("Missing customer columns: " + invalidCustomerColumnNames);
        }

        if (visibleSheetNames.contains(APPLICATION_ONE_SHEET)) {
            Sheet applicationOneSheet = workbook.getSheet(APPLICATION_ONE_SHEET);
            Row applicationOneHeaderRow =
                    applicationOneSheet.getRow(OptionalSheets.APPLICATION_ONE_SHEET.getColumnNameRow());
            List<String> invalidApplicationOneColumnNames = new ArrayList<>();
            for (ApplicationOneColumns applicationOneColumn : ApplicationOneColumns.values()) {
                if (!applicationOneHeaderRow.getCell(applicationOneColumn.getIndex()).getStringCellValue()
                        .equals(applicationOneColumn.getColumnName())) {
                    invalidApplicationOneColumnNames.add(applicationOneColumn.getColumnName());
                }
            }

            List<String> applicationOneColumnNames = Arrays.stream(ApplicationOneColumns.values())
                    .map(ApplicationOneColumns::getColumnName)
                    .toList();
            if (!invalidApplicationOneColumnNames.isEmpty()) {
                database.logErrorMessage(logId, work,
                        "Възникна грешка - невалидна структура на колони в работния лист \"Приложение 1\": "
                                + applicationOneColumnNames);
                throw new IllegalArgumentException(
                        "Missing application one columns: " + invalidApplicationOneColumnNames);
            }
        }

        if (visibleSheetNames.contains(APPLICATION_TWO_SHEET)) {
            Sheet applicationTwoSheet = workbook.getSheet(APPLICATION_TWO_SHEET);
            Row applicationTwoHeaderRow =
                    applicationTwoSheet.getRow(OptionalSheets.APPLICATION_TWO_SHEET.getColumnNameRow());
            List<String> invalidApplicationTwoColumnNames = new ArrayList<>();
            for (ApplicationTwoColumns applicationTwoColumn : ApplicationTwoColumns.values()) {
                if (!applicationTwoHeaderRow.getCell(applicationTwoColumn.getIndex()).getStringCellValue()
                        .equals(applicationTwoColumn.getColumnName())) {
                    invalidApplicationTwoColumnNames.add(applicationTwoColumn.getColumnName());
                }
            }

            List<String> applicationTwoColumnNames = Arrays.stream(ApplicationTwoColumns.values())
                    .map(ApplicationTwoColumns::getColumnName)
                    .toList();
            if (!invalidApplicationTwoColumnNames.isEmpty()) {
                database.logErrorMessage(logId, work,
                        "Възникна грешка - невалидна структура на колони в работния лист \"Приложение 2\": "
                                + applicationTwoColumnNames);
                throw new IllegalArgumentException(
                        "Missing application two columns: " + invalidApplicationTwoColumnNames);
            }
        }

        database.logInfoMessage(logId, work, "Валидирана структура на колоните в ексел шаблона.");
    }

    private Map<String, Long> processActExcelSheet(String logId, Workbook workbook, WorkBean work, String archivePath)
            throws Exception {
        Sheet actSheet = workbook.getSheetAt(ACT_SHEET);
        final int startingRow = 5;
        List<ActColumns> actColumns = Arrays.asList(ActColumns.values());
        Map<String, Long> actIds = new HashMap<>();

        for (int i = startingRow; i <= ROWS; i++) {
            Row row = actSheet.getRow(i);
            RegAct regAct = new RegAct();
            regAct.setImpId(work.getId().longValue());
            regAct.setExcelRow(row.getRowNum() + 1);

            if (row.getCell(CustomerColumns.NUM_ACT.getIndex()).getCellType() == CellType.BLANK) {
                continue;
            }

            for (int j = ActColumns.ACT_TYPE.getIndex(); j <= ActColumns.ADMINISTRATIVE_UNIT.getIndex(); j++) {
                Cell cell = row.getCell(j);
                if (cell.getCellType() != CellType.BLANK) {
                    try {
                        Field f = regAct.getClass().getField(actColumns.get(j).getField());
                        if (actColumns.get(j).getType().equals("date")) {
                            f.set(regAct, cell.getLocalDateTimeCellValue());
                        } else if (actColumns.get(j).getType().equals("string")) {
                            if (cell.getCellType() == CellType.STRING) {
                                f.set(regAct, cell.getStringCellValue());
                            } else if (cell.getCellType() == CellType.NUMERIC) {
                                f.set(regAct, String.valueOf((long) cell.getNumericCellValue()));
                            }
                        }
                    } catch (Exception e) {
                        log.error("Error setting field: {}", actColumns.get(j).getField(), e);
                        database.logWarningMessage(logId, work,
                                "Възникна грешка в Лист: " + actSheet.getSheetName() +
                                        " на Ред: " +
                                        (row.getRowNum() + 1) +
                                        " - възникна проблем в извличането на стойността на клетка: "
                                        + actColumns.get(j).getColumnName());
                    }
                }
            }

            Cell actType = row.getCell(ActColumns.ACT_TYPE.getIndex());
            if (actType.getCellType() != CellType.BLANK) {
                String actTypeValue = actType.getStringCellValue();
                String actTypeCode =
                        getNomenclatureCode(logId, work, workbook, NomenclatureSheets.ACT_TYPE_SHEET.getSheetName(),
                                actTypeValue);
                regAct.setActType(actTypeCode);
            }

            Cell messageType = row.getCell(ActColumns.MESSAGE_TYPE.getIndex());
            if (messageType.getCellType() != CellType.BLANK) {
                String messageTypeValue = messageType.getStringCellValue();
                String messageTypeCode =
                        getNomenclatureCode(logId, work, workbook, NomenclatureSheets.MESSAGE_TYPE_SHEET.getSheetName(),
                                messageTypeValue);
                regAct.setMessageType(messageTypeCode);
            }

            Cell docStatus = row.getCell(ActColumns.DOC_STATUS.getIndex());
            if (docStatus.getCellType() != CellType.BLANK) {
                String docStatusValue = docStatus.getStringCellValue();
                String docStatusCode =
                        getNomenclatureCode(logId, work, workbook, NomenclatureSheets.STATUS_SHEET.getSheetName(),
                                docStatusValue);
                regAct.setStatus(docStatusCode);
            }

            Cell administration = row.getCell(ActColumns.ADMINISTRATION.getIndex());
            if (administration.getCellType() != CellType.BLANK) {
                String administrationValue = administration.getStringCellValue();
                String administrationCode = getNomenclatureCode(logId, work, workbook,
                        NomenclatureSheets.ADMINISTRATION_SHEET.getSheetName(), administrationValue);
                regAct.setAdministration(administrationCode);
            }

            Cell administrativeUnit = row.getCell(ActColumns.ADMINISTRATIVE_UNIT.getIndex());
            if (administrativeUnit.getCellType() != CellType.BLANK) {
                String administrativeUnitValue = administrativeUnit.getStringCellValue();
                String administrativeUnitCode = getNomenclatureCode(logId, work, workbook,
                        NomenclatureSheets.ADMINISTRATIVE_UNIT_SHEET.getSheetName(), administrativeUnitValue);
                regAct.setAdministrativeUnit(administrativeUnitCode);
            }

            Long actId = database.saveRegActToDB(logId, work, regAct, actSheet);
            Cell concatenation = row.getCell(ActColumns.CONCATENATION.getIndex());
            if (concatenation.getCellType() != CellType.BLANK) {
                String concatenationValue = concatenation.getStringCellValue();
                if (!actIds.containsKey(concatenationValue) && actId != null) {
                    actIds.put(concatenationValue, actId);
                }
            }

            Cell documentOne = row.getCell(ActColumns.DOCUMENT_ONE.getIndex());
            if (documentOne.getCellType() != CellType.BLANK) {
                String documentOneValue = documentOne.getStringCellValue();
                RegActDocumentOne regActDocumentOne = new RegActDocumentOne();
                regActDocumentOne.setImpId(work.getId().longValue());
                regActDocumentOne.setRegActId(actId);
                regActDocumentOne.setExcelRow(row.getRowNum() + 1);
                Long docId = findFileByPath(logId, work, documentOneValue, archivePath, actSheet, row);
                regActDocumentOne.setDocumentId(docId);
                database.saveRegActDocOneToDb(logId, work, regActDocumentOne, actSheet);
            }

            Cell documentTwo = row.getCell(ActColumns.DOCUMENT_TWO.getIndex());
            if (documentTwo.getCellType() != CellType.BLANK) {
                String documentTwoValue = documentTwo.getStringCellValue();
                RegActDocumentTwo regActDocumentTwo = new RegActDocumentTwo();
                regActDocumentTwo.setImpId(work.getId().longValue());
                regActDocumentTwo.setRegActId(actId);
                regActDocumentTwo.setExcelRow(row.getRowNum() + 1);
                Long docId = findFileByPath(logId, work, documentTwoValue, archivePath, actSheet, row);
                regActDocumentTwo.setDocumentId(docId);
                database.saveRegActDocTwoToDb(logId, work, regActDocumentTwo, actSheet);
            }
        }

        database.logInfoMessage(logId, work, "Брой извлечени актове: " + actIds.size());

        return actIds;
    }

    private void processObjectExcelSheet(String logId, Workbook workbook, WorkBean work, Map<String, Long> actIds)
            throws Exception {
        Sheet objectSheet = workbook.getSheetAt(OBJECT_SHEET);
        final int startingRow = 4;
        List<ObjectColumns> objectColumns = Arrays.asList(ObjectColumns.values());
        List<Long> objectIds = new ArrayList<>();

        for (int i = startingRow; i <= ROWS; i++) {
            Row row = objectSheet.getRow(i);
            RegObject regObject = new RegObject();
            regObject.setImpId(work.getId().longValue());
            regObject.setExcelRow(row.getRowNum() + 1);

            if (row.getCell(ObjectColumns.NUM_ACT.getIndex()).getCellType() == CellType.BLANK) {
                continue;
            }

            Cell numAct = row.getCell(ObjectColumns.NUM_ACT.getIndex());

            regObject.setRegActId(actIds.get(numAct.getStringCellValue()));

            for (int j = ObjectColumns.CADIDENT.getIndex(); j <= ObjectColumns.ADDITIONAL_DESCRIPTION.getIndex(); j++) {
                Cell cell = row.getCell(j);
                if (cell.getCellType() != CellType.BLANK) {
                    try {
                        Field f = regObject.getClass().getField(objectColumns.get(j).getField());
                        if (objectColumns.get(j).getType().equals("string")) {
                            if (cell.getCellType() == CellType.STRING) {
                                f.set(regObject, cell.getStringCellValue());
                            } else if (cell.getCellType() == CellType.NUMERIC) {
                                f.set(regObject, String.valueOf((long) cell.getNumericCellValue()));
                            }
                        }
                    } catch (Exception e) {
                        log.error("Error setting field: {}", objectColumns.get(j).getField(), e);
                        database.logWarningMessage(logId, work,
                                "Възникна грешка в Лист: " + objectSheet.getSheetName() +
                                        " на Ред: " +
                                        (row.getRowNum() + 1) +
                                        "- възникна проблем в извличането на стойността на клетка: "
                                        + objectColumns.get(j).getColumnName()); //todo трябва ли да имаме такъв лог?
                    }
                }
            }

            Cell territoryType = row.getCell(ObjectColumns.TERRITORY_TYPE.getIndex());
            if (territoryType.getCellType() != CellType.BLANK) {
                String territoryTypeValue = territoryType.getStringCellValue();
                String territoryTypeCode = getNomenclatureCode(logId, work, workbook,
                        NomenclatureSheets.TERRITORY_TYPE_SHEET.getSheetName(), territoryTypeValue);
                regObject.setTerritoryType(territoryTypeCode);
            }

            Long addressId = processAddress(logId,
                    objectColumns,
                    row,
                    ObjectColumns.DISTRICT.getIndex(),
                    ObjectColumns.VILLAGE.getIndex(),
                    work, objectSheet);
            regObject.setAddressId(addressId);

            Long id = database.saveRegObjectToDB(logId, work, regObject, objectSheet);
            if (id != null) {
                objectIds.add(id);
            }
        }

        database.logInfoMessage(logId, work, "Брой извлечени обекти: " + objectIds.size());
    }

    private void processContestingExcelSheet(String logId, Workbook workbook, WorkBean work, String archivePath,
                                             Map<String, Long> actIds)
            throws Exception {
        Sheet contestingSheet = workbook.getSheetAt(CONTESTING_SHEET);
        List<Long> contestingDocsIds = new ArrayList<>();
        final int startingRow = 4;

        for (int i = startingRow; i <= ROWS; i++) {
            Row row = contestingSheet.getRow(i);

            if (row.getCell(ContestingColumns.NUM_ACT.getIndex()).getCellType() == CellType.BLANK
                    || (row.getCell(ContestingColumns.NUM_ACT.getIndex()).getCellType() != CellType.BLANK &&
                    row.getCell(ContestingColumns.GRAPHICAL_CONTESTING.getIndex()).getCellType() == CellType.BLANK)) {
                continue;
            }

            RegContDocument regContDocument = new RegContDocument();
            regContDocument.setImpId(work.getId().longValue());
            regContDocument.setExcelRow(row.getRowNum() + 1);

            Cell numAct = row.getCell(ContestingColumns.NUM_ACT.getIndex());
            regContDocument.setRegActId(actIds.get(numAct.getStringCellValue()));

            Cell contestingDesc = row.getCell(ContestingColumns.TEXT_CONTESTING.getIndex());
            if (contestingDesc.getCellType() != CellType.BLANK) {
                regContDocument.setDescription(contestingDesc.getStringCellValue());
            }

            Cell graphicalContesting = row.getCell(ContestingColumns.GRAPHICAL_CONTESTING.getIndex());
            if (graphicalContesting.getCellType() != CellType.BLANK) {
                Long docId = findFileByPath(logId, work, graphicalContesting.getStringCellValue(), archivePath,
                        contestingSheet, row);
                regContDocument.setDocumentId(docId);
            }
            Long id = database.saveRegContDocToDB(logId, work, regContDocument, contestingSheet);
            if (id != null) {
                contestingDocsIds.add(id);
            }
        }

        database.logInfoMessage(logId, work, "Брой извлечени оспорвания: " + contestingDocsIds.size());
    }

    private void processCustomerExcelSheet(String logId, Workbook workbook, WorkBean work, Map<String, Long> actIds)
            throws Exception {
        Sheet customerSheet = workbook.getSheetAt(CUSTOMER_SHEET);
        final int startingRow = 5;
        List<CustomerColumns> customerColumns = Arrays.asList(CustomerColumns.values());
        List<Long> customerIds = new ArrayList<>();

        for (int i = startingRow; i <= ROWS; i++) {
            Row row = customerSheet.getRow(i);
            Customer customer = new Customer();
            customer.setImpId(work.getId().longValue());
            customer.setExcelRow(row.getRowNum() + 1);

            if (row.getCell(CustomerColumns.NUM_ACT.getIndex()).getCellType() == CellType.BLANK) {
                continue;
            }

            Cell numAct = row.getCell(CustomerColumns.NUM_ACT.getIndex());
            customer.setRegActId(actIds.get(numAct.getStringCellValue()));

            for (int j = CustomerColumns.CUST_TYPE.getIndex(); j <= CustomerColumns.PHONE.getIndex(); j++) {
                Cell cell = row.getCell(j);
                if (cell.getCellType() != CellType.BLANK) {
                    try {
                        Field f = customer.getClass().getField(customerColumns.get(j).getField());
                        if (customerColumns.get(j).getType().equals("string")) {
                            if (cell.getCellType() == CellType.NUMERIC) {
                                f.set(customer, String.valueOf((long) cell.getNumericCellValue()));
                            } else if (cell.getCellType() == CellType.STRING) {
                                f.set(customer, cell.getStringCellValue());
                            }
                        }
                    } catch (Exception e) {
                        log.error("Error setting field: {}", customerColumns.get(j).getField(), e);
                        database.logWarningMessage(logId, work,
                                "Възникна грешка в Лист: " + customerSheet.getSheetName()
                                        + " на Ред: " + (row.getRowNum() + 1) +
                                        " - възникна проблем в извличането на стойността на клетка: "
                                        + customerColumns.get(j).getColumnName()); //todo трябва ли да имаме такъв лог?
                    }
                }
            }

            Cell customerType = row.getCell(CustomerColumns.CUST_TYPE.getIndex());
            if (customerType.getCellType() != CellType.BLANK) {
                String customerTypeValue = customerType.getStringCellValue();
                String customerTypeCode = getNomenclatureCode(logId, work, workbook,
                        NomenclatureSheets.CUSTOMER_TYPE_SHEET.getSheetName(), customerTypeValue);
                customer.setCustomerType(customerTypeCode);
            }

            Cell customerQuality = row.getCell(CustomerColumns.CUST_QUALITY.getIndex());
            if (customerQuality.getCellType() != CellType.BLANK) {
                String customerQualityValue = customerQuality.getStringCellValue();
                String customerQualityCode = getNomenclatureCode(logId, work, workbook,
                        NomenclatureSheets.CUSTOMER_QUALITY_SHEET.getSheetName(), customerQualityValue);
                customer.setCapacity(customerQualityCode);
            }

            Cell identifierType = row.getCell(CustomerColumns.ID_TYPE.getIndex());
            if (identifierType.getCellType() != CellType.BLANK) {
                String identifierTypeValue = identifierType.getStringCellValue();
                String identifierTypeCode =
                        getNomenclatureCode(logId, work, workbook, NomenclatureSheets.ID_TYPE_SHEET.getSheetName(),
                                identifierTypeValue);
                customer.setIdentifierType(identifierTypeCode);
            }

            Long addressId = processAddress(logId,
                    customerColumns,
                    row,
                    CustomerColumns.COUNTRY.getIndex(),
                    CustomerColumns.VILLAGE.getIndex(),
                    work, customerSheet);
            customer.setAddressId(addressId);
            Long id = database.saveCustomerToDB(logId, work, customer, customerSheet);
            if (id != null) {
                customerIds.add(id);
            }
        }

        database.logInfoMessage(logId, work, "Брой извлечени заявители/възложители: " + customerIds.size());
    }

    private void processApplicationOneExcelSheet(String logId, Workbook workbook, WorkBean work, String archivePath,
                                                 Map<String, Long> actIds)
            throws Exception {
        Sheet applicationOneSheet = workbook.getSheet(APPLICATION_ONE_SHEET);
        List<Long> appOneIds = new ArrayList<>();
        final int startingRow = 3;

        for (int i = startingRow; i <= ROWS; i++) {
            Row row = applicationOneSheet.getRow(i);
            RegAppOneDocument appOneDocument = new RegAppOneDocument();
            appOneDocument.setImpId(work.getId().longValue());
            appOneDocument.setExcelRow(row.getRowNum() + 1);

            if (row.getCell(ApplicationOneColumns.NUM_ACT.getIndex()).getCellType() == CellType.BLANK
                    || (row.getCell(ApplicationOneColumns.NUM_ACT.getIndex()).getCellType() != CellType.BLANK &&
                    row.getCell(ApplicationOneColumns.FILE_NAME.getIndex()).getCellType() == CellType.BLANK)) {
                continue;
            }

            Cell numAct = row.getCell(ApplicationOneColumns.NUM_ACT.getIndex());
            appOneDocument.setRegActId(actIds.get(numAct.getStringCellValue()));

            Cell layoutPlanProjects = row.getCell(ApplicationOneColumns.LAYOUT_PLANS_PROJECTS.getIndex());
            String layoutPlanProjectsValue = layoutPlanProjects.getStringCellValue();
            if (layoutPlanProjects.getCellType() != CellType.BLANK) {
                String layoutPlanProjectsCode = getNomenclatureCode(logId, work, workbook,
                        NomenclatureSheets.LAYOUT_PROJECTS_SHEET.getSheetName(), layoutPlanProjectsValue);
                appOneDocument.setType(layoutPlanProjectsCode);
            }

            Cell appOneSubcategory = row.getCell(ApplicationOneColumns.APPLICATION_ONE_SUBCATEGORY.getIndex());
            String appOneSubcategoryValue = appOneSubcategory.getStringCellValue();
            if (appOneSubcategory.getCellType() != CellType.BLANK) {
                switch (layoutPlanProjectsValue) {
                    case OUP_MUNICIPALITY_VALUE -> appOneDocument.setSubType(getNomenclatureCode(logId, work, workbook,
                            NomenclatureSheets.OUP_MUNICIPALITY_SHEET.getSheetName(), appOneSubcategoryValue));
                    case OUP_CITY_VALUE -> appOneDocument.setSubType(getNomenclatureCode(logId, work, workbook,
                            NomenclatureSheets.OUP_CITY_SHEET.getSheetName(), appOneSubcategoryValue));
                    case PUP_VALUE -> appOneDocument.setSubType(
                            getNomenclatureCode(logId, work, workbook, NomenclatureSheets.PUP_SHEET.getSheetName(),
                                    appOneSubcategoryValue));
                    default -> appOneDocument.setSubType(null);
                }
            }

            Cell fileName = row.getCell(ApplicationOneColumns.FILE_NAME.getIndex());
            if (fileName.getCellType() != CellType.BLANK) {
                Long docId =
                        findFileByPath(logId, work, fileName.getStringCellValue(), archivePath, applicationOneSheet,
                                row);
                appOneDocument.setDocumentId(docId);
            }
            Long id = database.saveRegAppOneDocToDB(logId, work, appOneDocument, applicationOneSheet);
            if (id != null) {
                appOneIds.add(id);
            }
        }

        database.logInfoMessage(logId, work, "Брой извлечени документи за Приложение 1: " + appOneIds.size());
    }

    private void processApplicationTwoExcelSheet(String logId, Workbook workbook, WorkBean work, String archivePath,
                                                 Map<String, Long> actIds)
            throws Exception {
        Sheet applicationTwoSheet = workbook.getSheet(APPLICATION_TWO_SHEET);
        List<Long> appTwoIds = new ArrayList<>();
        final int startingRow = 3;

        for (int i = startingRow; i <= ROWS; i++) {
            Row row = applicationTwoSheet.getRow(i);
            RegAppTwoDocument appTwoDocument = new RegAppTwoDocument();
            appTwoDocument.setImpId(work.getId().longValue());
            appTwoDocument.setExcelRow(row.getRowNum() + 1);

            if (row.getCell(ApplicationTwoColumns.NUM_ACT.getIndex()).getCellType() == CellType.BLANK
                    || (row.getCell(ApplicationTwoColumns.NUM_ACT.getIndex()).getCellType() != CellType.BLANK &&
                    row.getCell(ApplicationTwoColumns.FILE_NAME.getIndex()).getCellType() == CellType.BLANK)) {
                continue;
            }

            Cell numAct = row.getCell(ApplicationTwoColumns.NUM_ACT.getIndex());
            appTwoDocument.setRegActId(actIds.get(numAct.getStringCellValue()));

            Cell appTwoDocumentsCopies = row.getCell(ApplicationTwoColumns.APPLICATION_TWO_DOCUMENT_COPIES.getIndex());
            String appTwoDocumentsCopiesValue = appTwoDocumentsCopies.getStringCellValue();
            if (appTwoDocumentsCopies.getCellType() != CellType.BLANK) {
                String appTwoDocumentsCopiesCode = getNomenclatureCode(logId, work, workbook,
                        NomenclatureSheets.DOCUMENT_COPIES_SHEET.getSheetName(), appTwoDocumentsCopiesValue);
                appTwoDocument.setType(appTwoDocumentsCopiesCode);
            }

            if (appTwoDocumentsCopiesValue.equals("Одобрен инвестиционен проект")) {
                Cell appTwoSubcategory =
                        row.getCell(ApplicationTwoColumns.SUBCATEGORY_FOR_APPROVED_INVESTMENT_PLAN.getIndex());
                String appTwoSubcategoryValue = appTwoSubcategory.getStringCellValue();
                if (appTwoSubcategory.getCellType() != CellType.BLANK) {
                    String appTwoSubcategoryCode = getNomenclatureCode(logId, work, workbook,
                            NomenclatureSheets.INVEST_PLAN_SHEET.getSheetName(), appTwoSubcategoryValue);
                    appTwoDocument.setSubType(appTwoSubcategoryCode);
                }
            }

            Cell fileName = row.getCell(ApplicationTwoColumns.FILE_NAME.getIndex());
            if (fileName.getCellType() != CellType.BLANK) {
                Long docId =
                        findFileByPath(logId, work, fileName.getStringCellValue(), archivePath, applicationTwoSheet,
                                row);
                appTwoDocument.setDocumentId(docId);
            }
            Long id = database.saveRegAppTwoDocToDB(logId, work, appTwoDocument, applicationTwoSheet);
            if (id != null) {
                appTwoIds.add(id);
            }
        }

        database.logInfoMessage(logId, work, "Брой извлечени документи за Приложение 2: " + appTwoIds.size());
    }

    private Long processAddress(String logId, List<? extends ColumnsEnum> columns, Row row, int startAddr, int endAddr,
                                WorkBean work, Sheet sheet)
            throws Exception {
        Address address = new Address();
        address.setImportId(work.getId().longValue());
        address.setExcelRow(row.getRowNum() + 1);

        for (int i = startAddr; i <= endAddr; i++) {
            Cell cell = row.getCell(i);
            if (cell.getCellType() != CellType.BLANK) {
                try {
                    Field f = address.getClass().getField(columns.get(i).getField());
                    f.set(address, cell.getStringCellValue());
                } catch (Exception e) {
                    log.error("Error setting field: {}", columns.get(i).getField(), e);
                    database.logWarningMessage(logId, work,
                            "Възникна грешка в Лист: " + sheet.getSheetName()
                                    + " на Ред: " + (row.getRowNum() + 1) +
                                    " - възникна проблем в извличането на стойността на клетка: "
                                    + columns.get(i).getColumnName()); //todo трябва ли да имаме такъв лог?
                }
            }
        }

        for (AddressDetailsColumns col : AddressDetailsColumns.values()) {
            Cell cell = row.getCell(col.getIndex());
            if (cell.getCellType() != CellType.BLANK) {
                try {
                    Field f = address.getClass().getField(col.getField());
                    if (cell.getCellType() == CellType.NUMERIC) {
                        f.set(address, String.valueOf((long) cell.getNumericCellValue()));
                    } else if (cell.getCellType() == CellType.STRING) {
                        f.set(address, cell.getStringCellValue());
                    }
                } catch (Exception e) {
                    log.error("Error setting field: {}", col.getField(), e);
                    database.logWarningMessage(logId, work,
                            "Възникна грешка в Лист: " + sheet.getSheetName()
                                    + " на Ред: " + (row.getRowNum() + 1) +
                                    " - възникна проблем в извличането на стойността на клетка: "
                                    + col.getColumnName()); //todo трябва ли да имаме такъв лог?
                }
            }
        }

        return database.saveAddressToDB(logId, work, address, sheet);
    }

    private Long findFileByPath(String logId, WorkBean work, String path, String archivePath, Sheet sheet, Row row)
            throws Exception {
        try (FileInputStream fis = new FileInputStream(archivePath);
             BufferedInputStream bis = new BufferedInputStream(fis);
             ZipArchiveInputStream zipInputStream = new ZipArchiveInputStream(bis)) {

            ZipArchiveEntry entry;
            while ((entry = zipInputStream.getNextEntry()) != null) {
                if (entry.getName().equals(path)) {
                    Document document = new Document();
                    document.setImpId(work.getId().longValue());
                    document.setFileName(entry.getName());
                    document.setUrl(path);

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
                    int bytesRead;
                    while ((bytesRead = zipInputStream.read(buffer)) != -1) {
                        baos.write(buffer, 0, bytesRead);
                    }
                    byte[] contentBytes = baos.toByteArray();

                    document.setFileSize((long) contentBytes.length);

                    Tika tika = new Tika();
                    String mimeType = tika.detect(new ByteArrayInputStream(contentBytes));
                    document.setMimeType(mimeType);

                    MessageDigest digest = MessageDigest.getInstance("SHA-256");
                    digest.update(contentBytes);
                    String sha256 = HexFormat.of().formatHex(digest.digest());
                    document.setSha256(sha256);

                    return database.saveDocumentToDB(logId, work, document, sheet, row);
                }
            }
        } catch (Exception e) {
            database.logWarningMessage(logId, work,
                    "Възникна грешка в Лист: " + sheet.getSheetName() +
                            " на Ред: " +
                            (row.getRowNum() + 1) +
                            "- възникна проблем: " + e.getMessage());
        }
        database.logWarningMessage(logId, work,
                "Възникна грешка в Лист: " + sheet.getSheetName() +
                        " на Ред: " + (row.getRowNum() + 1) +
                        " - възникна проблем при намирането на файл с име: " + path + ".");
        return null;
    }

    private String getNomenclatureCode(String logId, WorkBean work, Workbook workbook, String sheetName,
                                       String nomenclature) throws Exception {
        Sheet nomenclatureSheet = workbook.getSheet(sheetName);
        final int nomCodeCol = 0;
        final int nomCol = 1;
        String nomCode = null;
        for (int i = 0; i <= nomenclatureSheet.getLastRowNum(); i++) {
            Row row = nomenclatureSheet.getRow(i);
            Cell nom = row.getCell(nomCol);
            if (nom.getCellType() != CellType.BLANK && Objects.equals(nom.getStringCellValue(), nomenclature)) {
                nomCode = row.getCell(nomCodeCol).getStringCellValue();
                return nomCode;
            }
        }

        if (nomenclature == null) {
            database.logWarningMessage(logId, work, "В лист: " + sheetName + " има невалидна номенклатура. Номенклатурата \"" + nomenclature + "\" не съществува в листовете с номенклатури.");
        }

        return nomCode;
    }

    @Override
    protected void workerExceptionHandling(String logId, WorkBean firstElementFromQueue, Exception e) {
        log.error("{} - ExcelExtractWorker with WorkBean : {} ERROR {}", logId, firstElementFromQueue, e, e);
    }

    @Override
    protected void workerStarted(String logId, WorkBean firstElementFromQueue) {
        log.debug("{} - ExcelExtractWorker with WorkBean : {} has STARTED working", logId, firstElementFromQueue);
    }

    @Override
    protected void workerFinished(String logId, WorkBean firstElementFromQueue) {
        log.debug("{} - ExcelExtractWorker with WorkBean : {} has FINISHED working", logId, firstElementFromQueue);
    }
}