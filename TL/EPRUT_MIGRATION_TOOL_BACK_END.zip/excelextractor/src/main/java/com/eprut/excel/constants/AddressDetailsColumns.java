package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum AddressDetailsColumns {
    ADDRESS_REG_NAME(17, "addrPlaceName", "Местност"),                        //Местност - наименование
    ADDRESS_REG_NUMBER(18, "addrPlaceNum", "№"),                              //Местност №
    SQUARE_NAME(19, "squareName", "Площад"),                                  //Площад - наименование
    SQUARE_NUMBER(20, "squareNum", "№"),                                      //Площад №
    QUARTER_NAME(21, "quarter", "Квартал"),                                   //Квартал
    BUILDING_NUMBER(22, "flatNumber", "Блок №"),                              //Блок №
    BOULEVARD_NAME(23,  "streetName", "Булевард"),                            //Булевард - наименование
    BOULEVARD_NUMBER(24, "streetNum", "№"),                                   //Булевард №
    STREET_NAME(25,  "streetName", "Улица"),                                  //Улица - наименование
    STREET_NUMBER(26, "streetNum", "№"),                                      //Улица №
    APP_COMPLEX_NAME(27, "appComplexName", "Жилищен комплекс"),               //Жилищен комплекс - наименование
    APP_COMPLEX_NUMBER(28, "appComplexNum", "Жилищен комплекс №"),            //Жилищен комплекс №
    OTHER_LOCAL_UNIT_NAME(29, "otherluname", "Друга наименование"),           //Друга локализационна единица - наименование
    OTHER_LOCAL_UNIT_NUMBER(30, "otherlunum", "Друга №"),                     //Друга локализационна единица №
    BUILDING_ENTRANCE(31, "flatEntrance", "Вход"),                            //Вход №
    FLOOR(32, "floor", "Етаж"),                                               //Етаж
    APARTMENT_NUMBER(33, "apartment", "Апартамент/Ателие №");                 //Апартамент/Ателие №

    private final int index;
    private final String field;
    private final String columnName;

    AddressDetailsColumns(int index, String field, String columnName) {
        this.index = index;
        this.field = field;
        this.columnName = columnName;
    }
}
