package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum NomenclatureSheets {
    REG_TYPE_SHEET("Вид регистър", true),
    ACT_TYPE_SHEET("Вид на акта", true),
    MESSAGE_TYPE_SHEET("Вид на съобщаване", true),
    STATUS_SHEET("Състояние", true),
    ADMINISTRATION_SHEET("Администрация", true),
    ADMINISTRATIVE_UNIT_SHEET("Административен орган", true),
    TERRITORY_TYPE_SHEET("Вид територия", true),
    CUSTOMER_TYPE_SHEET("Вид на заявителя", true),
    CUSTOMER_QUALITY_SHEET("Качество", true),
    ID_TYPE_SHEET("Вид на идентификатор", true),
    COUNTRY_SHEET("Държави", true),
    PUP_SHEET("Устройствен план ПУП", false),
    OUP_MUNICIPALITY_SHEET("Устройствен план ОУП община", false),
    OUP_CITY_SHEET("Устройствен план ОУП град", false),
    LAYOUT_PROJECTS_SHEET("Проекти на устройствени планове", false),
    DOCUMENT_COPIES_SHEET("Копия на документи", false),
    INVEST_PLAN_SHEET("Съдържание на инвестиц. проект", false);

    private final String sheetName;
    private final Boolean isMandatory;

    NomenclatureSheets(String sheetName, Boolean isMandatory) {
        this.sheetName = sheetName;
        this.isMandatory = isMandatory;
    }
}