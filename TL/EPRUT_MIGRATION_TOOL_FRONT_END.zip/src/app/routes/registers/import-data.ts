import { ApiModel } from "@shared/models/api-model";

export class ImportData extends ApiModel<ImportData> {
    filename: string;
    size: number;
    numActs: number;
    numObjects: number;
    numAttachedFiles: number;
    hasErrors: boolean;

    constructor(init?: Partial<ImportData>) {
        super(ImportData);
        Object.assign(this, init);
    }
}
