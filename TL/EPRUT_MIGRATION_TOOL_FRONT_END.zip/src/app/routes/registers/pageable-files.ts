import { FileModel } from "./file-model";

export class PageableFiles {

    content: FileModel[];
    size: number;
    pageNumber: number;
    totalElements: number;

    constructor(init?: Partial<PageableFiles>) {

        Object.assign(this, init);

        if (init?.content) {
            this.content = [];

            init.content.forEach((value) => {
                this.content.push(new FileModel(value));
            })
        }
    }
}
