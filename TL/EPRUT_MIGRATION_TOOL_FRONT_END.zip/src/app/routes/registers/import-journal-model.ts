import { ApiModel } from "@shared/models/api-model";

export class ImportJournalModel extends ApiModel<ImportJournalModel> {

    uploadDate: Date;
    msgType: string;
    message: string;

    constructor(init?: Partial<ImportJournalModel>) {
        super(ImportJournalModel);

        Object.assign(this, init);

        if (init?.uploadDate) {
            this.uploadDate = new Date(init.uploadDate);
        }
    }
}
