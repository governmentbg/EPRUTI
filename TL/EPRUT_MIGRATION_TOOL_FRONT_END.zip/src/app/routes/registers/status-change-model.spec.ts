import { StatusChangeModel } from './status-change-model';

describe('StatusChangeModel', () => {
  it('should create an instance', () => {
    expect(new StatusChangeModel()).toBeTruthy();
  });

  it('should initialize with given values', () => {
    const init = { statusId: 1, statusCode: 'ACTIVE' };
    const model = new StatusChangeModel(init);
    expect(model.statusId).toBe(1);
    expect(model.statusCode).toBe('ACTIVE');
  });

  it('should have default values when not initialized', () => {
    const model = new StatusChangeModel();
    expect(model.statusId).toBeUndefined();
    expect(model.statusCode).toBeUndefined();
  });
});
