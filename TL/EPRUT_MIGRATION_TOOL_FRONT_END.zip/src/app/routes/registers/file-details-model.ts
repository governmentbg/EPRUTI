import { ApiModel } from "@shared/models/api-model";

export class FileDetailsModel extends ApiModel<FileDetailsModel> {

    name: string;
    size: number;
    objectsCount: number;
    actsCount: number;
    filesAttached: number;

    constructor(init?: Partial<FileDetailsModel>) {
        super(FileDetailsModel);
        Object.assign(this, init);
    }
}
