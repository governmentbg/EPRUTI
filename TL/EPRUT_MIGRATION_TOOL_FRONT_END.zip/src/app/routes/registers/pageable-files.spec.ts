import { PageableFiles } from './pageable-files';
import { FileModel } from './file-model';

describe('PageableFiles', () => {
  it('should create an instance', () => {
    expect(new PageableFiles()).toBeTruthy();
  });

  it('should initialize with given values', () => {
    const init = {
      content: [
        new FileModel({ id: 1, fileName: 'file1', uploadDate: new Date(), statusId: 1, statusCode: 'ACTIVE', statusDescription: 'Active', registerDescription: 'Register 1' }),
        new FileModel({ id: 2, fileName: 'file2', uploadDate: new Date(), statusId: 2, statusCode: 'INACTIVE', statusDescription: 'Inactive', registerDescription: 'Register 2' })
      ],
      size: 10,
      pageNumber: 1,
      totalElements: 2
    };
    
    const pageableFiles = new PageableFiles(init);
    expect(pageableFiles.size).toBe(10);
    expect(pageableFiles.pageNumber).toBe(1);
    expect(pageableFiles.totalElements).toBe(2);
    expect(pageableFiles.content.length).toBe(2);
    expect(pageableFiles.content[0]).toBeInstanceOf(FileModel);
  });

  it('should handle empty content array', () => {
    const init = {
      content: [],
      size: 10,
      pageNumber: 1,
      totalElements: 0
    };
    const pageableFiles = new PageableFiles(init);
    expect(pageableFiles.content.length).toBe(0);
  });

  it('should handle undefined content', () => {
    const init = {
      size: 10,
      pageNumber: 1,
      totalElements: 0
    };
    const pageableFiles = new PageableFiles(init);
    expect(pageableFiles.content).toEqual([]);
  });
});
