import { MessageModel } from './message-model';

describe('MessageModel', () => {
  it('should create an instance', () => {
    expect(new MessageModel()).toBeTruthy();
  });

  it('should initialize date correctly', () => {
    const date = new Date();
    const model = new MessageModel({ date });
    expect(model.date).toEqual(date);
  });

  it('should initialize messageType correctly', () => {
    const messageType = 'info';
    const model = new MessageModel({ messageType });
    expect(model.messageType).toEqual(messageType);
  });

  it('should initialize messageDescription correctly', () => {
    const messageDescription = 'This is a test message';
    const model = new MessageModel({ messageDescription });
    expect(model.messageDescription).toEqual(messageDescription);
  });

  it('should handle partial initialization', () => {
    const date = new Date();
    const model = new MessageModel({ date });
    expect(model.date).toEqual(date);
    expect(model.messageType).toBeUndefined();
    expect(model.messageDescription).toBeUndefined();
  });
});
