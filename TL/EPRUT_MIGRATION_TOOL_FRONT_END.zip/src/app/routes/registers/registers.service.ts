import { Injectable, Injector } from '@angular/core';
import { HttpParams, HttpResponse } from '@angular/common/http';
import { RegisterModel } from './register-model';
import { Observable, Subject } from 'rxjs';
import { CrudService } from '@core/services/crud-service';
import { FileOutputModel } from '@shared/models/file-output-model';
import { DisplayValueWithCodeModel } from '@shared/models/display-value-with-code-model';
import { ImportData } from './import-data';
import { PageableData } from './pageable-data';
import { FileModel } from './file-model';
import { ImportJournalModel } from './import-journal-model';
import { StatusChangeModel } from './status-change-model';

@Injectable({
  providedIn: 'root'
})
export class RegistersService extends CrudService<RegisterModel> {

  refreshFiles$: Subject<void> = new Subject<void>();

  get refreshFiles(): Observable<void> {
    return this.refreshFiles$.asObservable();
  }

  constructor(injector: Injector) {
    super(injector);
  }

  submitFile(registerCode: string, file: File): Observable<FileOutputModel> {
    const formData = new FormData();
    formData.append('file', file);
    return this.httpClient.post<FileOutputModel>(`${this.APIUrl}/import-file/${registerCode}`, formData);
  }

  getRegisterDescription(code: string): Observable<DisplayValueWithCodeModel> {
    return this.httpClient.get<DisplayValueWithCodeModel>(`${this.APIUrl}/description/${code}`);
  }

  getFiles(registerCode: string, filters?: { startDate?: string; endDate?: string; statusCode?: string }, page: number = 0, size: number = 5, sort?: { field: string, direction: 'asc' | 'desc' | '' }[]): Observable<PageableData<FileModel>> {
    let params = new HttpParams()
    .set('page', page.toString())
    .set('size', size.toString());
    
    if (filters) {
      Object.keys(filters).forEach(key => {
        if (filters[key]) {
          let value = filters[key];
          if (key === 'startDate' || key === 'endDate') {
            value = new Date(value).toISOString();
          } else if (key === 'statusCode' && typeof value === 'object') {
            value = value.code.toString();
          }
          params = params.set(key, value);
        }
      });      
    }

    if (sort) {
      sort.forEach(s => {
        params = params.append('sort', `${s.field},${s.direction}`);
      });
    }

    return this.httpClient.get<PageableData<FileModel>>(`${this.APIUrl}/import-file/${registerCode}`, { params: params });
  }

  getImportJournal(registerCode: string, fileId: number, page: number = 0, size: number = 5, sort?: { field: string, direction: 'asc' | 'desc' | '' }[]): Observable<PageableData<ImportJournalModel>> {
    let params = new HttpParams()
    .set('page', page.toString())
    .set('size', size.toString());

    if (sort) {
      sort.forEach(s => {
        params = params.append('sort', `${s.field},${s.direction}`);
      });
    }

    return this.httpClient.get<PageableData<ImportJournalModel>>(`${this.APIUrl}/import-file/${registerCode}/details/${fileId}/import-journal`, { params: params });
  }

  getRegisterNormativeActs(registerCode: string): Observable<DisplayValueWithCodeModel[]> {
    return this.httpClient.get<DisplayValueWithCodeModel[]>(`${this.APIUrl}/${registerCode}/info`);
  }

  downloadJournal(registerCode: string, fileId: number): Observable<HttpResponse<Blob>> {
    return this.httpClient.get(`${this.APIUrl}/import-file/${registerCode}/details/${fileId}/download-journal`, {
      responseType: 'blob',
      observe: 'response'
    });
  }

  downloadWithErrors(registerCode: string, fileId: number): Observable<HttpResponse<Blob>> {
    return this.httpClient.get(`${this.APIUrl}/import-file/${registerCode}/details/${fileId}/import-errors`, {
      responseType: 'blob',
      observe: 'response'
    });
  }

  startMigration(registerCode: string, fileId: number): Observable<StatusChangeModel> {
    return this.httpClient.post<StatusChangeModel>(`${this.APIUrl}/import-file/${registerCode}/details/${fileId}/import-migration`, null);
  }

  getFileData(registerCode: string, importId: number): Observable<ImportData> {
    return this.httpClient.get<ImportData>(`${this.APIUrl}/import-file/${registerCode}/details/${importId}`);
  }

  getStatuses(): Observable<DisplayValueWithCodeModel[]> {
    return this.httpClient.get<DisplayValueWithCodeModel[]>(`${this.APIUrl}/statuses`);
  }

  getResourceUrl(): string {
    return 'import/registers';
  }

  fromServerModel(json: any): RegisterModel {
    return new RegisterModel(json);
  }
}
