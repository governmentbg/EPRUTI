import { PageableData } from "./pageable-data";

describe('PageableData', () => {
  it('should create an instance', () => {
    expect(new PageableData()).toBeTruthy();
  });

  it('should initialize properties correctly', () => {
    const data = new PageableData({
      content: [1, 2, 3],
      size: 3,
      pageNumber: 1,
      totalElements: 10,
      statusCode: '200',
      isLast: false
    });

    expect(data.content).toEqual([1, 2, 3]);
    expect(data.size).toBe(3);
    expect(data.pageNumber).toBe(1);
    expect(data.totalElements).toBe(10);
    expect(data.statusCode).toBe('200');
    expect(data.isLast).toBe(false);
  });

  it('should map content using the provided constructor', () => {
    class TestClass {
      value: number;
      constructor(value: number) {
        this.value = value;
      }
    }

    const data = new PageableData<TestClass>({
      content: [1, 2, 3].map(value => new TestClass(value))
    }, TestClass);

    expect(data.content).toEqual([new TestClass(1), new TestClass(2), new TestClass(3)]);
  });

  it('should handle empty content correctly', () => {
    const data = new PageableData();

    expect(data.content).toEqual([]);
  });
});
