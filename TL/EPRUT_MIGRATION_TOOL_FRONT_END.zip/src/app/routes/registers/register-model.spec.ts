import { RegisterModel } from './register-model';

describe('RegisterModel', () => {
  it('should create an instance', () => {
    expect(new RegisterModel()).toBeTruthy();
  });

  it('should accept partial initialization', () => {
    const partialInit = { description: 'Test description' };
    const model = new RegisterModel(partialInit);
    expect(model.description).toEqual('Test description');
  });

  it('should have undefined description if not initialized', () => {
    const model = new RegisterModel();
    expect(model.description).toBeUndefined();
  });
});
