import { FileDetailsModel } from './file-details-model';

describe('FileDetailsModel', () => {
  it('should create an instance', () => {
    expect(new FileDetailsModel()).toBeTruthy();
  });

  it('should initialize properties correctly', () => {
    const init = {
      name: 'Test File',
      size: 1024,
      objectsCount: 10,
      actsCount: 5,
      filesAttached: 2
    };
    const model = new FileDetailsModel(init);
    expect(model.name).toBe(init.name);
    expect(model.size).toBe(init.size);
    expect(model.objectsCount).toBe(init.objectsCount);
    expect(model.actsCount).toBe(init.actsCount);
    expect(model.filesAttached).toBe(init.filesAttached);
  });

  it('should have default values for properties when not initialized', () => {
    const model = new FileDetailsModel();
    expect(model.name).toBeUndefined();
    expect(model.size).toBeUndefined();
    expect(model.objectsCount).toBeUndefined();
    expect(model.actsCount).toBeUndefined();
    expect(model.filesAttached).toBeUndefined();
  });
});
