import { Route } from "@angular/router";
import { RegistersComponent } from "./registers/registers.component";
import { ImportFileComponent } from "./import-file/import-file.component";
import { FileDetailsComponent } from "./import-file/file-details/file-details.component";

export const registersRoutes: Route[] = [
    {
        path: '',
        component: RegistersComponent,
    },
    {
        path: 'import-file/:code',
        component: ImportFileComponent,
    },
    {
        path: 'import-file/:code/details/:fileId',
        component: FileDetailsComponent,
    },
    { path: '**', redirectTo: '' }
];