import { ImportJournalModel } from './import-journal-model';

describe('ImportJournalModel', () => {
  it('should create an instance', () => {
    expect(new ImportJournalModel()).toBeTruthy();
  });

  it('should initialize properties correctly', () => {
    const init = {
      uploadDate: new Date('2023-10-01T00:00:00Z'),
      msgType: 'INFO',
      message: 'Test message'
    };
    const model = new ImportJournalModel(init);

    expect(model.uploadDate).toEqual(new Date(init.uploadDate));
    expect(model.msgType).toBe(init.msgType);
    expect(model.message).toBe(init.message);
  });

  it('should handle partial initialization', () => {
    const init = {
      msgType: 'ERROR'
    };
    const model = new ImportJournalModel(init);

    expect(model.uploadDate).toBeUndefined();
    expect(model.msgType).toBe(init.msgType);
    expect(model.message).toBeUndefined();
  });

  it('should create an instance without initialization', () => {
    const model = new ImportJournalModel();

    expect(model.uploadDate).toBeUndefined();
    expect(model.msgType).toBeUndefined();
    expect(model.message).toBeUndefined();
  });
});
