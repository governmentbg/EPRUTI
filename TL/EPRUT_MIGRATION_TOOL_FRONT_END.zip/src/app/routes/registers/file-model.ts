import { ApiModel } from "@shared/models/api-model";

export class FileModel extends ApiModel<FileModel> {

    uploadDate: Date;
    fileName: string;
    statusId: number;
    statusCode: string;
    statusDescription: string;
    registerDescription: string;

    constructor(init?: Partial<FileModel>) {
        super(FileModel);

        Object.assign(this, init);

        if (init?.uploadDate) {
            this.uploadDate = new Date(init.uploadDate);
        }
    }
}
