import { ImportData } from './import-data';

describe('ImportData', () => {
  it('should create an instance', () => {
    expect(new ImportData()).toBeTruthy();
  });

  it('should initialize properties correctly', () => {
    const init = {
      filename: 'test.csv',
      size: 1024,
      numActs: 10,
      numObjects: 5,
      numAttachedFiles: 2,
      hasErrors: false
    };
    const importData = new ImportData(init);
    expect(importData.filename).toBe(init.filename);
    expect(importData.size).toBe(init.size);
    expect(importData.numActs).toBe(init.numActs);
    expect(importData.numObjects).toBe(init.numObjects);
    expect(importData.numAttachedFiles).toBe(init.numAttachedFiles);
    expect(importData.hasErrors).toBe(init.hasErrors);
  });

  it('should handle partial initialization', () => {
    const init = {
      filename: 'partial.csv',
      size: 512
    };
    const importData = new ImportData(init);
    expect(importData.filename).toBe(init.filename);
    expect(importData.size).toBe(init.size);
    expect(importData.numActs).toBeUndefined();
    expect(importData.numObjects).toBeUndefined();
    expect(importData.numAttachedFiles).toBeUndefined();
    expect(importData.hasErrors).toBeUndefined();
  });
});
