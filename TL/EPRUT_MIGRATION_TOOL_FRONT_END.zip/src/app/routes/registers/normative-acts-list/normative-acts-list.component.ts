import { AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { TranslateModule } from '@ngx-translate/core';
import { MaterialModule } from '@shared/material.module';
import { DisplayValueWithCodeModel } from '@shared/models/display-value-with-code-model';
import { RegistersService } from '../registers.service';
import { Observable } from 'rxjs';
import { AsyncPipe } from '@angular/common';

@Component({
  selector: 'app-normative-acts-list',
  standalone: true,
  imports: [
    TranslateModule,
    AsyncPipe,
    MaterialModule
  ],
  templateUrl: './normative-acts-list.component.html',
  styleUrl: './normative-acts-list.component.scss'
})
export class NormativeActsListComponent implements OnInit {

  normativeActs$: Observable<DisplayValueWithCodeModel[]>;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: DisplayValueWithCodeModel,
    private _dialogRef: MatDialogRef<NormativeActsListComponent>,
    private _registersService: RegistersService
  ) { }

  ngOnInit(): void {
    this.normativeActs$ = this._registersService.getRegisterNormativeActs(this.data.code);
  }

  close(): void {
    this._dialogRef.close();
  }

}
