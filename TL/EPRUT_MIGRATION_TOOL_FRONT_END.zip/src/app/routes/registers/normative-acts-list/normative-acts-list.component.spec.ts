import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { of } from 'rxjs';
import { RegistersService } from '../registers.service';
import { DisplayValueWithCodeModel } from '@shared/models/display-value-with-code-model';

import { NormativeActsListComponent } from './normative-acts-list.component';

describe('NormativeActsListComponent', () => {
  let component: NormativeActsListComponent;
  let fixture: ComponentFixture<NormativeActsListComponent>;
  let mockDialogRef: MatDialogRef<NormativeActsListComponent>;
  let mockRegistersService: RegistersService;
  let mockData: DisplayValueWithCodeModel;

  beforeEach(async () => {
    mockDialogRef = jasmine.createSpyObj(['close']);
    mockRegistersService = jasmine.createSpyObj(['getRegisterNormativeActs']);
    
    await TestBed.configureTestingModule({
      imports: [NormativeActsListComponent],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: mockData },
        { provide: MatDialogRef, useValue: mockDialogRef },
        { provide: RegistersService, useValue: mockRegistersService }
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NormativeActsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close the dialog', () => {
    component.close();
    expect(mockDialogRef.close).toHaveBeenCalled();
  });
});
