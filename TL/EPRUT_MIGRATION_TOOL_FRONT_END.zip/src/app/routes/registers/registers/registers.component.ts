import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  OnInit,
  inject,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { catchError, map, Observable, of, Subject, Subscription, takeUntil, tap } from 'rxjs';

import { SettingsService } from '@core';
import { BreadcrumbComponent } from '@shared';
import { RegistersService } from '../registers.service';
import { RegisterModel } from '../register-model';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TranslateModule } from '@ngx-translate/core';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ActivatedRoute, Router } from '@angular/router';
import { AsyncPipe } from '@angular/common';
import { AbstractControl, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { NormativeActsListComponent } from '../normative-acts-list/normative-acts-list.component';
import { LoadingService } from '@shared/components/loading-bar/loading.service';
import { TemplateDownloadService } from '@core/services/template-download.service';

@Component({
  selector: 'app-registers',
  templateUrl: './registers.component.html',
  styleUrl: './registers.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [
    MatButtonModule,
    MatTooltipModule,
    MatDialogModule,
    ReactiveFormsModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatTableModule,
    TranslateModule,
    BreadcrumbComponent,
    AsyncPipe
  ],
})
export class RegistersComponent implements OnInit, OnDestroy {

  private _unsubscribeAll: Subject<any> = new Subject<any>();

  private readonly settings = inject(SettingsService);

  notifySubscription = Subscription.EMPTY;

  dataSource: RegisterModel[] = [];
  filteredRegisters$: Observable<RegisterModel[]> = of([]);

  filterForm: FormGroup;

  displayedColumns = ['name', 'actions'];

  constructor(
    private _dialog: MatDialog,
    private _snackbar: MatSnackBar,
    private _fb: FormBuilder,
    private _registersService: RegistersService,
    private _templateDownloadService: TemplateDownloadService,
    private _route: ActivatedRoute,
    private _loadingService: LoadingService,
    private _router: Router,
  ) {}

  ngOnInit() {

    this.notifySubscription = this.settings.notify.subscribe(opts => {
      this.filteredRegisters$ = this._registersService.getList().pipe(
        tap((registers) => {
          this.dataSource = registers;
        }),
        catchError((error) => {
          return of([]);
        }),
        takeUntil(this._unsubscribeAll)
      );
    });

    this.filterForm = this._fb.group({
      registerName: [null]
    });
  }

  clearFilter(): void {
    this.registerName?.reset();
    this.applyFilter('');
  }

  applyFilter(value: string): void {
    const filterValue = value.trim().toLowerCase();
    this.filteredRegisters$ = of(this.dataSource.filter(register => 
      register.description.toLowerCase().includes(filterValue)
    ));
  }

  showNormActs(event: Event, row: any): void {
    event.stopPropagation();
    
    this._loadingService.show();
    this._dialog.open(NormativeActsListComponent, {
      data: row,
    });
  }

  importFile(row: any): void {
    this._router.navigate(['import-file', row.code], { 
      relativeTo: this._route,
      state: { description: row.description }
    });
  }

  downloadFile(event: Event, code: string, type: 'excel' | 'xml'): void {
    event.stopPropagation();

    this._templateDownloadService.downloadFile(code, type).pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: (res) => {
        const blob = res.blob;
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = res.fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      }
    });
  }

  public get registerName(): AbstractControl | null {
    return this.filterForm?.get('registerName');
  }

  ngOnDestroy() {
    this.notifySubscription.unsubscribe();
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
