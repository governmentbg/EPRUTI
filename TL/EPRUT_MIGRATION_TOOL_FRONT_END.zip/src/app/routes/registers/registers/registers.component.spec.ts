import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { RegistersComponent } from './registers.component';
import { RegistersService } from '../registers.service';
import { SettingsService } from '@core';
import { LoadingService } from '@shared/components/loading-bar/loading.service';

describe('RegistersComponent', () => {
  let component: RegistersComponent;
  let fixture: ComponentFixture<RegistersComponent>;
  let registersService: jasmine.SpyObj<RegistersService>;
  let settingsService: jasmine.SpyObj<SettingsService>;

  beforeEach(async () => {
    const registersServiceSpy = jasmine.createSpyObj('RegistersService', ['getList']);
    const settingsServiceSpy = jasmine.createSpyObj('SettingsService', ['notify']);

    await TestBed.configureTestingModule({
      declarations: [RegistersComponent],
      imports: [
        ReactiveFormsModule,
        FormsModule,
        MatDialogModule,
        MatSnackBarModule,
        RouterTestingModule,
        TranslateModule.forRoot(),
        MatIconModule,
        MatTooltipModule,
        MatTableModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        BrowserAnimationsModule
      ],
      providers: [
        { provide: RegistersService, useValue: registersServiceSpy },
        { provide: SettingsService, useValue: settingsServiceSpy },
        LoadingService
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(RegistersComponent);
    component = fixture.componentInstance;
    registersService = TestBed.inject(RegistersService) as jasmine.SpyObj<RegistersService>;

    registersService.getList.and.returnValue(of([]));

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize filterForm', () => {
    expect(component.filterForm).toBeDefined();
  });

  it('should call getList and populate dataSource on init', () => {
    expect(registersService.getList).toHaveBeenCalled();
    expect(component.dataSource).toEqual([]);
  });

  it('should reset filter form and apply filter', () => {
    component.filterForm.controls['registerName'].setValue('test');
    component.clearFilter();
    expect(component.filterForm.controls['registerName'].value).toBeNull();
  });

  it('should filter registers based on input', () => {
    component.dataSource = [{ description: 'test' }] as any;
    component.applyFilter('test');
    component.filteredRegisters$.subscribe(filtered => {
      expect(filtered.length).toBe(1);
    });
  });

  it('should open dialog on showNormActs', () => {
    const dialogSpy = spyOn(component['_dialog'], 'open');
    component.showNormActs(new Event('click'), {});
    expect(dialogSpy).toHaveBeenCalled();
  });

  it('should navigate on importFile', () => {
    const routerSpy = spyOn(component['_router'], 'navigate');
    component.importFile({ code: '123', description: 'test' });
    expect(routerSpy).toHaveBeenCalledWith(['import-file', '123'], { 
      relativeTo: component['_route'],
      state: { description: 'test' }
    });
  });

  it('should unsubscribe on destroy', () => {
    const unsubscribeSpy = spyOn(component['_unsubscribeAll'], 'next');
    component.ngOnDestroy();
    expect(unsubscribeSpy).toHaveBeenCalled();
  });
});
