import { ApiModel } from "@shared/models/api-model";

export class RegisterModel extends ApiModel<RegisterModel> {

    description: string;

    constructor(init?: Partial<RegisterModel>) {
        super(RegisterModel);
        if (init) {
            Object.assign(this, init);
        }
    }
}
