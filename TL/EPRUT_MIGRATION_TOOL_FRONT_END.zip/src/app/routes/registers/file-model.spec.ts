import { FileModel } from './file-model';

describe('FileModel', () => {
  it('should create an instance', () => {
    expect(new FileModel()).toBeTruthy();
  });

  it('should initialize properties correctly', () => {
    const init = {
      uploadDate: new Date('2023-10-01T00:00:00Z'),
      fileName: 'testFile.txt',
      statusId: 1,
      statusCode: 'ACTIVE',
      statusDescription: 'Active status',
      registerDescription: 'Test register'
    };
    const fileModel = new FileModel(init);

    expect(fileModel.uploadDate).toEqual(new Date(init.uploadDate));
    expect(fileModel.fileName).toBe(init.fileName);
    expect(fileModel.statusId).toBe(init.statusId);
    expect(fileModel.statusCode).toBe(init.statusCode);
    expect(fileModel.statusDescription).toBe(init.statusDescription);
    expect(fileModel.registerDescription).toBe(init.registerDescription);
  });

  it('should handle missing optional properties', () => {
    const init = {
      fileName: 'testFile.txt',
      statusId: 1
    };
    const fileModel = new FileModel(init);

    expect(fileModel.uploadDate).toBeUndefined();
    expect(fileModel.fileName).toBe(init.fileName);
    expect(fileModel.statusId).toBe(init.statusId);
    expect(fileModel.statusCode).toBeUndefined();
    expect(fileModel.statusDescription).toBeUndefined();
    expect(fileModel.registerDescription).toBeUndefined();
  });
});
