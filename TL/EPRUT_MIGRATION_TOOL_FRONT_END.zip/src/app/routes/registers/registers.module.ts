import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { registersRoutes } from './registers.routes';



@NgModule({
  declarations: [],
  imports: [
    RouterModule.forChild(registersRoutes),
    CommonModule
  ]
})
export class RegistersModule { }
