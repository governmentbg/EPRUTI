import { ApiModel } from "@shared/models/api-model";

export class StatusChangeModel extends ApiModel<StatusChangeModel> {

    statusId: number;
    statusCode: string;

    constructor(init?: Partial<StatusChangeModel>) {
        super(StatusChangeModel);
        Object.assign(this, init);
    }
}
