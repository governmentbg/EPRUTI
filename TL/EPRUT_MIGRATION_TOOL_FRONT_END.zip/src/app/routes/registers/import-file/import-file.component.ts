import { Component, OnInit, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { BreadcrumbComponent } from '@shared';
import { FileUploaderComponent } from '@shared/components/file-uploader/file-uploader.component';
import { FileListComponent } from './file-list/file-list.component';
import { MaterialModule } from '@shared/material.module';

@Component({
  selector: 'app-import-file',
  standalone: true,
  imports: [
    BreadcrumbComponent,
    MatButtonModule,
    MatIconModule,
    TranslateModule,
    MaterialModule,
    FileUploaderComponent,
    FileListComponent
  ],
  templateUrl: './import-file.component.html',
  styleUrl: './import-file.component.scss'
})
export class ImportFileComponent implements OnInit {

  @ViewChild('fileListComponent') fileListComponent: FileListComponent;

  code: string;
  intervals: number[] = [15, 30, 60];
  selectedInterval: number = 0;

  constructor(
    private _router: Router,
    private _route: ActivatedRoute
  ) {  }

  ngOnInit(): void {
    this.code = this._route.snapshot.params['code'];
  }

  refreshTable(): void {
    const savedFormValues = localStorage.getItem('fileListFormValues');
    this.fileListComponent.refresh(this.fileListComponent.pageIndex, this.fileListComponent.pageSize, JSON.parse(savedFormValues), this.fileListComponent.lastSavedSorting ? [{ field: this.fileListComponent.lastSavedSorting.active, direction: this.fileListComponent.lastSavedSorting.direction }] : null);
  }

  onIntervalChange(interval: number): void {
    this.selectedInterval = interval;
  }

  back(): void {
    this._router.navigate(['../'], { relativeTo: this._route });
  }

}
