import { AsyncPipe, CommonModule } from '@angular/common';
import { AfterViewInit, Component, inject, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { MaterialModule } from '@shared/material.module';
import { DisplayValueWithCodeModel } from '@shared/models/display-value-with-code-model';
import { NomenclaturesService } from '@shared/nomenclatures/nomenclatures.service';
import { interval, map, Observable, startWith, Subject, Subscription, takeUntil, tap, timer } from 'rxjs';
import { FileModel } from '../../file-model';
import { MatSort, MatSortable } from '@angular/material/sort';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { RegistersService } from '../../registers.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SettingsService } from '@core';
import { StatusColorDirective } from '@shared/directives/status-color.directive';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-file-list',
  standalone: true,
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule,
    StatusColorDirective,
    AsyncPipe
  ],
  templateUrl: './file-list.component.html',
  styleUrl: './file-list.component.scss'
})
export class FileListComponent implements OnInit, OnChanges, OnDestroy {

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  private _initLoad: boolean = true;

  private readonly settings = inject(SettingsService);

  @Input() registerCode: string;

  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  formGroup: FormGroup;

  @Input() duration: number;

  notifySubscription: Subscription = Subscription.EMPTY;
  timerSubscription: Subscription = Subscription.EMPTY;

  filteredStatuses$: Observable<DisplayValueWithCodeModel[]>;
  statuses: DisplayValueWithCodeModel[];
  totalElements: number;
  pageSize: number = 5;
  pageIndex: number = 0;
  lastSavedSorting: { active: string; direction: 'asc' | 'desc' | '' };

  dataSource: MatTableDataSource<FileModel>;
  displayedColumns: string[] = [
    'uploadDate',
    'filename',
    'statusCode',
    'actions'
  ];

  constructor(
    private _snackbar: MatSnackBar,
    private _translateService: TranslateService,
    private _router: Router,
    private _route: ActivatedRoute,
    private _registersService: RegistersService,
    private _nomenclaturesService: NomenclaturesService,
    private _fb: FormBuilder
  ) {
  }

  ngOnInit(): void {

    this._nomenclaturesService.getFileStatuses().pipe(takeUntil(this._unsubscribeAll))
    .subscribe({
      next: (statuses) => {
        this.statuses = statuses;

        this.filteredStatuses$ = this.statusCode.valueChanges.pipe(
          startWith(''),
          map(value => this._filter(value || '')),
        );
      }
    })

    this.formGroup = this._fb.group({
      startDate: [null],
      endDate: [null],
      statusCode: [null],
    });

    const savedFormValues = localStorage.getItem('fileListFormValues');
    if (savedFormValues) {
      this.formGroup.setValue(JSON.parse(savedFormValues));
    }

    this.formGroup.valueChanges.pipe(takeUntil(this._unsubscribeAll)).subscribe(values => {
      localStorage.setItem('fileListFormValues', JSON.stringify(values));
    });

    this._registersService.refreshFiles.pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: () => {
        this.refresh(this.pageIndex, this.pageSize, this.formGroup.value, this.lastSavedSorting ? [{ field: this.lastSavedSorting.active, direction: this.lastSavedSorting.direction }] : null);
      }
    });

    this.notifySubscription = this.settings.notify.subscribe(() => {

      if (this._initLoad) {
        this._initLoad = false;
        this.sort.sort({ id: 'uploadDate', start: 'desc' } as MatSortable);
        return;
      }
      
      this.refresh(this.pageIndex, this.pageSize, this.formGroup.value, this.lastSavedSorting ? [{ field: this.lastSavedSorting.active, direction: this.lastSavedSorting.direction }] : null);
    });

  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes && changes["duration"].currentValue > 0) {

      this._snackbar.open(this._translateService.instant('fileDetails.successfullyStartedTimer', { seconds: changes["duration"].currentValue }), null, {
        duration: 5000
      });

      this.timerSubscription = timer(0, this.duration * 1000).pipe(takeUntil(this._unsubscribeAll)).subscribe({
        next: () => {
          this.refresh(this.pageIndex, this.pageSize, this.formGroup.value, this.lastSavedSorting ? [{ field: this.lastSavedSorting.active, direction: this.lastSavedSorting.direction }] : null);
        }
      });
    } else if (changes && changes["duration"].currentValue === 0) {
      this.timerSubscription.unsubscribe();
    }
  }

  get statusCode(): AbstractControl | null {
    return this.formGroup.get('statusCode');
  }

  reset(): void {
    if (this.hasFormValues()) {
      this.formGroup.reset();
      this.refresh(0, this.pageSize, this.formGroup.value, this.lastSavedSorting ? [{ field: this.lastSavedSorting.active, direction: this.lastSavedSorting.direction }] : null);
    }
  }

  submit(): void {
    const filters = {
      startDate: this.formGroup.get('startDate').value,
      endDate: this.formGroup.get('endDate').value,
      statusCode: this.formGroup.get('statusCode').value?.code
    };
    this.refresh(0, this.pageSize, filters, this.lastSavedSorting ? [{ field: this.lastSavedSorting.active, direction: this.lastSavedSorting.direction }] : null);
  }

  refresh(pageIndex?: number, pageSize?: number, filters?: { startDate?: string; endDate?: string; statusCode?: string }, sort?: { field: string, direction: 'asc' | 'desc' | '' }[]): void {
    this._registersService.getFiles(this.registerCode, filters, pageIndex, pageSize, sort).pipe(takeUntil(this._unsubscribeAll))
      .subscribe({
        next: (pageableFiles) => {
          this.dataSource = new MatTableDataSource<FileModel>(pageableFiles.content);

          this.totalElements = pageableFiles.totalElements;
          this.pageIndex = pageableFiles.pageNumber;
        }
      });
  }

  changePage(event: PageEvent): void {
    if (event.pageSize) {
      this.pageSize = event.pageSize;
    }

    this.refresh(event.pageIndex, event.pageSize, this.formGroup.value, this.lastSavedSorting ? [{ field: this.lastSavedSorting.active, direction: this.lastSavedSorting.direction }] : null);
  }

  changeSort(event: { active: string; direction: 'asc' | 'desc' | '' }): void {
    this.lastSavedSorting = event;
    this.refresh(this.pageIndex, this.pageSize, this.formGroup.value, [{ field: event.active, direction: event.direction }]);
  }

  showFileInfo(row: any): void {
    this._router.navigate(['details', row.id], { relativeTo: this._route });
  }

  displayFn(value: DisplayValueWithCodeModel): string {
    return value && value.description ? value.description : '';
  }

  private _filter(value: string | DisplayValueWithCodeModel): DisplayValueWithCodeModel[] {

    let filterValue: string;

    if (typeof value === 'object') {      
      filterValue = value?.description.toLowerCase();
    } else {
      filterValue = value?.toLowerCase();
    }

    return this.statuses?.filter(option => option.description.toLowerCase().includes(filterValue));
  }

  hasFormValues(): boolean {
    return Object.values(this.formGroup.controls).some(control => control.value);
  }

  ngOnDestroy(): void {
    this.timerSubscription.unsubscribe();
    this.notifySubscription.unsubscribe();
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
