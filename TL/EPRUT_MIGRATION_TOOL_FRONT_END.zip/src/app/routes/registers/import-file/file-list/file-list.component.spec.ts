import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, Subject } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RegistersService } from '../../registers.service';
import { NomenclaturesService } from '@shared/nomenclatures/nomenclatures.service';
import { SettingsService } from '@core';
import { FormBuilder } from '@angular/forms';
import { FileListComponent } from './file-list.component';

describe('FileListComponent', () => {
  let component: FileListComponent;
  let fixture: ComponentFixture<FileListComponent>;
  let mockRegistersService;
  let mockNomenclaturesService;
  let mockSettingsService;
  let mockSnackbar;
  let mockTranslateService;
  let mockRouter;
  let mockActivatedRoute;

  beforeEach(async () => {
    mockRegistersService = jasmine.createSpyObj('RegistersService', ['getFiles', 'refreshFiles']);
    mockNomenclaturesService = jasmine.createSpyObj('NomenclaturesService', ['getFileStatuses']);
    mockSettingsService = { notify: new Subject() };
    mockSnackbar = jasmine.createSpyObj('MatSnackBar', ['open']);
    mockTranslateService = jasmine.createSpyObj('TranslateService', ['instant']);
    mockRouter = jasmine.createSpyObj('Router', ['navigate']);
    mockActivatedRoute = { snapshot: { params: {} } };

    await TestBed.configureTestingModule({
      imports: [FileListComponent],
      providers: [
        { provide: RegistersService, useValue: mockRegistersService },
        { provide: NomenclaturesService, useValue: mockNomenclaturesService },
        { provide: SettingsService, useValue: mockSettingsService },
        { provide: MatSnackBar, useValue: mockSnackbar },
        { provide: TranslateService, useValue: mockTranslateService },
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        FormBuilder
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(FileListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should refresh files on settings notify', () => {
    spyOn(component, 'refresh');
    mockSettingsService.notify.next();
    expect(component.refresh).toHaveBeenCalled();
  });

  it('should refresh files on duration change', () => {
    spyOn(component, 'refresh');
    component.ngOnChanges({ duration: { currentValue: 10, previousValue: 0, firstChange: false, isFirstChange: () => false } });
    expect(component.refresh).toHaveBeenCalled();
  });

  it('should reset form and refresh files', () => {
    spyOn(component, 'refresh');
    component.reset();
    expect(component.formGroup.value).toEqual({ startDate: null, endDate: null, statusCode: null });
    expect(component.refresh).toHaveBeenCalled();
  });

  it('should submit form and refresh files', () => {
    spyOn(component, 'refresh');
    component.submit();
    expect(component.refresh).toHaveBeenCalled();
  });

  it('should unsubscribe from all subscriptions on destroy', () => {
    spyOn(component['_unsubscribeAll'], 'next');
    spyOn(component['_unsubscribeAll'], 'complete');
    component.ngOnDestroy();
    expect(component['_unsubscribeAll'].next).toHaveBeenCalled();
    expect(component['_unsubscribeAll'].complete).toHaveBeenCalled();
  });
});
