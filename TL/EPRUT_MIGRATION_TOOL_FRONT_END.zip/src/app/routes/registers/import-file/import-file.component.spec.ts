import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';
import { FileListComponent } from './file-list/file-list.component';

import { ImportFileComponent } from './import-file.component';

describe('ImportFileComponent', () => {
  let component: ImportFileComponent;
  let fixture: ComponentFixture<ImportFileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ImportFileComponent, RouterTestingModule],
      providers: [
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: { params: { code: 'testCode' } }
          }
        }
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImportFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set code on ngOnInit', () => {
    component.ngOnInit();
    expect(component.code).toBe('testCode');
  });

  it('should refresh table', () => {
    const fileListComponent = jasmine.createSpyObj('FileListComponent', ['refresh']);
    component.fileListComponent = fileListComponent;
    spyOn(localStorage, 'getItem').and.returnValue(JSON.stringify({}));
    component.refreshTable();
    expect(fileListComponent.refresh).toHaveBeenCalled();
  });

  it('should change interval', () => {
    component.onIntervalChange(30);
    expect(component.selectedInterval).toBe(30);
  });
});
