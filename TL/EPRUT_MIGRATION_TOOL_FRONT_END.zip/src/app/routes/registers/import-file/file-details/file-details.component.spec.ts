import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FileDetailsComponent } from './file-details.component';
import { RegistersService } from '../../registers.service';
import { of, throwError } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { TranslateModule } from '@ngx-translate/core';
import { HttpHeaders, HttpResponse } from '@angular/common/http';

describe('FileDetailsComponent', () => {
  let component: FileDetailsComponent;
  let fixture: ComponentFixture<FileDetailsComponent>;
  let registersService: RegistersService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        FileDetailsComponent,
        HttpClientTestingModule,
        RouterTestingModule,
        MatSnackBarModule,
        TranslateModule.forRoot()
      ],
      providers: [RegistersService]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FileDetailsComponent);
    component = fixture.componentInstance;
    registersService = TestBed.inject(RegistersService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize form group on init', () => {
    component.ngOnInit();
    expect(component.formGroup).toBeDefined();
  });

  it('should handle error when fetching file data', () => {
    spyOn(registersService, 'getFileData').and.returnValue(throwError({ status: 404 }));
    spyOn(component['_router'], 'navigate');
    component.ngOnInit();
    expect(component['_router'].navigate).toHaveBeenCalledWith([`/registers/import-file/${component.code}`]);
  });

  it('should change page and refresh data', () => {
    spyOn(component, 'refresh');
    component.changePage({ pageIndex: 1, pageSize: 10, length: 100 });
    expect(component.refresh).toHaveBeenCalledWith(1, 10, jasmine.any(Array));
  });

  it('should change sort and refresh data', () => {
    spyOn(component, 'refresh');
    component.changeSort({ active: 'dateAdded', direction: 'asc' });
    expect(component.refresh).toHaveBeenCalledWith(component.pageIndex, component.pageSize, jasmine.any(Array));
  });

  it('should handle error when starting migration', () => {
    spyOn(registersService, 'startMigration').and.returnValue(throwError({}));
    spyOn(console, 'error');
    component.startMigration();
    expect(console.error).toHaveBeenCalled();
  });

  it('should download file with errors', () => {
    spyOn(registersService, 'downloadWithErrors').and.returnValue(of(new HttpResponse({ body: new Blob() })));
    spyOn(document.body, 'appendChild').and.callThrough();
    component.downloadWithErrors();
    expect(registersService.downloadWithErrors).toHaveBeenCalled();
    expect(document.body.appendChild).toHaveBeenCalled();
  });

  it('should download journal', () => {
    spyOn(registersService, 'downloadJournal').and.returnValue(of(new HttpResponse({ body: new Blob() })));
    spyOn(document.body, 'appendChild').and.callThrough();
    component.downloadJournal();
    expect(registersService.downloadJournal).toHaveBeenCalled();
    expect(document.body.appendChild).toHaveBeenCalled();
  });

  it('should start timer with interval', () => {
    spyOn(component, 'startTimer');
    component.onIntervalChange(30);
    expect(component.startTimer).toHaveBeenCalledWith(30);
  });

  it('should stop timer', () => {
    spyOn(component.timerSubscription, 'unsubscribe');
    component.stopTimer();
    expect(component.timerSubscription.unsubscribe).toHaveBeenCalled();
  });

  it('should refresh table', () => {
    spyOn(component, 'refresh');
    component.refreshTable();
    expect(component.refresh).toHaveBeenCalled();
  });

  it('should navigate back', () => {
    spyOn(component['_router'], 'navigate');
    component.back();
    expect(component['_router'].navigate).toHaveBeenCalledWith([`/registers/import-file/${component.code}`]);
  });

  it('should unsubscribe on destroy', () => {
    spyOn(component.timerSubscription, 'unsubscribe');
    spyOn(component.notifySubscription, 'unsubscribe');
    component.ngOnDestroy();
    expect(component.timerSubscription.unsubscribe).toHaveBeenCalled();
    expect(component.notifySubscription.unsubscribe).toHaveBeenCalled();
  });
});
