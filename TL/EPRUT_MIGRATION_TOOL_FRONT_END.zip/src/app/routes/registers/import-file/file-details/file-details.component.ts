import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, EventEmitter, inject, Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { BreadcrumbComponent } from '@shared/components/breadcrumb/breadcrumb.component';
import { MaterialModule } from '@shared/material.module';
import { RegistersService } from '../../registers.service';
import { Subject, Subscription, takeUntil, timer } from 'rxjs';
import { ImportJournalModel } from '../../import-journal-model';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { SettingsService } from '@core';
import { HttpStatusCode } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort, MatSortable } from '@angular/material/sort';

@Component({
  selector: 'app-file-details',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    BreadcrumbComponent,
    TranslateModule
  ],
  templateUrl: './file-details.component.html',
  styleUrl: './file-details.component.scss'
})
export class FileDetailsComponent implements OnInit, OnDestroy {

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  private _initLoad: boolean = true;

  private readonly settings = inject(SettingsService);

  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  selectedInterval: number = 0;

  statusCode: string;
  code: string;
  intervals: number[] = [15, 30, 60];
  fileId: number;
  hasErrors: boolean;
  isLastFetched: boolean = false;
  
  notifySubscription = Subscription.EMPTY;
  timerSubscription: Subscription = Subscription.EMPTY;

  formGroup: FormGroup;
  lastSavedSorting: { active: string; direction: 'asc' | 'desc' | '' };
  dataSource: MatTableDataSource<ImportJournalModel>;
  totalElements: number;
  pageSize: number = 5;
  pageIndex: number = 0;
  displayedColumns: string[] = [
    'dateAdded',
    'msgType',
    'message',
  ];

  constructor(
    private _snackbar: MatSnackBar,
    private _translateService: TranslateService,
    private _registersService: RegistersService,
    private _fb: FormBuilder,
    private _router: Router,
    private _route: ActivatedRoute
  ) {
    this.code = this._route.snapshot.params['code'];
    this.fileId = this._route.snapshot.params['fileId'];
  }

  ngOnInit(): void {

    this.formGroup = this._fb.group({
      filename: [null],
      size: [null],
      numActs: [null],
      numObjects: [null],
      numAttachedFiles: [null]
    });

    this.formGroup.disable();

    this._registersService.getFileData(this.code, this.fileId).pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: (data) => {
        this.formGroup.patchValue(data);
        this.hasErrors = data.hasErrors;
      },
      error: (e) => {

        if (e.status === HttpStatusCode.NotFound || e.status === HttpStatusCode.Unauthorized) {
          this._router.navigate([`/registers/import-file/${this.code}`]);          
        }

        console.error(e);
      }
    });

    if (this._initLoad) {
      this._initLoad = false;
      this.sort.sort({ id: 'dateAdded', start: 'desc' } as MatSortable);
      return;
    }

    // this.notifySubscription = this.settings.notify.subscribe(() => {
    //   this.refresh(this.pageIndex, this.pageSize, this.lastSavedSorting ? [{ field: this.lastSavedSorting.active, direction: this.lastSavedSorting.direction }] : null);
    // });
  }

  changePage(event: PageEvent): void {
    if (event.pageSize) {
      this.pageSize = event.pageSize;
    }

    this.refresh(event.pageIndex, event.pageSize, this.lastSavedSorting ? [{ field: this.lastSavedSorting.active, direction: this.lastSavedSorting.direction }] : null);
  }

  changeSort(event: { active: string; direction: 'asc' | 'desc' | '' }): void {
    this.lastSavedSorting = event;
    this.refresh(this.pageIndex, this.pageSize, [{ field: event.active, direction: event.direction }]);
  }

  startMigration(): void {
    this._registersService.startMigration(this.code, this.fileId).pipe(takeUntil(this._unsubscribeAll))
      .subscribe({
        next: (res) => {

          this._snackbar.open(this._translateService.instant('fileDetails.successfullyStartedMigration'), this._translateService.instant('common.close'), {
            duration: 5000
          });

          if (!this.selectedInterval || this.selectedInterval === 0) {
            this.refresh(this.pageIndex, this.pageSize, this.lastSavedSorting ? [{ field: this.lastSavedSorting.active, direction: this.lastSavedSorting.direction }] : null);
            return;
          }

          this.startTimer(this.selectedInterval);
        },
        error: (e) => {
          console.error(e);
        }
      });
  }

  downloadWithErrors(): void {
    this._registersService.downloadWithErrors(this.code, this.fileId).pipe(takeUntil(this._unsubscribeAll))
      .subscribe({
        next: (res) => {
          const blob = res.body;
          const contentDisposition = res.headers.get('Content-Disposition');
          const matches = /filename="([^"]*)"/.exec(contentDisposition);
          const filename = (matches != null && matches[1]) ? matches[1] : 'errors.csv';

          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          window.URL.revokeObjectURL(url);
        },
        error: (e) => {
          console.error(e);
        }
      });
  }

  downloadJournal(): void {
    this._registersService.downloadJournal(this.code, this.fileId).pipe(takeUntil(this._unsubscribeAll))
      .subscribe({
        next: (res) => {
          const blob = res.body;
          const contentDisposition = res.headers.get('Content-Disposition');
          const matches = /filename="([^"]*)"/.exec(contentDisposition);
          const filename = (matches != null && matches[1]) ? matches[1] : 'journal.csv';

          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          window.URL.revokeObjectURL(url);
        },
        error: (e) => {
          console.error(e);
        }
      });
  }

  onIntervalChange(interval: number): void {
    this.selectedInterval = interval;

    this.startTimer(interval);
  }

  startTimer(interval: number): void {
    this.stopTimer();

    if (interval > 0) {
      
      this._snackbar.open(this._translateService.instant('fileDetails.successfullyStartedTimer', { seconds: interval }), null, {
        duration: 5000
      });

      this.timerSubscription = timer(0, interval * 1000).pipe(takeUntil(this._unsubscribeAll)).subscribe({
        next: () => {

          this._registersService.getFileData(this.code, this.fileId).pipe(takeUntil(this._unsubscribeAll)).subscribe({
            next: (data) => {
              this.formGroup.patchValue(data);
              this.hasErrors = data.hasErrors;
            },
            error: (e) => {
      
              if (e.status === HttpStatusCode.NotFound || e.status === HttpStatusCode.Unauthorized) {
                this._router.navigate([`/registers/import-file/${this.code}`]);          
              }
      
              console.error(e);
            }
          });

          this.refresh(this.pageIndex, this.pageSize, this.lastSavedSorting ? [{ field: this.lastSavedSorting.active, direction: this.lastSavedSorting.direction }] : null);
        }
      });
    } else if (interval === 0) {
      this.stopTimer();
    }
  }

  stopTimer(): void {
    this.timerSubscription.unsubscribe();
  }

  refreshTable(): void {

    this._registersService.getFileData(this.code, this.fileId).pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: (data) => {
        this.formGroup.patchValue(data);
        this.hasErrors = data.hasErrors;
      },
      error: (e) => {

        if (e.status === HttpStatusCode.NotFound || e.status === HttpStatusCode.Unauthorized) {
          this._router.navigate([`/registers/import-file/${this.code}`]);          
        }

        console.error(e);
      }
    });

    this.refresh(this.pageIndex, this.pageSize, this.lastSavedSorting ? [{ field: this.lastSavedSorting.active, direction: this.lastSavedSorting.direction }] : null);
  }

  refresh(pageIndex?: number, pageSize?: number, sort?: { field: string, direction: 'asc' | 'desc' | '' }[]): void {
    this._registersService.getImportJournal(this.code, this.fileId, pageIndex, pageSize, sort).pipe(takeUntil(this._unsubscribeAll))
      .subscribe({
        next: (pageableFiles) => {
          if (pageableFiles.isLast) {
            this.isLastFetched = true;
            this.selectedInterval = 0;
            this.timerSubscription.unsubscribe();
          }

          this.statusCode = pageableFiles.statusCode;

          this.dataSource = new MatTableDataSource<ImportJournalModel>(pageableFiles.content);

          this.totalElements = pageableFiles.totalElements;
          this.pageIndex = pageableFiles.pageNumber;
        }
      });
  }

  back(): void {
    this._router.navigate([`/registers/import-file/${this.code}`]);
  }

  ngOnDestroy(): void {
    this.timerSubscription.unsubscribe();
    this.notifySubscription.unsubscribe();
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
