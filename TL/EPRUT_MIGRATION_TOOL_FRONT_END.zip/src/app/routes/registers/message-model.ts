import { ApiModel } from "@shared/models/api-model";

export class MessageModel extends ApiModel<MessageModel> {

    date: Date;
    messageType: string;
    messageDescription: string;

    constructor(init?: Partial<MessageModel>) {
        super(MessageModel);

        if (init?.date) {
            this.date = new Date(init.date);
        }
    }
}
