import { StatusColorDirective } from './status-color.directive';

describe('StatusColorDirective', () => {

  it('should create an instance', () => {

    const elementRef = { nativeElement: document.createElement('div') };

    const renderer = jasmine.createSpyObj('Renderer2', ['setStyle']);

    const directive = new StatusColorDirective(elementRef, renderer);

    expect(directive).toBeTruthy();

  })
});