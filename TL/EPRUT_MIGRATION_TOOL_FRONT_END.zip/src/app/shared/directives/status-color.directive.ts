import { Directive, ElementRef, Input, OnChanges, Renderer2, SimpleChanges } from '@angular/core';

@Directive({
  selector: '[appStatusColor]',
  standalone: true
})
export class StatusColorDirective implements OnChanges {

  @Input() statusCode: string;

  errorCodes: string[] = ['EX_ERROR', 'XML_ERROR', 'DATA_ERROR', 'TRANSFER_ERROR'];
  successCode: string = 'TRANSFER_DONE';

  constructor(private _el: ElementRef, private _renderer: Renderer2) { }

  ngOnChanges(changes: SimpleChanges): void {
    let color: string;

    if (changes['statusCode']) {
      if (this.errorCodes.includes(this.statusCode)) {
        color = '#ab3030';
      } else if (this.statusCode === this.successCode) {
        color = '#30ab42';
      }
    }

    this._renderer.removeClass(this._el.nativeElement, color);
    this._renderer.setStyle(this._el.nativeElement, 'color', color);
  }
}
