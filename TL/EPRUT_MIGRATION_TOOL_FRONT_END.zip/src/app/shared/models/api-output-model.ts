import { ApiModel } from "./api-model";

export interface ApiOutputModel<T extends ApiModel<T>> {
  result: T[],
  count: number;
  offset: number;
  size: number;
}
