import { DisplayValueModel } from "./display-value-model";

export class DisplayValueWithCodeModel extends DisplayValueModel {

  code!: string;

  constructor(init?: Partial<DisplayValueWithCodeModel>) {
    super(init);

    if (init) {
      Object.assign(this, init);
    }
  }
}
