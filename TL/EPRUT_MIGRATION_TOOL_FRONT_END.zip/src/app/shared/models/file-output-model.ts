export class FileOutputModel {
    id: number;
    statusId: number;
    userId: string;

    constructor(init?: Partial<FileOutputModel>) {
        if (init) {
            Object.assign(this, init);
        }
    }
}
