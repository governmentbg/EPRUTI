import { FileOutputModel } from './file-output-model';

describe('FileOutputModel', () => {
  it('should create an instance', () => {
    expect(new FileOutputModel()).toBeTruthy();
  });
});
