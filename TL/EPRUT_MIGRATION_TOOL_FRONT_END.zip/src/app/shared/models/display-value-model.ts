export class DisplayValueModel {
  id!: number | string;
  description!: string;

  constructor(init?: Partial<DisplayValueModel>) {
    if (init) {
      Object.assign(this, init);
    }
  }
}
