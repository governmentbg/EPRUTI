import { DisplayValueModel } from "./display-value-model";
import { DisplayValueWithCodeModel } from "./display-value-with-code-model";

export abstract class ApiModel<T> {

  id?: number | string;
  constructor(private createT: new (input: any) => T) {

  }

  convertToApi(): any {
    const res = new this.createT(this) as any;

    Object.keys(res).forEach((k: any) => {

      if (res[k] instanceof DisplayValueWithCodeModel || res[k] instanceof DisplayValueModel) {
        res[k + 'Id'] = res[k].id;
        delete res[k];
      }

    });

    return res;
  }



}
