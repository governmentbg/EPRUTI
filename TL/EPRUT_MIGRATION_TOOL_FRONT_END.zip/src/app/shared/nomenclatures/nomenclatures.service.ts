import { Injectable, Injector } from "@angular/core";
import { NomenclatureModel } from "./nomenclature-model";
import { BehaviorSubject, Observable, tap } from "rxjs";
import { DisplayValueWithCodeModel } from "@shared/models/display-value-with-code-model";
import { CrudService } from "@core/services/crud-service";


@Injectable({
    providedIn: 'root',
})
export class NomenclaturesService extends CrudService<NomenclatureModel> {
    
    private _nFileStatuses: BehaviorSubject<
        DisplayValueWithCodeModel[] | null
    > = new BehaviorSubject(null);

    constructor(injector: Injector) {
        super(injector);
    }

    get nFileStatuses$(): Observable<DisplayValueWithCodeModel[]> {
        return this._nFileStatuses.asObservable();
    }

    getFileStatuses(): Observable<DisplayValueWithCodeModel[]> {
        return this.httpClient
            .get<DisplayValueWithCodeModel[]>(
                `${this.APIPrefix}/import/registers/statuses`
            )
            .pipe(
                tap((data: DisplayValueWithCodeModel[]) => {
                    this._nFileStatuses.next(data);
                })
            );
    }

    override getResourceUrl(): string {
        return '/';
    }

    override fromServerModel(json: any): NomenclatureModel {
        return new NomenclatureModel(json);
    }
}
