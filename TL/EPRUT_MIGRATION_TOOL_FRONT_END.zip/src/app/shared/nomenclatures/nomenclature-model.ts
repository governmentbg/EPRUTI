import { ApiModel } from "@shared/models/api-model";

export class NomenclatureModel extends ApiModel<NomenclatureModel> {

    code: string;
    name: string;
    isActive?: boolean

    constructor(init?: Partial<NomenclatureModel>) {
        super(NomenclatureModel);

        Object.assign(this, init);
    }
}
