import { NomenclatureModel } from './nomenclature-model';

describe('NomenclatureModel', () => {
  it('should create an instance', () => {
    expect(new NomenclatureModel()).toBeTruthy();
  });
});
