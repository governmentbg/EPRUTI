import { Component, ElementRef, inject, Input, OnDestroy, signal, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { RegistersService } from 'app/routes/registers/registers.service';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-file-uploader',
  standalone: true,
  imports: [TranslateModule, MatIconModule, MatButtonModule],
  templateUrl: './file-uploader.component.html',
  styleUrl: './file-uploader.component.scss'
})
export class FileUploaderComponent implements OnDestroy {

  private _unsubscribeAll: Subject<any> = new Subject<any>();

  @Input() registerCode: string;

  fileName = signal('');
  fileSize = signal(0);
  uploadProgress = signal(0);
  @ViewChild('fileInput') fileInput: ElementRef | undefined;
  selectedFile: File | null = null;
  uploadSuccess: boolean = false;
  uploadError: boolean = false;

  constructor(
    private _registersService: RegistersService,
    private _translateService: TranslateService,
    private _snackBar: MatSnackBar
  ) {}

  onFileChange(event: any): void {
    const file = event.target.files[0] as File | null;

    if (!file) {
      return;
    }

    this.uploadFile(file);
  }

  onFileDrop(event: DragEvent): void {
    event.preventDefault();
    const file = event.dataTransfer?.files[0] as File | null;
    this.uploadFile(file);
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
  }

  uploadFile(file: File | null): void {
    if (file && file.type.includes('zip')) {
      this.selectedFile = file;
      this.fileSize.set(Math.round(file.size / (1024 * 1024)));

      this.uploadSuccess = true;
      this.uploadError = false;
      this.fileName.set(file.name);
    } else {
      this.uploadSuccess = false;
      this.uploadError = true;

      const message = this._translateService.instant('registers.uploadFileError');
      const action = this._translateService.instant('common.close');

      this._snackBar.open(message, action, {
        duration: 3000,
        panelClass: 'error',
      });
    }
  }

  submitFile(): void {
    if (this.selectedFile) {
      this._registersService.submitFile(this.registerCode, this.selectedFile).pipe(takeUntil(this._unsubscribeAll)).subscribe({
        next: () => {

          const message = this._translateService.instant('registers.importSuccess', { fileName: this.selectedFile?.name });
          const action = this._translateService.instant('common.close');

          this._snackBar.open(message, action, {
            duration: 3000,
          });

          this._registersService.refreshFiles$.next();
          this.removeFile();
        },
        error: (e) => {
          
        }
      });
    }
  }

  removeFile(): void {
    this.selectedFile = null;
    this.fileName.set('');
    this.fileSize.set(0);
    this.uploadSuccess = false;
    this.uploadError = false;
    this.uploadProgress.set(0);
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
