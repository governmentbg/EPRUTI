import { ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewEncapsulation, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { NavigationEnd, Router, RouterLink } from '@angular/router';
import { MenuService } from '@core/bootstrap/menu.service';
import { TranslateModule } from '@ngx-translate/core';
import { filter, startWith, Subject, Subscription, switchMap, takeUntil } from 'rxjs';
import { RegistersService } from 'app/routes/registers/registers.service';
import { SettingsService } from '@core';

@Component({
  selector: 'breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrl: './breadcrumb.component.scss',
  encapsulation: ViewEncapsulation.None,
  standalone: true,
  imports: [MatIconModule, TranslateModule, RouterLink],
})
export class BreadcrumbComponent implements OnInit, OnDestroy {

  private _unsubscribeAll: Subject<any> = new Subject<any>();

  private readonly router = inject(Router);
  private readonly menu = inject(MenuService);

  @Input() nav: string[] = [];

  @Input() isSubMenu: boolean = false;

  @Input() registerCode: string;

  navItems: { name: string; breadcrumb: string; link: string; code?: string }[] = [];
  breadcrumbTitle: string;
  notifySubscription = Subscription.EMPTY;

  constructor(
    private _registersService: RegistersService,
    private _settings: SettingsService,
    private _cdr: ChangeDetectorRef
  ) {  }

  trackByNavItem(index: number, item: string) {
    return item;
  }

  ngOnInit() {
    this.router.events
      .pipe(
        filter(event => event instanceof NavigationEnd),
        startWith(this.router)
      )
      .subscribe(() => {
        this.genBreadcrumb();
      });
  }

  genBreadcrumb() {

    const routes = this.router.url.slice(1).split('/');
    this.navItems = this.menu.getLevel(routes, this.isSubMenu);
    this._cdr.detectChanges();

    this.notifySubscription = this._settings.notify.pipe(
      switchMap(() => {
        if (this.registerCode) {
          return this._registersService.getRegisterDescription(this.registerCode);
        }
        return [];
      }),
      takeUntil(this._unsubscribeAll)
    ).subscribe({
      next: (register) => {
        if (register) {
          this.breadcrumbTitle = register.description;
        }
      }
    });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
    this.notifySubscription.unsubscribe();
  }
}
