import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BreadcrumbComponent } from './breadcrumb.component';
import { provideRouter } from '@angular/router';
import { MenuService } from '@core/bootstrap/menu.service';
import { TranslateModule } from '@ngx-translate/core';
import { of } from 'rxjs';
import { ChangeDetectorRef } from '@angular/core';

describe('BreadcrumbComponent', () => {
  let component: BreadcrumbComponent;
  let fixture: ComponentFixture<BreadcrumbComponent>;
  let menuServiceStub: Partial<MenuService>;

  beforeEach(async () => {
    menuServiceStub = {
      change: () => of([]),
      getLevel: (routes: string[], isSubMenu: boolean) => []
    };

    await TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot()],
      declarations: [BreadcrumbComponent],
      providers: [
        provideRouter([]),
        { provide: MenuService, useValue: menuServiceStub },
        ChangeDetectorRef
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should generate breadcrumb on init', () => {
    spyOn(component, 'genBreadcrumb');
    component.ngOnInit();
    expect(component.genBreadcrumb).toHaveBeenCalled();
  });

  it('should unsubscribe on destroy', () => {
    spyOn(component['_unsubscribeAll'], 'next');
    spyOn(component['_unsubscribeAll'], 'complete');
    component.ngOnDestroy();
    expect(component['_unsubscribeAll'].next).toHaveBeenCalled();
    expect(component['_unsubscribeAll'].complete).toHaveBeenCalled();
  });

  it('should track by nav item', () => {
    const item = 'test';
    const index = 1;
    expect(component.trackByNavItem(index, item)).toBe(item);
  });
});
