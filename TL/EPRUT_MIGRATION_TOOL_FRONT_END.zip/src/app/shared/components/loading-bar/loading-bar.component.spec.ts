import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoadingBarComponent } from './loading-bar.component';
import { LoadingService } from './loading.service';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { of, Subject } from 'rxjs';

describe('LoadingBarComponent', () => {
    let component: LoadingBarComponent;
    let fixture: ComponentFixture<LoadingBarComponent>;
    let loadingService: LoadingService;

    beforeEach(async () => {
        const loadingServiceMock = {
            get mode$() { return of('indeterminate'); },
            get progress$() { return of(50); },
            get show$() { return of(true); },
            setAutoMode: jasmine.createSpy('setAutoMode')
        };

        await TestBed.configureTestingModule({
            declarations: [LoadingBarComponent],
            imports: [MatProgressBarModule],
            providers: [
                { provide: LoadingService, useValue: loadingServiceMock }
            ]
        }).compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(LoadingBarComponent);
        component = fixture.componentInstance;
        loadingService = TestBed.inject(LoadingService);
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should set auto mode on changes', () => {
        component.autoMode = false;
        component.ngOnChanges({
            autoMode: {
                currentValue: false,
                previousValue: true,
                firstChange: false,
                isFirstChange: () => false
            }
        });
        expect(loadingService.setAutoMode).toHaveBeenCalledWith(false);
    });

    it('should subscribe to mode$', () => {
        const modeSubject = new Subject<'determinate' | 'indeterminate'>();
        spyOnProperty(loadingService, 'mode$').and.returnValue(modeSubject.asObservable());
        component.ngOnInit();
        modeSubject.next('determinate');
        expect(component.mode).toBe('determinate');
    });

    it('should subscribe to progress$', () => {
        const progressSubject = new Subject<number>();
        spyOnProperty(loadingService, 'progress$').and.returnValue(progressSubject.asObservable());
        component.ngOnInit();
        progressSubject.next(75);
        expect(component.progress).toBe(75);
    });

    it('should subscribe to show$', () => {
        const showSubject = new Subject<boolean>();
        spyOnProperty(loadingService, 'show$').and.returnValue(showSubject.asObservable());
        component.ngOnInit();
        showSubject.next(true);
        expect(component.show).toBe(true);
    });

    it('should unsubscribe on destroy', () => {
        const unsubscribeSpy = spyOn(component['_unsubscribeAll'], 'next');
        const completeSpy = spyOn(component['_unsubscribeAll'], 'complete');
        component.ngOnDestroy();
        expect(unsubscribeSpy).toHaveBeenCalled();
        expect(completeSpy).toHaveBeenCalled();
    });
});
