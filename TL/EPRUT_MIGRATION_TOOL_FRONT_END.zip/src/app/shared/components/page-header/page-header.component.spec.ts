import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { PageHeaderComponent } from './page-header.component';
import { BreadcrumbComponent } from '../breadcrumb/breadcrumb.component';
import { MenuService } from '@core';

describe('PageHeaderComponent', () => {
  let component: PageHeaderComponent;
  let fixture: ComponentFixture<PageHeaderComponent>;
  let menuService: jasmine.SpyObj<MenuService>;

  beforeEach(async () => {
    const menuSpy = jasmine.createSpyObj('MenuService', ['getLevel']);

    await TestBed.configureTestingModule({
      imports: [TranslateModule.forRoot(), BreadcrumbComponent],
      declarations: [PageHeaderComponent],
      providers: [
        { provide: MenuService, useValue: menuSpy },
        provideRouter([]),
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(PageHeaderComponent);
    component = fixture.componentInstance;
    menuService = TestBed.inject(MenuService) as jasmine.SpyObj<MenuService>;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set title from menu level if not provided', () => {
    const mockMenuLevel = [{ name: 'Dashboard', breadcrumb: 'Dashboard', link: '/dashboard' }];
    menuService.getLevel.and.returnValue(mockMenuLevel);
    component.ngOnInit();
    expect(component.title).toBe('Dashboard');
  });

  it('should not override provided title', () => {
    component.title = 'Custom Title';
    component.ngOnInit();
    expect(component.title).toBe('Custom Title');
  });

  it('should hide breadcrumb when hideBreadcrumb is true', () => {
    component.hideBreadcrumb = true;
    fixture.detectChanges();
    const breadcrumbElement = fixture.nativeElement.querySelector('breadcrumb');
    expect(breadcrumbElement).toBeNull();
  });

  it('should show breadcrumb when hideBreadcrumb is false', () => {
    component.hideBreadcrumb = false;
    component.nav = ['Home', 'Dashboard'];
    fixture.detectChanges();
    const breadcrumbElement = fixture.nativeElement.querySelector('breadcrumb');
    expect(breadcrumbElement).not.toBeNull();
  });
});
