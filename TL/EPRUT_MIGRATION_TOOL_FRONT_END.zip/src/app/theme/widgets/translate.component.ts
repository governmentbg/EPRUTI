import { CommonModule, KeyValuePipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { SettingsService } from '@core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-translate',
  template: `

    <!-- Button -->
    <button
        mat-button
        (click)="toggleLanguage()">
        <div class="flex items-center">
            <span class="w-6 rounded-sm pt-2 overflow-hidden">
                <img
                    class="w-full rounded-full"
                    [src]="'assets/images/flags/' + flagCodes[nextLang]?.toUpperCase() + '.svg'"
                    [alt]="'Flag image for ' + nextLang">
            </span>
            <span class="text-sm ml-3">{{ getLabel(nextLang) }}</span>
        </div>
    </button>
    
  `,
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule, MatMenuModule],
})
export class TranslateComponent {
  private readonly translate = inject(TranslateService);
  private readonly settings = inject(SettingsService);

  activeLang: string = 'bg';
  flagCodes: { [key: string]: string };
  langs: { id: string, label: string }[] = [
    { id: 'bg', label: 'Български' },
    { id: 'en', label: 'English' },
  ];

  constructor() {
    this.translate.addLangs(['bg', 'en']);

    this.flagCodes = {
      bg: 'bg',
      en: 'en',
    };
  }

  useLanguage(language: string) {
    this.activeLang = language;
    this.translate.use(language);
    this.settings.setLanguage(language);
  }

  get nextLang(): string {
    return this.activeLang === 'bg' ? 'en' : 'bg';
  }

  toggleLanguage() {
    this.useLanguage(this.nextLang);
  }

  getLabel(lang: string): string {
    return this.langs.find(l => l.id === lang)?.label || '';
  }
}
