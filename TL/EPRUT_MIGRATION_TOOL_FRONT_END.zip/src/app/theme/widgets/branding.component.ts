import { Component, Input } from '@angular/core';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-branding',
  template: `
    <a class="branding" [routerLink]="['/']">
      <img src="assets/images/logo.png" class="branding-logo" alt="logo" />
    </a>
  `,
  styles: `
    .branding {
      display: flex;
      align-items: center;
      margin: 0 0.5rem;
      text-decoration: none;
      white-space: nowrap;
      color: inherit;
    }

    .branding-logo {
      width: 16.5rem;
      height: 4.3rem;
    }
  `,
  standalone: true,
  imports: [TranslateModule, RouterModule],
})
export class BrandingComponent {
  @Input() showName = true;
}
