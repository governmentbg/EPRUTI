import { BehaviorSubject, Observable, catchError, map, startWith, tap, throwError } from "rxjs";
import { BaseRequestService } from "./base-request-service";
import { EventEmitter, Injectable, Injector } from "@angular/core";
import { HttpErrorResponse, HttpParams } from "@angular/common/http";
import { ApiModel } from "@shared/models/api-model";

@Injectable({
    providedIn: 'root'
})
export class CrudService<T extends ApiModel<any>> extends BaseRequestService<T> {

    error: EventEmitter<HttpErrorResponse> = new EventEmitter();


    private _item: BehaviorSubject<T | null> = new BehaviorSubject<T | null>(null);
    private _items: BehaviorSubject<T[]> = new BehaviorSubject<T[]>([]);

    private _loading: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

    constructor(injector: Injector) {
        super(injector);
    }

    get data$(): Observable<T[] | null> {
        return this._items.asObservable();
    }

    get item$(): Observable<T | null> {
        return this._item.asObservable();
    }


    get loading$(): Observable<boolean> {
        return this._loading.asObservable();
    }


    getResourceUrl(): string {
        throw new Error('Method not implemented.');
    }

    fromServerModel(json: any): T {
        throw new Error('Method not implemented.');
    }

    getList(): Observable<T[]> {

        this._loading.next(true);

        return this.httpClient.get<T[]>(this.APIUrl)
            .pipe(
                map((json) => json.map((item) => this.fromServerModel(item))),
                catchError(e => {
                    this._loading.next(false);
                    return this.handleError(e);
                }),
                tap(() => this._loading.next(false)),
            );

    }

    get(id: string | number): Observable<T> {

        this._loading.next(true);

        return this.httpClient.get<T>(`/${this.APIUrl}/${id}`)
            .pipe(
                map((json) => this.fromServerModel(json)),
                catchError(e => {
                    this._loading.next(false);
                    return this.handleError(e);
                }),
                tap(() => this._loading.next(false)),
            );
    }


    create(resource: T): Observable<T> {

        this._loading.next(true);

        return this.httpClient.post<T>(`/${this.APIUrl}`, this.toServerModel(resource))
            .pipe(
                map((json) => this.fromServerModel(json)),
                catchError(e => {
                    this._loading.next(false);
                    return this.handleError(e);
                }),
                tap(() => this._loading.next(false)),
            );
    }

    delete(id: string | number): Observable<T> {

        this._loading.next(true);

        return this.httpClient.delete<T>(`/${this.APIUrl}/${id}`)
            .pipe(
                map((json) => this.fromServerModel(json)),
                catchError(e => {
                    this._loading.next(false);
                    return this.handleError(e);
                }),
                tap(() => this._loading.next(false)),
            );
    }

    update(id: string | number, resource: T): Observable<T> {

        this._loading.next(true);

        return this.httpClient.put<T>(`/${this.APIUrl}/${id}`, this.toServerModel(resource))
            .pipe(
                map((json) => this.fromServerModel(json)),
                catchError(e => {
                    this._loading.next(false);
                    return this.handleError(e);
                }),
                tap(() => this._loading.next(false)),
            );
    }

    protected override handleError(error: HttpErrorResponse) {

        return throwError(() => error);

    }

}
