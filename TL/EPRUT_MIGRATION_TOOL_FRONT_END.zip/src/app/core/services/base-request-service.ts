import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { throwError } from "rxjs";
import { Injector } from "@angular/core";
import { ApiModel } from "@shared/models/api-model";

export abstract class BaseRequestService<T extends ApiModel<any>> {

    protected get APIPrefix(): string { return '/import-api/' };

    protected get APIUrl(): string { return this.APIPrefix + this.getResourceUrl() };

    protected httpClient: HttpClient;

    constructor(protected injector: Injector) {
        this.httpClient = injector.get<HttpClient>(HttpClient);

    }

    abstract getResourceUrl(): string;

    protected getResourceUrlWithParams(): string {
        return '';
    }


    toServerModel(entity: T): any {

        delete entity.id;
        return entity.convertToApi();
    }

    abstract fromServerModel(json: any): T;

    protected handleError(error: HttpErrorResponse) {

        console.log('error.message', error.error);
        return throwError(() => error.error);
    }
}
