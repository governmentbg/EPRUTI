export interface AppSettings {
  navPos: 'top' | 'side';
  dir: 'ltr';
  theme: 'light';
  showHeader: boolean;
  headerPos: 'fixed' | 'above';
  showUserPanel: boolean;
  sidenavOpened: boolean;
  sidenavCollapsed: boolean;
  language: string;
}

export const defaults: AppSettings = {
  navPos: 'top',
  dir: 'ltr',
  theme: 'light',
  showHeader: true,
  headerPos: 'fixed',
  showUserPanel: true,
  sidenavOpened: true,
  sidenavCollapsed: false,
  language: 'bg',
};
