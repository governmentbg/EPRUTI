import { Component, OnInit, AfterViewInit, inject } from '@angular/core';
import { PreloaderService, SettingsService } from '@core';
import { RouterOutlet } from '@angular/router';
import { LoadingBarComponent } from '@shared/components/loading-bar/loading-bar.component';

@Component({
  selector: 'app-root',
  template: `
    <loading-bar [autoMode]="true"></loading-bar>
    <router-outlet />
  `,
  standalone: true,
  imports: [RouterOutlet, LoadingBarComponent],
})
export class AppComponent implements OnInit, AfterViewInit {
  private readonly preloader = inject(PreloaderService);
  private readonly settings = inject(SettingsService);

  ngOnInit() {
    this.settings.setDirection();
    this.settings.setTheme();
  }

  ngAfterViewInit() {
    this.preloader.hide();
  }
}
