package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum NomenclatureSheets {
    REG_TYPE_SHEET("Вид регистър", 0, 1, true),
    ACT_TYPE_SHEET("Вид на акта", 0, 1, true),
    MESSAGE_TYPE_SHEET("Вид на съобщаване", 0, 1, true),
    STATUS_SHEET("Състояние", 0, 1, true),
    ADMINISTRATION_SHEET("Администрация", 0, 1, true),
    ADMINISTRATIVE_UNIT_SHEET("Административен орган", 0, 1, true),
    TERRITORY_TYPE_SHEET("Вид територия", 0, 1, true),
    CUSTOMER_TYPE_SHEET("Вид на заявителя", 0, 1, true),
    CUSTOMER_QUALITY_SHEET("Качество", 0, 1, true),
    ID_TYPE_SHEET("Вид на идентификатор", 0, 1, true),
    COUNTRY_SHEET("Държави", 0, 2, true),
    DISTRICT_SHEET("Територия на компетентност", 6, 5, true),
    MUNICIPALITY_SHEET("Територия на компетентност", 9, 8, true),
    SETTLEMENT_SHEET("Територия на компетентност", 0, 3, true),
    REGION_SHEET("Райони", 1, 2, true),
    VILLAGE_SHEET("Селищни образувания", 0, 2, true),
    PUP_SHEET("Устройствен план ПУП", 0, 1, false),
    OUP_MUNICIPALITY_SHEET("Устройствен план ОУП община", 0, 1, false),
    OUP_CITY_SHEET("Устройствен план ОУП град", 0, 1, false),
    LAYOUT_PROJECTS_SHEET("Проекти на устройствени планове", 0, 1, false),
    DOCUMENT_COPIES_SHEET("Копия на документи", 0, 1, false),
    INVEST_PLAN_SHEET("Съдържание на инвестиц. проект", 0, 1, false);

    private final String sheetName;
    private final Boolean isMandatory;
    private final int nomenclatureCodeColumn;
    private final int nomenclatureColumn;

    NomenclatureSheets(String sheetName, int nomenclatureCodeColumn, int nomenclatureColumn, Boolean isMandatory) {
        this.sheetName = sheetName;
        this.isMandatory = isMandatory;
        this.nomenclatureCodeColumn = nomenclatureCodeColumn;
        this.nomenclatureColumn = nomenclatureColumn;
    }
}