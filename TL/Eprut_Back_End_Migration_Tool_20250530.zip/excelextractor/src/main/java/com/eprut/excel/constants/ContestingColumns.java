package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum ContestingColumns {
    NUM_ACT(0, "Номер на акта *"),                              //Номер на акта
    TEXT_CONTESTING(1, "Текстова част на оспорването"),         //Текстова част на оспорването
    GRAPHICAL_CONTESTING(2, "Графична част на оспорването");    //Графична част на оспорването

    private final int index;
    private final String columnName;

    ContestingColumns(int index, String columnName) {
        this.index = index;
        this.columnName = columnName;
    }
}
