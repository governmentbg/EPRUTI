package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum ObjectColumns implements IColumnsEnum {
    NUM_ACT(0, "Номер на акта *", "numAct", "string", null),                                              //Номер на акта
    DISTRICT(1, "Област", "district", "address", NomenclatureSheets.DISTRICT_SHEET),                                      //Област
    MUNICIPALITY(2, "Община", "municipality", "address", NomenclatureSheets.MUNICIPALITY_SHEET),                          //Община
    SETTLEMENT(3, "Населено място", "settlement", "address", NomenclatureSheets.SETTLEMENT_SHEET),                        //Населено място
    REGION(4, "Район", "region", "address", NomenclatureSheets.REGION_SHEET),                                             //Район
    VILLAGE(5, "Селищно образувание", "village", "address", NomenclatureSheets.VILLAGE_SHEET),                            //Селищно образувание
    CADIDENT(6, "Кадастрален идентификатор", "cadastre", "string", null),                                 //Кадастрален идентификатор
    LOCAL_PLACE(7, "Местност", "localPlace", "string", null),                                             //Местност
    REG_DISTRICT(8, "Квартал по регулация", "regulationDistrict", "string", null),                        //Квартал по регулация
    UPI(9, "УПИ", "upi", "string", null),                                                                 //УПИ
    CAD_REGION(10, "Планоснимачен район", "planRegion", "string", null),                                  //Планоснимачен район
    CAD_NUMBER(11, "Планоснимачен номер", "planNumber", "string", null),                                  //Планоснимачен номер
    RPM_PLACENAME(12, "Местност КВС", "kvsTerritory", "string", null),                                    //Местност КВС
    RPM_NUMBER(13, "Номер КВС", "kvsNumber", "string", null),                                             //Номер КВС
    TERRITORY_TYPE(14, "Вид територия", "territoryType", "nomenclature", NomenclatureSheets.TERRITORY_TYPE_SHEET),        //Вид територия
    PROTECTED_AREA(15, "Защитена територия", "protectedTerritory", "string", null),                       //Защитена територия
    ADDITIONAL_DESCRIPTION(16, "Допълнително описание на обекта", "description", "string", null);         //Допълнително описание на обекта

    private final int index;
    private final String columnName;
    private final String field;
    private final String type;
    private final NomenclatureSheets nomenclatureSheet;

    ObjectColumns(int index, String columnName, String field, String type, NomenclatureSheets nomenclatureSheet) {
        this.index = index;
        this.columnName = columnName;
        this.field = field;
        this.type = type;
        this.nomenclatureSheet = nomenclatureSheet;
    }
}
