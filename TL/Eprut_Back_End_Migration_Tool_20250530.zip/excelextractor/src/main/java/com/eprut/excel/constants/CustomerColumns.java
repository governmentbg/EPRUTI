package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum CustomerColumns implements IColumnsEnum {
    NUM_ACT(0, "Номер на акта *", "numAct", "string", null),                                                //Номер на акта
    CUST_TYPE(1, "Вид на заявителя", "customerType", "nomenclature", NomenclatureSheets.CUSTOMER_TYPE_SHEET),               //Вид на заявителя
    CUST_QUALITY(2, "Качество на заявителя", "capacity", "nomenclature", NomenclatureSheets.CUSTOMER_QUALITY_SHEET),        //Качество на заявителя
    ID_TYPE(3, "Вид на идентификатора", "identifierType", "nomenclature", NomenclatureSheets.ID_TYPE_SHEET),                //Вид на идентификатора
    PUBLIC_ID(4, "Публичен идентификатор", "identifier", "string", null),                                   //Публичен идентификатор
    CUST_ALIAS(5, "Наименование", "unitName", "string", null),                                              //Наименование - отключено при избор Булстат/ЕИК от поле Вид на идентификатор
    FIRSTNAME(6, "Име", "firstName", "string", null),                                                       //Име
    SURNAME(7, "Презиме", "middleName", "string", null),                                                    //Презиме
    LASTNAME(8, "Фамилия", "lastName", "string", null),                                                     //Фамилия
    EMAIL(9, "Електронен адрес", "email", "string", null),                                                  //Имейл
    PHONE(10, "Телефон", "phone", "string", null),                                                          //Телефон
    COUNTRY(11, "Държава", "country", "address", NomenclatureSheets.COUNTRY_SHEET),                                         //Държава
    DISTRICT(12, "Област", "district", "address", NomenclatureSheets.DISTRICT_SHEET),                                       //Област
    MUNICIPALITY(13, "Община", "municipality", "address", NomenclatureSheets.MUNICIPALITY_SHEET),                           //Община
    SETTLEMENT(14, "Населено място", "settlement", "address", NomenclatureSheets.SETTLEMENT_SHEET),                         //Населено място
    REGION(15, "Район", "region", "address", NomenclatureSheets.REGION_SHEET),                                              //Район - ЕКАТТЕ
    VILLAGE(16, "Селищно образувание", "village", "address", NomenclatureSheets.VILLAGE_SHEET);                             //Селищно образувание

    private final int index;
    private final String columnName;
    private final String field;
    private final String type;
    private final NomenclatureSheets nomenclatureSheet;

    CustomerColumns(int index, String columnName, String field, String type, NomenclatureSheets nomenclatureSheet) {
        this.index = index;
        this.columnName = columnName;
        this.field = field;
        this.type = type;
        this.nomenclatureSheet = nomenclatureSheet;
    }
}
