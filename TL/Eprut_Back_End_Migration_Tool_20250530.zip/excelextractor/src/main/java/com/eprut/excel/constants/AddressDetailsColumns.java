package com.eprut.excel.constants;

import lombok.Getter;

@Getter
public enum AddressDetailsColumns {
    ADDRESS_REG_NAME(17, "addrPlaceName", "Местност"),                        //Местност - наименование
    SQUARE_NAME(18, "squareName", "Площад"),                                  //Площад - наименование
    SQUARE_NUMBER(19, "squareNum", "№"),                                      //Площад №
    QUARTER_NAME(20, "quarter", "Квартал"),                                   //Квартал
    BUILDING_NUMBER(21, "flatNumber", "Блок №"),                              //Блок №
    BOULEVARD_NAME(22,  "streetName", "Булевард"),                            //Булевард - наименование
    BOULEVARD_NUMBER(23, "streetNum", "№"),                                   //Булевард №
    STREET_NAME(24,  "streetName", "Улица"),                                  //Улица - наименование
    STREET_NUMBER(25, "streetNum", "№"),                                      //Улица №
    APP_COMPLEX_NAME(26, "appComplexName", "Жилищен комплекс"),               //Жилищен комплекс - наименование
    APP_COMPLEX_NUMBER(27, "appComplexNum", "Жилищен комплекс №"),            //Жилищен комплекс №
    OTHER_LOCAL_UNIT_NAME(28, "otherluname", "Друга наименование"),           //Друга локализационна единица - наименование
    OTHER_LOCAL_UNIT_NUMBER(29, "otherlunum", "Друга №"),                     //Друга локализационна единица №
    BUILDING_ENTRANCE(30, "flatEntrance", "Вход"),                            //Вход №
    FLOOR(31, "floor", "Етаж"),                                               //Етаж
    APARTMENT_NUMBER(32, "apartment", "Апартамент/Ателие №");                 //Апартамент/Ателие №

    private final int index;
    private final String field;
    private final String columnName;

    AddressDetailsColumns(int index, String field, String columnName) {
        this.index = index;
        this.field = field;
        this.columnName = columnName;
    }
}
