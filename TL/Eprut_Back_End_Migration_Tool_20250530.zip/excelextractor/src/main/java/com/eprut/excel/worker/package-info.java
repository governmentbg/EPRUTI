/**
 * Project: eprut
 * Module: com.eprut.excel.worker
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Логика за извличане на данните от Excel.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.excel.worker;
