/**
 * Project: eprut
 * Module: com.eprut.excel.constants
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Константи за извличане на данни от Excel.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.excel.constants;
