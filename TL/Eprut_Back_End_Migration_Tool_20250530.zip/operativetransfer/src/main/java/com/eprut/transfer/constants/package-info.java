/**
 * Project: eprut
 * Module: com.eprut.transfer.constants
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Константни променливи за трансфер на импортираните данни.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.transfer.constants;
