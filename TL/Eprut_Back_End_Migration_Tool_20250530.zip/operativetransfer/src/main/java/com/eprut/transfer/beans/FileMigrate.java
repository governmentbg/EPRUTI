package com.eprut.transfer.beans;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.UUID;

@Data
@ToString
@EqualsAndHashCode
public class FileMigrate {
    private Long admId;
    private UUID uuid;
    private String rUserId;
    private String objectId;
    private Long objectTypeSysId;
    private String name;
    private BigDecimal size;
    private String url;
    private Timestamp regDate;
}
