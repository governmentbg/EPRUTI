/**
 * Project: eprut
 * Module: com.eprut.transfer
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Модул за трансфер на данни в оперативната система.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.transfer;
