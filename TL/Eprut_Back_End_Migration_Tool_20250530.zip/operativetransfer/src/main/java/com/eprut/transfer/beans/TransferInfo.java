package com.eprut.transfer.beans;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.UUID;

@Data
@ToString
@EqualsAndHashCode
public class TransferInfo {
    private Long admId;
    private UUID uuid;
}
