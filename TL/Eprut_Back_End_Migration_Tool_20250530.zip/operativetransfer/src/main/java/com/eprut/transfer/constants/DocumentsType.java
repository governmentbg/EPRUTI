package com.eprut.transfer.constants;

import lombok.Getter;

@Getter
public enum DocumentsType {
    DOCUMENT_ONE_FULL("1"),
    DOCUMENT_TWO_GDPR("2"),
    APPLICATION_ONE("3"),
    APPLICATION_TWO("4"),
    OUP_MUNICIPALITY("1"),
    OUP_CITY("2"),
    PUP("3"),
    ACCEPTED_INVEST_PROJECT("48");

    private final String code;

    DocumentsType(String code) {
        this.code = code;
    }
}
