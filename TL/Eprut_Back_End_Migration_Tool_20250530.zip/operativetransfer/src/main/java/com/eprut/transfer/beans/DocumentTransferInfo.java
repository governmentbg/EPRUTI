package com.eprut.transfer.beans;

import lombok.Data;

import java.util.UUID;

@Data
public class DocumentTransferInfo {
    private Long id;
    private Long docId;
    private Long relDocTypeId;
    private String relDocContentId;
    private String officeId;
    private Long entryTypeId;
    private UUID fileId;
    private String fileName;
    private String rUserId;
    private UUID actId;
    private String url;
}
