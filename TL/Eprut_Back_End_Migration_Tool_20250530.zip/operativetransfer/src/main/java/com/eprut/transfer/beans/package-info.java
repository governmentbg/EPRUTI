/**
 * Project: eprut
 * Module: com.eprut.transfer.beans
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Структури от данни за временно съхранение на данни които ще се трансферират в оперативната система.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.transfer.beans;
