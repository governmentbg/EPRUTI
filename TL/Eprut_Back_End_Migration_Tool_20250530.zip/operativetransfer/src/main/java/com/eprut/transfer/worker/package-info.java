/**
 * Project: eprut
 * Module: com.eprut.transfer.worker
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Логика за обработка на данните за трансфер.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.transfer.worker;
