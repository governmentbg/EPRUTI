package com.eprut.transfer.worker;

import com.eprut.db.beans.Address;
import com.eprut.db.beans.AttachedDocument;
import com.eprut.db.beans.BaseDocument;
import com.eprut.db.beans.Customer;
import com.eprut.db.beans.Document;
import com.eprut.db.beans.OfficeInfo;
import com.eprut.db.beans.RegAct;
import com.eprut.db.beans.RegActFullDocument;
import com.eprut.db.beans.RegActGdprDocument;
import com.eprut.db.beans.RegAppOneDocument;
import com.eprut.db.beans.RegAppTwoDocument;
import com.eprut.db.beans.RegContDocument;
import com.eprut.db.beans.RegObject;
import com.eprut.db.constants.Nomenclatures;
import com.eprut.db.impl.WorkBean;
import com.eprut.grpc.DocServerManager;
import com.eprut.transfer.beans.DocumentTransferInfo;
import com.eprut.transfer.beans.EkatteInfo;
import com.eprut.transfer.beans.FileMigrate;
import com.eprut.transfer.beans.TransferInfo;
import com.eprut.transfer.constants.DocumentsType;
import com.eprut.transfer.db.TransferDb;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.SignerInformation;
import org.bouncycastle.cms.SignerInformationStore;
import org.bouncycastle.util.Store;
import tl.abstractWorkers.AbstractQueueWorker;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import static com.eprut.db.DBConnector.getConnection;

@Slf4j
public class TransferWorker extends AbstractQueueWorker<WorkBean> {

    private TransferDb database;

    //Номенклатури
    private Map<String, Long> countries;
    private Map<String, EkatteInfo> ekattes;
    private Map<String, Long> municipalities;
    private Map<String, Long> provinces;
    private Map<String, Long> regions;
    private Map<String, Long> administrationTypes;
    private Map<String, Long> announcementTypes;
    private Map<String, Long> actTypes;
    private Map<String, Long> customerIdentifierTypes;
    private Map<String, Long> customerTypes;
    private Map<Long, Map<String, Long>> customerRegister;
    private Map<String, Long> issuerTypes;
    private Map<String, Long> statusTypes;
    private Map<String, Long> territoryTypes;
    private Map<String, Long> actRegisterIds;
    private Map<String, Long> registerIds;
    private Map<String, Long> objectTypes;
    private Map<String, Long> entryTypes;
    private Map<String, Long> objectTypeSys;
    private Map<String, Long> relDocTypes;
    private Map<String, Long> baseDocTypes;
    private Map<String, Long> attachedDocumentsTypes;
    private Map<Long, Map<String, Long>> documentsSubtypes;
    private Map<String, OfficeInfo> officeInfo;
    private DocServerManager docServerManager; //todo set properties
    private static final int BASE = 16;
    private static final String COUNTRY_ID = "6";

    /**
     * Initialize abstract que with some number of threads and delays.
     *
     * @param nThreads             number of treads
     * @param initialDelay         delay in see {@link  TimeUnit}.
     * @param periodOfQueueRefresh refresh period in see {@link  TimeUnit}.
     * @param timeUnit             time unit.
     */
    public TransferWorker(int nThreads, Long initialDelay, Long periodOfQueueRefresh,
                          TimeUnit timeUnit, TransferDb database, DocServerManager docServerManager) {
        super(nThreads, initialDelay, periodOfQueueRefresh, timeUnit);
        this.database = database;
        this.docServerManager = docServerManager;
    }

    @Override
    protected void updateWorkerQueue() {
        String logId = UUID.randomUUID().toString();
        try {
            database.getReadyToStart(logId).stream().distinct().filter(e -> !queue.contains(e)).forEach(queue::addLast);
        } catch (Exception e) {
            log.error("{}: updateWorkerQueue error", logId, e);
        }
    }

    @Override
    protected void workerExecutedMethod(String logId, WorkBean firstElementFromQueue) {
        boolean doWork = true;
        try {
            if (database.checkIfNotStarted(logId, firstElementFromQueue)) {
                try {
                    database.start(logId, firstElementFromQueue);
                } catch (Exception e) {
                    if (database.checkIfNotStarted(logId, firstElementFromQueue)) {
                        throw e;
                    } else {
                        doWork = false;
                    }
                }
                if (doWork) {
                    String registerCode = database.getRegisterCodeFromImport(logId, firstElementFromQueue);

                    //Зареждаме номенклатурите, които ще използваме
                    loadNomenclatures(logId, firstElementFromQueue);

                    //Извличане на URL на подпис за съответния импорт
                    String signatureURL = database.getSignatureByImport(logId, firstElementFromQueue);
                    File signature = docServerManager.downloadFile(logId, signatureURL, InetAddress.getLocalHost().getHostAddress(),
                            firstElementFromQueue.getUserId(), firstElementFromQueue.getRoles(), "");

                    if (signature == null) {
                        throw new Exception("Signature could not be found");
                    }

                    String html = parseP7sToHtml(signature);
                    //String html = "podpis";

                    //Извличаме всички валидни актове
                    Map<Long, RegAct> validRegActs =
                            database.getAllValidRegActsByImportId(logId, firstElementFromQueue);
                    //Извличаме всички валидни обекти
                    List<RegObject> validObjects =
                            database.getAllValidRegActObjectsByImportId(logId, firstElementFromQueue);
                    //Извличаме всички валидни заявители/възложители
                    List<Customer> validCustomers =
                            database.getAllValidCustomersByImportId(logId, firstElementFromQueue);
                    //Извличаме всички валидни адреси
                    Map<Long, Address> validAddresses =
                            database.getAllValidAddressesByImportId(logId, firstElementFromQueue);
                    //Извличаме всички валидни документи - Документ 1 и 2, Приложение 1 и 2, Оспорвания
                    Map<Long, Document> uploadedDocuments =
                            database.getAllUploadedDocumentByImportId(logId, firstElementFromQueue);
                    //Извличаме всички валидни Оспорвания, навързани към id на акт
                    Map<Long, List<RegContDocument>> validContestingDocuments =
                            database.getAllValidContestingsByImportId(logId, firstElementFromQueue);

                    database.finishedPreparing(logId, firstElementFromQueue);

                    Connection transactionConnection = null;
                    try {
                        transactionConnection = getConnection();

                        //Трансфер на актовете към базата данни и запазване на статуса на акта - връща Map от id на акт и RegAct.
                        Map<Long, RegAct> transferredActs =
                                transferRegActs(logId, firstElementFromQueue, transactionConnection, validRegActs,
                                        validContestingDocuments, html);

                        //Трансфер на обектите, техните адреси и връзката между тях
                        List<RegObject> actObjects =
                                transferRegActObjects(logId, firstElementFromQueue, transactionConnection, validObjects,
                                        validAddresses);

                        //Трансфер на заявителите/възложителите и техните адреси
                        List<Customer> actCustomers =
                                transferCustomers(logId, firstElementFromQueue, transactionConnection, validCustomers,
                                        validAddresses, registerCode);

                        //Трансфер на качените файлове - връща Map с id на документ и DocumentTransferInfo - информация за трансферирания файл
                        //returns a map of doc's id (before transfer) and DocumentTransferInfo
                        Map<Long, DocumentTransferInfo> uploadedDocFiles =
                                transferUploadedDocuments(logId, firstElementFromQueue, transactionConnection,
                                        transferredActs,
                                        uploadedDocuments);

                        //Трансфер на оспорванията - връща Map с id на документ (преди трансфера) и DocumentTransferInfo за оспорването - adm_id и uu_id след трансфер
                        Map<Long, DocumentTransferInfo> contestingFiles =
                                transferContestingDocuments(logId, firstElementFromQueue, transactionConnection,
                                        transferredActs, uploadedDocuments);

                        //Запълване на таблиците с връзките между акт и обект, акт и заявител/възложител, връзката между документите
                        fillActObjects(logId, firstElementFromQueue, transactionConnection, actObjects,
                                transferredActs);
                        fillActCustomers(logId, firstElementFromQueue, transactionConnection, actCustomers,
                                transferredActs);
                        fillDocumentsRelation(logId, firstElementFromQueue, transactionConnection, uploadedDocFiles);

                        //Запълване на таблицата със статусите на актовете
                        saveOutdocStatus(logId, firstElementFromQueue, transactionConnection, transferredActs,
                                validContestingDocuments, contestingFiles);

                        //Saves the files to the GRPC service
                        saveGrpcDocs(logId, firstElementFromQueue, docServerManager, uploadedDocFiles);
                        saveGrpcDocs(logId, firstElementFromQueue, docServerManager, contestingFiles);

                        if (database.hasErrorWarningMessages(logId, firstElementFromQueue)) {
                            throw new Exception("Открити са грешки или предупреждения при трансфер.");
                        }

                        transactionConnection.commit();

                        database.callPostMigrate(logId, firstElementFromQueue);
                    } catch (Exception e) {
                        if (transactionConnection != null) {
                            try {
                                transactionConnection.rollback();
                            } catch (SQLException rollbackEx) {
                                log.error("{}: Грешка при rollback", logId, rollbackEx);
                            }
                        }
                        throw e;
                    } finally {
                        if (transactionConnection != null) {
                            try {
                                transactionConnection.close();
                            } catch (SQLException closeEx) {
                                log.error("{}: Грешка при затваряне на връзката", logId, closeEx);
                            }
                        }
                    }

                    database.finish(logId, firstElementFromQueue);
                }
            }
        } catch (Exception e) {
            try {
                database.error(logId, firstElementFromQueue, e);
            } catch (Exception ex) {
                try {
                    database.logErrorMessage(logId, firstElementFromQueue,
                            "Възникна грешка при опит за стартиране на оброботка.", ex);
                } catch (Exception e1) {
                    //ignore.
                }
                this.workerExceptionHandling(logId, firstElementFromQueue, ex);
            }
        }
    }

    private void saveGrpcDocs(String logId, WorkBean firstElementFromQueue, DocServerManager serverManager, Map<Long, DocumentTransferInfo> uploadedDocFiles) throws UnknownHostException {

        for (DocumentTransferInfo value : uploadedDocFiles.values()) {
            serverManager.saveFile(logId, value.getUrl(), value.getFileId().toString(), value.getActId().toString(), value.getFileName(),
                    InetAddress.getLocalHost().getHostAddress(), firstElementFromQueue.getUserId(),
                    firstElementFromQueue.getRoles(),
                    "");
        }

    }

    private void loadNomenclatures(String logId, WorkBean firstElementFromQueue) throws Exception {
        countries = database.getCountries(logId, firstElementFromQueue);
        ekattes = database.getEkattes(logId, firstElementFromQueue);
        municipalities = database.getMunicipalities(logId, firstElementFromQueue);
        provinces = database.getProvinces(logId, firstElementFromQueue);
        regions = database.getRegions(logId, firstElementFromQueue);
        administrationTypes =
                database.getAdministrationTypes(logId, firstElementFromQueue);
        announcementTypes = database.getAnnouncementTypes(logId, firstElementFromQueue);
        actTypes = database.getActTypes(logId, firstElementFromQueue);
        customerIdentifierTypes =
                database.getCustomerIdentifierTypes(logId, firstElementFromQueue);
        customerTypes = database.getCustomerTypes(logId, firstElementFromQueue);
        customerRegister = database.getCustomerRegister(logId, firstElementFromQueue);
        issuerTypes = database.getIssuerTypes(logId, firstElementFromQueue);
        statusTypes = database.getStatusTypes(logId, firstElementFromQueue);
        territoryTypes = database.getTerritoryTypes(logId, firstElementFromQueue);
        actRegisterIds = database.getActRegisterIds(logId, firstElementFromQueue);
        registerIds = database.getRegisterIds(logId, firstElementFromQueue);
        objectTypes = database.getObjectTypes(logId, firstElementFromQueue);
        objectTypeSys = database.getObjectTypeSys(logId, firstElementFromQueue);
        entryTypes = database.getEntryTypes(logId, firstElementFromQueue);
        relDocTypes = database.getRelDocTypes(logId, firstElementFromQueue);
        baseDocTypes = database.getGroupRelDocContentTypes(logId, firstElementFromQueue);
        attachedDocumentsTypes = database.getAttachedDocumentsType(logId, firstElementFromQueue,
                baseDocTypes.get(DocumentsType.APPLICATION_ONE.getCode()),
                baseDocTypes.get(DocumentsType.APPLICATION_TWO.getCode()));
        documentsSubtypes = database.getDocumentsSubtypes(logId, firstElementFromQueue);
        officeInfo = database.getOfficeInfoByEkatte(logId, firstElementFromQueue);
    }

    private Map<Long, RegAct> transferRegActs(String logId, WorkBean work, Connection transactionConnection,
                                              Map<Long, RegAct> validRegActs,
                                              Map<Long, List<RegContDocument>> validContestingDocuments, String signatureHTML)
            throws Exception {
        log.info("{}: transferRegAct started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: validRegActs: {}", logId, validRegActs);
        log.trace("{}: validContestingDocuments: {}", logId, validContestingDocuments);
        Map<Long, RegAct> transferredActs = new HashMap<>();
        try {
            String registerNum = database.getRegisterCodeFromImport(logId, work);
            List<RegAct> regActs = new ArrayList<>(validRegActs.values());
            for (RegAct regAct : regActs) {
                regAct.setRUserId(work.getUserId());
                regAct.setActType(getMappedValue(actTypes, regAct.getActType()));
                regAct.setMessageType(getMappedValue(announcementTypes, regAct.getMessageType()));
                regAct.setStatus(getMappedValue(statusTypes, regAct.getStatus()));

                if (regAct.getAdministration().equals(Nomenclatures.PROVINCE_ADMINISTRATION.getCode())) {
                    OfficeInfo office = officeInfo.get(regAct.getAdmPopular());
                    regAct.setRnOfficeId(database.getOfficeIdByProvince(logId, work, office.getProvinceId()));
                } else if (regAct.getAdministration().equals(Nomenclatures.MUNICIPALITY_ADMINISTRATION.getCode())) {
                    OfficeInfo office = officeInfo.get(regAct.getAdmPopular());
                    regAct.setRnOfficeId(database.getOfficeIdByMunAndProvince(logId, work, office.getMunId(),
                            office.getProvinceId()));
                } else if (regAct.getAdministration().equals(Nomenclatures.REGION_ADMINISTRATION.getCode())) {
                    Long regionId = regions.get(regAct.getAdmPopular());
                    regAct.setRnOfficeId(database.getOfficeIdByRegion(logId, work, regionId));
                } else {
                    regAct.setRnOfficeId(database.getOfficeIdByAdministrationType(logId, work,
                            Long.valueOf(regAct.getAdministration())));
                }

                regAct.setAdministration(getMappedValue(administrationTypes, regAct.getAdministration()));
                regAct.setAdministrativeUnit(getMappedValue(issuerTypes, regAct.getAdministrativeUnit()));

                Long registerId = actRegisterIds.get(registerNum);
                TransferInfo outdoc =
                        database.saveRegActToTransferDB(logId, work, transactionConnection, regAct, registerId, signatureHTML);
                regAct.setOpId(outdoc.getAdmId());
                regAct.setUuid(outdoc.getUuid());
                database.setRegActOpId(logId, work, transactionConnection, regAct);
                transferredActs.put(regAct.getId(), regAct);
            }
        } catch (Exception e) {
            //database.logWarningMessage(logId, work, "Възникна проблем при обработката на трансфер - проблем при трансфер на акт.");
            log.error("{}: transferRegAct - error", logId, e);
            throw e;
        } finally {
            log.info("{}: transferRegAct finished", logId);
        }
        return transferredActs;
    }

    private List<RegObject> transferRegActObjects(String logId, WorkBean work, Connection transactionConnection,
                                                  List<RegObject> validObjects, Map<Long, Address> validAddresses)
            throws Exception {
        log.info("{}: transferRegActObjects started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: validObjects: {}", logId, validObjects);
        List<RegObject> actObjects = new ArrayList<>();
        try {
            for (RegObject regObject : validObjects) {
                regObject.setTerritoryType(getMappedValue(territoryTypes, regObject.getTerritoryType()));
                regObject.setRUserId(work.getUserId());
                Address addr = validAddresses.get(regObject.getAddressId());
                addr.setRUserId(work.getUserId());
                addr.setDistrict(getMappedValue(provinces, addr.getDistrict()));
                addr.setMunicipality(getMappedValue(municipalities, addr.getMunicipality()));
                if (addr.getSettlement() != null) {
                    addr.setSettlement(String.valueOf(ekattes.get(addr.getSettlement()).getAdmId()));
                } else if (addr.getVillage() != null) {
                    addr.setVillage(String.valueOf(ekattes.get(addr.getVillage()).getAdmId()));
                }
                addr.setRegion(getMappedValue(regions, addr.getRegion()));
                TransferInfo objectInfo =
                        database.saveRegActObjectToTransferDB(logId, work, transactionConnection, regObject, addr);
                regObject.setOpId(objectInfo.getAdmId());
                regObject.setUuid(objectInfo.getUuid());
                database.setRegActObjectOpId(logId, work, transactionConnection, regObject);

                if (addr.hasNonEmptyDataFieldsForObjects()) {
                    Long regActObjAddrId =
                            database.saveRegActObjectAddrToTransferDB(logId, work, transactionConnection, addr);
                    database.setAddressOpId(logId, work, transactionConnection, regActObjAddrId, addr);
                    database.saveRegObjectAddressRelation(logId, work, transactionConnection, regObject,
                            regActObjAddrId);
                }

                actObjects.add(regObject);
            }
        } catch (Exception e) {
            //database.logWarningMessage(logId, work, "");
            log.error("{}: transferRegActObjects - error", logId, e);
            throw e;
        } finally {
            log.info("{}: transferRegActObjects finished", logId);
        }
        return actObjects;
    }

    private List<Customer> transferCustomers(String logId, WorkBean work, Connection transactionConnection,
                                             List<Customer> validCustomers, Map<Long, Address> validAddresses,
                                             String registerCode)
            throws Exception {
        log.info("{}: transferCustomers started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: validCustomers: {}", logId, validCustomers);
        log.trace("{}: validAddresses: {}", logId, validAddresses);
        log.trace("{}: registerCode: {}", logId, registerCode);
        List<Customer> customers = new ArrayList<>();
        try {
            for (Customer customer : validCustomers) {
                Address address = validAddresses.get(customer.getAddressId());

                customer.setCustomerType(getMappedValue(customerTypes, customer.getCustomerType()));

                if (customer.getCustomerType() != null && !customer.getCustomerType().equals(COUNTRY_ID)) {
                    customer.setCapacity(getMappedValue(customerRegister.get(Long.valueOf(customer.getCustomerType())),
                            customer.getCapacity()));
                }

                customer.setIdentifierType(getMappedValue(customerIdentifierTypes, customer.getIdentifierType()));
                customer.setRUserId(work.getUserId());
                address.setDistrict(getMappedValue(provinces, address.getDistrict()));
                address.setMunicipality(getMappedValue(municipalities, address.getMunicipality()));

                String postcode = null;
                if (address.getSettlement() != null) {
                    postcode = ekattes.get(address.getSettlement()).getPostcode();
                    address.setPostcode(postcode);
                    address.setSettlement(String.valueOf(ekattes.get(address.getSettlement()).getAdmId()));

                } else if (address.getVillage() != null) {
                    postcode = ekattes.get(address.getVillage()).getPostcode();
                    address.setPostcode(postcode);
                    address.setVillage(String.valueOf(ekattes.get(address.getVillage()).getAdmId()));
                }

                address.setRegion(getMappedValue(regions, address.getRegion()));
                address.setCountry(getMappedValue(countries, address.getCountry()));
                address.setRUserId(work.getUserId());

                Long addressId = null;
                if (address.hasNonEmptyDataFieldsForCustomers()) {
                    addressId = database.saveCustomerAddressToTransferDB(logId, work, transactionConnection, address);
                    database.setAddressOpId(logId, work, transactionConnection, addressId, address);
                }

                Long registerId = registerIds.get(registerCode);
                Long opId = database.saveCustomerToTransferDB(logId, work, transactionConnection, customer, addressId,
                        registerId);
                customer.setOpId(opId);
                database.setCustomerOpId(logId, work, transactionConnection, customer);
                customers.add(customer);
            }
        } catch (Exception e) {
            //database.logWarningMessage(logId, work, "");
            log.error("{}: transferCustomers - error", logId, e);
            throw e;
        } finally {
            log.info("{}: transferCustomers finished", logId);
        }
        return customers;
    }

    //returns map of document id and DocumentTransferInfo after saving to db
    private Map<Long, DocumentTransferInfo> transferUploadedDocuments(String logId, WorkBean work,
                                                                      Connection transactionConnection,
                                                                      Map<Long, RegAct> transferredRegActs,
                                                                      Map<Long, Document> uploadedDocuments)
            throws Exception {

        log.info("{}: transferUploadedDocuments started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: transferredRegActs: {}", logId, transferredRegActs);
        log.trace("{}: uploadedDocuments: {}", logId, uploadedDocuments);
        List<RegAppOneDocument> validAppOneDocuments = database.getAllValidAppOneDocsByImportId(logId, work);
        List<RegActFullDocument> validFullDocuments = database.getAllValidFullDocsByImportId(logId, work);
        List<RegActGdprDocument> validGdprDocuments = database.getAllValidGdprDocsByImportId(logId, work);
        List<RegAppTwoDocument> validAppTwoDocuments = database.getAllValidAppTwoDocsByImportId(logId, work);

        Map<Long, DocumentTransferInfo> docFiles = new HashMap<>();
        try {
            for (RegActFullDocument regActFullDocument : validFullDocuments) {
                Document doc = uploadedDocuments.get(regActFullDocument.getDocumentId());
                DocumentTransferInfo transferredFile =
                        processBaseDocument(logId, work, transactionConnection, transferredRegActs, doc,
                                regActFullDocument,
                                DocumentsType.DOCUMENT_ONE_FULL);
                database.setFullDocumentOpId(logId, work, transactionConnection, transferredFile.getId(),
                        regActFullDocument);
                docFiles.put(doc.getId(), transferredFile);
            }

            for (RegActGdprDocument regActGdprDocument : validGdprDocuments) {
                Document doc = uploadedDocuments.get(regActGdprDocument.getDocumentId());
                DocumentTransferInfo
                        transferredFile =
                        processBaseDocument(logId, work, transactionConnection, transferredRegActs, doc,
                                regActGdprDocument,
                                DocumentsType.DOCUMENT_TWO_GDPR);
                database.setGdprDocumentOpId(logId, work, transactionConnection, transferredFile.getId(),
                        regActGdprDocument);
                docFiles.put(doc.getId(), transferredFile);
            }

            for (RegAppOneDocument regAppOneDocument : validAppOneDocuments) {
                Document doc = uploadedDocuments.get(regAppOneDocument.getDocumentId());
                DocumentTransferInfo transferredFile =
                        processAttachedDocument(logId, work, transactionConnection, transferredRegActs, doc,
                                regAppOneDocument);
                database.setAppOneDocumentOpId(logId, work, transactionConnection, transferredFile.getId(),
                        regAppOneDocument);
                docFiles.put(doc.getId(), transferredFile);
            }

            for (RegAppTwoDocument regAppTwoDocument : validAppTwoDocuments) {
                Document doc = uploadedDocuments.get(regAppTwoDocument.getDocumentId());
                DocumentTransferInfo transferredFile =
                        processAttachedDocument(logId, work, transactionConnection, transferredRegActs, doc,
                                regAppTwoDocument);
                database.setAppTwoDocumentOpId(logId, work, transactionConnection, transferredFile.getId(),
                        regAppTwoDocument);
                docFiles.put(doc.getId(), transferredFile);
            }
        } catch (Exception e) {
            //database.logWarningMessage(logId, work, "Възникна проблем при обработката на трансфер - проблем при трансфер на акт.");
            log.error("{}: transferUploadedDocuments - error", logId, e);
            throw e;
        } finally {
            log.info("{}: transferUploadedDocuments finished", logId);
        }
        return docFiles;
    }

    //returns a map of list of uploaded contesting documents, mapped by reg act id.
    private Map<Long, DocumentTransferInfo> transferContestingDocuments(String logId, WorkBean work,
                                                                        Connection transactionConnection,
                                                                        Map<Long, RegAct> transferredRegActs,
                                                                        Map<Long, Document> uploadedDocuments)
            throws Exception {

        log.info("{}: transferUploadedDocuments started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: transferredRegActs: {}", logId, transferredRegActs);
        log.trace("{}: uploadedDocuments: {}", logId, uploadedDocuments);
        Long contestingObjectTypeSysId = objectTypeSys.get(Nomenclatures.STATUS_AA.getCode());
        Map<Long, List<RegContDocument>> validContestings =
                database.getAllValidContestingsByImportId(logId, work);
        Map<Long, DocumentTransferInfo> docFiles = new HashMap<>();
        try {
            List<RegContDocument> validContestingsList =
                    validContestings.values().stream().flatMap(List::stream).toList();
            for (RegContDocument regContDocument : validContestingsList) {
                Document doc = uploadedDocuments.get(regContDocument.getDocumentId());
                RegAct regAct = transferredRegActs.get(regContDocument.getRegActId());
                FileMigrate file = new FileMigrate();
                file.setRUserId(work.getUserId());
                file.setObjectId(regAct.getUuid().toString());
                file.setObjectTypeSysId(contestingObjectTypeSysId);
                file.setName(doc.getFileName());
                file.setSize(BigDecimal.valueOf(doc.getFileSize()));
                file.setUrl(doc.getUrl());
                DocumentTransferInfo transferredFile =
                        database.saveDocumentToTransferDb(logId, work, transactionConnection, file);
                database.setContestingDocumentOpId(logId, work, transactionConnection, transferredFile.getId(),
                        regContDocument);
                docFiles.put(doc.getId(), transferredFile);
            }
        } catch (Exception e) {
            //database.logWarningMessage(logId, work, "Възникна проблем при обработката на трансфер - проблем при трансфер на акт.");
            log.error("{}: transferUploadedDocuments - error", logId, e);
            throw e;
        } finally {
            log.info("{}: transferUploadedDocuments finished", logId);
        }
        return docFiles;
    }

    private <T extends BaseDocument> DocumentTransferInfo processBaseDocument(String logId, WorkBean work,
                                                                              Connection transactionConnection,
                                                                              Map<Long, RegAct> transferredRegActs,
                                                                              Document doc,
                                                                              T baseDoc,
                                                                              DocumentsType docType)
            throws Exception {
        log.info("{}: processDocument started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: transferredRegActs: {}", logId, transferredRegActs);
        log.trace("{}: doc: {}", logId, doc);
        log.trace("{}: baseDoc: {}", logId, baseDoc);
        log.trace("{}: docType: {}", logId, docType);
        Long docObjectTypeSysId = objectTypeSys.get(Nomenclatures.OUTGOING_DOCUMENT.getCode());
        Long baseDocumentId = relDocTypes.get(Nomenclatures.BASE_DOCUMENT.getCode());
        Long entryTypeId = entryTypes.get(Nomenclatures.ENTRY_TYPE.getCode());
        DocumentTransferInfo transferredFile;
        try {
            RegAct regAct = transferredRegActs.get(baseDoc.getRegActId());
            FileMigrate file = new FileMigrate();
            file.setRUserId(work.getUserId());
            file.setObjectId(regAct.getUuid().toString());
            file.setObjectTypeSysId(docObjectTypeSysId);
            file.setName(doc.getFileName());
            file.setSize(BigDecimal.valueOf(doc.getFileSize()));
            file.setUrl(doc.getUrl());
            transferredFile = database.saveDocumentToTransferDb(logId, work, transactionConnection, file);
            transferredFile.setRUserId(work.getUserId());
            transferredFile.setDocId(regAct.getOpId());
            transferredFile.setActId(regAct.getUuid());
            transferredFile.setUrl(doc.getUrl());
            transferredFile.setRelDocTypeId(baseDocumentId);
            Long baseDocTypeId = baseDocTypes.get(docType.getCode());
            Long baseDocSubtypeId = documentsSubtypes.get(baseDocTypeId).get(docType.getCode());
            transferredFile.setRelDocContentId(baseDocSubtypeId.toString());
            transferredFile.setOfficeId(regAct.getRnOfficeId().toString()); //todo Виж ме
            transferredFile.setEntryTypeId(entryTypeId);
            transferredFile.setFileName(doc.getFileName());
        } catch (Exception e) {
            log.error("{}: processDocument - error", logId, e);
            throw e;
        } finally {
            log.info("{}: processDocument finished", logId);
        }
        return transferredFile;
    }

    private <T extends AttachedDocument> DocumentTransferInfo processAttachedDocument(String logId, WorkBean work,
                                                                                      Connection transactionConnection,
                                                                                      Map<Long, RegAct> transferredRegActs,
                                                                                      Document doc,
                                                                                      T attachedDoc)
            throws Exception {
        log.info("{}: processDocument started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: transferredRegActs: {}", logId, transferredRegActs);
        log.trace("{}: doc: {}", logId, doc);
        log.trace("{}: attachedDoc: {}", logId, attachedDoc);
        Long docObjectTypeSysId = objectTypeSys.get(Nomenclatures.OUTGOING_DOCUMENT.getCode());
        Long attachedDocumentId = relDocTypes.get(Nomenclatures.ATTACHED_DOCUMENT.getCode());
        Long entryTypeId = entryTypes.get(Nomenclatures.ENTRY_TYPE.getCode());
        DocumentTransferInfo transferredFile;
        try {
            RegAct regAct = transferredRegActs.get(attachedDoc.getRegActId());
            FileMigrate file = new FileMigrate();
            file.setRUserId(work.getUserId());
            file.setObjectId(regAct.getUuid().toString());
            file.setObjectTypeSysId(docObjectTypeSysId);
            file.setName(doc.getFileName());
            file.setSize(BigDecimal.valueOf(doc.getFileSize()));
            file.setUrl(doc.getUrl());
            transferredFile = database.saveDocumentToTransferDb(logId, work, transactionConnection, file);
            transferredFile.setRUserId(work.getUserId());
            transferredFile.setDocId(regAct.getOpId());
            transferredFile.setActId(regAct.getUuid());
            transferredFile.setUrl(doc.getUrl());
            transferredFile.setRelDocTypeId(attachedDocumentId);
            if (attachedDoc.getType() != null) {
                Long attachedDocTypeId = attachedDocumentsTypes.get(attachedDoc.getType());
                if (attachedDoc.getSubType() != null) {
                    Long attachedDocSubtypeId = documentsSubtypes.get(attachedDocTypeId).get(attachedDoc.getSubType());
                    transferredFile.setRelDocContentId(attachedDocSubtypeId.toString());
                } else {
                    transferredFile.setRelDocContentId(
                            attachedDocTypeId.toString()); //това ще работи адекватно само ако във валидацията е указано че приложение 1 задължително трябва да има въведен подтип
                }

            }
            transferredFile.setOfficeId(regAct.getRnOfficeId().toString());
            transferredFile.setEntryTypeId(entryTypeId);
            transferredFile.setFileName(doc.getFileName());
        } catch (Exception e) {
            log.error("{}: processDocument - error", logId, e);
            throw e;
        } finally {
            log.info("{}: processDocument finished", logId);
        }
        return transferredFile;
    }

    private void fillActObjects(String logId, WorkBean work, Connection transactionConnection,
                                List<RegObject> regObjects, Map<Long, RegAct> validRegActs) throws Exception {
        log.info("{}: fillActObjects started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: validRegActs: {}", logId, validRegActs);
        try {
            for (RegObject regObject : regObjects) {
                RegAct regAct = validRegActs.get(regObject.getRegActId());
                database.saveActObjects(logId, work, transactionConnection, regAct, regObject,
                        entryTypes.get(Nomenclatures.ENTRY_TYPE.getCode()),
                        objectTypes.get(Nomenclatures.OBJECT_TYPE.getCode()));
            }
        } catch (Exception e) {
            log.error("{}: fillActObjects - error", logId, e);
            throw e;
        } finally {
            log.info("{}: fillActObjects finished", logId);
        }
    }

    private void fillActCustomers(String logId, WorkBean work, Connection transactionConnection,
                                  List<Customer> actCustomers, Map<Long, RegAct> validRegActs) throws Exception {
        log.info("{}: fillActCustomers started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: validRegActs: {}", logId, validRegActs);
        try {
            for (Customer customer : actCustomers) {
                RegAct regAct = validRegActs.get(customer.getRegActId());
                database.saveActCustomers(logId, work, transactionConnection, regAct, customer);
            }
        } catch (Exception e) {
            log.error("{}: fillActCustomers - error", logId, e);
            throw e;
        } finally {
            log.info("{}: fillActCustomers finished", logId);
        }
    }

    private void fillDocumentsRelation(String logId, WorkBean work, Connection transactionConnection,
                                       Map<Long, DocumentTransferInfo> uploadedDocFiles)
            throws Exception {
        log.info("{}: fillDocumentsRelation started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: uploadedDocFiles: {}", logId, uploadedDocFiles);
        try {
            for (DocumentTransferInfo uploadedDocFile : uploadedDocFiles.values()) {
                database.transferDocumentsRelationToDb(logId, work, transactionConnection, uploadedDocFile);
            }
        } catch (Exception e) {
            log.error("{}: fillDocumentsRelation - error", logId, e);
            throw e;
        } finally {
            log.info("{}: fillDocumentsRelation finished", logId);
        }
    }

    private void saveOutdocStatus(String logId, WorkBean work, Connection transactionConnection,
                                  Map<Long, RegAct> validRegActs,
                                  Map<Long,
                                          List<RegContDocument>> validContestingDocuments,
                                  Map<Long, DocumentTransferInfo> contestingFiles)
            throws Exception {
        log.info("{}: saveOutdocStatus started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: validRegActs: {}", logId, validRegActs);
        log.trace("{}: validContestingDocuments: {}", logId, validContestingDocuments);
        String contestingStatusId = String.valueOf(statusTypes.get(Nomenclatures.CONTESTING_STATUS.getCode()));
        List<RegAct> regActs = new ArrayList<>(validRegActs.values());
        try {
            for (RegAct regAct : regActs) {
                if (Objects.equals(regAct.getStatus(), contestingStatusId)) {
                    List<RegContDocument> contDocuments = validContestingDocuments.get(regAct.getId());
                    for (RegContDocument regContDocument : contDocuments) {
                        UUID fileUuid = contestingFiles.get(regContDocument.getDocumentId()).getFileId();
                        database.transferContestingOutDocStatusToDb(logId, work, transactionConnection, regAct,
                                regContDocument, fileUuid);
                    }
                } else {
                    database.transferOutDocStatusToDb(logId, work, transactionConnection, regAct);
                }
            }
        } catch (Exception e) {
            log.error("{}: saveOutdocStatus - error", logId, e);
            throw e;
        } finally {
            log.info("{}: saveOutdocStatus finished", logId);
        }
    }

    private String parseP7sToHtml(File p7sFile) throws Exception {
        try (FileInputStream fis = new FileInputStream(p7sFile)) {
            byte[] p7sData = fis.readAllBytes();

            CMSSignedData signedData = new CMSSignedData(p7sData);
            Store<X509CertificateHolder> certStore = signedData.getCertificates();
            SignerInformationStore signers = signedData.getSignerInfos();
            Collection<SignerInformation> signerInfos = signers.getSigners();

            StringBuilder html = new StringBuilder();

            for (SignerInformation signer : signerInfos) {
                Collection<X509CertificateHolder> certCollection = certStore.getMatches(signer.getSID());
                for (X509CertificateHolder certHolder : certCollection) {
                    CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
                    X509Certificate cert = (X509Certificate) certFactory.generateCertificate(
                            new java.io.ByteArrayInputStream(certHolder.getEncoded()));

                    html.append(Base64.getEncoder().encodeToString(cert.getEncoded()));
                }
            }

            return html.toString();
        }
    }


    private String getThumbprint(X509Certificate cert) throws Exception {
        java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-1");
        byte[] der = cert.getEncoded();
        md.update(der);
        byte[] digest = md.digest();

        StringBuilder sb = new StringBuilder();
        for (byte b : digest) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }

    private String getMappedValue(Map<?, ?> map, Object key) {
        Object value = map.get(key);
        return value != null ? String.valueOf(value) : null;
    }


    @Override
    protected void workerExceptionHandling(String logId, WorkBean firstElementFromQueue, Exception e) {
        log.error("{} - TransferWorker with WorkBean : {} ERROR {}", logId, firstElementFromQueue, e, e);
    }

    @Override
    protected void workerStarted(String logId, WorkBean firstElementFromQueue) {
        log.debug("{} - TransferWorker with WorkBean : {} has STARTED working", logId, firstElementFromQueue);
    }

    @Override
    protected void workerFinished(String logId, WorkBean firstElementFromQueue) {
        log.debug("{} - TransferWorker with WorkBean : {} has FINISHED working", logId, firstElementFromQueue);
    }
}

