package com.eprut.transfer.beans;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class EkatteInfo {

    private Long admId;
    private String postcode;
}
