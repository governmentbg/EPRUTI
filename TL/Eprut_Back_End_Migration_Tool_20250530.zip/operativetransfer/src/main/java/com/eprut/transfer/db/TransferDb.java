package com.eprut.transfer.db;

import com.eprut.db.beans.Address;
import com.eprut.db.beans.Customer;
import com.eprut.db.beans.Document;
import com.eprut.db.beans.OfficeInfo;
import com.eprut.db.beans.RegAct;
import com.eprut.db.beans.RegActFullDocument;
import com.eprut.db.beans.RegActGdprDocument;
import com.eprut.db.beans.RegAppOneDocument;
import com.eprut.db.beans.RegAppTwoDocument;
import com.eprut.db.beans.RegContDocument;
import com.eprut.db.beans.RegObject;
import com.eprut.db.config.IpInfoConfig;
import com.eprut.db.impl.DatabaseManager;
import com.eprut.db.impl.WorkBean;
import com.eprut.transfer.beans.DocumentTransferInfo;
import com.eprut.transfer.beans.EkatteInfo;
import com.eprut.transfer.beans.FileMigrate;
import com.eprut.transfer.beans.TransferInfo;
import com.eprut.transfer.constants.States;
import lombok.extern.slf4j.Slf4j;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.eprut.db.DBConnector.getConnection;

@Slf4j
public class TransferDb extends DatabaseManager {

    private static final String GET_ALL_VALID_REG_ACTS_BY_IMP_ID = """
            select *
            from staging.reg_act
            where imp_id = ? and is_valid = true
            """;

    private static final String GET_ALL_VALID_REG_OBJECTS_BY_IMP_ID = """
            select *
            from staging.reg_actobject
            where imp_id = ? and is_valid = true
            """;

    private static final String GET_ALL_VALID_ADDRESSES_BY_IMPORT_ID = """
            select *
            from staging.address
            where imp_id = ? and is_valid = true
            """;

    private static final String GET_ALL_VALID_CUSTOMERS_BY_IMPORT_ID = """
            select *
            from staging.customer
            where imp_id = ? and is_valid = true
            """;

    private static final String GET_ALL_VALID_APP_ONE_DOCS_BY_IMPORT_ID = """
            select *
            from staging.reg_app01_documents
            where imp_id = ? and is_valid = true
            """;

    private static final String GET_ALL_VALID_APP_TWO_DOCS_BY_IMPORT_ID = """
            select *
            from staging.reg_app02_documents
            where imp_id = ? and is_valid = true
            """;

    private static final String GET_ALL_VALID_FULL_DOCUMENTS = """
            select *
            from staging.reg_full_documents
            where imp_id = ? and is_valid = true
            """;

    private static final String GET_ALL_VALID_GDPR_DOCUMENTS = """
            select *
            from staging.reg_gdpr_documents
            where imp_id = ? and is_valid = true
            """;

    private static final String GET_ALL_VALID_CONTESTING_BY_IMPORT_ID = """
            select *
            from staging.reg_cont_documents
            where imp_id = ? and is_valid = true
            """;

    private static final String GET_ALL_UPLOADED_DOCUMENTS_BY_IMPORT_ID = """
            select *
            from staging.documents d
            where (exists (
                select 1
                from staging.reg_full_documents fd
                where fd.document_id = d.id and fd.is_valid = true
            ) or exists (
                select 1
                from staging.reg_gdpr_documents gd
                where gd.document_id = d.id and gd.is_valid = true
            ) or exists (
                select 1
                from staging.reg_app01_documents a01d
                where a01d.document_id = d.id and a01d.is_valid = true
            ) or exists (
                select 1
                from staging.reg_app02_documents a02d
                where a02d.document_id = d.id and a02d.is_valid = true
            ) or exists (
                select 1
                from staging.reg_cont_documents rcd
                where rcd.document_id = d.id and rcd.is_valid = true
            )) and imp_id = ?;
            """;

    private static final String GET_COUNTRY = """
            select * from bnd.country
            """;

    private static final String GET_REL_DOC_TYPES = """
            select * from admdata.nreldoctype
            """;

    private static final String GET_BASE_GROUP_REL_DOC_CONTENT_TYPES = """
            select *
            from admdata.ngroupreldoccontent
            where rn_parentid is null;
            """;

    private static final String GET_ATTACHED_DOCUMENTS_TYPES = """
            select code, adm_id as id
            from admdata.ngroupreldoccontent
            where rn_parentid = ? or rn_parentid = ?
            union
            select code, adm_id as id
            from admdata.nreldoccontent
            where rn_groupreldoccontent = ? or rn_groupreldoccontent = ?;
            """;

    private static final String GET_DOCUMENTS_SUBTYPES = """
            select *
            from admdata.nreldoccontent
            where rn_groupreldoccontent is not null
            """;

    private static final String GET_DISTRICT = """
            select * from bnd.district
            """;

    private static final String GET_EKATTE = """
            select * from bnd.ekatte
            """;

    private static final String GET_MUNICIPALITY = """
            select * from bnd.municipality
            """;

    private static final String GET_PROVINCE = """
            select * from bnd.province
            """;

    private static final String GET_REGIONS = """
            select * from bnd.region
            """;

    private static final String GET_ADMINISTRATION_TYPES = """
            select * from admdata.nadministrationtype
            """;

    private static final String GET_ANNOUNCEMENT_TYPES = """
            select * from admdata.nannouncementtype
            """;

    private static final String GET_ACT_TYPES = """
            select * from admdata.nbkdoctype
            """;

    private static final String GET_CUSTOMER_IDENTIFIER_TYPES = """
            select * from regmigrate.ncustidenttype
            """;

    private static final String GET_CUSTOMER_TYPES = """
            select * from admdata.ncusttype
            """;

    private static final String GET_CUSTOMER_REGISTER = """
            select *
            from admdata.ncustomerregister
            where isvisible = true
            """;

    private static final String GET_ISSUER_TYPES = """
            select * from admdata.nissuer
            """;

    private static final String GET_STATUS_TYPES = """
            select * from admdata.nstatus
            """;

    private static final String GET_TERRITORY_TYPES = """
            select * from admdata.nterritorytype
            """;

    //todo add esignatureinfo
    private static final String SAVE_REG_ACT_TO_TRANSFER_DB = """
            insert into regmigrate.outdoc (r_userid, rn_bkdoctypeid, rn_officeid, rn_issuerid, regnum, createdate, announcedate,
                                           rn_announcementtypeid, factgrounds, leggrounds, validtodate, actdescription, entryintoforcedate, rn_actregisterid, regdate, esignatureinfo)
            values(?, ?, ?, ?, ?, ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) returning adm_id, uu_id;
            """;

    private static final String SAVE_REG_ACT_OBJECT_TO_TRANSFER_DB = """
            insert into regmigrate.regobject (r_userid, objectdesc, cadident, regplacename, regquarter, upi, cadregion, cadnumber, rpmplacename, rpmnumber,
                                           rn_territorytypeid, protectedareadesc, rn_provinceid, rn_munid, rn_ekatteid, rn_regionid, regdate)
            values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) returning adm_id, uu_id;
            """;

    //todo add full descr
    private static final String SAVE_REG_ACT_OBJECT_ADDR_TO_TRANSFER_DB = """
            insert into regmigrate.regaddr (r_userid, quarter, streetname, streetnum, flatnum, flatentrance, floor, apartment, squarename, squarenum,
                                         appcomplexname, appcomplexnum, addrplacename, regdate, otherluname, otherlunum)
            values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) returning adm_id;
            """;

    private static final String SAVE_REG_ACT_OBJECT_ADDR_RELATION = """
            insert into regmigrate.xregobjectaddr (r_userid, r_regobjectid, r_regaddrid)
            values (?, ?, ?)
            """;

    private static final String SAVE_CUSTOMER_TO_TRANSFER_DB = """
            insert into regmigrate.customer (r_userid, rn_custtypeid, egnbulstat, firstname, surname, family, othername, phone, email, rn_registertypeid, r_addressid, rn_custidenttypeid)
            values(?, ?, ?, ?, ?, ? , ?, ?, ?, ?, ?, ?) returning adm_id;
            """;

    //todo fulldesc
    private static final String SAVE_CUSTOMER_ADDRESS_TO_TRANSFER_DB = """
            insert into regmigrate.addr (r_userid, rn_countryid, rn_provinceid, rn_munid, rn_ekatteid, postcode, rn_regionid, flatentrance, floor, apartment, squarename, squarenum,
            appcomplexname, appcomplexnum, quarter, streetname, streetnum, flatnum, otherluname, otherlunum, addrplacename)
            values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, ?) returning adm_id;
            """;

    private static final String SAVE_REG_ACT_CUSTOMERS_TO_TRANSFER_DB = """
            insert into regmigrate.xoutdoccust (r_userid, r_outdocid, rn_officeid, r_custid)
            values(?, ?, ?, ?)
            """;

    private static final String SAVE_REG_ACT_OBJECTS_REL_TO_TRANSFER_DB = """
            insert into regmigrate.xdocobj(r_userid, r_docid, rn_entrytypeid, rn_objecttypeid, objectid, objectdesc)
            values(?, ?, ?, ?, ?, ?)
            """;

    private static final String SAVE_DOCUMENT_TO_TRANSFER_DB = """
            insert into regmigrate.files (r_userid, r_objectid, rn_objecttypesysid, name, size, url, regdate)
            values(?, ?, ?, ?, ?, ?, ?) returning adm_id, uu_id, "name"
            """;

    private static final String SAVE_CONTESTING_OUTDOC_STATUS_TO_TRANSFER_DB = """
            insert into regmigrate.outdocstatus (r_userid, r_outdocid, rn_statusid, description, fileid)
            values(?, ?, ?, ?, ?)
            """;

    private static final String SAVE_OUTDOC_STATUS_TO_TRANSFER_DB = """
            insert into regmigrate.outdocstatus (r_userid, r_outdocid, rn_statusid)
            values(?, ?, ?)
            """;

    private static final String SAVE_DOCUMENT_RELATION_TO_TRANSFER_DB = """
            insert into regmigrate.xdocrel (r_userid, r_docid, rn_reldoctypeid, rn_reldoccontentid, rn_officeid, rn_entrytypeid, fileid, filename)
            values(?, ?, ?, ?, ?, ?, ?, ?)
            """;

    private static final String GET_ACT_REGISTER_IDS = """
            select * from admdata.nactregister;
            """;

    private static final String GET_IMPORT = """
            select * from staging.import where id = ?
            """;

    private static final String GET_REGISTER_IDS = """
            select * from admdata.nactregister;
            """;

    private static final String GET_OBJECT_TYPES = """
            select * from admdata.nobjecttype;
            """;

    private static final String GET_OBJECT_TYPE_SYS = """
            select * from admdata.nobjecttypesys;
            """;

    private static final String GET_ENTRY_TYPES = """
            select * from admdata.nentrytype;
            """;

    private static final String UPDATE_REG_ACT_OP_ID = """
            update staging.reg_act
            set op_id = ?
            where id = ?
            """;

    private static final String UPDATE_CUSTOMER_OP_ID = """
            update staging.customer
            set op_id = ?
            where id = ?
            """;

    private static final String UPDATE_REG_ACT_OBJECT_OP_ID = """
            update staging.reg_actobject
            set op_id = ?
            where id = ?
            """;

    private static final String UPDATE_ADDRESS_OP_ID = """
            update staging.address
            set op_id = ?
            where id = ?
            """;

    private static final String UPDATE_GDPR_DOCUMENT_OP_ID = """
            update staging.reg_gdpr_documents
            set op_id = ?
            where id = ?
            """;

    private static final String UPDATE_FULL_DOCUMENT_OP_ID = """
            update staging.reg_full_documents
            set op_id = ?
            where id = ?
            """;

    private static final String UPDATE_APP_ONE_DOCUMENT_OP_ID = """
            update staging.reg_app01_documents
            set op_id = ?
            where id = ?
            """;

    private static final String UPDATE_APP_TWO_DOCUMENT_OP_ID = """
            update staging.reg_app02_documents
            set op_id = ?
            where id = ?
            """;

    private static final String UPDATE_CONTESTING_DOCUMENT_OP_ID = """
            update staging.reg_cont_documents
            set op_id = ?
            where id = ?
            """;

    private static final String HAS_ERROR_WARNING_MESSAGES = """
            select exists (
                select 1
                from staging.import_log il
                join staging.n_imp_msg_type nimt on il.msg_type_id = nimt.id
                where (nimt.code = 'WARNING' OR nimt.code = 'ERROR') and import_id = ?
            );
            """;

    private static final String GET_OFFICE_INFO = """
            select e.ekatte as ekatte, m.adm_id as mun, p.adm_id as province from bnd.ekatte e
            join bnd.municipality m on e.r_munid = m.adm_id
            join bnd.province p on m.r_provinceid = p.adm_id
            """;

    private static final String GET_OFFICE_ID_BY_MUN_AND_PROVINCE = """
            select adm_id from admdata.noffices
            where rn_provinceid = ? and rn_munid = ?
            """;

    private static final String GET_OFFICE_ID_BY_PROVINCE = """
            select adm_id from admdata.noffices
            where rn_provinceid = ? and rn_munid IS NULL
            """;

    private static final String GET_OFFICE_ID_BY_REGION = """
            select adm_id
            from admdata.noffices
            where rn_regionid = ?;
            """;

    private static final String GET_OFFICE_ID_BY_ADMINISTRATION_TYPE = """
            select adm_id from admdata.noffices
                        where rn_administrationtypeid = ?
            """;

    private static final String POST_MIGRATE_FUNCTION_CALL = """
            select regmigrate.postmigrate()
            """;

    private static final String GET_SIGNATURE_BY_IMPORT = """
            select file.url
            from staging.import_files file join staging.import i on file.id = i.file_signature_id
            where i.id = ?;
            """;

    /**
     * Get predefined work items.
     *
     * @param logId
     * @return work item.
     * @throws Exception
     */
    public List<WorkBean> getReadyToStart(String logId) throws Exception {
        return super.getReadyToStart(logId, States.TRANSFER_ACCEPTED.name());
    }

    @Override
    public WorkBean start(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.TRANSFER_PREPARING.name(), IpInfoConfig.getSignature());
    }

    @Override
    public boolean checkIfNotStarted(String logId, WorkBean work) throws Exception {
        return checkIfNotStarted(logId, work, States.TRANSFER_ACCEPTED.name());
    }

    @Override
    public WorkBean finishedPreparing(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.TRANSFER_WORKING.name());
    }

    @Override
    public WorkBean finish(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.TRANSFER_DONE.name());
    }

    @Override
    public WorkBean error(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.TRANSFER_ERROR.name());
    }

    @Override
    public WorkBean error(String logId, WorkBean work, Exception e) throws Exception {
        return changeStatusToError(logId, work, States.TRANSFER_ERROR.name(), e);
    }

    /**
     * Returns map of all valid reg acts for the current import id, mappped by reg act id.
     *
     * @param logId
     * @param work
     * @return Map<Long, RegAct>
     * @throws Exception
     */
    public Map<Long, RegAct> getAllValidRegActsByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getAllValidRegActsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<Long, RegAct> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ALL_VALID_REG_ACTS_BY_IMP_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegAct currentRegAct = new RegAct();
                        currentRegAct.setId(rs.getLong("id"));
                        currentRegAct.setImpId(rs.getLong("imp_id"));
                        currentRegAct.setExcelRow(rs.getInt("excel_row"));
                        currentRegAct.setOpId(rs.getLong("op_id"));
                        currentRegAct.setActNum(rs.getString("number"));
                        currentRegAct.setActType(rs.getString("type"));
                        Timestamp actDate = rs.getTimestamp("act_date");
                        if (actDate != null) {
                            currentRegAct.setActDate(actDate.toLocalDateTime());
                        }
                        Timestamp messageDate = rs.getTimestamp("message_date");
                        if (messageDate != null) {
                            currentRegAct.setMessageDate(messageDate.toLocalDateTime());
                        }
                        currentRegAct.setMessageType(rs.getString("message_type"));
                        Timestamp issuedDate = rs.getTimestamp("issued_date");
                        if (issuedDate != null) {
                            currentRegAct.setIssuedDate(issuedDate.toLocalDateTime());
                        }
                        currentRegAct.setStatus(rs.getString("status"));
                        Timestamp changeDate = rs.getTimestamp("change_date");
                        if (changeDate != null) {
                            currentRegAct.setChangeDate(changeDate.toLocalDateTime());
                        }
                        Timestamp validityDate = rs.getTimestamp("validity_date");
                        if (validityDate != null) {
                            currentRegAct.setValidityDate(validityDate.toLocalDateTime());
                        }
                        currentRegAct.setFactReason(rs.getString("fact_reason"));
                        currentRegAct.setLegalReason(rs.getString("legal_reason"));
                        currentRegAct.setAdministration(rs.getString("administration"));
                        currentRegAct.setAdministrativeUnit(rs.getString("administrative_unit"));
                        currentRegAct.setAdmPopular(rs.getString("adm_popular"));
                        currentRegAct.setObjectIdentification(rs.getString("object_identification"));
                        currentRegAct.setIsValid(rs.getBoolean("is_valid"));
                        result.put(currentRegAct.getId(), currentRegAct);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAllValidRegActsByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAllValidRegActsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all valid reg act objects for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegObject>
     * @throws Exception
     */
    public List<RegObject> getAllValidRegActObjectsByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getAllValidRegActObjectsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegObject> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ALL_VALID_REG_OBJECTS_BY_IMP_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegObject currentRegObject = new RegObject();
                        currentRegObject.setId(rs.getLong("id"));
                        currentRegObject.setImpId(rs.getLong("imp_id"));
                        currentRegObject.setOpId(rs.getLong("op_id"));
                        currentRegObject.setExcelRow(rs.getInt("excel_row"));
                        currentRegObject.setRegActId(rs.getLong("reg_act_id"));
                        currentRegObject.setCadastre(rs.getString("cadastre"));
                        currentRegObject.setLocalPlace(rs.getString("local_place"));
                        currentRegObject.setRegulationDistrict(rs.getString("regulation_district"));
                        currentRegObject.setUpi(rs.getString("upi"));
                        currentRegObject.setPlanRegion(rs.getString("plan_region"));
                        currentRegObject.setPlanNumber(rs.getString("plan_number"));
                        currentRegObject.setKvsTerritory(rs.getString("kvs_territory"));
                        currentRegObject.setKvsNumber(rs.getString("kvs_number"));
                        currentRegObject.setTerritoryType(rs.getString("teritory_type"));
                        currentRegObject.setProtectedTerritory(rs.getString("protected_teritory"));
                        currentRegObject.setDescription(rs.getString("description"));
                        currentRegObject.setAddressId(rs.getLong("adress_id"));
                        currentRegObject.setIsValid(rs.getBoolean("is_valid"));
                        result.add(currentRegObject);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAllValidRegActObjectsByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAllValidRegActObjectsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all valid reg act addresses for the current import id.
     *
     * @param logId
     * @param work
     * @return Map<Long, Address>
     * @throws Exception
     */
    public Map<Long, Address> getAllValidAddressesByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getAllValidAddressesByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<Long, Address> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ALL_VALID_ADDRESSES_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        Address currentAddress = new Address();
                        currentAddress.setId(rs.getLong("id"));
                        currentAddress.setImportId(rs.getLong("imp_id"));
                        currentAddress.setExcelRow(rs.getInt("excel_row"));
                        currentAddress.setOpId(rs.getLong("op_id"));
                        currentAddress.setCountry(rs.getString("country"));
                        currentAddress.setDistrict(rs.getString("district"));
                        currentAddress.setMunicipality(rs.getString("municipality"));
                        currentAddress.setSettlement(rs.getString("settlement"));
                        currentAddress.setVillage(rs.getString("village"));
                        currentAddress.setRegion(rs.getString("region"));
                        currentAddress.setFloor(rs.getString("floor"));
                        currentAddress.setFlatEntrance(rs.getString("flatentrance"));
                        currentAddress.setApartment(rs.getString("apartment"));
                        currentAddress.setSquareName(rs.getString("squarename"));
                        currentAddress.setSquareNum(rs.getString("squarenum"));
                        currentAddress.setAppComplexName(rs.getString("appcomplexname"));
                        currentAddress.setAppComplexNum(rs.getString("appcomplexnum"));
                        currentAddress.setQuarter(rs.getString("quarter"));
                        currentAddress.setStreetName(rs.getString("streetname"));
                        currentAddress.setStreetNum(rs.getString("streetnum"));
                        currentAddress.setFlatNumber(rs.getString("flatnum"));
                        currentAddress.setOtherluname(rs.getString("otherluname"));
                        currentAddress.setOtherlunum(rs.getString("otherlunum"));
                        currentAddress.setAddrPlaceName(rs.getString("addrplacename"));
                        currentAddress.setIsValid(rs.getBoolean("is_valid"));
                        result.put(currentAddress.getId(), currentAddress);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAllValidAddressesByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAllValidAddressesByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all valid reg act customers for the current import id.
     *
     * @param logId
     * @param work
     * @return List<Customers>
     * @throws Exception
     */
    public List<Customer> getAllValidCustomersByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getAllValidCustomersByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<Customer> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ALL_VALID_CUSTOMERS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        Customer currentCustomer = new Customer();
                        currentCustomer.setId(rs.getLong("id"));
                        currentCustomer.setImpId(rs.getLong("imp_id"));
                        currentCustomer.setExcelRow(rs.getInt("excel_row"));
                        currentCustomer.setOpId(rs.getLong("op_id"));
                        currentCustomer.setRegActId(rs.getLong("reg_act_id"));
                        currentCustomer.setIdentifierType(rs.getString("identifier_type"));
                        currentCustomer.setIdentifier(rs.getString("identifier"));
                        currentCustomer.setCustomerType(rs.getString("customer_type"));
                        currentCustomer.setUnitName(rs.getString("unit_name"));
                        currentCustomer.setFirstName(rs.getString("first_name"));
                        currentCustomer.setMiddleName(rs.getString("middle_name"));
                        currentCustomer.setLastName(rs.getString("last_name"));
                        currentCustomer.setEmail(rs.getString("email"));
                        currentCustomer.setPhone(rs.getString("phone"));
                        currentCustomer.setCapacity(rs.getString("capacity"));
                        currentCustomer.setAddressId(rs.getLong("adress_id"));
                        currentCustomer.setIsValid(rs.getBoolean("is_valid"));
                        result.add(currentCustomer);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAllValidCustomersByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAllValidCustomersByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns map of all valid reg act contestings for the current import id, mapped by reg act id.
     *
     * @param logId
     * @param work
     * @return Map<Long, List < RegContDocument>>
     * @throws Exception
     */
    public Map<Long, List<RegContDocument>> getAllValidContestingsByImportId(String logId, WorkBean work)
            throws Exception {
        log.info("{}: getAllValidContestingByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<Long, List<RegContDocument>> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ALL_VALID_CONTESTING_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegContDocument regContDocument = new RegContDocument();
                        regContDocument.setId(rs.getLong("id"));
                        regContDocument.setImpId(rs.getLong("imp_id"));
                        regContDocument.setExcelRow(rs.getInt("excel_row"));
                        regContDocument.setOpId(rs.getLong("op_id"));
                        regContDocument.setRegActId(rs.getLong("reg_act_id"));
                        regContDocument.setDocumentId(rs.getLong("document_id"));
                        regContDocument.setDescription(rs.getString("description"));
                        regContDocument.setIsValid(rs.getBoolean("is_valid"));
                        result.computeIfAbsent(regContDocument.getRegActId(), k -> new ArrayList<>())
                                .add(regContDocument);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAllValidContestingByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAllValidContestingByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all valid reg act application one documents for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegAppOneDocument>
     * @throws Exception
     */
    public List<RegAppOneDocument> getAllValidAppOneDocsByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getAllValidAppOneDocsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegAppOneDocument> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ALL_VALID_APP_ONE_DOCS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegAppOneDocument currentRegAppOneDocument = new RegAppOneDocument();
                        currentRegAppOneDocument.setId(rs.getLong("id"));
                        currentRegAppOneDocument.setImpId(rs.getLong("imp_id"));
                        currentRegAppOneDocument.setExcelRow(rs.getInt("excel_row"));
                        currentRegAppOneDocument.setOpId(rs.getLong("op_id"));
                        currentRegAppOneDocument.setRegActId(rs.getLong("reg_act_id"));
                        currentRegAppOneDocument.setDocumentId(rs.getLong("document_id"));
                        currentRegAppOneDocument.setType(rs.getString("type"));
                        currentRegAppOneDocument.setSubType(rs.getString("subtype"));
                        currentRegAppOneDocument.setIsValid(rs.getBoolean("is_valid"));
                        result.add(currentRegAppOneDocument);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAllValidAppOneDocsByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAllValidAppOneDocsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all valid reg act application two documents for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegAppTwoDocument>
     * @throws Exception
     */
    public List<RegAppTwoDocument> getAllValidAppTwoDocsByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getAllValidAppTwoDocsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegAppTwoDocument> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ALL_VALID_APP_TWO_DOCS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegAppTwoDocument currentRegAppOneDocument = new RegAppTwoDocument();
                        currentRegAppOneDocument.setId(rs.getLong("id"));
                        currentRegAppOneDocument.setImpId(rs.getLong("imp_id"));
                        currentRegAppOneDocument.setExcelRow(rs.getInt("excel_row"));
                        currentRegAppOneDocument.setOpId(rs.getLong("op_id"));
                        currentRegAppOneDocument.setRegActId(rs.getLong("reg_act_id"));
                        currentRegAppOneDocument.setDocumentId(rs.getLong("document_id"));
                        currentRegAppOneDocument.setType(rs.getString("type"));
                        currentRegAppOneDocument.setSubType(rs.getString("subtype"));
                        currentRegAppOneDocument.setIsValid(rs.getBoolean("is_valid"));
                        result.add(currentRegAppOneDocument);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAllValidAppTwoDocsByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAllValidAppTwoDocsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all valid reg act full documents for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegActFullDocument>
     * @throws Exception
     */
    public List<RegActFullDocument> getAllValidFullDocsByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getAllValidFullDocsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegActFullDocument> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ALL_VALID_FULL_DOCUMENTS)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegActFullDocument regActFullDocument = new RegActFullDocument();
                        regActFullDocument.setId(rs.getLong("id"));
                        regActFullDocument.setImpId(rs.getLong("imp_id"));
                        regActFullDocument.setExcelRow(rs.getInt("excel_row"));
                        regActFullDocument.setOpId(rs.getLong("op_id"));
                        regActFullDocument.setRegActId(rs.getLong("reg_act_id"));
                        regActFullDocument.setDocumentId(rs.getLong("document_id"));
                        regActFullDocument.setIsValid(rs.getBoolean("is_valid"));
                        result.add(regActFullDocument);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAllValidFullDocsByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAllValidFullDocsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all valid reg act gdpr documents for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegActGdprDocument>
     * @throws Exception
     */
    public List<RegActGdprDocument> getAllValidGdprDocsByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getAllValidFullDocsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegActGdprDocument> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ALL_VALID_GDPR_DOCUMENTS)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegActGdprDocument regActGdprDocument = new RegActGdprDocument();
                        regActGdprDocument.setId(rs.getLong("id"));
                        regActGdprDocument.setImpId(rs.getLong("imp_id"));
                        regActGdprDocument.setExcelRow(rs.getInt("excel_row"));
                        regActGdprDocument.setOpId(rs.getLong("op_id"));
                        regActGdprDocument.setRegActId(rs.getLong("reg_act_id"));
                        regActGdprDocument.setDocumentId(rs.getLong("document_id"));
                        regActGdprDocument.setIsValid(rs.getBoolean("is_valid"));
                        result.add(regActGdprDocument);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAllValidFullDocsByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAllValidFullDocsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns a map of all valid uploaded documents for current import id - everything except contesting documents, mapped by document id.
     *
     * @param logId
     * @param work
     * @return List<Document>
     * @throws Exception
     */
    public Map<Long, Document> getAllUploadedDocumentByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getAllUploadedDocumentByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<Long, Document> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ALL_UPLOADED_DOCUMENTS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        Document doc = new Document();
                        doc.setId(rs.getLong("id"));
                        doc.setImpId(rs.getLong("imp_id"));
                        doc.setFileName(rs.getString("filename"));
                        doc.setMimeType(rs.getString("mime_type"));
                        doc.setFileSize(rs.getLong("size"));
                        doc.setSha256(rs.getString("sha256"));
                        doc.setUrl(rs.getString("url"));
                        result.put(doc.getId(), doc);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAllUploadedDocumentByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAllUploadedDocumentByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Get object type sys ids by codes.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getObjectTypeSys(String logId, WorkBean work) throws Exception {
        log.info("{}: getObjectTypeSys - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_OBJECT_TYPE_SYS)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getObjectTypeSys - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getObjectTypeSys - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of country nomenclatures, mapped by country code.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getCountries(String logId, WorkBean work) throws Exception {
        log.info("{}: getCountries - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_COUNTRY)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getCountries - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getCountries - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of rel document types nomenclatures, mapped by rel doc type code.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getRelDocTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getRelDocTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REL_DOC_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRelDocTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRelDocTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of rel document content types nomenclatures, mapped by group rel doc content id.
     *
     * @param logId
     * @param work
     * @param appOneTypeId
     * @param appTwoTypeId
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getAttachedDocumentsType(String logId, WorkBean work, Long appOneTypeId, Long appTwoTypeId)
            throws Exception {
        log.info("{}: getRelDocTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: appOneTypeId: {}", logId, appOneTypeId);
        log.trace("{}: appTwoTypeId: {}", logId, appTwoTypeId);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ATTACHED_DOCUMENTS_TYPES)) {
                int i = 1;
                cs.setLong(i++, appOneTypeId);
                cs.setLong(i++, appTwoTypeId);
                cs.setLong(i++, appOneTypeId);
                cs.setLong(i++, appTwoTypeId);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRelDocTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRelDocTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of rel document content subtypes nomenclatures, mapped by group rel doc content id.
     *
     * @param logId
     * @param work
     * @return Map<Long, Map < String, Long>>
     * @throws Exception
     */
    public Map<Long, Map<String, Long>> getDocumentsSubtypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getRelDocTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<Long, Map<String, Long>> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_DOCUMENTS_SUBTYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.computeIfAbsent(rs.getLong("rn_groupreldoccontent"), k -> new HashMap<>())
                                .put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRelDocTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRelDocTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of group rel document content types nomenclatures, mapped by code.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getGroupRelDocContentTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getGroupRelDocContentTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_BASE_GROUP_REL_DOC_CONTENT_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getGroupRelDocContentTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getGroupRelDocContentTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of district nomenclatures, mapped by district nsicode.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getDistricts(String logId, WorkBean work) throws Exception {
        log.info("{}: getDistricts - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_DISTRICT)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("nsicode"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getDistricts - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getDistricts - finished", logId);
        }
        return result;
    }

    /**
     * Retrieve map of all ekattes, their adm_ids and postcodes.
     *
     * @param logId
     * @param work
     * @return Map<String, EkatteInfo>
     * @throws Exception
     */
    public Map<String, EkatteInfo> getEkattes(String logId, WorkBean work) throws Exception {
        log.info("{}: getEkattes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, EkatteInfo> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_EKATTE)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("ekatte"),
                                new EkatteInfo(rs.getLong("adm_id"), rs.getString("postcode")));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getEkattes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getEkattes - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of municipality nomenclatures, mapped by municipality nsicode.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getMunicipalities(String logId, WorkBean work) throws Exception {
        log.info("{}: getMunicipalities - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_MUNICIPALITY)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("nsicode"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getMunicipalities - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getMunicipalities - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of municipality nomenclatures, mapped by municipality ekatte.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getMunicipalitiesByEkatte(String logId, WorkBean work) throws Exception {
        log.info("{}: getMunicipalitiesByEkatte - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_MUNICIPALITY)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("ekatte"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getMunicipalitiesByEkatte - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getMunicipalitiesByEkatte - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of province nomenclatures, mapped by province nsicode.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getProvinces(String logId, WorkBean work) throws Exception {
        log.info("{}: getProvinces - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_PROVINCE)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("nsicode"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getProvinces - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getProvinces - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of province nomenclatures, mapped by province ekatte.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getProvincesByEkatte(String logId, WorkBean work) throws Exception {
        log.info("{}: getProvincesByEkatte - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_PROVINCE)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("ekatte"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getProvincesByEkatte - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getProvincesByEkatte - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of region nomenclatures, mapped by region nsicode.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getRegions(String logId, WorkBean work) throws Exception {
        log.info("{}: getRegions - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REGIONS)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("nsicode"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegions - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegions - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of administration type nomenclatures, mapped by administrative type code.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getAdministrationTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getAdministrationTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ADMINISTRATION_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAdministrationTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAdministrationTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of announcement type nomenclatures, mapped by announcement type code.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getAnnouncementTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getAnnouncementTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ANNOUNCEMENT_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAnnouncementTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAnnouncementTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of act type nomenclatures, mapped by act type code.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getActTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getActTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ACT_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getActTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getActTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of customer identifier type nomenclatures, mapped by customer identifier type code.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getCustomerIdentifierTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getCustomerIdentifierTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_CUSTOMER_IDENTIFIER_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getCustomerIdentifierTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getCustomerIdentifierTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get all customer type nomenclatures, mapped by customer type code.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getCustomerTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getCustomerTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_CUSTOMER_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getCustomerTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getCustomerTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get all customer register types, mapped by customer type id.
     *
     * @param logId
     * @param work
     * @return Map<Long, Map < String, Long>>
     * @throws Exception
     */
    public Map<Long, Map<String, Long>> getCustomerRegister(String logId, WorkBean work) throws Exception {
        log.info("{}: getCustomerRegister - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<Long, Map<String, Long>> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_CUSTOMER_REGISTER)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.computeIfAbsent(rs.getLong("rn_custtypeid"), k -> new HashMap<>())
                                .put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getCustomerRegister - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getCustomerRegister - finished", logId);
        }
        return result;
    }

    /**
     * Get all issuer type nomenclatures, mapped by issuer type code.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getIssuerTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getIssuerTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ISSUER_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getIssuerTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getIssuerTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get all status type nomenclatures, mapped by status type code.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getStatusTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getStatusTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_STATUS_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getStatusTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getStatusTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get all territory type nomenclatures, mapped by territory type code.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getTerritoryTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getTerritoryTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_TERRITORY_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getTerritoryTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getTerritoryTypes - finished", logId);
        }
        return result;
    }

    /**
     * Transfer reg act to db.
     *
     * @param logId
     * @param work
     * @param c
     * @param regAct
     * @param registerId
     * @return OutdocInfo
     * @throws Exception
     */
    public TransferInfo saveRegActToTransferDB(String logId, WorkBean work, Connection c, RegAct regAct,
                                               Long registerId, String signatureHTML)
            throws Exception {
        log.info("{}: saveRegActToTransferDB - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: regAct: {}", logId, regAct);
        log.trace("{}: registerId: {}", logId, registerId);
        TransferInfo outdoc = new TransferInfo();
        try (CallableStatement cs = c.prepareCall(SAVE_REG_ACT_TO_TRANSFER_DB)) {
            int i = 1;
            cs.setObject(i++, regAct.getRUserId() != null ? UUID.fromString(regAct.getRUserId()) : null);
            cs.setObject(i++, regAct.getActType() != null ? Long.valueOf(regAct.getActType()) : null, Types.BIGINT);
            cs.setObject(i++, regAct.getRnOfficeId() != null ? regAct.getRnOfficeId() : null,
                    Types.BIGINT);
            cs.setObject(i++,
                    regAct.getAdministrativeUnit() != null ? Long.valueOf(regAct.getAdministrativeUnit()) : null,
                    Types.BIGINT);
            cs.setString(i++, regAct.getActNum());
            cs.setTimestamp(i++, regAct.getActDate() != null ? Timestamp.valueOf(regAct.getActDate()) : null);
            cs.setTimestamp(i++,
                    regAct.getMessageDate() != null ? Timestamp.valueOf(regAct.getMessageDate()) : null);
            cs.setObject(i++, regAct.getMessageType() != null ? Long.valueOf(regAct.getMessageType()) : null,
                    Types.BIGINT);
            cs.setString(i++, regAct.getFactReason());
            cs.setString(i++, regAct.getLegalReason());
            cs.setTimestamp(i++,
                    regAct.getValidityDate() != null ? Timestamp.valueOf(regAct.getValidityDate()) : null);
            cs.setString(i++, regAct.getObjectIdentification());
            cs.setTimestamp(i++, regAct.getIssuedDate() != null ? Timestamp.valueOf(regAct.getIssuedDate()) : null);
            cs.setLong(i++, registerId);
            cs.setTimestamp(i++, Timestamp.valueOf(LocalDateTime.now()));
            cs.setString(i++, signatureHTML);
            cs.execute();

            try (ResultSet rs = cs.getResultSet()) {
                if (rs.next()) {
                    outdoc.setAdmId(rs.getLong("adm_id"));
                    outdoc.setUuid((UUID) rs.getObject("uu_id"));
                } else {
                    throw new Exception("Problem with Reg Act transfer to db.");
                }
            }
        } catch (Exception e) {
            logWarningMessage(logId, work,
                    "Възникна проблем при мигрирането на акт от ред " + regAct.getExcelRow() + ".");
            log.error("{}: saveRegActToTransferDB - error", logId, e);
        } finally {
            log.info("{}: saveRegActToTransferDB - finished", logId);
        }
        return outdoc;
    }

    /**
     * Transfer reg act object to db.
     *
     * @param logId
     * @param work
     * @param c
     * @param regObject
     * @param addr
     * @return TransferInfo
     * @throws Exception
     */
    public TransferInfo saveRegActObjectToTransferDB(String logId, WorkBean work, Connection c, RegObject regObject,
                                                     Address addr)
            throws Exception {
        log.info("{}: saveRegActObjectToTransferDB - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: regObject: {}", logId, regObject);
        log.trace("{}: addr: {}", logId, addr);
        TransferInfo object = new TransferInfo();
        try (CallableStatement cs = c.prepareCall(SAVE_REG_ACT_OBJECT_TO_TRANSFER_DB)) {
            int i = 1;
            cs.setObject(i++, regObject.getRUserId() != null ? UUID.fromString(regObject.getRUserId()) : null);
            cs.setString(i++, regObject.getDescription());
            cs.setString(i++, regObject.getCadastre());
            cs.setString(i++, regObject.getLocalPlace());
            cs.setString(i++, regObject.getRegulationDistrict());
            cs.setString(i++, regObject.getUpi());
            cs.setString(i++, regObject.getPlanRegion());
            cs.setString(i++, regObject.getPlanNumber());
            cs.setString(i++, regObject.getKvsTerritory());
            cs.setString(i++, regObject.getKvsNumber());
            cs.setObject(i++,
                    regObject.getTerritoryType() != null ? Integer.parseInt(regObject.getTerritoryType()) : null,
                    Types.INTEGER);
            cs.setString(i++, regObject.getProtectedTerritory());
            cs.setObject(i++, addr.getDistrict() != null ? Short.parseShort(addr.getDistrict()) : null, Types.SMALLINT);
            cs.setObject(i++, addr.getMunicipality() != null ? Short.parseShort(addr.getMunicipality()) : null,
                    Types.SMALLINT);
            if (addr.getSettlement() != null) {
                cs.setShort(i++, Short.parseShort(addr.getSettlement()));
            } else if (addr.getVillage() != null) {
                cs.setShort(i++, Short.parseShort(addr.getVillage()));
            } else {
                cs.setNull(i++, Types.SMALLINT);
            }
            cs.setObject(i++, addr.getRegion() != null ? Short.parseShort(addr.getRegion()) : null, Types.SMALLINT);
            cs.setTimestamp(i++, Timestamp.valueOf(LocalDateTime.now()));

            cs.execute();

            try (ResultSet rs = cs.getResultSet()) {
                if (rs.next()) {
                    object.setAdmId(rs.getLong("adm_id"));
                    object.setUuid((UUID) rs.getObject("uu_id"));
                } else {
                    throw new Exception("Problem with reg act object transfer to db.");
                }
            }
        } catch (Exception e) {
            logWarningMessage(logId, work,
                    "Възникна проблем при мигрирането на обект от ред " + regObject.getExcelRow() + ".");
            log.error("{}: saveRegActObjectToTransferDB - error", logId, e);
        } finally {
            log.info("{}: saveRegActObjectToTransferDB - finished", logId);
        }
        return object;
    }

    /**
     * Transfer reg act object's address to db.
     *
     * @param logId
     * @param work
     * @param c
     * @param addr
     * @return Long
     * @throws Exception
     */
    public Long saveRegActObjectAddrToTransferDB(String logId, WorkBean work, Connection c, Address addr)
            throws Exception {
        log.info("{}: saveRegActObjectAddrToTransferDB - started", logId);
        log.trace("{}: addr: {}", logId, addr);
        Long id = null;
        try (CallableStatement cs = c.prepareCall(SAVE_REG_ACT_OBJECT_ADDR_TO_TRANSFER_DB)) {
            int i = 1;
            cs.setObject(i++, addr.getRUserId() != null ? UUID.fromString(addr.getRUserId()) : null);
            cs.setString(i++, addr.getQuarter());
            cs.setString(i++, addr.getStreetName());
            cs.setString(i++, addr.getStreetNum());
            cs.setString(i++, addr.getFlatNumber());
            cs.setString(i++, addr.getFlatEntrance());
            cs.setString(i++, addr.getFloor());
            cs.setString(i++, addr.getApartment());
            cs.setString(i++, addr.getSquareName());
            cs.setString(i++, addr.getSquareNum());
            cs.setString(i++, addr.getAppComplexName());
            cs.setString(i++, addr.getAppComplexNum());
            cs.setString(i++, addr.getAddrPlaceName());
            cs.setTimestamp(i++, Timestamp.valueOf(LocalDateTime.now()));
            cs.setString(i++, addr.getOtherluname());
            cs.setString(i++, addr.getOtherlunum());
            cs.execute();

            try (ResultSet rs = cs.getResultSet()) {
                if (rs.next()) {
                    id = rs.getLong("adm_id");
                } else {
                    throw new Exception("Problem with reg act object's address transfer to db.");
                }
            }
        } catch (Exception e) {
            logWarningMessage(logId, work,
                    "Възникна проблем при мигрирането на адрес на обект от ред " + addr.getExcelRow() + ".");
            log.error("{}: saveRegActObjectAddrToTransferDB - error", logId, e);
        } finally {
            log.info("{}: saveRegActObjectAddrToTransferDB - finished", logId);
        }
        return id;
    }

    /**
     * Save reg object id and object address id to mid-table.
     *
     * @param logId
     * @param work
     * @param c
     * @param regObject
     * @param regObjectAddressId
     */
    public void saveRegObjectAddressRelation(String logId, WorkBean work, Connection c, RegObject regObject,
                                             Long regObjectAddressId)
            throws SQLException {
        log.info("{}: saveRegObjectAddressRelation - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: regObject: {}", logId, regObject);
        log.trace("{}: regObjectAddressId: {}", logId, regObjectAddressId);
        try (CallableStatement cs = c.prepareCall(SAVE_REG_ACT_OBJECT_ADDR_RELATION)) {
            int i = 1;
            cs.setObject(i++, regObject.getRUserId() != null ? UUID.fromString(regObject.getRUserId()) : null);
            cs.setLong(i++, regObject.getOpId());
            cs.setObject(i++, regObjectAddressId, Types.BIGINT);
            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with saving reg act object and address relation.");
            }
        } catch (Exception e) {
            //todo log?
            log.error("{}: saveRegObjectAddressRelation - error", logId, e);
        } finally {
            log.info("{}: saveRegObjectAddressRelation - finished", logId);
        }
    }

    /**
     * Transfer customer's address to db.
     *
     * @param logId
     * @param c
     * @param addr
     * @return Long
     * @throws Exception
     */
    public Long saveCustomerAddressToTransferDB(String logId, WorkBean work, Connection c, Address addr)
            throws Exception {
        log.info("{}: saveCustomerAddressToTransferDB - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: address: {}", logId, addr);
        Long id = null;
        try (CallableStatement cs = c.prepareCall(SAVE_CUSTOMER_ADDRESS_TO_TRANSFER_DB)) {
            int i = 1;
            cs.setObject(i++, addr.getRUserId() != null ? UUID.fromString(addr.getRUserId()) : null);
            cs.setObject(i++, addr.getCountry() != null ? Short.parseShort(addr.getCountry()) : null, Types.SMALLINT);
            cs.setObject(i++, addr.getDistrict() != null ? Short.parseShort(addr.getDistrict()) : null, Types.SMALLINT);
            cs.setObject(i++, addr.getMunicipality() != null ? Short.parseShort(addr.getMunicipality()) : null,
                    Types.SMALLINT);
            if (addr.getSettlement() != null) {
                cs.setShort(i++, Short.parseShort(addr.getSettlement()));
            } else if (addr.getVillage() != null) {
                cs.setShort(i++, Short.parseShort(addr.getVillage()));
            } else {
                cs.setNull(i++, Types.SMALLINT);
            }
            cs.setString(i++, addr.getPostcode());
            cs.setObject(i++, addr.getRegion() != null ? Short.parseShort(addr.getRegion()) : null, Types.SMALLINT);
            cs.setString(i++, addr.getFlatEntrance());
            cs.setString(i++, addr.getFloor());
            cs.setString(i++, addr.getApartment());
            cs.setString(i++, addr.getSquareName());
            cs.setString(i++, addr.getSquareNum());
            cs.setString(i++, addr.getAppComplexName());
            cs.setString(i++, addr.getAppComplexNum());
            cs.setString(i++, addr.getQuarter());
            cs.setString(i++, addr.getStreetName());
            cs.setString(i++, addr.getStreetNum());
            cs.setString(i++, addr.getFlatNumber());
            cs.setString(i++, addr.getOtherluname());
            cs.setString(i++, addr.getOtherlunum());
            cs.setString(i++, addr.getAddrPlaceName());
            cs.execute();

            try (ResultSet rs = cs.getResultSet()) {
                if (rs.next()) {
                    id = rs.getLong("adm_id");
                } else {
                    throw new Exception("Problem with customer address saving to db.");
                }
            }
        } catch (Exception e) {
            logWarningMessage(logId, work,
                    "Възникна проблем при мигрирането на адрес на заявител/възложител на ред " + addr.getExcelRow() +
                            ".");
            log.error("{}: saveCustomerAddressToTransferDB - error", logId, e);
        } finally {
            log.info("{}: saveCustomerAddressToTransferDB - finished", logId);
        }
        return id;
    }

    /**
     * Transfer customer to db.
     *
     * @param logId
     * @param work
     * @param c
     * @param customer
     * @param addressId
     * @param registerId
     * @return Long
     * @throws Exception
     */
    public Long saveCustomerToTransferDB(String logId, WorkBean work, Connection c, Customer customer, Long addressId, Long registerId)
            throws Exception {
        log.info("{}: saveCustomerToTransferDB - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: customer: {}", logId, customer);
        log.trace("{}: addressId: {}", logId, addressId);
        log.trace("{}: registerId: {}", logId, registerId);
        Long id = null;
        try (CallableStatement cs = c.prepareCall(SAVE_CUSTOMER_TO_TRANSFER_DB)) {
            int i = 1;
            cs.setObject(i++, customer.getRUserId() != null ? UUID.fromString(customer.getRUserId()) : null);
            cs.setObject(i++, customer.getCustomerType() != null ? Short.parseShort(customer.getCustomerType()) : null,
                    Types.SMALLINT);
            cs.setString(i++, customer.getIdentifier());
            cs.setString(i++, customer.getFirstName());
            cs.setString(i++, customer.getMiddleName());
            cs.setString(i++, customer.getLastName());
            cs.setString(i++, customer.getUnitName());
            cs.setString(i++, customer.getPhone());
            cs.setString(i++, customer.getEmail());
            cs.setLong(i++, registerId);
            cs.setObject(i++, addressId, Types.BIGINT);
            cs.setObject(i++,
                    customer.getIdentifierType() != null ? Short.parseShort(customer.getIdentifierType()) : null,
                    Types.SMALLINT);
            cs.execute();
            try (ResultSet rs = cs.getResultSet()) {
                if (rs.next()) {
                    id = rs.getLong("adm_id");
                } else {
                    throw new Exception("Problem with Customer transfer to db.");
                }
            }
        } catch (Exception e) {
            logWarningMessage(logId, work,
                    "Възникна проблем при мигрирането на заявител/възложител на ред " + customer.getExcelRow() + ".");
            log.error("{}: saveCustomerToTransferDB - error", logId, e);
        } finally {
            log.info("{}: saveCustomerToTransferDB - finished", logId);
        }
        return id;
    }

    /**
     * Transfer uploaded document to db.
     *
     * @param logId
     * @param work
     * @param c
     * @param file
     * @return DocumentTransferInfo
     * @throws Exception
     */
    public DocumentTransferInfo saveDocumentToTransferDb(String logId, WorkBean work, Connection c, FileMigrate file)
            throws Exception {
        log.info("{}: saveDocumentToTransferDb - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: file: {}", logId, file);
        DocumentTransferInfo result = new DocumentTransferInfo();
        try (CallableStatement cs = c.prepareCall(SAVE_DOCUMENT_TO_TRANSFER_DB)) {
            int i = 1;
            cs.setObject(i++, file.getRUserId() != null ? UUID.fromString(file.getRUserId()) : null);
            cs.setString(i++, file.getObjectId());
            cs.setLong(i++, file.getObjectTypeSysId());
            cs.setString(i++, file.getName());
            cs.setBigDecimal(i++, file.getSize());
            cs.setString(i++, file.getUrl());
            cs.setTimestamp(i++, Timestamp.valueOf(LocalDateTime.now()));
            cs.execute();
            try (ResultSet rs = cs.getResultSet()) {
                if (rs.next()) {
                    result.setId(rs.getLong("adm_id"));
                    result.setFileId((UUID) rs.getObject("uu_id"));
                    result.setFileName(rs.getString("name"));
                    return result;
                } else {
                    throw new SQLException("Problem with transferring document to db.");
                }
            }
        } catch (Exception e) {
            logWarningMessage(logId, work, "Възникна проблем при мигрирането на файл с име: " + file.getName());
            log.error("{}: saveDocumentToTransferDb - error", logId, e);
        } finally {
            log.info("{}: saveDocumentToTransferDb - finished", logId);
        }
        return result;
    }

    /**
     * Get act register ids.
     *
     * @param logId
     * @param work
     * @return Map
     * @throws Exception
     */
    public Map<String, Long> getActRegisterIds(String logId, WorkBean work) throws Exception {
        log.info("{}: getActRegisterIds - started", logId);
        log.trace("{}: import: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ACT_REGISTER_IDS)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {

                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getActRegisterIds - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getActRegisterIds - finished", logId);
        }
        return result;
    }

    /**
     * Get register code from import.
     *
     * @param logId
     * @param work
     * @return String
     * @throws Exception
     */
    public String getRegisterCodeFromImport(String logId, WorkBean work) throws Exception {
        log.info("{}: getRegisterCodeFromImport - started", logId);
        log.trace("{}: work: {}", logId, work);
        String result = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_IMPORT)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        result = rs.getString("register_code");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegisterCodeFromImport - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegisterCodeFromImport - finished", logId);
        }
        return result;
    }

    /**
     * Get register ids.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getRegisterIds(String logId, WorkBean work) throws Exception {
        log.info("{}: getRegisterIds - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REGISTER_IDS)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegisterIds - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegisterIds - finished", logId);
        }
        return result;
    }

    /**
     * Get object types.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getObjectTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getObjectTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_OBJECT_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getObjectTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getObjectTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get entry types.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getEntryTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getEntryTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ENTRY_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getEntryTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getEntryTypes - finished", logId);
        }
        return result;
    }

    /**
     * Set operative id of reg act.
     *
     * @param logId
     * @param work
     * @param c
     * @param regAct
     * @throws Exception
     */
    public void setRegActOpId(String logId, WorkBean work, Connection c, RegAct regAct) throws Exception {
        log.info("{}: updateRegActOpId - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: regAct: {}", logId, regAct);
        try (CallableStatement cs = c.prepareCall(UPDATE_REG_ACT_OP_ID)) {
            int i = 1;
            cs.setLong(i++, regAct.getOpId());
            cs.setLong(i++, regAct.getId());
            if (cs.executeUpdate() != 1) {
                throw new SQLException("Invalid transition 0 updates");
            }
        } catch (Exception e) {
            log.error("{}: updateRegActOpId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: updateRegActOpId - finished", logId);
        }
    }

    /**
     * Set operative id of reg act object.
     *
     * @param logId
     * @param work
     * @param c
     * @param regObject
     * @throws Exception
     */
    public void setRegActObjectOpId(String logId, WorkBean work, Connection c, RegObject regObject) throws Exception {
        log.info("{}: setRegActObjectOpId - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: regObject: {}", logId, regObject);
        try (CallableStatement cs = c.prepareCall(UPDATE_REG_ACT_OBJECT_OP_ID)) {
            int i = 1;
            cs.setLong(i++, regObject.getOpId());
            cs.setLong(i++, regObject.getId());
            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with setting operative id of reg act object.");
            }
        } catch (Exception e) {
            log.error("{}: setRegActObjectOpId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: setRegActObjectOpId - finished", logId);
        }
    }

    /**
     * Set operative id of address.
     *
     * @param logId
     * @param work
     * @param c
     * @param opId
     * @param addr
     * @throws Exception
     */
    public void setAddressOpId(String logId, WorkBean work, Connection c, Long opId, Address addr) throws Exception {
        log.info("{}: setAddressOpId - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: opId: {}", logId, opId);
        log.trace("{}: addr: {}", logId, addr);
        try (CallableStatement cs = c.prepareCall(UPDATE_ADDRESS_OP_ID)) {
            int i = 1;
            cs.setLong(i++, opId);
            cs.setLong(i++, addr.getId());
            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with setting operative id of reg act object's address.");
            }
        } catch (Exception e) {
            log.error("{}: setAddressOpId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: setAddressOpId - finished", logId);
        }
    }

    /**
     * Set operative id of gdpr document.
     *
     * @param logId
     * @param work
     * @param c
     * @param opId
     * @param gdprDocument
     * @throws Exception
     */
    public void setGdprDocumentOpId(String logId, WorkBean work, Connection c, Long opId,
                                    RegActGdprDocument gdprDocument) throws Exception {
        log.info("{}: setGdprDocumentOpId - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: opId: {}", logId, opId);
        log.trace("{}: gdprDocument: {}", logId, gdprDocument);
        try (CallableStatement cs = c.prepareCall(UPDATE_GDPR_DOCUMENT_OP_ID)) {
            int i = 1;
            cs.setLong(i++, opId);
            cs.setLong(i++, gdprDocument.getId());
            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with setting operative id of gdpr document.");
            }
        } catch (Exception e) {
            log.error("{}: setGdprDocumentOpId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: setGdprDocumentOpId - finished", logId);
        }
    }

    /**
     * Set operative id of full document.
     *
     * @param logId
     * @param work
     * @param c
     * @param opId
     * @param fullDocument
     * @throws Exception
     */
    public void setFullDocumentOpId(String logId, WorkBean work, Connection c, Long opId,
                                    RegActFullDocument fullDocument) throws Exception {
        log.info("{}: setFullDocumentOpId - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: opId: {}", logId, opId);
        log.trace("{}: fullDocument: {}", logId, fullDocument);
        try (CallableStatement cs = c.prepareCall(UPDATE_FULL_DOCUMENT_OP_ID)) {
            int i = 1;
            cs.setLong(i++, opId);
            cs.setLong(i++, fullDocument.getId());
            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with setting operative id of full document.");
            }
        } catch (Exception e) {
            log.error("{}: setFullDocumentOpId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: setFullDocumentOpId - finished", logId);
        }
    }

    /**
     * Set operative id of application one document.
     *
     * @param logId
     * @param work
     * @param c
     * @param opId
     * @param appOneDocument
     * @throws Exception
     */
    public void setAppOneDocumentOpId(String logId, WorkBean work, Connection c, Long opId,
                                      RegAppOneDocument appOneDocument) throws Exception {
        log.info("{}: setAppOneDocumentOpId - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: opId: {}", logId, opId);
        log.trace("{}: appOneDocument: {}", logId, appOneDocument);
        try (CallableStatement cs = c.prepareCall(UPDATE_APP_ONE_DOCUMENT_OP_ID)) {
            int i = 1;
            cs.setLong(i++, opId);
            cs.setLong(i++, appOneDocument.getId());
            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with setting operative id of application one document.");
            }
        } catch (Exception e) {
            log.error("{}: setAppOneDocumentOpId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: setAppOneDocumentOpId - finished", logId);
        }
    }

    /**
     * Set operative id of application two document.
     *
     * @param logId
     * @param work
     * @param c
     * @param opId
     * @param appTwoDocument
     * @throws Exception
     */
    public void setAppTwoDocumentOpId(String logId, WorkBean work, Connection c, Long opId,
                                      RegAppTwoDocument appTwoDocument) throws Exception {
        log.info("{}: setAppTwoDocumentOpId - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: opId: {}", logId, opId);
        log.trace("{}: appTwoDocument: {}", logId, appTwoDocument);
        try (CallableStatement cs = c.prepareCall(UPDATE_APP_TWO_DOCUMENT_OP_ID)) {
            int i = 1;
            cs.setLong(i++, opId);
            cs.setLong(i++, appTwoDocument.getId());
            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with setting operative id of application two document.");
            }
        } catch (Exception e) {
            log.error("{}: setAppTwoDocumentOpId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: setAppTwoDocumentOpId - finished", logId);
        }
    }

    /**
     * Set operative id of contesting document.
     *
     * @param logId
     * @param work
     * @param c
     * @param opId
     * @param regContDocument
     * @throws Exception
     */
    public void setContestingDocumentOpId(String logId, WorkBean work, Connection c, Long opId,
                                          RegContDocument regContDocument) throws Exception {
        log.info("{}: setContestingDocumentOpId - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: opId: {}", logId, opId);
        log.trace("{}: regContDocument: {}", logId, regContDocument);
        try (CallableStatement cs = c.prepareCall(UPDATE_CONTESTING_DOCUMENT_OP_ID)) {
            int i = 1;
            cs.setLong(i++, opId);
            cs.setLong(i++, regContDocument.getId());
            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with setting operative id of contesting document.");
            }
        } catch (Exception e) {
            log.error("{}: setContestingDocumentOpId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: setContestingDocumentOpId - finished", logId);
        }
    }

    /**
     * Set operative id of customer.
     *
     * @param logId
     * @param work
     * @param c
     * @param customer
     * @throws Exception
     */
    public void setCustomerOpId(String logId, WorkBean work, Connection c, Customer customer) throws Exception {
        log.info("{}: updateCustomerOpId - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: customer: {}", logId, customer);
        try (CallableStatement cs = c.prepareCall(UPDATE_CUSTOMER_OP_ID)) {
            int i = 1;
            cs.setLong(i++, customer.getOpId());
            cs.setLong(i++, customer.getId());
            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with setting operative id of customer.");
            }
        } catch (Exception e) {
            log.error("{}: updateCustomerOpId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: updateCustomerOpId - finished", logId);
        }
    }

    /**
     * Save relation between act and customers to db.
     *
     * @param logId
     * @param work
     * @param c
     * @param regAct
     * @param customer
     * @throws Exception
     */
    public void saveActCustomers(String logId, WorkBean work, Connection c, RegAct regAct, Customer customer)
            throws Exception {
        log.info("{}: saveCustomerToTransferDB - started", logId);
        log.trace("{}: regAct: {}", logId, regAct);
        log.trace("{}: customer: {}", logId, customer);
        try (CallableStatement cs = c.prepareCall(SAVE_REG_ACT_CUSTOMERS_TO_TRANSFER_DB)) {
            int i = 1;
            cs.setObject(i++, regAct.getRUserId() != null ? UUID.fromString(regAct.getRUserId()) : null);
            cs.setLong(i++, regAct.getOpId());
            cs.setObject(i++, regAct.getRnOfficeId() != null ? regAct.getRnOfficeId() : null,
                    Types.BIGINT);
            cs.setLong(i++, customer.getOpId());
            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with saving relation between act and customers to db.");
            }
        } catch (Exception e) {
            log.error("{}: saveCustomerToTransferDB - error", logId, e);
            throw e;
        } finally {
            log.info("{}: saveCustomerToTransferDB - finished", logId);
        }
    }

    /**
     * Save relation between act and objects to db.
     *
     * @param logId
     * @param work
     * @param c
     * @param act
     * @param object
     * @throws Exception
     */
    public void saveActObjects(String logId, WorkBean work, Connection c, RegAct act, RegObject object, Long entryType,
                               Long objectType) throws Exception {
        log.info("{}: saveActObjects - started", logId);
        log.trace("{}: RegAct: {}", logId, act);
        log.trace("{}: objectId: {}", logId, object);
        try (CallableStatement cs = c.prepareCall(SAVE_REG_ACT_OBJECTS_REL_TO_TRANSFER_DB)) {
            int i = 1;
            cs.setObject(i++, act.getRUserId() != null ? UUID.fromString(act.getRUserId()) : null);
            cs.setLong(i++, act.getOpId());
            cs.setLong(i++, entryType);
            cs.setLong(i++, objectType);
            cs.setString(i++, object.getUuid().toString());
            cs.setString(i++, object.getDescription());

            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with saving relation between act and objects to db.");
            }

        } catch (Exception e) {
            log.error("{}: saveActObjects - error", logId, e);
            throw e;
        } finally {
            log.info("{}: saveActObjects - finished", logId);
        }
    }

    /**
     * Transfer contesting outdoc status to db.
     *
     * @param logId
     * @param work
     * @param c
     * @param act
     * @param contDocument
     * @param fileUuid
     * @throws Exception
     */
    public void transferContestingOutDocStatusToDb(String logId, WorkBean work, Connection c, RegAct act,
                                                   RegContDocument contDocument, UUID fileUuid) throws Exception {
        log.info("{}: transferContestingOutDocStatusToDb - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: RegAct: {}", logId, act);
        log.trace("{}: contDocument: {}", logId, contDocument);
        log.trace("{}: fileUuid: {}", logId, fileUuid);
        try (CallableStatement cs = c.prepareCall(SAVE_CONTESTING_OUTDOC_STATUS_TO_TRANSFER_DB)) {
            int i = 1;
            cs.setObject(i++, act.getRUserId() != null ? UUID.fromString(act.getRUserId()) : null);
            cs.setLong(i++, act.getOpId());
            cs.setObject(i++, act.getStatus() != null ? Long.parseLong(act.getStatus()) : null,
                    Types.BIGINT);
            cs.setString(i++, contDocument != null ? contDocument.getDescription() : null); //fixme !!!!!!!!!!!!!!
            cs.setObject(i++, fileUuid, Types.OTHER);

            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with saving contesting outdoc status to db.");
            }
        } catch (Exception e) {
            log.error("{}: transferContestingOutDocStatusToDb - error", logId, e);
            throw e;
        } finally {
            log.info("{}: transferContestingOutDocStatusToDb - finished", logId);
        }
    }

    /**
     * Transfer contesting outdoc status to db.
     *
     * @param logId
     * @param work
     * @param c
     * @param act
     * @throws Exception
     */
    public void transferOutDocStatusToDb(String logId, WorkBean work, Connection c, RegAct act) throws Exception {
        log.info("{}: transferOutDocStatusToDb - started", logId);
        log.trace("{}: RegAct: {}", logId, act);
        try (CallableStatement cs = c.prepareCall(SAVE_OUTDOC_STATUS_TO_TRANSFER_DB)) {
            int i = 1;
            cs.setObject(i++, act.getRUserId() != null ? UUID.fromString(act.getRUserId()) : null);
            cs.setLong(i++, act.getOpId());
            cs.setObject(i++, act.getStatus() != null ? Long.parseLong(act.getStatus()) : null,
                    Types.BIGINT);
            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with saving outdoc status to db.");
            }
        } catch (Exception e) {
            log.error("{}: transferOutDocStatusToDb - error", logId, e);
            throw e;
        } finally {
            log.info("{}: transferOutDocStatusToDb - finished", logId);
        }
    }

    /**
     * Transfer documents relation to db.
     *
     * @param logId
     * @param work
     * @param c
     * @param doc
     * @throws Exception
     */
    public void transferDocumentsRelationToDb(String logId, WorkBean work, Connection c, DocumentTransferInfo doc)
            throws Exception {
        log.info("{}: transferDocumentsRelationToDb - started", logId);
        log.trace("{}: doc: {}", logId, doc);
        try (CallableStatement cs = c.prepareCall(SAVE_DOCUMENT_RELATION_TO_TRANSFER_DB)) {
            int i = 1;
            cs.setObject(i++, doc.getRUserId() != null ? UUID.fromString(doc.getRUserId()) : null);
            cs.setLong(i++, doc.getDocId());
            cs.setLong(i++, doc.getRelDocTypeId());
            cs.setObject(i++, doc.getRelDocContentId() != null ? Long.valueOf(doc.getRelDocContentId()) : null, Types.BIGINT);
            cs.setObject(i++, doc.getOfficeId() != null ? Long.valueOf(doc.getOfficeId()) : null, Types.BIGINT);
            cs.setLong(i++, doc.getEntryTypeId());
            cs.setObject(i++, doc.getFileId());
            cs.setString(i++, doc.getFileName());
            if (cs.executeUpdate() != 1) {
                throw new SQLException("Problem with saving documents relation to db.");
            }
        } catch (Exception e) {
            log.error("{}: transferDocumentsRelationToDb - error", logId, e);
            throw e;
        } finally {
            log.info("{}: transferDocumentsRelationToDb - finished", logId);
        }
    }

    /**
     * Returns if there are any error/warning messages for import.
     *
     * @param logId
     * @param work
     * @return Boolean
     * @throws Exception
     */
    public Boolean hasErrorWarningMessages(String logId, WorkBean work) throws Exception {
        log.info("{}: hasErrorWarningMessages - started", logId);
        log.trace("{}: work: {}", logId, work);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(HAS_ERROR_WARNING_MESSAGES)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        return rs.getBoolean(1);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: hasErrorWarningMessages - error", logId, e);
            throw e;
        } finally {
            log.info("{}: hasErrorWarningMessages - finished", logId);
        }
        return false;
    }

    /**
     * Returns mun_id and province_id for each ekatte.
     *
     * @param logId
     * @param work
     * @return Map<String, OfficeInfo>
     * @throws Exception
     */
    public Map<String, OfficeInfo> getOfficeInfoByEkatte(String logId, WorkBean work) throws Exception {
        log.info("{}: getOfficeInfo - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, OfficeInfo> officeInfo = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_OFFICE_INFO)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        officeInfo.put(rs.getString("ekatte"), new OfficeInfo(rs.getLong("mun"), rs.getLong("province")));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getOfficeInfo - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getOfficeInfo - finished", logId);
        }
        return officeInfo;
    }

    /**
     * Returns id for office by municipality id and province id.
     *
     * @param logId
     * @param work
     * @return Long
     * @throws Exception
     */
    public Long getOfficeIdByMunAndProvince(String logId, WorkBean work, Long munId, Long provinceId) throws Exception {
        log.info("{}: getOfficeIdByMunAndProvince - started", logId);
        log.trace("{}: work: {}", logId, work);
        Long id = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_OFFICE_ID_BY_MUN_AND_PROVINCE)) {
                int i = 1;
                cs.setLong(i++, provinceId);
                cs.setObject(i++, munId, Types.BIGINT);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        id = rs.getLong("adm_id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getOfficeIdByMunAndProvince - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getOfficeIdByMunAndProvince - finished", logId);
        }
        return id;
    }

    /**
     * Returns id for office by province id.
     *
     * @param logId
     * @param work
     * @return Long
     * @throws Exception
     */
    public Long getOfficeIdByProvince(String logId, WorkBean work, Long provinceId) throws Exception {
        log.info("{}: getOfficeIdByProvince - started", logId);
        log.trace("{}: work: {}", logId, work);
        Long id = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_OFFICE_ID_BY_PROVINCE)) {
                int i = 1;
                cs.setLong(i++, provinceId);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        id = rs.getLong("adm_id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getOfficeIdByProvince - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getOfficeIdByProvince - finished", logId);
        }
        return id;
    }

    /**
     * Returns id for office by region id.
     *
     * @param logId
     * @param work
     * @return Long
     * @throws Exception
     */
    public Long getOfficeIdByRegion(String logId, WorkBean work, Long provinceId) throws Exception {
        log.info("{}: getOfficeIdByRegion - started", logId);
        log.trace("{}: work: {}", logId, work);
        Long id = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_OFFICE_ID_BY_REGION)) {
                int i = 1;
                cs.setLong(i++, provinceId);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        id = rs.getLong("adm_id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getOfficeIdByRegion - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getOfficeIdByRegion - finished", logId);
        }
        return id;
    }

    /**
     * Returns id for office by administration type.
     *
     * @param logId
     * @param work
     * @return Long
     * @throws Exception
     */
    public Long getOfficeIdByAdministrationType(String logId, WorkBean work, Long admId) throws Exception {
        log.info("{}: getOfficeIdByAdministrationType - started", logId);
        log.trace("{}: work: {}", logId, work);
        Long id = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_OFFICE_ID_BY_ADMINISTRATION_TYPE)) {
                int i = 1;
                cs.setLong(i++, admId);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        id = rs.getLong("adm_id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getOfficeIdByAdministrationType - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getOfficeIdByAdministrationType - finished", logId);
        }
        return id;
    }

    /**
     * Calls postMigrate() function.
     * @param logId
     * @param work
     * @throws Exception
     */
    public void callPostMigrate(String logId, WorkBean work) throws Exception {
        log.info("{}: callPostMigrate - started", logId);
        log.trace("{}: work: {}", logId, work);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(POST_MIGRATE_FUNCTION_CALL)) {
                cs.execute();
            }
            c.commit();
        } catch (Exception e) {
            log.error("{}: callPostMigrate - error", logId, e);
            throw e;
        } finally {
            log.info("{}: callPostMigrate - finished", logId);
        }
    }

    /**
     *
     * @param logId
     * @param work
     * @return String
     * @throws Exception
     */
    public String getSignatureByImport(String logId, WorkBean work) throws Exception {
        log.info("{}: getSignatureByImport - started", logId);
        log.trace("{}: work: {}", logId, work);
        try (Connection c = getConnection()) {

            try (CallableStatement cs = c.prepareCall(GET_SIGNATURE_BY_IMPORT)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        return rs.getString("url");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getSignatureByImport - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getSignatureByImport - finished", logId);
        }
        return null;
    }
}
