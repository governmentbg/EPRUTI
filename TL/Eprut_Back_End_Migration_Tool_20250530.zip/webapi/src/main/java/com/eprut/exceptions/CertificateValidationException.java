package com.eprut.exceptions;

public class CertificateValidationException extends BaseException {
    public CertificateValidationException(String bgMessage) {
        super(bgMessage);
    }

    public CertificateValidationException(String bgMessage, String message) {
        super(bgMessage, message);
    }

    public CertificateValidationException(String bgMessage, String message, Throwable cause) {
        super(bgMessage, message, cause);
    }

    public CertificateValidationException(String bgMessage, Throwable cause) {
        super(bgMessage, cause);
    }

    public CertificateValidationException(
            String bgMessage,
            String message,
            Throwable cause,
            boolean enableSuppression,
            boolean writableStackTrace) {
        super(bgMessage, message, cause, enableSuppression, writableStackTrace);
    }
}
