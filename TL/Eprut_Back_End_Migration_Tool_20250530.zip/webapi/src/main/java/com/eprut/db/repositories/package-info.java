/**
 * Project: eprut
 * Module: com.eprut.db.repositories
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Заявки към базата данни.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.db.repositories;
