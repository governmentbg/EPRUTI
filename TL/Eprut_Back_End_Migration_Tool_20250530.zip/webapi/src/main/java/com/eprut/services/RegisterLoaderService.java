package com.eprut.services;

import com.eprut.db.views.out.RegisterOutView;
import com.eprut.exceptions.NoPermissionsException;
import com.eprut.exceptions.RegisterTypeNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;

import java.util.List;
import java.util.Locale;

public interface RegisterLoaderService {

    /**
     * Намира и връща списък на всички регистри за текущата локализация.
     * @param locale
     * @return List<RegisterOutView>
     */
    List<RegisterOutView> getAllRegistersForCurrentUser(Locale locale)
            throws UnauthorizedAccessException, NoPermissionsException;

    /**
     * Намира и връща регистър по даден код на регистъра.
     * @param registerCode
     * @param locale
     * @return RegisterOutView
     */
    RegisterOutView getRegisterByCode(String registerCode, Locale locale) throws RegisterTypeNotFoundException;
}
