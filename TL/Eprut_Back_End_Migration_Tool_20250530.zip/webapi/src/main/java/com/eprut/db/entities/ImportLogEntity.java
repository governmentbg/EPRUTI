package com.eprut.db.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

import java.time.Instant;

@Entity
@Table(name = "import_log", schema = "staging")
@Data
public class ImportLogEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "import_id", nullable = false)
    private Long importId;

    @Column(name = "date_added", nullable = false)
    private Instant dateAdded;

    @Column(name = "msg_type_id", nullable = false)
    private Long msgTypeId;

    @Column(name = "msg", length = 512, nullable = false)
    private String msg;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "msg_type_id", insertable = false, updatable = false)
    private NImportMessageTypeEntity msgType;
}
