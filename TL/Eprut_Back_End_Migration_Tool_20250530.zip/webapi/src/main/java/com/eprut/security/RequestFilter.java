package com.eprut.security;


import com.eprut.beans.IdentityServerModel;
import com.eprut.exceptions.AuthenticationException;
import com.eprut.services.IdentityServerService;
import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.util.UUID;


@Component
@Order(1)
public class RequestFilter extends OncePerRequestFilter {

    private static final String TOKEN_HEADER = "Authorization";
    private static final String TOKEN_PREFIX = "Bearer ";

    private final IdentityServerService identityServerService;
    private final JwtUtil jwtUtil;

    /**
     * This is the constructor for the request filter.
     *
     * @param identityServerService identity service for extracting info from token. Oauth.
     */
    @Autowired
    public RequestFilter(IdentityServerService identityServerService, JwtUtil jwtUtil) {
        this.identityServerService = identityServerService;
        this.jwtUtil = jwtUtil;
    }

    @SneakyThrows
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
        request.setAttribute("uuid", UUID.randomUUID().toString());
        AbstractAuthenticationToken authentication = null;
        try {
            authentication = getAuthentication(request);
        } catch (Exception e) {
            logger.error("TOKEN ERROR: token:", e);
            throw new AuthenticationException(e.getMessage());
        }
        SecurityContextHolder.getContext().setAuthentication(authentication);
        filterChain.doFilter(request, response);
    }

    private AbstractAuthenticationToken getAuthentication(HttpServletRequest request) throws Exception {
        String token = request.getHeader(TOKEN_HEADER);

        //1. Validate if there is token in the request header.
        if (!StringUtils.hasText(token) || !token.startsWith(TOKEN_PREFIX)) {
//            logger.error("No token provided in the request header.");
            return null;
        }

        String accessToken = token.replace(TOKEN_PREFIX, "");

        //2. Validate the structure of the token - signature and expiration date.
        Claims claims;
        try {
            claims = jwtUtil.validateToken(accessToken);
        } catch (Exception e) {
            logger.error("Token validation failed: " + e.getMessage());
            throw new AuthenticationException("Invalid or expired token.");
        }

        //3. Missing user id in the token.
        String userUuid = claims.get("Id", String.class);
        if (userUuid == null) {
            logger.error("No id provided in the token.");
            throw new AuthenticationException("No id provided in the token.");
        }

        //4. Error loading user details from IdentityServerService
        IdentityServerModel userDetails;
        try {
            userDetails = (IdentityServerModel) identityServerService.loadUserByUsername(userUuid);
        } catch (Exception e) {
            logger.error("Error loading user " + userUuid + ": " + e.getMessage());
            throw new AuthenticationException("Error loading user: " + userUuid);
        }

        //5. Null or empty user details
        if (userDetails == null) {
            logger.error("User details not found for UUID: " + userUuid);
            throw new AuthenticationException("User details not found for user: " + userUuid);
        }

        request.setAttribute("uuid", userDetails.getRequestId());
        return new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
    }
}
