/**
 * Project: eprut
 * Module: com.eprut.utils
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Пакет за обща функционалност за валидация на КЕП.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.utils;
