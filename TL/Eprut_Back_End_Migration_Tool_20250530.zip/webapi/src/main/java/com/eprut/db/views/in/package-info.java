/**
 * Project: eprut
 * Module: com.eprut.db.views.in
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: DTO можедли на данни за обработка на заявка.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.db.views.in;
