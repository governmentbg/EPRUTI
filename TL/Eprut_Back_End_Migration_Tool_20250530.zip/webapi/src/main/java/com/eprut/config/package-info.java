/**
 * Project: eprut
 * Module: com.eprut.config
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Конфигурация на уеб услугите.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.config;
