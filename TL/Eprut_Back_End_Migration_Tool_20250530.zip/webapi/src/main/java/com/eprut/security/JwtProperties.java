package com.eprut.security;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Getter
public class JwtProperties {

    @Value("${eprut.jwt.secret}")
    private String secret;

    @Value("${eprut.jwt.issuer}")
    private String issuer;

    @Value("${eprut.jwt.audience}")
    private String audience;
}
