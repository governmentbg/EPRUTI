package com.eprut.services;

import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.NoPermissionsException;
import com.eprut.exceptions.UnauthorizedAccessException;
import com.eprut.exceptions.UserNotFoundException;

import java.io.IOException;

public interface ImportErrorsRetrievalService {

    /**
     * Генериране на CSV файл, който съдържа всички грешки за конкретен импорт.
     * @param importId
     * @return byte[]
     */
    byte[] generateXLSXforImportErrors(String registerCode, Long importId)
            throws IOException, ImportNotFoundException, UnauthorizedAccessException, UserNotFoundException,
            NoPermissionsException;
}
