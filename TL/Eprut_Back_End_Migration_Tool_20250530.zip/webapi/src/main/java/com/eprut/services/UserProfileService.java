package com.eprut.services;

import com.eprut.db.views.out.AdmUserOutView;

public interface UserProfileService {

    /**
     * Returns user profile details.
     * @return AdmUserOutView
     */
    AdmUserOutView getUserProfileDetails();
}
