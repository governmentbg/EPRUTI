package com.eprut.utils;

import com.eprut.config.RestTemplateConfig;
import com.eprut.exceptions.CertificateValidationException;
import com.eprut.utils.certvalidation.BASE64DecodedMultipartFile;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
@Slf4j
public class CertValidationUtility {

    @Autowired
    @Qualifier("restTemplateConfig")
    private RestTemplateConfig restTemplateConfig;

    private String sign = System.getProperty("eprut.signature");

    protected CloseableHttpClient createHttpConnection() {
        CloseableHttpClient httpClient = restTemplateConfig.createHttpClient();
        return httpClient;
    }

    /**
     *
     * @param file
     * @param signature
     * @return boolean
     */
    public boolean checkValidDetachedSignature(MultipartFile file, MultipartFile signature) {
        String logId = UUID.randomUUID().toString();
        log.info(String.format("%s: Started checkValidCertificate UTIL", logId));
        try (CloseableHttpClient client = createHttpConnection()) {
            String url = sign;
            url = url + "/ValidatePkcs7Servlet";
            HttpPost httpPost = new HttpPost(url);
            String boundary = "===" + System.currentTimeMillis() + "===";
            httpPost.setHeader("Content-type", "multipart/form-data; boundary=" + boundary);
            HttpEntity entity =
                    MultipartEntityBuilder.create()
                            .setMode(HttpMultipartMode.STRICT)
                            .setCharset(StandardCharsets.UTF_8)
                            .setBoundary(boundary)
                            .addBinaryBody(
                                    "binary-documnet",
                                    file.getBytes(),
                                    ContentType.create(MediaType.APPLICATION_OCTET_STREAM_VALUE),
                                    file.getOriginalFilename())
                            .addBinaryBody(
                                    "detached-signature",
                                    signature.getBytes(),
                                    ContentType.create(MediaType.APPLICATION_OCTET_STREAM_VALUE),
                                    signature.getOriginalFilename())
                            .build();
            httpPost.setEntity(entity);
            try (CloseableHttpResponse response = client.execute(httpPost)) {
                String responseString = EntityUtils.toString(response.getEntity(), "UTF-8");
                if (responseString.startsWith("VALID")) {
                    return true;
                } else {
                    log.error(
                            String.format(
                                    "%s: Error while validating the signature!: %s", logId, responseString));
                    return false;
                }
            }
        } catch (Exception exc) {
            log.error(String.format("%s: Http encountered Error!: %s", logId, exc.getMessage()), exc);
            return false;
        } finally {
            log.info(String.format("%s: Finished checkValidCertificate UTIL", logId));
        }
    }

    /**
     *
     * @param certificate
     * @return boolean
     * @throws CertificateValidationException
     */
    public boolean checkValidCertificate(MultipartFile certificate)
            throws CertificateValidationException {
        String logId = UUID.randomUUID().toString();
        log.info(String.format("%s: Started checkValidCertificate UTIL", logId));
        try (CloseableHttpClient client = createHttpConnection()) {
            String url = sign;
            url = url + "/ValidateX509CertificateServlet";
            HttpPost httpPost = new HttpPost(url);
            String boundary = "===" + System.currentTimeMillis() + "===";
            httpPost.setHeader("Content-type", "multipart/form-data; boundary=" + boundary);
            HttpEntity entity =
                    MultipartEntityBuilder.create()
                            .setMode(HttpMultipartMode.STRICT)
                            .setCharset(StandardCharsets.UTF_8)
                            .setBoundary(boundary)
                            .addBinaryBody(
                                    "x509-certificate",
                                    certificate.getBytes(),
                                    ContentType.create(MediaType.APPLICATION_OCTET_STREAM_VALUE),
                                    certificate.getOriginalFilename())
                            .addTextBody("crl", "true")
                            .addTextBody("ocsp", "true")
                            .build();
            httpPost.setEntity(entity);
            try (CloseableHttpResponse response = client.execute(httpPost)) {
                String responseString = EntityUtils.toString(response.getEntity(), "UTF-8");
                if (responseString.startsWith("VALID")) {
                    return true;
                } else {
                    log.error(
                            String.format(
                                    "%s: Error while validating the certificate!: %s", logId, responseString));
                    return false;
                }
            }
        } catch (Exception exc) {
            log.error(String.format("%s: Http encountered Error!: %s", logId, exc.getMessage()), exc);
            return false;
        } finally {
            log.info(String.format("%s: Finished checkValidCertificate UTIL", logId));
        }
    }

    /**
     *
     * @param signature
     * @return MultipartFile
     * @throws CertificateValidationException
     */
    public MultipartFile extractCertificateFromSignature(MultipartFile signature)
            throws CertificateValidationException {
        String logId = UUID.randomUUID().toString();
        log.info(String.format("%s: Started extractCertificateFromSignature UTIL", logId));
        try (CloseableHttpClient client = createHttpConnection()) {
            String url = sign;
            url = url + "/ParsePkcs7Servlet";
            HttpPost httpPost = new HttpPost(url);
            String boundary = "===" + System.currentTimeMillis() + "===";
            httpPost.setHeader("Content-type", "multipart/form-data; boundary=" + boundary);
            HttpEntity entity =
                    MultipartEntityBuilder.create()
                            .setMode(HttpMultipartMode.STRICT)
                            .setCharset(StandardCharsets.UTF_8)
                            .setBoundary(boundary)
                            .addBinaryBody(
                                    "detached-signature",
                                    signature.getBytes(),
                                    ContentType.create(MediaType.APPLICATION_OCTET_STREAM_VALUE),
                                    signature.getOriginalFilename())
                            .build();
            httpPost.setEntity(entity);
            try (CloseableHttpResponse response = client.execute(httpPost)) {
                String responseString = EntityUtils.toString(response.getEntity(), "UTF-8");
                BASE64DecodedMultipartFile certificate =
                        new BASE64DecodedMultipartFile(
                                responseString.getBytes(StandardCharsets.UTF_8), signature.getName(),
                                signature.getOriginalFilename(), signature.getContentType());
                return certificate;
            }
        } catch (Exception exc) {
            log.error(String.format("%s: Http encountered Error!: %s", logId, exc.getMessage()), exc);
            throw new CertificateValidationException("Невалиден подпис");
        } finally {
            log.info(String.format("%s: Finished extractCertificateFromSignature UTIL", logId));
        }
    }

    /**
     *
     * @param cert
     * @return Map<String, String>
     * @throws CertificateValidationException
     */
    public Map<String, String> extractInfoFromCertificate(MultipartFile cert)
            throws CertificateValidationException {
        String logId = UUID.randomUUID().toString();
        log.info(String.format("%s: Started extractInfoFromCertificate UTIL", logId));
        Map<String, String> result = new HashMap<>();
        try (CloseableHttpClient client = createHttpConnection()) {
            String url = sign;
            url = url + "/ParseX509CertificateServlet";
            HttpPost httpPost = new HttpPost(url);
            String boundary = "===" + System.currentTimeMillis() + "===";
            httpPost.setHeader("Content-type", "multipart/form-data; boundary=" + boundary);
            HttpEntity entity =
                    MultipartEntityBuilder.create()
                            .setMode(HttpMultipartMode.STRICT)
                            .setCharset(StandardCharsets.UTF_8)
                            .setBoundary(boundary)
                            .addBinaryBody(
                                    "x509-certificate",
                                    cert.getBytes(),
                                    ContentType.create(MediaType.APPLICATION_OCTET_STREAM_VALUE),
                                    cert.getOriginalFilename())
                            .build();
            httpPost.setEntity(entity);
            try (CloseableHttpResponse response = client.execute(httpPost)) {
                String responseString = EntityUtils.toString(response.getEntity(), "UTF-8");
                responseString =
                        responseString.replaceFirst("\"", "").substring(0, responseString.length() - 2);
                if (responseString.lastIndexOf("\"") == responseString.length() - 1) {
                    responseString = responseString + " ";
                }

                String[] columns = responseString.split("\",\"");
                for (int i = 0; i < columns.length; i += 2) {
                    String keyEscaped = columns[i];
                    String valueEscaped = columns[i + 1];
                    result.put(keyEscaped, valueEscaped);
                }

                return result;
            }
        } catch (Exception exc) {
            log.error(String.format("%s: Http encountered Error!: %s", logId, exc.getMessage()), exc);
            throw new CertificateValidationException("Невалиден подпис");
        } finally {
            log.info(String.format("%s: Finished extractInfoFromCertificate UTIL", logId));
        }
    }

    /**
     *
     * @param file
     * @param signature
     * @return String
     * @throws CertificateValidationException
     */
    public String extractPersonIdFromFileAndSignature(MultipartFile file, MultipartFile signature)
            throws CertificateValidationException {
        if (!checkValidDetachedSignature(file, signature)) {
            throw new CertificateValidationException("Подписът е невалиден");
        }
        MultipartFile certificate = extractCertificateFromSignature(signature);
        if (!checkValidCertificate(certificate)) {
            throw new CertificateValidationException("Сертификатът е невалиден");
        }
        Map<String, String> certData = extractInfoFromCertificate(certificate);

        String personId = certData.get("PersonId");
        if (personId == null) {
            throw new CertificateValidationException("Сертификатът не съдържа необходимите данни");
        }
        return personId;
    }
}
