package com.eprut.services.impl;

import com.eprut.beans.IdentityServerModel;
import com.eprut.db.entities.VRegisterEntity;
import com.eprut.db.repositories.RegisterRepository;
import com.eprut.db.views.out.RegisterOutView;
import com.eprut.exceptions.NoPermissionsException;
import com.eprut.exceptions.RegisterTypeNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;
import com.eprut.services.RegisterLoaderService;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

@Service
@Slf4j
public class RegisterLoaderServiceImpl implements RegisterLoaderService {

    @Autowired
    private RegisterRepository registerRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<RegisterOutView> getAllRegistersForCurrentUser(Locale locale)
            throws UnauthorizedAccessException, NoPermissionsException {
        String logId = UUID.randomUUID().toString();
        String language = locale.getLanguage();
        log.info("{}: getAllRegistersForCurrentUser started", logId);
        log.debug("{}: locale: {} language: {}", logId, locale, language);

        List<String> documentTypes = new ArrayList<>();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof IdentityServerModel userDetails) {
            documentTypes = userDetails.getActCodes();
        }

        if (documentTypes == null) {
            throw new NoPermissionsException("User has no permissions to upload documents.");
        }

        try {
            List<VRegisterEntity> vRegisterEntities = registerRepository.findAllByCurrentUser(language, documentTypes);
            List<RegisterOutView> res = modelMapper.map(vRegisterEntities, new TypeToken<List<RegisterOutView>>() {
            }.getType());
            log.info("{}: successfully retrieved {} VRegisterEntities", logId, vRegisterEntities.size());
            return res;
        } catch (Exception e) {
            log.error("{}: getAllRegistersForCurrentUser error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: getAllRegistersForCurrentUser finished", logId);
        }
    }

    @Override
    public RegisterOutView getRegisterByCode(String registerCode, Locale locale) throws RegisterTypeNotFoundException {
        String logId = UUID.randomUUID().toString();
        String language = locale.getLanguage();
        log.info("{}: getRegisterByCode started", logId);
        log.debug("{}: registerCode: {}", logId, registerCode);
        log.debug("{}: locale: {} language: {}", logId, locale, language);
        try {
            VRegisterEntity register = registerRepository.findByCode(registerCode, language)
                    .orElseThrow(() -> new RegisterTypeNotFoundException("Register with code: " + registerCode + " not found."));
            return modelMapper.map(register, RegisterOutView.class);
        } catch (Exception e) {
            log.error("{}: getRegisterByCode error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: getRegisterByCode finished", logId);
        }
    }
}
