/**
 * Project: eprut
 * Module: com.eprut.db.views
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: DTO общи модели на данни за обмяна на информация.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.db.views;
