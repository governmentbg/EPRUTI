package com.eprut.services.impl;

import com.eprut.beans.IdentityServerModel;
import com.eprut.constants.LogMessageTypes;
import com.eprut.db.entities.ImportEntity;
import com.eprut.db.entities.ImportLogEntity;
import com.eprut.db.entities.NImportStatusEntity;
import com.eprut.db.repositories.ImportLogsRepository;
import com.eprut.db.repositories.ImportRepository;
import com.eprut.db.repositories.ImportStatusRepository;
import com.eprut.db.views.out.ImportMigrationStateOutView;
import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.NoPermissionsException;
import com.eprut.exceptions.StatusNotFoundException;
import com.eprut.exceptions.UnauthorizedAccessException;
import com.eprut.exceptions.UserNotFoundException;
import com.eprut.services.ImportMigrationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Service
@Slf4j
public class ImportMigrationServiceImpl implements ImportMigrationService {

    private static final String MIGRATION_STATUS = "TRANSFER_ACCEPTED";

    @Autowired
    private ImportRepository importRepository;

    @Autowired
    private ImportStatusRepository importStatusRepository;

    @Autowired
    private ImportLogsRepository importLogsRepository;

    @Override
    public ImportMigrationStateOutView startImportMigration(String registerCode, Long importId)
            throws ImportNotFoundException, StatusNotFoundException, UnauthorizedAccessException, UserNotFoundException,
            NoPermissionsException {
        String logId = UUID.randomUUID().toString();
        log.info("{}: startImportMigration started", logId);
        log.debug("{}: params: registerCode: {}", logId, registerCode);
        log.debug("{}: params: importId: {}", logId, importId);
        try {
            ImportEntity imp = importRepository.findByRegisterCodeAndImportId(registerCode, importId)
                    .orElseThrow(() -> new ImportNotFoundException("Import with id: " + importId + " and register code: " + registerCode + " not found."));

            List<String> registerTypes = new ArrayList<>();
            String userUuid = null;
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null && authentication.getPrincipal() instanceof IdentityServerModel userDetails) {
                userUuid = userDetails.getId();
                registerTypes = userDetails.getRegisterCodes();
            }

            if (userUuid == null) {
                throw new UserNotFoundException("User not found.");
            }

            if (!registerTypes.contains(registerCode)) {
                throw new NoPermissionsException("User has no permissions for this register type.");
            }

            if (!Objects.equals(imp.getUserId(), userUuid)) {
                throw new UnauthorizedAccessException("User with id: " + userUuid + " is not authorized to perform this action.");
            }

            NImportStatusEntity status = importStatusRepository.findByStatusCode(MIGRATION_STATUS)
                    .orElseThrow(() -> new StatusNotFoundException("Status with code: " + MIGRATION_STATUS + " not found."));

            imp.setStatusId(status.getId());
            importRepository.save(imp);

            String msg = String.format("Промяна на статус към '%s'", status.getDescription());
            logStateMessage(importId, LogMessageTypes.STATE.getId(), msg);

            ImportMigrationStateOutView importMigrationStateOutView = new ImportMigrationStateOutView();
            importMigrationStateOutView.setId(imp.getId());
            importMigrationStateOutView.setStatusId(imp.getStatusId());
            importMigrationStateOutView.setStatusCode(MIGRATION_STATUS);

            return importMigrationStateOutView;
        } catch (Exception e) {
            log.error("{}: startImportMigration error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: startImportMigration finished", logId);
        }
    }

    private void logStateMessage(Long importId, Long msgTypeId, String msg) {
        ImportLogEntity importLog = new ImportLogEntity();
        importLog.setImportId(importId);
        importLog.setDateAdded(Instant.now());
        importLog.setMsgTypeId(msgTypeId);
        importLog.setMsg(msg);
        importLogsRepository.save(importLog);
    }
}
