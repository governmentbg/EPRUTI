package com.eprut.controllers;

import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.NoPermissionsException;
import com.eprut.exceptions.UnauthorizedAccessException;
import com.eprut.exceptions.UserNotFoundException;
import com.eprut.services.ImportErrorsRetrievalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@RestController
@RequestMapping("/import/registers/import-file")
public class ImportErrorsRetrievalController {

    @Autowired
    private ImportErrorsRetrievalService importErrorsRetrievalService;

    /**
     * Извлича всички грешки за конкретен импорт и връща CSV файл с подробната информация.
     *
     * @param registerCode
     * @param importId
     * @return ResponseEntity<byte[]>
     * @throws IOException
     */
    @GetMapping("/{registerCode}/details/{importId}/import-errors")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<byte[]> downloadXLSXforImportErrors(@PathVariable("registerCode") String registerCode,
                                                              @PathVariable("importId") Long importId)
            throws IOException, ImportNotFoundException, UnauthorizedAccessException, UserNotFoundException,
            NoPermissionsException {
        byte[] csvBytes = importErrorsRetrievalService.generateXLSXforImportErrors(registerCode, importId);
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy_HHmmss"));
        String filename = String.format("Errors_%s_%s_%s.xlsx", registerCode, importId, timestamp);

        ContentDisposition contentDisposition = ContentDisposition.builder("attachment")
                .filename(filename)
                .build();

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .header(HttpHeaders.CONTENT_DISPOSITION, contentDisposition.toString())
                .body(csvBytes);
    }
}
