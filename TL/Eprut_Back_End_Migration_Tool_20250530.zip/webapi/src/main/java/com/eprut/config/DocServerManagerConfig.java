package com.eprut.config;

import com.eprut.grpc.DocServerManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DocServerManagerConfig {

    @Value("${eprut.docsrv.host}")
    private String host;

    @Value("${eprut.docsrv.port}")
    private Integer port;

    @Value("${eprut.docsrv.username}")
    private String username;

    @Value("${eprut.docsrv.password}")
    private String password;

    /**
     * A bean, responsible for managing interactions with a document server via gRPC.
     * Handles file uploads, downloads and authentication (login and token refresh).
     * @return DocServerManager
     */
    @Bean
    public DocServerManager docServerManager() {
        return new DocServerManager(host, port, username, password);
    }
}
