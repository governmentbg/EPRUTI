package com.eprut.exceptions;

public class FileAlreadyExistException extends BaseException {

    public static final int STATUS = 400;
    private static final String EXP = "FILE.ALREADY.EXIST";

    @Override
    public int getStatus() {
        return STATUS;
    }

    public FileAlreadyExistException() {
        super(EXP);
    }

    public FileAlreadyExistException(String message) {
        super(EXP, message);
    }

    public FileAlreadyExistException(String message, Throwable cause) {
        super(EXP, message, cause);
    }

    public FileAlreadyExistException(Throwable cause) {
        super(EXP, cause);
    }

    public FileAlreadyExistException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(EXP, message, cause, enableSuppression, writableStackTrace);
    }
}
