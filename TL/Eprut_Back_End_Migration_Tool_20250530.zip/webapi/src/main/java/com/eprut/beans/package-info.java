/**
 * Project: eprut
 * Module: com.eprut.beans
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Временни структури за данни при обработката на уеб услугите.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.beans;
