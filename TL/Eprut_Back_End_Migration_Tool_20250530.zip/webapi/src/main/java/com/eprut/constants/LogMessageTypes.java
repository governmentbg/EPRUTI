package com.eprut.constants;

import lombok.Getter;

@Getter
public enum LogMessageTypes {
    ERROR(1),
    SYS(2),
    INFO(3),
    STATE(4),
    WARNING(5);

    private final long id;

    LogMessageTypes(long id) {
        this.id = id;
    }
}
