package com.eprut.services.impl;

import com.eprut.beans.IdentityServerModel;
import com.eprut.constants.LogMessageTypes;
import com.eprut.constants.StatusTypes;
import com.eprut.db.entities.ImportEntity;
import com.eprut.db.entities.ImportFilesEntity;
import com.eprut.db.entities.ImportLogEntity;
import com.eprut.db.entities.NImportStatusEntity;
import com.eprut.db.repositories.ImportFilesRepository;
import com.eprut.db.repositories.ImportLogsRepository;
import com.eprut.db.repositories.ImportRepository;
import com.eprut.db.repositories.ImportStatusRepository;
import com.eprut.db.views.out.FileImportStateOutView;
import com.eprut.exceptions.CertificateValidationException;
import com.eprut.exceptions.FileAlreadyExistException;
import com.eprut.exceptions.InvalidImportTypeException;
import com.eprut.exceptions.InvalidZipStructureException;
import com.eprut.exceptions.NoPermissionsException;
import com.eprut.exceptions.StatusNotFoundException;
import com.eprut.exceptions.UserNotFoundException;
import com.eprut.grpc.DocServerManager;
import com.eprut.grpc.beans.FileUploadMetaInfo;
import com.eprut.services.FileImportService;
import com.eprut.utils.CertValidationUtility;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.tika.Tika;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.system.ApplicationTemp;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.UUID;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

@Service
@Slf4j
public class FileImportServiceImpl implements FileImportService {

    private static final String ZIP_MIME_TYPE = "application/zip";
    private static final String XML_MIME_TYPE = "application/xml";
    private static final String XLSX_MIME_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    private static final String XLS_MIME_TYPE = "application/vnd.ms-excel";
    private static final String P7S = "application/pkcs7-signature";
    private static final String P7M = "application/pkcs7-mime";
    private static final int DEFAULT_BUFFER_SIZE = 8192;

    private final ApplicationTemp appTemp;

    @Autowired
    private CertValidationUtility certValidationUtility;

    @Autowired
    private ImportRepository importRepository;

    @Autowired
    private ImportFilesRepository importFilesRepository;

    @Autowired
    private ImportStatusRepository importStatusRepository;

    @Autowired
    private ImportLogsRepository importLogsRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private DocServerManager docServerManager;

    @Value("${system.tmp.dir:}")
    private String tmpDir;

    /**
     * Constructor.
     */
    public FileImportServiceImpl() {
        appTemp = new ApplicationTemp();
        if (tmpDir == null || tmpDir.isBlank()) {
            tmpDir = appTemp.getDir().getAbsolutePath();
        }
    }

    @Override
    @Transactional(readOnly = false)
    public FileImportStateOutView uploadFile(String registerCode, MultipartFile file, MultipartFile signature)
            throws IOException, NoSuchAlgorithmException, InvalidZipStructureException, InvalidImportTypeException,
            StatusNotFoundException, UserNotFoundException, NoPermissionsException, CertificateValidationException,
            FileAlreadyExistException {
        String logId = UUID.randomUUID().toString();
        log.info("{}: uploadFile started", logId);
        log.debug("{}: params: registerCode: {}", logId, registerCode);
        log.debug("{}: params: file: {}", logId, file.getOriginalFilename());

        String userIp = getUserIp();

        List<String> registerTypes = new ArrayList<>();
        String userUuid = null;
        String identifier = null;
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof IdentityServerModel userDetails) {
            userUuid = userDetails.getId();
            identifier = userDetails.getEgnbulstat();
            registerTypes = userDetails.getRegisterCodes();
        }

        if (userUuid == null) {
            throw new UserNotFoundException("User not found.");
        }

        if (!registerTypes.contains(registerCode)) {
            throw new NoPermissionsException("User has no permissions to upload documents for this register type.");
        }

        if (identifier == null) {
            throw new UserNotFoundException("Both identifiers ");
        }

        try {
            String personId = certValidationUtility.extractPersonIdFromFileAndSignature(file, signature);
            if (!personId.equals(identifier)) {
                throw new UserNotFoundException("The user and the signature owner does not match.");
            }

            ImportEntity importEntity = new ImportEntity();
            importEntity.setUserId(userUuid);
            importEntity.setUploadDate(Instant.now());
            importEntity.setFilename(file.getOriginalFilename());
            importEntity.setRegisterCode(registerCode);
            importEntity.setTraceId(UUID.randomUUID());
            importEntity.setUploaderIp(userIp);
            importRepository.save(importEntity);

            ImportFilesEntity importFile = new ImportFilesEntity();
            importFile.setFilename(file.getOriginalFilename());
            importFile.setSize(file.getSize());

            String archiveSHA256 = getSHA256(file);
            importFile.setSha256(archiveSHA256);

            NImportStatusEntity is = null;

            String errorMsg = null;
            Tika tika = new Tika();
            String detectMimeType = null;
            try (InputStream inputStream = file.getInputStream()) {
                detectMimeType = tika.detect(inputStream);
                if (!ZIP_MIME_TYPE.equals(detectMimeType)) {
                    importFile.setMimeType(detectMimeType);
                    importFile.setUrl("not-uploaded");
                    ImportFilesEntity savedImportFile = importFilesRepository.save(importFile);

                    String impErrorStatusCode = StatusTypes.IMP_ERROR_STATUS.getValue();
                    is = importStatusRepository.findByStatusCode(impErrorStatusCode).orElseThrow(
                            () -> new StatusNotFoundException(
                                    "Status with code: " + impErrorStatusCode + " not found."));
                    importEntity.setStatusId(is.getId());

                    errorMsg = "Разрешено е качването на архиви само с разширение от тип .zip.";
                    logMessage(importEntity.getId(), LogMessageTypes.ERROR.getId(), errorMsg);
                    importEntity.setFatalStackTrace(errorMsg);
                    importEntity.setFileId(savedImportFile.getId());
                    importRepository.save(importEntity);
                    throw new InvalidImportTypeException(
                            "Unsupported MIME type: " + detectMimeType + ". Only ZIP files are supported.");
                }
            }

            importFile.setMimeType(detectMimeType);

            String fileType = null;
            try (InputStream inputStream = file.getInputStream();
                 ZipArchiveInputStream zis = new ZipArchiveInputStream(inputStream)) {

                ZipArchiveEntry entry;
                while ((entry = zis.getNextEntry()) != null) {
                    if (!entry.isDirectory()) {
                        String entryName = entry.getName();
                        if (entryName.contains("/") || entryName.contains("\\")) {
                            continue;
                        }

                        String mimeType = tika.detect(zis, entryName);

                        if (XML_MIME_TYPE.equals(mimeType)) {
                            fileType = "XML";
                            String xmlUploadStatusCode = StatusTypes.XML_UPLOAD_STATUS.getValue();
                            is = importStatusRepository.findByStatusCode(xmlUploadStatusCode)
                                    .orElseThrow(() -> new StatusNotFoundException(
                                            "Status with code: " + xmlUploadStatusCode + " not found."));
                            break;
                        } else if (XLS_MIME_TYPE.equals(mimeType) || XLSX_MIME_TYPE.equals(mimeType)) {
                            fileType = "EXCEL";
                            String excelUploadStatusCode = StatusTypes.EXCEL_UPLOAD_STATUS.getValue();
                            is = importStatusRepository.findByStatusCode(excelUploadStatusCode)
                                    .orElseThrow(() -> new StatusNotFoundException(
                                            "Status with code: " + excelUploadStatusCode + " not found."));
                            break;
                        }
                    }
                }
            }

            if (fileType == null) {
                importFile.setUrl("not-uploaded");
                ImportFilesEntity savedImportFile = importFilesRepository.save(importFile);

                String impErrorStatusCode = StatusTypes.IMP_ERROR_STATUS.getValue();
                is = importStatusRepository.findByStatusCode(impErrorStatusCode).orElseThrow(
                        () -> new StatusNotFoundException("Status with code: " + impErrorStatusCode + " not found."));
                importEntity.setStatusId(is.getId());

                errorMsg =
                        "Възникна грешка - архивът не съдържа XML/Excel документ или той не е разположен на първо ниво.";
                logMessage(importEntity.getId(), LogMessageTypes.ERROR.getId(), errorMsg);
                importEntity.setFatalStackTrace(errorMsg);
                importEntity.setFileId(savedImportFile.getId());
                importRepository.save(importEntity);
                throw new InvalidZipStructureException(
                        "The ZIP file does not contain a XML or EXCEL file at top level.");
            }

            importEntity.setStatusId(is.getId());
            importEntity.setImportType(fileType);

            importFile.setMimeType(detectMimeType);

            //grpc
            //---------------------
            String fileUrl = null;
            FileUploadMetaInfo fileMetaInfo = new FileUploadMetaInfo(file.getOriginalFilename(), file.getSize());
            try (InputStream inputStream = file.getInputStream()) {
                fileUrl = docServerManager.uploadFile(logId, inputStream, fileMetaInfo, userIp, userUuid, "", "");
                //docServerManager.saveFile(logId, fileUrl, userIp, userUuid, "", ""); //todo !!!!!!!!!!!!!!!!
            }

            if (fileUrl == null) {
                importFile.setUrl("not-uploaded");
                ImportFilesEntity savedImportFile = importFilesRepository.save(importFile);

                String impErrorStatusCode = StatusTypes.IMP_ERROR_STATUS.getValue();
                is = importStatusRepository.findByStatusCode(impErrorStatusCode).orElseThrow(
                        () -> new StatusNotFoundException("Status with code: " + impErrorStatusCode + " not found."));
                importEntity.setStatusId(is.getId());

                errorMsg = "Възникна грешка при качването на архива.";
                logMessage(importEntity.getId(), LogMessageTypes.ERROR.getId(), errorMsg);
                importEntity.setFatalStackTrace(errorMsg);
                importEntity.setFileId(savedImportFile.getId());
                importRepository.save(importEntity);
                throw new IOException("Failed to upload the archive file to the document server.");
            }

            //за grpc
            importFile.setUrl(fileUrl);
            //importFile.setUrl(uploadedFile.getAbsolutePath());
            //---------------------

            //File uploadedFile = storeFileAndGetUrl(file); //do not remove - качване при нас

            if (importFilesRepository.existsBySha256(archiveSHA256)) {
                ImportFilesEntity savedImportFile = importFilesRepository.save(importFile);

                String impErrorStatusCode = StatusTypes.IMP_ERROR_STATUS.getValue();
                is = importStatusRepository.findByStatusCode(impErrorStatusCode).orElseThrow(
                        () -> new StatusNotFoundException("Status with code: " + impErrorStatusCode + " not found."));
                importEntity.setStatusId(is.getId());

                errorMsg = "Възникна грешка при качването на архив - вече съществува архив със същото съдържание.";
                logMessage(importEntity.getId(), LogMessageTypes.ERROR.getId(), errorMsg);
                importEntity.setFatalStackTrace(errorMsg);
                importEntity.setFileId(savedImportFile.getId());
                importRepository.save(importEntity);
                throw new FileAlreadyExistException("A file with the same SHA-256 hash already exists.");
            }

            ImportFilesEntity savedImportFile = importFilesRepository.save(importFile);

            importEntity.setFileId(savedImportFile.getId());

            FileUploadMetaInfo signatureMetaInfo =
                    new FileUploadMetaInfo(signature.getOriginalFilename(), file.getSize());

            String signatureSHA256 = getSHA256(signature);

            ImportFilesEntity importSignature = new ImportFilesEntity();
            importSignature.setFilename(signature.getOriginalFilename());
            importSignature.setSize(signature.getSize());
            importSignature.setSha256(signatureSHA256);

            String mimeType = null;
            try (InputStream inputStream = signature.getInputStream()) {
                mimeType = tika.detect(inputStream);
                if (!P7S.equals(mimeType) && !P7M.equals(mimeType)) {
                    String impErrorStatusCode = StatusTypes.IMP_ERROR_STATUS.getValue();
                    is = importStatusRepository.findByStatusCode(impErrorStatusCode).orElseThrow(
                            () -> new StatusNotFoundException(
                                    "Status with code: " + impErrorStatusCode + " not found."));
                    importEntity.setStatusId(is.getId());

                    errorMsg = "Разрешено е качването на подпис не е в разширените видове .p7s И .p7m";
                    logMessage(importEntity.getId(), LogMessageTypes.ERROR.getId(), errorMsg);
                    importEntity.setFatalStackTrace(errorMsg);
                    throw new InvalidImportTypeException(
                            "Unsupported MIME type: " + mimeType + ". Only P7S and P7M files are supported.");
                }
            }

            String signatureUrl = null;
            try (InputStream inputStream = signature.getInputStream()) {
                signatureUrl =
                        docServerManager.uploadFile(logId, inputStream, signatureMetaInfo, userIp, userUuid, "", "");
            }

            if (signatureUrl == null) {
                String impErrorStatusCode = StatusTypes.IMP_ERROR_STATUS.getValue();
                is = importStatusRepository.findByStatusCode(impErrorStatusCode).orElseThrow(
                        () -> new StatusNotFoundException("Status with code: " + impErrorStatusCode + " not found."));
                importEntity.setStatusId(is.getId());

                errorMsg = "Възникна грешка при качването на подписа.";
                logMessage(importEntity.getId(), LogMessageTypes.ERROR.getId(), errorMsg);
                importEntity.setFatalStackTrace(errorMsg);
                importRepository.save(importEntity);
                throw new IOException("Failed to upload the signature file to the document server.");
            }

            importSignature.setUrl(signatureUrl);
            importSignature.setMimeType(mimeType);
            ImportFilesEntity savedSignature = importFilesRepository.save(importSignature);
            importEntity.setFileSignatureId(savedSignature.getId());


            importRepository.save(importEntity);

            return modelMapper.map(importEntity, FileImportStateOutView.class);
        } catch (Exception e) {
            //importEntity.setFatalStackTrace(e.getMessage()); //todo това да се изнесе другаде и да се добави статус грешка при всяка възникнала грешка
            //importRepository.save(importEntity);
             log.error("{}: uploadFile error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: uploadFile finished", logId);
        }
    }

    private String getSHA256(MultipartFile file) throws NoSuchAlgorithmException, IOException {
        byte[] buffer = new byte[DEFAULT_BUFFER_SIZE];
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream inputStream = file.getInputStream();
             DigestInputStream digestInputStream = new DigestInputStream(inputStream, digest)) {
            while (digestInputStream.read(buffer) != -1) {
            }
        }

        return HexFormat.of().formatHex(digest.digest());
    }

    private File storeFileAndGetUrl(MultipartFile file) throws IOException {
        Path targetLocation = Paths.get(tmpDir, UUID.randomUUID().toString(), file.getOriginalFilename());
        File f = new File(targetLocation.toAbsolutePath().toString());
        f.getParentFile().mkdirs();
        File currParent = f.getParentFile();
        while (currParent != null) {
            currParent.setReadable(true, false);
            currParent.setWritable(true, false);
            currParent.setExecutable(true, false);
            currParent = currParent.getParentFile();
        }
        try {
            f.createNewFile();
        } catch (IOException e) {
            //ignore
        }
        f.setReadable(true, false);
        f.setWritable(true, false);
        Files.copy(file.getInputStream(), targetLocation.toAbsolutePath(), REPLACE_EXISTING);
        return targetLocation.toAbsolutePath().toFile();
    }

    private void logMessage(Long importId, Long msgTypeId, String msg) {
        ImportLogEntity importLog = new ImportLogEntity();
        importLog.setImportId(importId);
        importLog.setDateAdded(Instant.now());
        importLog.setMsgTypeId(msgTypeId);
        importLog.setMsg(msg);
        importLogsRepository.save(importLog);
    }

    private String getUserIp() {
        String userIp = request.getHeader("X-Forwarded-For");

        if (userIp != null && !userIp.isEmpty()) {
            // X-Forwarded-For can contain multiple IPs (client, proxies)
            // The first one is typically the original client IP
            int commaIndex = userIp.indexOf(',');
            if (commaIndex != -1) {
                userIp = userIp.substring(0, commaIndex).trim();
            }
        } else {
            // Try other common headers if X-Forwarded-For is not present
            userIp = request.getHeader("Proxy-Client-IP");
            if (userIp == null || userIp.isEmpty()) {
                userIp = request.getHeader("WL-Proxy-Client-IP");
            }
            if (userIp == null || userIp.isEmpty()) {
                userIp = request.getHeader("HTTP_X_FORWARDED_FOR");
            }
            if (userIp == null || userIp.isEmpty()) {
                userIp = request.getHeader("HTTP_X_FORWARDED");
            }
            if (userIp == null || userIp.isEmpty()) {
                userIp = request.getHeader("HTTP_CLIENT_IP");
            }
            if (userIp == null || userIp.isEmpty()) {
                userIp = request.getRemoteAddr();
            }
        }
        return userIp;
    }
}
