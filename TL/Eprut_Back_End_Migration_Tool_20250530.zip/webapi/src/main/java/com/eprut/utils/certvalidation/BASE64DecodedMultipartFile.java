package com.eprut.utils.certvalidation;

import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class BASE64DecodedMultipartFile implements MultipartFile {

    private final byte[] imgContent;
    private final String fileName;
    private final String originalFileName;
    private final String contentType;

    /**
     *
     * @param imgContent
     * @param fileName
     * @param originalFileName
     * @param contentType
     */
    public BASE64DecodedMultipartFile(
            byte[] imgContent, String fileName, String originalFileName, String contentType) {
        this.imgContent = imgContent;
        this.fileName = fileName;
        this.originalFileName = originalFileName;
        this.contentType = contentType;
    }

    /**
     *
     * @return String
     */
    @Override
    public String getName() {
        return fileName;
    }

    /**
     *
     * @return String
     */
    @Override
    public String getOriginalFilename() {
        return originalFileName;
    }

    /**
     *
     * @return String
     */
    @Override
    public String getContentType() {
        return contentType;
    }

    /**
     *
     * @return String
     */
    @Override
    public boolean isEmpty() {
        return imgContent == null || imgContent.length == 0;
    }

    /**
     *
     * @return String
     */
    @Override
    public long getSize() {
        return imgContent.length;
    }

    /**
     *
     * @return String
     * @throws IOException
     */
    @Override
    public byte[] getBytes() throws IOException {
        return imgContent;
    }

    /**
     *
     * @return String
     * @throws IOException
     */
    @Override
    public InputStream getInputStream() throws IOException {
        return new ByteArrayInputStream(imgContent);
    }

    /**
     *
     * @param dest
     * @throws IOException
     * @throws IllegalStateException
     */
    @Override
    public void transferTo(File dest) throws IOException, IllegalStateException {
        new FileOutputStream(dest).write(imgContent);
    }
}
