package com.eprut.config;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ModelMapperConfig {

    /**
     * Configuration class for setting up the ModelMapper bean.
     * The configuration sets the mapping strategy to STRICT,
     * ensuring that mappings are only created when property names match exactly.
     * @return ModelMapper
     */
    @Bean
    public ModelMapper getMapper() {
        ModelMapper m = new ModelMapper();
        m.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        return m;
    }
}
