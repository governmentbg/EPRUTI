package com.eprut.services.impl;

import com.eprut.beans.IdentityServerModel;
import com.eprut.db.repositories.AdmUserRepository;
import com.eprut.db.views.out.AdmUserOutView;
import com.eprut.exceptions.UserNotFoundException;
import com.eprut.services.UserProfileService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@Slf4j
public class UserProfileServiceImpl implements UserProfileService {

    @Autowired
    private AdmUserRepository admUserRepository;

    @Override
    public AdmUserOutView getUserProfileDetails() {
        String logId = UUID.randomUUID().toString();
        log.info("{}: getUserProfileDetails started", logId);
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication == null || !(authentication.getPrincipal() instanceof IdentityServerModel userDetails)) {
                throw new UserNotFoundException("User not found.");
            }
            String userUuid = userDetails.getId();

            return admUserRepository.getAdmUserByUserId(UUID.fromString(userUuid))
                    .orElseThrow(() -> new UserNotFoundException("User profile details not found for user: " + userUuid));
        } catch (UserNotFoundException e) {
            log.error("{}: getUserProfileDetails error", logId, e);
            throw new RuntimeException(e);
        } finally {
            log.info("{}: getUserProfileDetails finished", logId);
        }
    }
}
