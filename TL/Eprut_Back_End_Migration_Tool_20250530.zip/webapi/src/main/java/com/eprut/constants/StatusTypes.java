package com.eprut.constants;

import lombok.Getter;

@Getter
public enum StatusTypes {
    IMP_ERROR_STATUS("IMP_ERROR"),
    XML_UPLOAD_STATUS("XML_UPLOADED"),
    EXCEL_UPLOAD_STATUS("EX_UPLOADED");

    private final String value;

    StatusTypes(String value) {
        this.value = value;
    }
}
