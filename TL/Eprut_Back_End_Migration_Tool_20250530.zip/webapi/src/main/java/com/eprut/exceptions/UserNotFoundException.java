package com.eprut.exceptions;

public class UserNotFoundException extends BaseException {
    public static final int STATUS = 401;
    private static final String EXP = "USER.NOT.FOUND";

    @Override
    public int getStatus() {
        return STATUS;
    }

    public UserNotFoundException() {
        super(EXP);
    }

    public UserNotFoundException(String message) {
        super(EXP, message);
    }

    public UserNotFoundException(String message, Throwable cause) {
        super(EXP, message, cause);
    }

    public UserNotFoundException(Throwable cause) {
        super(EXP, cause);
    }

    public UserNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(EXP, message, cause, enableSuppression, writableStackTrace);
    }
}
