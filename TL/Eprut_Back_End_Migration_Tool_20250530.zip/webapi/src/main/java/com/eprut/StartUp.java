package com.eprut;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class StartUp extends SpringBootServletInitializer {

    /** Entry point for the application.
     * @param args arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(StartUp.class, args);
    }
}
