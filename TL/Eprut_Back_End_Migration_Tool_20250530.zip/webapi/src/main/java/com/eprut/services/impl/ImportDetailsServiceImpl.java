package com.eprut.services.impl;

import com.eprut.beans.IdentityServerModel;
import com.eprut.db.entities.ImportEntity;
import com.eprut.db.entities.ImportLogEntity;
import com.eprut.db.repositories.DocumentsRepository;
import com.eprut.db.repositories.ImportLogsRepository;
import com.eprut.db.repositories.ImportRepository;
import com.eprut.db.repositories.RegActObjectRepository;
import com.eprut.db.repositories.RegActRepository;
import com.eprut.db.views.out.ImportDetailsOutView;
import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.NoPermissionsException;
import com.eprut.exceptions.UnauthorizedAccessException;
import com.eprut.exceptions.UserNotFoundException;
import com.eprut.services.ImportDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Service
@Slf4j
public class ImportDetailsServiceImpl implements ImportDetailsService {

    private static final List<String> VALID_STATUS_CODES = Arrays.asList("DATA_ERROR",
                                                                         "TRANSFER_READY",
                                                                         "TRANSFER_ACCEPTED",
                                                                         "TRANSFER_PREPARING",
                                                                         "TRANSFER_WORKING",
                                                                         "TRANSFER_ERROR",
                                                                         "TRANSFER_DONE");

    @Autowired
    private ImportRepository importRepository;

    @Autowired
    private RegActRepository regActRepository;

    @Autowired
    private RegActObjectRepository regActObjectRepository;

    @Autowired
    private DocumentsRepository documentsRepository;

    @Autowired
    private ImportLogsRepository importLogsRepository;

    @Override
    public ImportDetailsOutView getImportDetails(String registerCode, Long importId)
            throws ImportNotFoundException, UnauthorizedAccessException, UserNotFoundException, NoPermissionsException {
        String logId = UUID.randomUUID().toString();
        log.info("{}: getImportDetails started", logId);
        log.debug("{}: params: registerCode: {}", logId, registerCode);
        log.debug("{}: params: importId: {}", logId, importId);
        try {
            ImportEntity importEntity = importRepository.findByRegisterCodeAndImportId(registerCode, importId)
                    .orElseThrow(() -> new ImportNotFoundException(
                            "Import with id: " + importId + " and register code: " + registerCode + " not found."));

            List<String> registerTypes = new ArrayList<>();
            String userUuid = null;
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null && authentication.getPrincipal() instanceof IdentityServerModel userDetails) {
                userUuid = userDetails.getId();
                registerTypes = userDetails.getRegisterCodes();
            }

            if (userUuid == null) {
                throw new UserNotFoundException("User not found.");
            }

            if (!registerTypes.contains(registerCode)) {
                throw new NoPermissionsException("User has no permissions for this register type.");
            }

            if (!Objects.equals(importEntity.getUserId(), userUuid)) {
                throw new UnauthorizedAccessException(
                        "User with id: " + userUuid + " is not authorized to perform this action.");
            }

            List<ImportLogEntity> errors = importLogsRepository.findImportErrorsByImportId(importId);

            String currentImportStatus = importEntity.getStatus().getCode();

            Long numActs = null;
            Long numObjects = null;
            Long numDocuments = null;

            ImportDetailsOutView importDetailsOutView = new ImportDetailsOutView();
            importDetailsOutView.setFilename(importEntity.getFilename());
            importDetailsOutView.setSize(importEntity.getFile().getSize());

            if (!VALID_STATUS_CODES.contains(currentImportStatus)) {
                importDetailsOutView.setNumActs(numActs);
                importDetailsOutView.setNumObjects(numObjects);
                importDetailsOutView.setNumAttachedFiles(numDocuments);
            } else {
                numActs = regActRepository.countActsByImportId(importId);
                importDetailsOutView.setNumActs(numActs);
                numObjects = regActObjectRepository.countObjectsByImportId(importId);
                importDetailsOutView.setNumObjects(numObjects);
                numDocuments = documentsRepository.countDocumentsByImportId(importId);
                importDetailsOutView.setNumAttachedFiles(numDocuments);
            }

            importDetailsOutView.setHasErrors(!errors.isEmpty());
            return importDetailsOutView;
        } catch (Exception e) {
            log.error("{}: getImportDetails error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: getImportDetails finished", logId);
        }
    }
}
