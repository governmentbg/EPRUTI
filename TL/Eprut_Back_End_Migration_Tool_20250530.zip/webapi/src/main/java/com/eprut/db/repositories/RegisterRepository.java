package com.eprut.db.repositories;

import com.eprut.db.entities.VRegisterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RegisterRepository extends JpaRepository<VRegisterEntity, Long> {

    /**
     * Намира всички регистри, за които текущия потребител има права да качва документи.
     * @param langCode
     * @return List<VRegisterEntity>
     */
    @Query("""
        select distinct r
        from VRegisterEntity r join VNRegActRegEntity rar on r.code = rar.regCode
        where r.langCode = :langCode and rar.regActCode in :codes
    """)
    List<VRegisterEntity> findAllByCurrentUser(@Param("langCode") String langCode, @Param("codes") List<String> codes);

    /**
     * Намира всички регистри, за които текущия потребител има права да качва документи.
     * @param codes
     * @return List<VRegisterEntity>
     */
    @Query("""
        select distinct r
        from VRegisterEntity r join VNRegActRegEntity rar on r.code = rar.regCode
        where rar.regActCode in :codes
    """)
    List<VRegisterEntity> findAllByCurrentUser(@Param("codes") List<String> codes);

    /**
     * Намира регистър по код.
     * @param code
     * @param langCode
     * @return VRegisterEntity
     */
    @Query("""
        select r
        from VRegisterEntity r
        where r.code = :code and r.langCode = :langCode
    """)
    Optional<VRegisterEntity> findByCode(@Param("code") String code, @Param("langCode") String langCode);
}
