package com.eprut.config;

import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.protocol.HttpContext;

import java.io.IOException;
import java.net.UnknownHostException;
import java.util.Arrays;

public class CustomHttpRequestRetryHandler extends DefaultHttpRequestRetryHandler {
    /**
     *
     * @param retryCount
     * @param requestSentRetryEnabled
     */
    public CustomHttpRequestRetryHandler(int retryCount, boolean requestSentRetryEnabled) {
        super(retryCount, requestSentRetryEnabled, Arrays.asList(UnknownHostException.class));
    }

    @Override
    public boolean retryRequest(IOException exception, int executionCount, HttpContext context) {
        boolean t = super.retryRequest(exception, executionCount, context);
        return t;
    }
}