/**
 * Project: eprut
 * Module: com.eprut.services
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Интерфейси за сервизи.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.services;
