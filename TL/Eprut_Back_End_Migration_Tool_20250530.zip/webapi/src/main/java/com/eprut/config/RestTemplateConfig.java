package com.eprut.config;

import com.eprut.exceptions.BaseException;
import org.apache.http.config.SocketConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration("restTemplateConfig")
public class RestTemplateConfig {

    private PoolingHttpClientConnectionManager poolingHttpClientConnectionManager;
    private CustomHttpRequestRetryHandler retryHandler;

    @Value("${eprut.crl.conn.timeout}")
    private int crlConnTimeout;
    @Value("${eprut.ocsp.retry.cnt}")
    private int ocspRetryCount;
    @Value("${eprut.http.max.conn}")
    private int httpMaxConn;
    @Value("${eprut.http.conn.per.route}")
    private int httpConnPerRoute;

    private static final int MS = 2000;

    /**
     * @return CloseableHttpClient
     */
    public CloseableHttpClient createHttpClient() {
        CloseableHttpClient httpClient =
                HttpClients.custom()
                        //                .setSSLSocketFactory(sslConnectionSocketFactory)
                        .setConnectionManager(poolingHttpClientConnectionManager)
                        .setConnectionManagerShared(true)
                        .setRetryHandler(retryHandler)
                        .build();

        return httpClient;
    }

    /**
     * @return PoolingHttpClientConnectionManager
     * @throws BaseException
     */
    @Bean("httpClientManager")
    public PoolingHttpClientConnectionManager httpClientManager() throws BaseException {

        PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
        connManager.setMaxTotal(httpMaxConn);
        connManager.setDefaultMaxPerRoute(httpConnPerRoute);
        connManager.setDefaultSocketConfig(SocketConfig.custom().setSoTimeout(crlConnTimeout).build());

        connManager.setValidateAfterInactivity(MS);

        retryHandler = new CustomHttpRequestRetryHandler(ocspRetryCount, true);
        return connManager;
    }
}
