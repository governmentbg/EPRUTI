package com.eprut.exceptions;

public class NoPermissionsException extends BaseException {
    public static final int STATUS = 403;
    private static final String EXP = "USER.HAS.NO.PERMISSIONS";

    @Override
    public int getStatus() {
        return STATUS;
    }

    public NoPermissionsException() {
        super(EXP);
    }

    public NoPermissionsException(String message) {
        super(EXP, message);
    }

    public NoPermissionsException(String message, Throwable cause) {
        super(EXP, message, cause);
    }

    public NoPermissionsException(Throwable cause) {
        super(EXP, cause);
    }

    public NoPermissionsException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(EXP, message, cause, enableSuppression, writableStackTrace);
    }
}
