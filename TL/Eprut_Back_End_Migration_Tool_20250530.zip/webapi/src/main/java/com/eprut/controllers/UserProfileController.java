package com.eprut.controllers;

import com.eprut.db.views.out.AdmUserOutView;
import com.eprut.services.UserProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/profile-details")
public class UserProfileController {

    @Autowired
    private UserProfileService userProfileService;

    /**
     * Връща информация за потребителския профил.
     * @return ResponseEntity<AdmUserOutView>
     */
    @GetMapping("")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<AdmUserOutView> getUserProfileDetails() {
        AdmUserOutView res = userProfileService.getUserProfileDetails();
        return ResponseEntity.ok(res);
    }
}
