package com.eprut.services.impl;

import com.eprut.beans.IdentityServerModel;
import com.eprut.db.entities.VRegisterEntity;
import com.eprut.db.repositories.AdmUserRepository;
import com.eprut.db.repositories.DocumentTypeRepository;
import com.eprut.db.repositories.RegisterRepository;
import com.eprut.db.views.out.DocumentTypeOutView;
import com.eprut.services.IdentityServerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class IdentityServerServiceImpl implements IdentityServerService {

    //todo local host na porta na prilojenieto
    @Value("${identityserver.userinfo.endpoint.url:parameter is not set}")
    private String identityServerUserInfoEndpointUrl;

    @Autowired
    private DocumentTypeRepository documentTypeRepository;

    @Autowired
    private AdmUserRepository admUserRepository;

    @Autowired
    private RegisterRepository registerRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        try {
            UUID userId = UUID.fromString(username);

            String egnbulstat = admUserRepository.getEgnBulstatByUserId(userId);

            if (egnbulstat == null) {
                throw new UsernameNotFoundException("User has no egnbulstat: " + username);
            }

            List<String> authorities = new ArrayList<>();
            authorities.add("DEFAULT_ROLE");

            List<DocumentTypeOutView> docTypes = documentTypeRepository.getDoctypeByUser(userId);
            List<String> actCodes = docTypes.stream()
                    .map(DocumentTypeOutView::getCode)
                    .collect(Collectors.toList());

            //fixme throw-a
            if (actCodes.isEmpty()) {
                throw new UsernameNotFoundException("User not found or has no document upload permissions: " + username);
            }

            List<String> registerCodes = registerRepository.findAllByCurrentUser(actCodes).stream().map(
                    VRegisterEntity::getCode).toList();

            //fixme throw-a
            if (registerCodes.isEmpty()) {
                throw new UsernameNotFoundException("User has no document upload permissions: " + username);
            }

            return new IdentityServerModel(
                    UUID.randomUUID().toString(),
                    username,
                    username,
                    egnbulstat,
                    authorities,
                    actCodes,
                    registerCodes
            );
        } catch (IllegalArgumentException e) {
            throw new UsernameNotFoundException("Invalid user id: " + username);
        } catch (UsernameNotFoundException e) {
            throw e;
        } catch (Exception e) {
            throw new UsernameNotFoundException("Error loading user: " + e.getMessage());
        }
    }
}
