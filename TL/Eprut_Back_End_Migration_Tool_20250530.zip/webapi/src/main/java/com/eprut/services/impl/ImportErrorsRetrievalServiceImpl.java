package com.eprut.services.impl;

import com.eprut.beans.IdentityServerModel;
import com.eprut.db.entities.ImportEntity;
import com.eprut.db.entities.ImportLogEntity;
import com.eprut.db.repositories.ImportLogsRepository;
import com.eprut.db.repositories.ImportRepository;
import com.eprut.exceptions.ImportNotFoundException;
import com.eprut.exceptions.NoPermissionsException;
import com.eprut.exceptions.UnauthorizedAccessException;
import com.eprut.exceptions.UserNotFoundException;
import com.eprut.services.ImportErrorsRetrievalService;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Service
@Slf4j
public class ImportErrorsRetrievalServiceImpl implements ImportErrorsRetrievalService {

    @Autowired
    private ImportLogsRepository importLogsRepository;

    @Autowired
    private ImportRepository importRepository;

    @Override
    public byte[] generateXLSXforImportErrors(String registerCode, Long importId)
            throws IOException, ImportNotFoundException, UnauthorizedAccessException, UserNotFoundException,
            NoPermissionsException {
        String logId = UUID.randomUUID().toString();
        log.info("{}: generateXLSXforImportErrors started", logId);
        log.debug("{}: params: importId {}", logId, importId);
        try {
            ImportEntity imp = importRepository.findByRegisterCodeAndImportId(registerCode, importId)
                    .orElseThrow(() -> new ImportNotFoundException("Import with id: " + importId + " and register code: " + registerCode + " not found."));

            List<String> registerTypes = new ArrayList<>();
            String userUuid = null;
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null && authentication.getPrincipal() instanceof IdentityServerModel userDetails) {
                userUuid = userDetails.getId();
                registerTypes = userDetails.getRegisterCodes();
            }

            if (userUuid == null) {
                throw new UserNotFoundException("User not found.");
            }

            if (!registerTypes.contains(registerCode)) {
                throw new NoPermissionsException("User has no permissions for this register type.");
            }

            if (!Objects.equals(imp.getUserId(), userUuid)) {
                throw new UnauthorizedAccessException("User with id: " + userUuid + " is not authorized to perform this action.");
            }

            List<ImportLogEntity> errors = importLogsRepository.findImportErrorsByImportId(importId);

            log.info("{}: generating xlsx file started", logId);

            try (Workbook workbook = new XSSFWorkbook()) {
                Sheet sheet = workbook.createSheet("Журнал");

                CellStyle headerStyle = workbook.createCellStyle();
                Font headerFont = workbook.createFont();
                headerFont.setBold(true);
                headerStyle.setFont(headerFont);

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

                String[] header = {"Дата", "Вид на Съобщение", "Съобщение"};

                Row headerRow = sheet.createRow(0);
                for (int i = 0; i < header.length; i++) {
                    Cell cell = headerRow.createCell(i);
                    cell.setCellValue(header[i]);
                    cell.setCellStyle(headerStyle);
                }

                int rowNum = 1;

                final int date = 0;
                final int messageType = 1;
                final int message = 2;
                for (ImportLogEntity ile : errors) {
                    Row row = sheet.createRow(rowNum++);
                    LocalDateTime dateAdded = LocalDateTime.ofInstant(ile.getDateAdded(), ZoneId.systemDefault());

                    row.createCell(date).setCellValue(dateAdded.format(formatter));
                    row.createCell(messageType).setCellValue(ile.getMsgType().getDescription());
                    row.createCell(message).setCellValue(ile.getMsg());
                }

                for (int i = 0; i < header.length; i++) {
                    sheet.autoSizeColumn(i);
                }

                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                workbook.write(outputStream);

                return outputStream.toByteArray();
            } catch (Exception e) {
                log.error("{}: error generating xlsx file: {}", logId, e.getMessage(), e);
                throw e;
            } finally {
                log.info("{}: generating xlsx file finished", logId);
            }
        } catch (Exception e) {
            log.error("{}: generateXLSXforImportErrors error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: generateXLSXforImportErrors finished", logId);
        }
    }
}
