/**
 * Project: eprut
 * Module: com.eprut.exceptions
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Описание на грешки които може да се срещнат по време на обработката на една заявка.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.exceptions;
