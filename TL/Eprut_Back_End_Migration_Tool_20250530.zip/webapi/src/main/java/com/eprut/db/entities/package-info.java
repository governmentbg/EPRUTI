/**
 * Project: eprut
 * Module: com.eprut.db.entities
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: DEO обекти за комуникация с базата данни.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.db.entities;
