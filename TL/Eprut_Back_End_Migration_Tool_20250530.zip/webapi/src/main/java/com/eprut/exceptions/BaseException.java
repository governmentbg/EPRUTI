package com.eprut.exceptions;

public class BaseException extends Exception {

    protected String code = "BASE.EXCEPTION.MESSAGE";
    private static final int STATUS = 500;

    public BaseException() {
        super();
    }

    public BaseException(String code) {
        super();
        this.code = code;
    }

    public BaseException(String code, String message) {
        super(message);
        this.code = code;
    }

    public BaseException(String code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
    }

    public BaseException(String code, Throwable cause) {
        super(cause);
        this.code = code;
    }

    protected BaseException(String code, String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public int getStatus() {
        return STATUS;
    }
}
