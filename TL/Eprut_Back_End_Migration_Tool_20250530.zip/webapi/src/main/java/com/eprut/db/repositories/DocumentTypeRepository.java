package com.eprut.db.repositories;

import com.eprut.db.views.out.DocumentTypeOutView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public class DocumentTypeRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * Returns a list of all document types that the current user has rights to upload.
     *
     * @param userId
     * @return List<DocumentTypeOutView>
     */
    public List<DocumentTypeOutView> getDoctypeByUser(UUID userId) {
        String sql = "SELECT * FROM admdata.get_doctype_byuser(?)";
        return jdbcTemplate.query(
                sql,
                ps -> ps.setObject(1, userId),
                new BeanPropertyRowMapper<>(DocumentTypeOutView.class)
        );
    }
}
