package com.eprut.db.repositories;

import com.eprut.db.views.out.AdmUserOutView;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public class AdmUserRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * Returns user details.
     * @param userId
     * @return Optional<AdmUserOutView>
     */
    public Optional<AdmUserOutView> getAdmUserByUserId(UUID userId) {
        String sql = "SELECT * FROM admdata.get_adm_user(?)";
        List<AdmUserOutView> result = jdbcTemplate.query(
                sql,
                ps -> ps.setObject(1, userId),
                new BeanPropertyRowMapper<>(AdmUserOutView.class)
        );
        return result.stream().findFirst();
    }

    /**
     * Returns user egnbulstat.
     * @param userId
     * @return String
     */
    public String getEgnBulstatByUserId(UUID userId) {
        String sql = "SELECT egnbulstat FROM admdata.get_adm_user(?)";
        List<String> results = jdbcTemplate.query(
                sql,
                (ps) -> ps.setObject(1, userId),
                (rs, rowNum) -> rs.getString("egnbulstat")
        );
        return results.isEmpty() ? null : results.getFirst();
    }

}
