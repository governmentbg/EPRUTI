/**
 * Project: eprut
 * Module: com.eprut.xml.constants
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Константи за извличане на данни от XML.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.xml.constants;
