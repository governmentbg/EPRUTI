/**
 * Project: eprut
 * Module: com.eprut.xml.worker.cases
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Имплементация на логика за различни регистри.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.xml.worker.cases;
