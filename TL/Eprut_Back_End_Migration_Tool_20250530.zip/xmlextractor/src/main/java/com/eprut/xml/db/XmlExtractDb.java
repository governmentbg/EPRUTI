package com.eprut.xml.db;

import com.eprut.db.beans.Address;
import com.eprut.db.beans.Customer;
import com.eprut.db.beans.Document;
import com.eprut.db.beans.RegAct;
import com.eprut.db.beans.RegActFullDocument;
import com.eprut.db.beans.RegActGdprDocument;
import com.eprut.db.beans.RegAppOneDocument;
import com.eprut.db.beans.RegAppTwoDocument;
import com.eprut.db.beans.RegContDocument;
import com.eprut.db.beans.RegObject;
import com.eprut.db.config.IpInfoConfig;
import com.eprut.db.impl.DatabaseManager;
import com.eprut.db.impl.WorkBean;
import com.eprut.xml.constants.States;
import lombok.extern.slf4j.Slf4j;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.eprut.db.DBConnector.getConnection;

@Slf4j
public class XmlExtractDb extends DatabaseManager {

    private static final String GET_IMPORT = """
            select * from staging.import where id = ?
            """;

    private static final String SAVE_ADDRESS_TO_DB = """
            insert into staging.address (imp_id, excel_row, country, district, municipality, settlement, village, region,
                                         addrplacename, squarename, squarenum, quarter, flatnum,
                                         streetname, streetnum, appcomplexname, appcomplexnum, otherluname, otherlunum,
                                         flatentrance, floor, apartment, is_valid)
            values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) returning id
            """;

    private static final String SAVE_REG_OBJECT_TO_DB = """
            insert into staging.reg_actobject (imp_id, excel_row, reg_act_id, cadastre, local_place, regulation_district, upi, plan_region, plan_number,
                                               kvs_territory, kvs_number, teritory_type, protected_teritory, description, adress_id, is_valid)
            values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) returning id
            """;

    private static final String SAVE_REG_ACT_TO_DB = """
            insert into staging.reg_act (imp_id, excel_row, number, type, act_date, message_date, message_type, issued_date, status, change_date, validity_date,
                                        fact_reason, legal_reason, administration, administrative_unit, adm_popular, object_identification, is_valid)
            values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) returning id
            """;

    private static final String SAVE_CUSTOMER_TO_DB = """
            insert into staging.customer (imp_id, excel_row, reg_act_id, identifier_type, identifier, customer_type,
                                          unit_name, first_name, middle_name, last_name, email, phone, capacity, adress_id, is_valid)
            values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) returning id
            """;

    private static final String SAVE_REG_CONT_DOC_TO_DB = """
            insert into staging.reg_cont_documents (imp_id, excel_row, reg_act_id, document_id, description, is_valid)
            values (?, ?, ?, ?, ?, ?) returning id
            """;

    private static final String SAVE_REG_ACT_DOC_ONE_TO_DB = """
            insert into staging.reg_gdpr_documents(imp_id, excel_row, reg_act_id, document_id, is_valid)
            values (?, ?, ?, ?, ?)
            """;

    private static final String SAVE_REG_ACT_DOC_TWO_TO_DB = """
            insert into staging.reg_full_documents(imp_id, excel_row, reg_act_id, document_id, is_valid)
            values (?, ?, ?, ?, ?)
            """;

    private static final String SAVE_DOCUMENT_TO_DB = """
            insert into staging.documents (imp_id, filename, mime_type, size, sha256, url)
            values (?, ?, ?, ?, ?, ?) returning id
            """;

    private static final String SAVE_REG_APP_ONE_TO_DB = """
            insert into staging.reg_app01_documents (imp_id, excel_row, reg_act_id, document_id, type, subtype, is_valid)
            values (?, ?, ?, ?, ?, ?, ?) returning id
            """;

    private static final String SAVE_REG_APP_TWO_TO_DB = """
            insert into staging.reg_app02_documents (imp_id, excel_row, reg_act_id, document_id, type, subtype, is_valid)
            values (?, ?, ?, ?, ?, ?, ?) returning id
            """;

    private static final String GET_LOCATION = """
             select
             case
                when ? is not null then substring(? from 1 for 5)
                when ? is not null then e.ekatte
                else null
             end as settlement,
            case
                when ? is not null then m.nsicode
                when ? is not null then m.nsicode
                when ? is not null then m.nsicode
                else null
            end as municipality,
             case
                when ? is not null then p.nsicode
                when ? is not null then p.nsicode
                when ? is not null then p.nsicode
                when ? is not null then p.nsicode
                else null
             end as province,
             case
                when ? is not null then r.nsicode
                else null
             end as region
             from bnd.ekatte e
             left join bnd.municipality m on e.r_munid = m.adm_id
             left join bnd.province p on m.r_provinceid = p.adm_id
             left join bnd.region r on m.adm_id = r.r_munid
             where
                 (? is not null and r.nsicode = ?) or
                 (? is not null and e.ekatte = ?) or
                 (? is not null and m.nsicode = ?) or
                 (? is not null and p.nsicode = ?)
             limit 1;
            """;

    private static final String GET_REG_ACT_TYPES = """
             select code, description
             from staging.v_n_reg_act where lang_code = 'bg'
            """;

    /**
     * Get predefined work items.
     *
     * @param logId
     * @return work item.
     * @throws Exception
     */
    public List<WorkBean> getReadyToStart(String logId) throws Exception {
        return super.getReadyToStart(logId, States.XML_UPLOADED.name());
    }

    @Override
    public WorkBean start(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.XML_PREPARING.name(), IpInfoConfig.getSignature());
    }

    @Override
    public boolean checkIfNotStarted(String logId, WorkBean work) throws Exception {
        return checkIfNotStarted(logId, work, States.XML_UPLOADED.name());
    }

    @Override
    public WorkBean finishedPreparing(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.XML_WORKING.name());
    }

    @Override
    public WorkBean finish(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.DATA_UPLOADED.name());
    }

    @Override
    public WorkBean error(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.XML_ERROR.name());
    }

    @Override
    public WorkBean error(String logId, WorkBean work, Exception e) throws Exception {
        return changeStatusToError(logId, work, States.XML_ERROR.name(), e);
    }

    /**
     * Get the path of a zip archive.
     *
     * @param logId
     * @param work
     * @return String
     * @throws Exception
     */
    public String getZipArchivePath(String logId, WorkBean work) throws Exception {
        return super.getZipArchivePath(logId, work);
    }

    /**
     * Get register code from import.
     *
     * @param logId
     * @param work
     * @return String
     * @throws Exception
     */
    public String getRegisterCodeFromImport(String logId, WorkBean work) throws Exception {
        log.info("{}: getRegisterCodeFromImport - started", logId);
        log.trace("{}: work: {}", logId, work);
        String result = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_IMPORT)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        result = rs.getString("register_code");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegisterCodeFromImport - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegisterCodeFromImport - finished", logId);
        }
        return result;
    }

    /**
     * Save act to db.
     *
     * @param logId
     * @param work
     * @param regAct
     * @return Long
     * @throws Exception
     */
    public Long saveRegActToDB(String logId, WorkBean work, RegAct regAct, Map<String, String> actTypes) throws Exception {
        log.info("{}: saveRegActToDB - started", logId);
        log.trace("{}: regAct: {}", logId, regAct);
        Long id = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(SAVE_REG_ACT_TO_DB)) {
                int i = 1;
                cs.setLong(i++, regAct.getImpId());
                cs.setInt(i++, regAct.getExcelRow());
                cs.setString(i++, regAct.getActNum());
                cs.setString(i++, regAct.getActType());
                cs.setTimestamp(i++, regAct.getActDate() != null ? Timestamp.valueOf(regAct.getActDate()) : null);
                cs.setTimestamp(i++,
                        regAct.getMessageDate() != null ? Timestamp.valueOf(regAct.getMessageDate()) : null);
                cs.setString(i++, regAct.getMessageType());
                cs.setTimestamp(i++, regAct.getIssuedDate() != null ? Timestamp.valueOf(regAct.getIssuedDate()) : null);
                cs.setString(i++, regAct.getStatus());
                cs.setTimestamp(i++, regAct.getChangeDate() != null ? Timestamp.valueOf(regAct.getChangeDate()) : null);
                cs.setTimestamp(i++,
                        regAct.getValidityDate() != null ? Timestamp.valueOf(regAct.getValidityDate()) : null);
                cs.setString(i++, regAct.getFactReason());
                cs.setString(i++, regAct.getLegalReason());
                cs.setString(i++, regAct.getAdministration());
                cs.setString(i++, regAct.getAdministrativeUnit());
                cs.setString(i++, regAct.getAdmPopular());
                cs.setString(i++, regAct.getObjectIdentification());
                cs.setBoolean(i++, true);
                cs.execute();
                c.commit();

                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        id = rs.getLong("id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: saveRegActToDB - error", logId, e);
            logWarningMessage(logId, work,
                    "Възникна грешка при записването на Акт с Тип: " + actTypes.get(regAct.getActType()) + ", С Номер" + regAct.getActNum() + e.getMessage());
        } finally {
            log.info("{}: saveRegActToDB - finished", logId);
        }
        return id;
    }

    /**
     * Save act object to db.
     *
     * @param logId
     * @param work
     * @param regObject
     * @return Long
     * @throws Exception
     */
    public Long saveRegObjectToDB(String logId, WorkBean work, RegObject regObject, RegAct regAct) throws Exception {
        log.info("{}: saveRegObjectToDB - started", logId);
        log.trace("{}: address: {}", logId, regObject);
        Long id = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(SAVE_REG_OBJECT_TO_DB)) {
                int i = 1;
                cs.setLong(i++, regObject.getImpId());
                cs.setInt(i++, regObject.getExcelRow());
                cs.setLong(i++, regObject.getRegActId());
                cs.setString(i++, regObject.getCadastre());
                cs.setString(i++, regObject.getLocalPlace());
                cs.setString(i++, regObject.getRegulationDistrict());
                cs.setString(i++, regObject.getUpi());
                cs.setString(i++, regObject.getPlanRegion());
                cs.setString(i++, regObject.getPlanNumber());
                cs.setString(i++, regObject.getKvsTerritory());
                cs.setString(i++, regObject.getKvsNumber());
                cs.setString(i++, regObject.getTerritoryType());
                cs.setString(i++, regObject.getProtectedTerritory());
                cs.setString(i++, regObject.getDescription());
                cs.setLong(i++, regObject.getAddressId());
                cs.setBoolean(i++, true);
                cs.execute();
                c.commit();

                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        id = rs.getLong("id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: saveRegObjectToDB - error", logId, e);
            logWarningMessage(logId, work,
                    "Възникна грешка при записването на Обект към Акт с Номер: " + regAct.getActNum() + e.getMessage());
        } finally {
            log.info("{}: saveRegObjectToDB - finished", logId);
        }
        return id;
    }

    /**
     * Save contesting document to db.
     *
     * @param logId
     * @param work
     * @param regContDocument
     * @return Long
     * @throws Exception
     */
    public Long saveRegContDocToDB(String logId, WorkBean work, RegContDocument regContDocument, RegAct regAct) throws Exception {
        log.info("{}: saveRegContDocToDB - started", logId);
        log.trace("{}: regContDocument: {}", logId, regContDocument);
        Long id = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(SAVE_REG_CONT_DOC_TO_DB)) {
                int i = 1;
                cs.setLong(i++, regContDocument.getImpId());
                cs.setInt(i++, regContDocument.getExcelRow());
                cs.setLong(i++, regContDocument.getRegActId());
                cs.setLong(i++, regContDocument.getDocumentId());
                cs.setString(i++, regContDocument.getDescription());
                cs.setBoolean(i++, true);
                cs.execute();
                c.commit();

                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        id = rs.getLong("id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: saveRegContDocToDB - error", logId, e);
            logWarningMessage(logId, work,
                    "ъзникна грешка при записването на Оспорване към Акт с Номер: " + regAct.getActNum() + e.getMessage());
        } finally {
            log.info("{}: saveRegContDocToDB - finished", logId);
        }
        return id;
    }

    /**
     * Save customer to db.
     *
     * @param logId
     * @param work
     * @param customer
     * @return Long
     * @throws Exception
     */
    public Long saveCustomerToDB(String logId, WorkBean work, Customer customer, RegAct regAct) throws Exception {
        log.info("{}: saveCustomerToDB - started", logId);
        log.trace("{}: customer: {}", logId, customer);
        Long id = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(SAVE_CUSTOMER_TO_DB)) {
                int i = 1;
                cs.setLong(i++, customer.getImpId());
                cs.setInt(i++, customer.getExcelRow());
                cs.setLong(i++, customer.getRegActId());
                cs.setString(i++, customer.getIdentifierType());
                cs.setString(i++, customer.getIdentifier());
                cs.setString(i++, customer.getCustomerType());
                cs.setString(i++, customer.getUnitName());
                cs.setString(i++, customer.getFirstName());
                cs.setString(i++, customer.getMiddleName());
                cs.setString(i++, customer.getLastName());
                cs.setString(i++, customer.getEmail());
                cs.setString(i++, customer.getPhone());
                cs.setString(i++, customer.getCapacity());
                cs.setObject(i++, customer.getAddressId(), Types.BIGINT);
                cs.setBoolean(i++, true);
                cs.execute();
                c.commit();

                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        id = rs.getLong("id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: saveCustomerToDB - error", logId, e);
            logWarningMessage(logId, work,
                    "Възникна грешка при записването на ЗаявителВъзложител към Акт с Номер: " + regAct.getActNum() + e.getMessage());
        } finally {
            log.info("{}: saveCustomerToDB - finished", logId);
        }
        return id;
    }

    /**
     * Save address to db.
     *
     * @param logId
     * @param work
     * @param address
     * @return Long
     * @throws Exception
     */
    public Long saveAddressToDB(String logId, WorkBean work, Address address, RegAct regAct) throws Exception {
        log.info("{}: saveAddressToDB - started", logId);
        log.trace("{}: address: {}", logId, address);
        Long id = null;
        try (Connection c = getConnection()) {
            final int start = 0;
            final int districtEnd = 3;
            final int end = 5;
            final int regionEnd = 8;

            try (CallableStatement cs = c.prepareCall(SAVE_ADDRESS_TO_DB)) {
                int i = 1;
                cs.setLong(i++, address.getImportId());
                cs.setInt(i++, address.getExcelRow());
                cs.setString(i++,
                        (address.getCountry() != null)
                                ? address.getCountry().split("\\s+")[0]
                                : null);
                cs.setString(i++,
                        (address.getDistrict() != null) ? address.getDistrict().substring(start, districtEnd) :
                                null);
                cs.setString(i++,
                        (address.getMunicipality() != null) ? address.getMunicipality().substring(start, end) :
                                null);
                cs.setString(i++,
                        address.getSettlement() != null ? address.getSettlement().substring(start, end) : null);
                cs.setString(i++, address.getVillage() != null ? address.getVillage().substring(start, end) : null);
                cs.setString(i++, address.getRegion() != null ? address.getRegion().substring(start, regionEnd) : null);
                cs.setString(i++, address.getAddrPlaceName());
                cs.setString(i++, address.getSquareName());
                cs.setString(i++, address.getSquareNum());
                cs.setString(i++, address.getQuarter());
                cs.setString(i++, address.getFlatNumber());
                cs.setString(i++, address.getStreetName());
                cs.setString(i++, address.getStreetNum());
                cs.setString(i++, address.getAppComplexName());
                cs.setString(i++, address.getAppComplexNum());
                cs.setString(i++, address.getOtherluname());
                cs.setString(i++, address.getOtherlunum());
                cs.setString(i++, address.getFlatEntrance());
                cs.setString(i++, address.getFloor());
                cs.setString(i++, address.getApartment());
                cs.setBoolean(i++, true);
                cs.execute();
                c.commit();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        id = rs.getLong("id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: saveAddressToDB - error", logId, e);
            logWarningMessage(logId, work,
                    "Възникна грешка при записването на Адрес към Акт с Номер: " + regAct.getActNum() + e.getMessage());
        } finally {
            log.info("{}: saveAddressToDB - finished", logId);
        }
        return id;
    }

    /**
     * Save reg act document one to db.
     *
     * @param logId
     * @param work
     * @param regActGdprDocument
     * @throws Exception
     */
    public void saveRegActDocOneToDb(String logId, WorkBean work, RegActGdprDocument regActGdprDocument, RegAct regAct) throws Exception {
        log.info("{}: saveRegActDocOneToDb - started", logId);
        log.trace("{}: regActDocumentOne: {}", logId, regActGdprDocument);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(SAVE_REG_ACT_DOC_ONE_TO_DB)) {
                int i = 1;
                cs.setLong(i++, regActGdprDocument.getImpId());
                cs.setInt(i++, regActGdprDocument.getExcelRow());
                cs.setLong(i++, regActGdprDocument.getRegActId());
                cs.setLong(i++, regActGdprDocument.getDocumentId());
                cs.setBoolean(i++, true);
                cs.execute();
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: saveRegActDocOneToDb - error", logId, e);
            logWarningMessage(logId, work,
                    "Възникна грешка при записването на Документ 1 към Акт с Номер: " + regAct.getActNum() + e.getMessage());
        } finally {
            log.info("{}: saveRegActDocOneToDb - finished", logId);
        }
    }

    /**
     * Save reg act document two to db.
     *
     * @param logId
     * @param work
     * @param regActFullDocument
     * @throws Exception
     */
    public void saveRegActDocTwoToDb(String logId, WorkBean work, RegActFullDocument regActFullDocument, RegAct regAct) throws Exception {
        log.info("{}: saveRegActDocTwoToDb - started", logId);
        log.trace("{}: regActFullDocument: {}", logId, regActFullDocument);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(SAVE_REG_ACT_DOC_TWO_TO_DB)) {
                int i = 1;
                cs.setLong(i++, regActFullDocument.getImpId());
                cs.setInt(i++, regActFullDocument.getExcelRow());
                cs.setLong(i++, regActFullDocument.getRegActId());
                cs.setLong(i++, regActFullDocument.getDocumentId());
                cs.setBoolean(i++, true);
                cs.execute();
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: saveRegActDocTwoToDb - error", logId, e);
            logWarningMessage(logId, work,
                    "Възникна грешка при записването на Документ 2 към Акт с Номер: " + regAct.getActNum() + e.getMessage());
        } finally {
            log.info("{}: saveRegActDocTwoToDb - finished", logId);
        }
    }

    /**
     * Save document to db.
     *
     * @param logId
     * @param work
     * @param document
     * @return Long
     * @throws Exception
     */
    public Long saveDocumentToDB(String logId, WorkBean work, Document document) throws Exception {
        log.info("{}: saveDocumentToDB - started", logId);
        log.trace("{}: document: {}", logId, document);
        Long id = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(SAVE_DOCUMENT_TO_DB)) {
                int i = 1;
                cs.setLong(i++, document.getImpId());
                cs.setString(i++, document.getFileName());
                cs.setString(i++, document.getMimeType());
                cs.setLong(i++, document.getFileSize());
                cs.setString(i++, document.getSha256());
                cs.setString(i++, document.getUrl());
                cs.execute();
                c.commit();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        id = rs.getLong("id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: saveDocumentToDB - error", logId, e);
            logWarningMessage(logId, work,
                    "" + e.getMessage()); //todo навсякъде да се махне съобщението за грешка
        } finally {
            log.info("{}: saveDocumentToDB - finished", logId);
        }
        return id;
    }

    /**
     * Save application one document to db.
     *
     * @param logId
     * @param work
     * @param regAppOneDocument
     * @return Long
     * @throws Exception
     */
    public Long saveRegAppOneDocToDB(String logId, WorkBean work, RegAppOneDocument regAppOneDocument, RegAct regAct)
            throws Exception {
        log.info("{}: saveRegAppOneDocToDB - started", logId);
        log.trace("{}: regContDocument: {}", logId, regAppOneDocument);
        Long id = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(SAVE_REG_APP_ONE_TO_DB)) {
                int i = 1;
                cs.setLong(i++, regAppOneDocument.getImpId());
                cs.setInt(i++, regAppOneDocument.getExcelRow());
                cs.setLong(i++, regAppOneDocument.getRegActId());
                cs.setLong(i++, regAppOneDocument.getDocumentId());
                cs.setString(i++, regAppOneDocument.getType());
                cs.setString(i++, regAppOneDocument.getSubType());
                cs.setBoolean(i++, true);
                cs.execute();
                c.commit();

                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        id = rs.getLong("id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: saveRegAppOneDocToDB - error", logId, e);
            logWarningMessage(logId, work,
                    "Възникна грешка при записването на Приложение 1 към Акт с Номер: " + regAct.getActNum() + e.getMessage());
        } finally {
            log.info("{}: saveRegAppOneDocToDB - finished", logId);
        }
        return id;
    }

    /**
     * Save application two document to db.
     *
     * @param logId
     * @param work
     * @param regAppTwoDocument
     * @return Long
     * @throws Exception
     */
    public Long saveRegAppTwoDocToDB(String logId, WorkBean work, RegAppTwoDocument regAppTwoDocument, RegAct regAct)
            throws Exception {
        log.info("{}: saveRegAppTwoDocToDB - started", logId);
        log.trace("{}: regContDocument: {}", logId, regAppTwoDocument);
        Long id = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(SAVE_REG_APP_TWO_TO_DB)) {
                int i = 1;
                cs.setLong(i++, regAppTwoDocument.getImpId());
                cs.setInt(i++, regAppTwoDocument.getExcelRow());
                cs.setLong(i++, regAppTwoDocument.getRegActId());
                cs.setLong(i++, regAppTwoDocument.getDocumentId());
                cs.setString(i++, regAppTwoDocument.getType());
                cs.setString(i++, regAppTwoDocument.getSubType());
                cs.setBoolean(i++, true);
                cs.execute();
                c.commit();

                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        id = rs.getLong("id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: saveRegAppTwoDocToDB - error", logId, e);
            logWarningMessage(logId, work,
                    "Възникна грешка при записването на Приложение 2 към Акт с Номер: " + regAct.getActNum() + e.getMessage());
        } finally {
            log.info("{}: saveRegAppTwoDocToDB - finished", logId);
        }
        return id;
    }

    /**
     * Retrieves location details (settlement, municipality, province, and region)
     * based on the provided input parameters.
     *
     * @param logId
     * @param region
     * @param settlement
     * @param municipality
     * @param district
     * @return Map<String, String>
     * @throws Exception
     */
    public Map<String, String> getLocationDetails(
            String logId, String region, String settlement, String municipality, String district) throws Exception {

        log.info("{}: getLocationDetails - started", logId);
        Map<String, String> result = new HashMap<>();

        String[] params = {
                region, region, settlement,
                region, settlement, municipality,
                region, settlement, municipality, district,
                region,  // Region
                region, region, settlement, settlement, municipality, municipality, district, district
        };

        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_LOCATION)) {

                for (int i = 0; i < params.length; i++) {
                    cs.setString(i + 1, params[i]); // Index starts at 1
                }

                cs.execute();
                c.commit();

                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        result.put("settlement", rs.getString("settlement"));
                        result.put("municipality", rs.getString("municipality"));
                        result.put("province", rs.getString("province"));
                        result.put("region", rs.getString("region"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getLocationDetails - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getLocationDetails - finished", logId);
        }

        return result;
    }

    /**
     * Retrieves location details (settlement, municipality, province, and region)
     * based on the provided input parameters.
     *
     * @param logId
     * @return Map<String, String>
     * @throws Exception
     */
    public Map<String, String> getAllActTypes(
            String logId) throws Exception {
        log.info("{}: getAllActTypes - started", logId);
        Map<String, String> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REG_ACT_TYPES)) {
                cs.execute();
                c.commit();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put("code", rs.getString("description"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAllActTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAllActTypes - finished", logId);
        }

        return result;
    }
}
