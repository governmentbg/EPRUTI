package com.eprut.xml.worker.cases;

import com.eprut.db.beans.Address;
import com.eprut.db.beans.Customer;
import com.eprut.db.beans.Document;
import com.eprut.db.beans.RegAct;
import com.eprut.db.beans.RegActFullDocument;
import com.eprut.db.beans.RegActGdprDocument;
import com.eprut.db.beans.RegAppOneDocument;
import com.eprut.db.beans.RegAppTwoDocument;
import com.eprut.db.beans.RegContDocument;
import com.eprut.db.beans.RegObject;
import com.eprut.db.impl.DatabaseManager;
import com.eprut.db.impl.WorkBean;
import com.eprut.grpc.DocServerManager;
import com.eprut.grpc.beans.FileUploadMetaInfo;
import com.eprut.xml.db.XmlExtractDb;
import com.tlogica.eprut.common_types.Annex1Type;
import com.tlogica.eprut.common_types.Annex2Type;
import com.tlogica.eprut.common_types.Annex3Type;
import com.tlogica.eprut.common_types.ApplicantType;
import com.tlogica.eprut.common_types.AttachedDocument;
import com.tlogica.eprut.common_types.ObjectType;
import com.tlogica.eprut.reg_05.ActType;
import lombok.extern.slf4j.Slf4j;
import org.apache.tika.Tika;

import javax.xml.datatype.XMLGregorianCalendar;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;

@Slf4j
public class Register05 {

    private static final String REGION = "region";
    private static final String SETTLEMENT = "settlement";
    private static final String MUNICIPALITY = "municipality";
    private static final String PROVINCE = "province";

    /**
     * @param logId
     * @param work
     * @param importData
     * @throws Exception
     */
    public static void transfer(String logId, WorkBean work, List<ActType> importData, XmlExtractDb database, Map<String, String> actTypes, DocServerManager docServerManager) throws Exception {
        log.info("{}: transfer - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: importData: {}", logId, importData);
        try {
            for (ActType actType : importData) {
                RegAct regAct = fillRegAct(logId, work, actType);
                Long regActId = database.saveRegActToDB(logId, work, regAct, actTypes);

                if (actType.getDoc01() != null) {
                    RegActFullDocument regActFullDocument = new RegActFullDocument();
                    regActFullDocument.setImpId(Long.valueOf(String.valueOf(work.getId())));
                    regActFullDocument.setRegActId(regActId);

                    Document document = fillDocument(logId, work, actType.getDoc01(), database, docServerManager);

                    Long documentId = database.saveDocumentToDB(logId, work, document);

                    regActFullDocument.setDocumentId(documentId);

                    database.saveRegActDocTwoToDb(logId, work, regActFullDocument, regAct);
                }

                if (actType.getDoc02() != null) {
                    RegActGdprDocument regActGdprDocument = new RegActGdprDocument();
                    regActGdprDocument.setImpId(Long.valueOf(String.valueOf(work.getId())));
                    regActGdprDocument.setRegActId(regActId);

                    Document document = fillDocument(logId, work, actType.getDoc01(), database, docServerManager);

                    Long documentId = database.saveDocumentToDB(logId, work, document);

                    regActGdprDocument.setDocumentId(documentId);

                    database.saveRegActDocOneToDb(logId, work, regActGdprDocument, regAct);
                }

                if (actType.getObjects() != null) {
                    for (ObjectType object : actType.getObjects().getObject()) {
                        Long addressId = null;

                        if (object.getAddress() != null) {
                            Address address = fillObjectAddress(logId, work, object, database);
                            addressId = database.saveAddressToDB(logId, work, address, regAct);
                        }

                        RegObject obj = fillRegObject(logId, work, object, actType, regActId);
                        obj.setAddressId(addressId);

                        database.saveRegObjectToDB(logId, work, obj, regAct);
                    }
                }

                if (actType.getApplicants() != null) {
                    for (ApplicantType applicantType : actType.getApplicants().getApplicant()) {
                        Long addressId = null;

                        if (applicantType.getAddress() != null) {
                            Address address = fillCustomerAddress(logId, work, applicantType, database);
                            addressId = database.saveAddressToDB(logId, work, address, regAct);
                        }
                        Customer customer = fillCustomer(logId, work, applicantType, regActId);
                        customer.setAddressId(addressId);

                        database.saveCustomerToDB(logId, work, customer, regAct);
                    }
                }

                if (actType.getAnnex3() != null) {
                    for (Annex3Type annex3 : actType.getAnnex3().getFile()) {
                        //reg_cont
                        RegContDocument regContDocument = new RegContDocument();
                        regContDocument.setImpId(Long.valueOf(String.valueOf(work.getId())));
                        regContDocument.setRegActId(regActId);
                        regContDocument.setDescription(annex3.getContestDescription());

                        com.eprut.db.beans.Document document = fillDocument(logId, work, annex3, database, docServerManager);

                        Long documentId = database.saveDocumentToDB(logId, work, document);

                        regContDocument.setDocumentId(documentId);

                        database.saveRegContDocToDB(logId, work, regContDocument, regAct);
                    }
                }

                if (actType.getAnnex1() != null) {
                    for (Annex1Type annex1 : actType.getAnnex1().getFile()) {
                        //reg_app1
                        RegAppOneDocument regAppOneDocument = new RegAppOneDocument();
                        regAppOneDocument.setImpId(Long.valueOf(String.valueOf(work.getId())));
                        regAppOneDocument.setRegActId(regActId);
                        regAppOneDocument.setType(annex1.getType());
                        regAppOneDocument.setSubType(annex1.getSubType());

                        com.eprut.db.beans.Document document = fillDocument(logId, work, annex1, database, docServerManager);

                        Long documentId = database.saveDocumentToDB(logId, work, document);

                        regAppOneDocument.setDocumentId(documentId);
                        database.saveRegAppOneDocToDB(logId, work, regAppOneDocument, regAct);
                    }
                }

                if (actType.getAnnex2() != null) {
                    for (Annex2Type annex2 : actType.getAnnex2().getFile()) {
                        //reg_app2
                        RegAppTwoDocument regAppTwoDocument = new RegAppTwoDocument();
                        regAppTwoDocument.setImpId(Long.valueOf(String.valueOf(work.getId())));
                        regAppTwoDocument.setRegActId(regActId);
                        regAppTwoDocument.setType(annex2.getType());
                        regAppTwoDocument.setSubType(annex2.getSubType());

                        com.eprut.db.beans.Document document = fillDocument(logId, work, annex2, database, docServerManager);

                        Long documentId = database.saveDocumentToDB(logId, work, document);

                        regAppTwoDocument.setDocumentId(documentId);

                        database.saveRegAppTwoDocToDB(logId, work, regAppTwoDocument, regAct);
                    }
                }
            }

        } catch (Exception e) {
            log.error("{}: transfer - error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: transfer - finished", logId);
        }
    }


    private static RegAct fillRegAct(String logId, WorkBean work, ActType actType) throws Exception {
        log.info("{}: fillRegAct - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: actType: {}", logId, actType);

        try {
            RegAct regAct = new RegAct();
            regAct.setImpId(Long.valueOf(String.valueOf(work.getId())));
            regAct.setActType(actType.getAdministrativeActType());
            regAct.setActNum(actType.getAdministrativeActNumber());
            regAct.setActDate(xmlGregorianToLocalDateTime(actType.getAdministrativeActDate()));
            regAct.setMessageDate(xmlGregorianToLocalDateTime(actType.getAnnouncementDate()));
            regAct.setMessageType(actType.getAnnouncementType());
            regAct.setIssuedDate(xmlGregorianToLocalDateTime(actType.getValidFromDate()));
            regAct.setStatus(actType.getStatus());
            regAct.setChangeDate(xmlGregorianToLocalDateTime(actType.getChangeDate()));
            regAct.setValidityDate(xmlGregorianToLocalDateTime(actType.getValidToDate()));
            regAct.setFactReason(actType.getFactGrounds());
            regAct.setLegalReason(actType.getLegalGrounds());
            regAct.setAdministration(actType.getPublisher().getAdministration());
            regAct.setAdministrativeUnit(actType.getPublisher().getAdministrationAuthority());
            regAct.setAdmPopular(actType.getPublisher().getEkatte());
            regAct.setObjectIdentification(actType.getObjectIdentification());
            regAct.setIsValid(true);

            return regAct;
        } catch (Exception e) {
            log.error("{}: v - error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: fillRegAct - finished", logId);
        }
    }

    private static RegObject fillRegObject(String logId, WorkBean work, ObjectType object, ActType actType, Long regActId) throws Exception {
        log.info("{}: fillRegObject - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: object: {}", logId, object);
        log.trace("{}: actType: {}", logId, actType);
        log.trace("{}: regActId: {}", logId, regActId);

        try {
            RegObject obj = new RegObject();
            obj.setRegActId(regActId);
            obj.setImpId(Long.valueOf(String.valueOf(work.getId())));
            obj.setNumAct(actType.getAdministrativeActNumber());
            obj.setCadastre(object.getCadastre());
            obj.setLocalPlace(object.getLocalPlace());
            obj.setRegulationDistrict(object.getRegulationDistrict());
            obj.setUpi(object.getUpi());
            obj.setPlanRegion(object.getPlanRegion());
            obj.setPlanNumber(object.getPlanNumber());
            obj.setKvsTerritory(object.getKvsTerritory());
            obj.setKvsNumber(object.getKvsNumber());
            obj.setTerritoryType(object.getTerritoryType());
            obj.setProtectedTerritory(object.getProtectedTerritory());
            obj.setDescription(object.getDescription());
            obj.setIsValid(true);

            return obj;

        } catch (Exception e) {
            log.error("{}: fillRegObject - error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: fillRegObject - finished", logId);
        }
    }

    private static Address fillObjectAddress(String logId, WorkBean work, ObjectType object, XmlExtractDb database) throws Exception {
        log.info("{}: fillObjectAddress - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: object: {}", logId, object);

        try {
            Address address = new Address();
            address.setImportId(Long.valueOf(String.valueOf(work.getId())));
            Map<String, String> location =
                    database.getLocationDetails(logId, object.getAddress().getRegion(), object.getAddress().getSettelment(), object.getAddress().getMunicipality(), object.getAddress().getDistrict());

            address.setRegion(location.get(REGION));
            address.setSettlement(location.get(SETTLEMENT));
            address.setMunicipality(location.get(MUNICIPALITY));
            address.setDistrict(location.get(PROVINCE));

            address.setFloor(object.getAddress().getFloor());
            address.setFlatEntrance(object.getAddress().getFlatEntrance());
            address.setApartment(object.getAddress().getApartment());
            address.setSquareName(object.getAddress().getSquareName());
            address.setSquareNum(object.getAddress().getSquareNum());
            address.setAppComplexName(object.getAddress().getAppComplexName());
            address.setAppComplexNum(object.getAddress().getAppComplexNum());
            address.setQuarter(object.getAddress().getQuarter());
            address.setStreetName(object.getAddress().getStreetName());
            address.setStreetNum(object.getAddress().getStreetNum());
            address.setFlatNumber(object.getAddress().getFlatNumber());
            address.setOtherluname(object.getAddress().getOtherluname());
            address.setOtherlunum(object.getAddress().getOtherlunum());
            address.setIsValid(true);

            return address;
        } catch (Exception e) {
            log.error("{}: fillObjectAddress - error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: fillObjectAddress - finished", logId);
        }
    }

    private static Address fillCustomerAddress(String logId, WorkBean work, ApplicantType customer, XmlExtractDb database) throws Exception {
        log.info("{}: fillCustomerAddress - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: customer: {}", logId, customer);

        try {
            Address address = new Address();
            address.setImportId(Long.valueOf(String.valueOf(work.getId())));

            Map<String, String> location = database.getLocationDetails(logId, customer.getAddress().getRegion(), customer.getAddress().getSettelment(), customer.getAddress().getMunicipality(),
                    customer.getAddress().getDistrict());

            address.setRegion(location.get(REGION));
            address.setSettlement(location.get(SETTLEMENT));
            address.setMunicipality(location.get(MUNICIPALITY));
            address.setDistrict(location.get(PROVINCE));
            address.setCountry(customer.getAddress().getCountry());
            address.setFloor(customer.getAddress().getFloor());
            address.setFlatEntrance(customer.getAddress().getFlatEntrance());
            address.setApartment(customer.getAddress().getApartment());
            address.setSquareName(customer.getAddress().getSquareName());
            address.setSquareNum(customer.getAddress().getSquareNum());
            address.setAppComplexName(customer.getAddress().getAppComplexName());
            address.setAppComplexNum(customer.getAddress().getAppComplexNum());
            address.setQuarter(customer.getAddress().getQuarter());
            address.setStreetName(customer.getAddress().getStreetName());
            address.setStreetNum(customer.getAddress().getStreetNum());
            address.setFlatNumber(customer.getAddress().getFlatNumber());
            address.setOtherluname(customer.getAddress().getOtherluname());
            address.setOtherlunum(customer.getAddress().getOtherlunum());
            address.setIsValid(true);

            return address;
        } catch (Exception e) {
            log.error("{}: fillCustomerAddress - error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: fillCustomerAddress - finished", logId);
        }
    }

    private static Customer fillCustomer(String logId, WorkBean work, ApplicantType applicantType, Long regActId) throws Exception {
        log.info("{}: fillCustomer - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: applicantType: {}", logId, applicantType);
        log.trace("{}: regActId: {}", logId, regActId);

        try {
            Customer customer = new Customer();
            customer.setImpId(Long.valueOf(String.valueOf(work.getId())));
            customer.setRegActId(regActId);
            if (applicantType.getEntity().getLegalEntity() != null) {
                customer.setIdentifierType(applicantType.getEntity().getLegalEntity().getIdentifierType());
                customer.setIdentifier(applicantType.getEntity().getLegalEntity().getIdentifier());
                customer.setCustomerType(applicantType.getEntity().getLegalEntity().getCustomerType());
                customer.setUnitName(applicantType.getEntity().getLegalEntity().getUnitName());
            } else if (applicantType.getEntity().getPhysicalEntity() != null) {
                customer.setIdentifierType(applicantType.getEntity().getPhysicalEntity().getIdentifierType());
                customer.setIdentifier(applicantType.getEntity().getPhysicalEntity().getIdentifier());
                customer.setCustomerType(applicantType.getEntity().getPhysicalEntity().getCustomerType());
                customer.setFirstName(applicantType.getEntity().getPhysicalEntity().getFirstName());
                customer.setMiddleName(applicantType.getEntity().getPhysicalEntity().getMiddleName());
                customer.setLastName(applicantType.getEntity().getPhysicalEntity().getLastName());
            } else if (applicantType.getEntity().getOtherEntity() != null) {
                customer.setIdentifierType(applicantType.getEntity().getOtherEntity().getIdentifierType());
                customer.setCustomerType(applicantType.getEntity().getOtherEntity().getCustomerType());
            }

            customer.setEmail(applicantType.getEntity().getEmail());
            customer.setPhone(applicantType.getEntity().getPhone());
            customer.setIsValid(true);

            return customer;

        } catch (Exception e) {
            log.error("{}: fillCustomer - error: {}", logId, e.getMessage(), e);
            throw e;
        } finally {
            log.info("{}: fillCustomer - finished", logId);
        }
    }

    private static com.eprut.db.beans.Document fillDocument(String logId, WorkBean work, AttachedDocument attachedDocument, DatabaseManager database, DocServerManager docServerManager)
            throws Exception {
        log.info("{}: fillDocument - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: attachedDocument: {}", logId, attachedDocument);

        File file = generateTempFile(attachedDocument.getFile(), attachedDocument.getFilename());

        com.eprut.db.beans.Document document = new com.eprut.db.beans.Document();
        document.setImpId(work.getId().longValue());
        document.setFileName(attachedDocument.getFilename());
        document.setFileSize(file.length());

        Tika tika = new Tika();
        String mimeType = tika.detect(new ByteArrayInputStream(attachedDocument.getFile()));
        document.setMimeType(mimeType);

        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        digest.update(attachedDocument.getFile());
        String sha256 = HexFormat.of().formatHex(digest.digest());
        document.setSha256(sha256);

        if (!document.getSha256().equals(attachedDocument.getSha256Checksum()) || !document.getMimeType().equals(attachedDocument.getMimeType())) {
            log.info("Invalid SHA256 or MimeType");
            database.logInfoMessage(logId, work, "Невалидно SHA256 или MimeType");
            database.error(logId, work);
        }

        InputStream inputStream = new ByteArrayInputStream(attachedDocument.getFile());

        FileUploadMetaInfo fileUploadMetaInfo = new FileUploadMetaInfo(attachedDocument.getFilename(), file.length());

        String path = docServerManager.uploadFile(logId, inputStream, fileUploadMetaInfo, InetAddress.getLocalHost().getHostAddress(),  work.getUserId(),
                    work.getRoles(), "");

        document.setUrl(path);

        return document;
    }

    private static File generateTempFile(byte[] fileBytes, String fileName) throws IOException {
        File tempFile = File.createTempFile(fileName, null);

        try (FileOutputStream fos = new FileOutputStream(tempFile)) {
            fos.write(fileBytes);
        }

        return tempFile;
    }

    private static LocalDateTime xmlGregorianToLocalDateTime(XMLGregorianCalendar xmlGregorianCalendar) {
        if (xmlGregorianCalendar == null) {
            return null;
        }

        return xmlGregorianCalendar.toGregorianCalendar()
                .toZonedDateTime()
                .withZoneSameInstant(ZoneId.systemDefault())
                .toLocalDateTime();
    }
}
