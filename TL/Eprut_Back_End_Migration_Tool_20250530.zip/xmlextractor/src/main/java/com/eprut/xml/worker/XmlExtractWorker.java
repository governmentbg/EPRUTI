package com.eprut.xml.worker;

import com.eprut.db.impl.WorkBean;
import com.eprut.grpc.DocServerManager;
import com.eprut.xml.db.XmlExtractDb;
import com.eprut.xml.worker.cases.Register01;
import com.eprut.xml.worker.cases.Register02;
import com.eprut.xml.worker.cases.Register03;
import com.eprut.xml.worker.cases.Register04;
import com.eprut.xml.worker.cases.Register05;
import com.eprut.xml.worker.cases.Register06;
import com.eprut.xml.worker.cases.Register07;
import com.eprut.xml.worker.cases.Register08;
import com.eprut.xml.worker.cases.Register09;
import com.eprut.xml.worker.cases.Register10;
import com.eprut.xml.worker.cases.Register11;
import com.eprut.xml.worker.cases.Register12;
import com.eprut.xml.worker.cases.Register13;
import com.eprut.xml.worker.cases.Register14;
import com.eprut.xml.worker.cases.Register15;
import com.eprut.xml.worker.cases.Register16;
import com.tlogica.eprut.full.ImportData;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Unmarshaller;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import tl.abstractWorkers.AbstractQueueWorker;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Slf4j
public class XmlExtractWorker extends AbstractQueueWorker<WorkBean> {

    private XmlExtractDb database;
    private Map<String, String> xsdCodes = new HashMap<>();
    private static final String COMMON_TYPES = "schemas/common-types.xsd";
    private static final String XSD_PATH = "schemas/full.xsd";
    private static final String CONTEXT_PATH = "com.tlogica.eprut.full";
    private static final String REGION = "region";
    private static final String SETTLEMENT = "settlement";
    private static final String MUNICIPALITY = "municipality";
    private static final String PROVINCE = "province";
    private Map<String, String> actTypes = new HashMap<>();
    private DocServerManager docServerManager; //todo set properties
    private static final int BEGIN_INDEX = 4;


    /**
     * Initialize abstract que with some number of threads and delays.
     *
     * @param nThreads             number of treads
     * @param initialDelay         delay in see {@link  TimeUnit}.
     * @param periodOfQueueRefresh refresh period in see {@link  TimeUnit}.
     * @param timeUnit             time unit.
     */
    public XmlExtractWorker(int nThreads, Long initialDelay, Long periodOfQueueRefresh,
                            TimeUnit timeUnit, XmlExtractDb database, DocServerManager docServerManager) {
        super(nThreads, initialDelay, periodOfQueueRefresh, timeUnit);
        this.database = database;
        this.docServerManager = docServerManager;
    }

    @Override
    protected void updateWorkerQueue() {
        String logId = UUID.randomUUID().toString();
        try {
            database.getReadyToStart(logId).stream().distinct().filter(e -> !queue.contains(e)).forEach(queue::addLast);
        } catch (Exception e) {
            log.error("{}: updateWorkerQueue error", logId, e);
        }
    }

    @Override
    protected void workerExecutedMethod(String logId, WorkBean firstElementFromQueue) {
        boolean doWork = true;
        try {
            if (database.checkIfNotStarted(logId, firstElementFromQueue)) {
                try {
                    database.start(logId, firstElementFromQueue);
                } catch (Exception e) {
                    if (database.checkIfNotStarted(logId, firstElementFromQueue)) {
                        throw e;
                    } else {
                        doWork = false;
                    }
                }
                if (doWork) {
                    String archiveUrl = database.getZipArchivePath(logId, firstElementFromQueue);

                    if (archiveUrl == null) {
                        database.logErrorMessage(logId, firstElementFromQueue,
                                "Възникна грешка при намирането на път към архив.");
                        throw new IllegalStateException(
                                "Archive path is null for import with id: " + firstElementFromQueue.getId());
                    }

//                    File archive = docServerManager.downloadFile(logId, archiveUrl, InetAddress.getLocalHost().getHostAddress(),
//                            firstElementFromQueue.getUserId(), firstElementFromQueue.getRoles(), "");
//                    String archivePath = archive.getAbsolutePath();
                    //String archivePath = database.getZipArchivePath(logId, firstElementFromQueue);

                    File archive = new File(archiveUrl);

                    if (!archive.exists()) {
                        database.logErrorMessage(logId, firstElementFromQueue,
                                "Възникна грешка при намирането на архив.");
                        throw new FileNotFoundException("Archive path doesn't exists for import with id: " + firstElementFromQueue.getId());
                    }

                    //File archiveFile = new File(archivePath);
                    Document xml = extractXmlFile(logId, firstElementFromQueue, archive);

                    String regNumber = null;

                    Element root = xml.getDocumentElement();
                    NodeList children = root.getChildNodes();

                    for (int i = 0; i < children.getLength(); i++) {
                        Node node = children.item(i);
                        if (node.getNodeType() == Node.ELEMENT_NODE) {
                            Element element = (Element) node;
                            String localName = element.getLocalName();

                            if (localName != null && localName.startsWith("reg_")) {
                                regNumber = localName.substring(BEGIN_INDEX);
                                System.out.println("Detected REG number: " + regNumber);
                                break; // Found the first reg element, stop here
                            }
                        }
                    }

                    String importCode = database.getRegisterCodeFromImport(logId, firstElementFromQueue);
                    if (regNumber != null && !regNumber.equals(importCode)) {
                        throw new IllegalStateException("XML не е за този регистър");
                    }

                    try {

                        File xsdFile = new File(Objects.requireNonNull(getClass().getClassLoader().getResource(XSD_PATH)).getFile());
                        File commonXsdFile = new File(Objects.requireNonNull(getClass().getClassLoader().getResource(COMMON_TYPES)).getFile());

                        if (!xsdFile.isFile()) {
                            System.out.println("XSD file not found in classpath!");
                            return;
                        }

                        SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

                        Schema schema = schemaFactory.newSchema(new Source[] {
                                new StreamSource(xsdFile),
                                new StreamSource(commonXsdFile),
                        });

                        Validator validator = schema.newValidator();

                        Source source = new DOMSource(xml);

                        try {
                            validator.validate(source);
                        } catch (Exception e) {
                            log.info("XSD validation failed!");
                            database.logInfoMessage(logId, firstElementFromQueue, "Грешка при Валидация с XSD");
                            database.error(logId, firstElementFromQueue);
                            throw e;
                        }

                        database.logInfoMessage(logId, firstElementFromQueue, "Успешна Валидация с XSD");

                        database.finishedPreparing(logId, firstElementFromQueue);

                        JAXBContext context = JAXBContext.newInstance(CONTEXT_PATH);

                        Unmarshaller unmarshaller = context.createUnmarshaller();

                        unmarshaller.setSchema(schema);

                        ImportData importData = (ImportData) unmarshaller.unmarshal(xml);

                        actTypes = database.getAllActTypes(logId);

                        switch (importCode) {
                            case "1":
                                Register01.transfer(logId, firstElementFromQueue, importData.getReg1(), database, actTypes, docServerManager);
                                break;
                            case "2":
                                Register02.transfer(logId, firstElementFromQueue, importData.getReg2(), database, actTypes, docServerManager);
                                break;
                            case "3":
                                Register03.transfer(logId, firstElementFromQueue, importData.getReg3(), database, actTypes, docServerManager);
                                break;
                            case "4":
                                Register04.transfer(logId, firstElementFromQueue, importData.getReg4(), database, actTypes, docServerManager);
                                break;
                            case "5":
                                Register05.transfer(logId, firstElementFromQueue, importData.getReg5(), database, actTypes, docServerManager);
                                break;
                            case "6":
                                Register06.transfer(logId, firstElementFromQueue, importData.getReg6(), database, actTypes, docServerManager);
                                break;
                            case "7":
                                Register07.transfer(logId, firstElementFromQueue, importData.getReg7(), database, actTypes, docServerManager);
                                break;
                            case "8":
                                Register08.transfer(logId, firstElementFromQueue, importData.getReg8(), database, actTypes, docServerManager);
                                break;
                            case "9":
                                Register09.transfer(logId, firstElementFromQueue, importData.getReg9(), database, actTypes, docServerManager);
                                break;
                            case "10":
                                Register10.transfer(logId, firstElementFromQueue, importData.getReg10(), database, actTypes, docServerManager);
                                break;
                            case "11":
                                Register11.transfer(logId, firstElementFromQueue, importData.getReg11(), database, actTypes, docServerManager);
                                break;
                            case "12":
                                Register12.transfer(logId, firstElementFromQueue, importData.getReg12(), database, actTypes, docServerManager);
                                break;
                            case "13":
                                Register13.transfer(logId, firstElementFromQueue, importData.getReg13(), database, actTypes, docServerManager);
                                break;
                            case "14":
                                Register14.transfer(logId, firstElementFromQueue, importData.getReg14(), database, actTypes, docServerManager);
                                break;
                            case "15":
                                Register15.transfer(logId, firstElementFromQueue, importData.getReg15(), database, actTypes, docServerManager);
                                break;
                            case "16":
                                Register16.transfer(logId, firstElementFromQueue, importData.getReg16(), database, actTypes, docServerManager);
                                break;
                            default:
                                break;
                        }

                        database.finish(logId, firstElementFromQueue);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        } catch (
                Exception e) {
            try {
//                database.error(logId, firstElementFromQueue, e);
            } catch (Exception ex) {
                try {
                    database.logErrorMessage(logId, firstElementFromQueue, "Възникна грешка при опит за стартиране на оброботка.", ex);
                } catch (Exception e1) {
                    //ignore.
                }
                this.workerExceptionHandling(logId, firstElementFromQueue, ex);
            }
        }
    }

    //    }
    @Override
    protected void workerExceptionHandling(String logId, WorkBean firstElementFromQueue, Exception e) {
        log.error("{} - XmlExtractWorker with WorkBean : {} ERROR {}", logId, firstElementFromQueue, e, e);
    }

    @Override
    protected void workerStarted(String logId, WorkBean firstElementFromQueue) {
        log.debug("{} - XmlExtractWorker with WorkBean : {} has STARTED working", logId, firstElementFromQueue);
    }

    @Override
    protected void workerFinished(String logId, WorkBean firstElementFromQueue) {
        log.debug("{} - XmlExtractWorker with WorkBean : {} has FINISHED working", logId, firstElementFromQueue);
    }

    private Document extractXmlFile(String logId, WorkBean work, File archive) throws Exception {
        log.info("{}: extractXmlFile - started", logId);

        try (FileInputStream fis = new FileInputStream(archive);
             ZipArchiveInputStream zis = new ZipArchiveInputStream(fis);
             ByteArrayOutputStream xmlBuffer = new ByteArrayOutputStream()) {

            ZipArchiveEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (!entry.isDirectory() && entry.getName().endsWith(".xml")) {
                    zis.transferTo(xmlBuffer);
                    try (InputStream is = new ByteArrayInputStream(xmlBuffer.toByteArray())) {
                        return parseXml(is); // Parse XML and return as Document
                    }
                }
            }

            throw new IllegalStateException("No XML file found in the archive.");
        } finally {
            log.info("{}: extractXmlFile - finished", logId);
        }
    }

    private Document parseXml(InputStream xmlStream) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(xmlStream);
        doc.getDocumentElement().normalize();
        return doc;
    }
}
