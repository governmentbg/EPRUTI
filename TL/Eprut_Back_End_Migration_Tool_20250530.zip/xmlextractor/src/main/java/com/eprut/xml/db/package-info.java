/**
 * Project: eprut
 * Module: com.eprut.xml.db
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Логика за комуникация с базата от данни.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.xml.db;
