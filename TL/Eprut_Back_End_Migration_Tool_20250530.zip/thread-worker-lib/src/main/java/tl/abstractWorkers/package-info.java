/**
 * Project: eprut
 * Module: tl.abstractWorkers
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Мини библиотека за работа с асинхронна опашка от базата данни.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package tl.abstractWorkers;
