/**
 * Project: eprut
 * Module: com.eprut.db.impl
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Абстрактна имплементация на логика за смяна на статуси и съхранение на лог.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.db.impl;
