/**
 * Project: eprut
 * Module: com.eprut.db
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Общ модул за комуникация с базата данни. Основна функционалност е логиране на съобщения и смяна на статус на обработка.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.db;
