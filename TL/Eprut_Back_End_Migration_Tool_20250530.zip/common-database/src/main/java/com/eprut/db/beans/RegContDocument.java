package com.eprut.db.beans;

import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode(callSuper = false)
public class RegContDocument extends BaseDocument implements ILogInfo {
    @Size(max = 50, message = "Description must not exceed 50 characters.")
    public String description;                  //Текстова част на оспорване

    @Override
    public String getLabel() {
        return "Оспорване";
    }
}
