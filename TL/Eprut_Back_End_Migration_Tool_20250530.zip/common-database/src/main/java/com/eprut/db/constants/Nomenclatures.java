package com.eprut.db.constants;

import lombok.Getter;

@Getter
public enum Nomenclatures {
    ENTRY_TYPE("2"),
    OBJECT_TYPE("241"),
    OUTGOING_DOCUMENT("2"),
    STATUS_AA("29"),
    CONTESTING_STATUS("4"),
    BASE_DOCUMENT("1"),
    ATTACHED_DOCUMENT("2"),
    PROVINCE_ADMINISTRATION("4"),
    MUNICIPALITY_ADMINISTRATION("5"),
    REGION_ADMINISTRATION("6");

    private final String code;

    Nomenclatures(String code) {
        this.code = code;
    }
}
