package com.eprut.db.beans;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode(callSuper = false)
public class RegAppOneDocument extends AttachedDocument implements ILogInfo {
    @Override
    public String getLabel() {
        return "Приложение 1";
    }
}
