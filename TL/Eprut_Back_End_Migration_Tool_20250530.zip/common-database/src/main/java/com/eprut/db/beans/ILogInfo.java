package com.eprut.db.beans;

public interface ILogInfo {

    /**
     * Returns excel row.
     * @return int
     */
    int getExcelRow();

    /**
     * Returns the label of the object.
     * @return String
     */
    String getLabel();
}
