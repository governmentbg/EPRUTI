package com.eprut.db.beans;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
public class RegActFullDocument extends BaseDocument {
}
