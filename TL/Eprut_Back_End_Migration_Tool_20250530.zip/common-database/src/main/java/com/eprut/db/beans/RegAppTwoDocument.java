package com.eprut.db.beans;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
public class RegAppTwoDocument extends AttachedDocument implements ILogInfo {
    @Override
    public String getLabel() {
        return "Приложение 2";
    }
}
