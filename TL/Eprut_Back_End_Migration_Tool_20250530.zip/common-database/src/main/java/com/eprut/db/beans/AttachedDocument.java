package com.eprut.db.beans;

import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode(callSuper = false)
public class AttachedDocument extends BaseDocument {
    @Size(max = 50, message = "Type must not exceed 50 characters.")
    public String type;                         //Основна категория
    @Size(max = 50, message = "SubType must not exceed 50 characters.")
    public String subType;                      //Подкатегория
}
