/**
 * Project: eprut
 * Module: com.eprut.db.config
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Механизъм за извличане на IP адрес на машината на която работи сервиза.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.db.config;
