/**
 * Project: eprut
 * Module: com.eprut.grpc
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Интеграция с документен сървър последством gRPC.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.grpc;
