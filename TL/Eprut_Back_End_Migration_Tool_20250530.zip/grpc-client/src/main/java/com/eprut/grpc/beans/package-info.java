/**
 * Project: eprut
 * Module: com.eprut.grpc.beans
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Структури от данни за временно съхранение които ще се използват за обмен на данни.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.grpc.beans;
