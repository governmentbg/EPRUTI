package com.eprut.grpc;

import authentication.AuthenticationGrpc;
import authentication.AuthenticationOuterClass;
import com.eprut.grpc.beans.BearerToken;
import com.eprut.grpc.beans.FileUploadMetaInfo;
import com.google.common.io.Files;
import com.google.protobuf.ByteString;
import io.grpc.ChannelCredentials;
import io.grpc.Grpc;
import io.grpc.ManagedChannel;
import io.grpc.StatusException;
import io.grpc.TlsChannelCredentials;
import io.grpc.stub.BlockingClientCall;
import lombok.extern.slf4j.Slf4j;
import storage.StorageGrpc;
import storage.StorageOuterClass;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;

/**
 * Project: eprut
 * Module: com.eprut.grpc
 * File: T
 * <p>
 * Created By dbyalev on 24.2.2025 г.
 * Description:
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
@Slf4j
public class DocServerManager {


    private static final int INT_BUFF_MIN_PERIOD = 5;
    private static final String CLIENT_IDENTIFIER = "migrate_java_client";
    private final ManagedChannel channel;
    private final String username;
    private final String password;
    private String token = "not_logged";
    private String refreshToken = "not_refreshed";
    private LocalDateTime tokenValidity;
    private LocalDateTime refreshValidity;

    /**
     * @param host
     * @param port
     */
    public DocServerManager(String host, int port, String username, String password) {
        this.username = username;
        this.password = password;
        tokenValidity = LocalDateTime.MIN;
        refreshValidity = LocalDateTime.MIN;
        ChannelCredentials creds = TlsChannelCredentials.newBuilder()
                // if server's cert doesn't chain to a standard root
//                .trustManager(caFile)
//                .keyManager(clientCertFile, keyFile) // client cert
                .build();
        this.channel = Grpc.newChannelBuilderForAddress(host, port, creds).build();

    }


    /**
     * Uploads file to doc srv in blocking io fashion.
     *
     * @param file         the file to be uploaded.
     * @param ip           the ip of the original uploader
     * @param userId       the id of the user UUID
     * @param userRoleIds  user roles
     * @param userGroupIds user groups
     * @return the path to the specified file or {@code null} if request failed.
     */
    public String uploadFile(String logId, File file, String ip, String userId, String userRoleIds, String userGroupIds) {
        log.debug("{}: uploadFile; file: {}", logId, file);
        log.debug("{}: uploadFile; ip: {}", logId, ip);
        log.debug("{}: uploadFile; userId: {}", logId, userId);
        log.debug("{}: uploadFile; userRoleIds: {}", logId, userRoleIds);
        log.debug("{}: uploadFile; userGroupIds: {}", logId, userGroupIds);

        log.trace("{}: uploadFile; check login status", logId);
        checkLoginStatus(logId);


        BearerToken bt = new BearerToken(token);
        log.trace("{}: uploadFile; constructed bearer", logId);
        StorageGrpc.StorageBlockingV2Stub stub = StorageGrpc.newBlockingV2Stub(channel).withCallCredentials(bt);
        log.trace("{}: uploadFile; created stub", logId);

        final BlockingClientCall<StorageOuterClass.UploadFileRequest, StorageOuterClass.UploadFileResponse> upload = stub.upload();
        log.trace("{}: uploadFile; create upload", logId);

        log.trace("{}: uploadFile; open file for read", logId);

        File tempFile = null;
        try {
            tempFile = File.createTempFile("tmp_b64", "tompx");

            try (ByteString.Output o = ByteString.newOutput()) {
                log.trace("{}: uploadFile; encoding file to base64", logId);
//                OutputStream os = Base64.getEncoder().wrap(o);
                Files.copy(file, o);

                log.trace("{}: uploadFile; encoded file to base64", logId);

                StorageOuterClass.File fileOut = StorageOuterClass.File.newBuilder().setName(file.getName()).setLength(file.length()).setContent(o.toByteString()).build();

                log.trace("{}: uploadFile; constructed file for request", logId);

                StorageOuterClass.Request request =
                        StorageOuterClass.Request.newBuilder().setBrowser(CLIENT_IDENTIFIER).setIp(ip).setUserGroupId(userGroupIds).setUserRoleIds(userRoleIds).setUserId(userId).build();

                log.trace("{}: uploadFile; constructed metadata for request", logId);

                StorageOuterClass.UploadFileRequest ufr = StorageOuterClass.UploadFileRequest.newBuilder().setFile(fileOut).setRequest(request).build();
                log.trace("{}: uploadFile; constructed request", logId);

                log.trace("{}: uploadFile; starting to write to server", logId);
                upload.write(ufr);
                log.trace("{}: uploadFile; finished writing to server", logId);
                upload.halfClose();
                log.trace("{}: uploadFile; closed client side stream haflWay. Waiting to read response", logId);
                if (upload.hasNext()) {
                    log.trace("{}: uploadFile; reading the response", logId);
                    StorageOuterClass.UploadFileResponse response = upload.read();
                    log.trace("{}: uploadFile; completed reading the response", logId);
                    log.debug("{}: UploadFileResponse: {}", logId, response);
                    return response.getPath().getValue();
                }
            }
            log.trace("{}: uploadFile; No response returning empty response", logId);
        } catch (IOException | InterruptedException | StatusException e) {
            tempFile.delete();
            log.error("{}: Error while uploading the file: {}", logId, e.getMessage(), e);
            throw new RuntimeException(e);
        }
        return null;
    }

    /**
     * Uploads file to doc srv in blocking io fashion.
     *
     * @param logId        The id of the log.
     * @param file         the Input Stream of file to be uploaded. The method does not close or rewind the stream.
     * @param fileInfo     the meta info of the file - file name and file size
     * @param ip           the ip of the original uploader
     * @param userId       the id of the user UUID
     * @param userRoleIds  user roles
     * @param userGroupIds user groups
     * @return the path to the specified file or {@code null} if request failed.
     */
    public String uploadFile(String logId, InputStream file, FileUploadMetaInfo fileInfo, String ip, String userId, String userRoleIds, String userGroupIds) {
        log.debug("{}: uploadFile; file: {}", logId, file);
        log.debug("{}: uploadFile; ip: {}", logId, ip);
        log.debug("{}: uploadFile; userId: {}", logId, userId);
        log.debug("{}: uploadFile; userRoleIds: {}", logId, userRoleIds);
        log.debug("{}: uploadFile; userGroupIds: {}", logId, userGroupIds);

        log.trace("{}: uploadFile; check login status", logId);
        checkLoginStatus(logId);


        BearerToken bt = new BearerToken(token);
        log.trace("{}: uploadFile; constructed bearer", logId);
        StorageGrpc.StorageBlockingV2Stub stub = StorageGrpc.newBlockingV2Stub(channel).withCallCredentials(bt);
        log.trace("{}: uploadFile; created stub", logId);

        final BlockingClientCall<StorageOuterClass.UploadFileRequest, StorageOuterClass.UploadFileResponse> upload = stub.upload();
        log.trace("{}: uploadFile; create upload", logId);

        log.trace("{}: uploadFile; open file for read", logId);

        File tempFile = null;
        try {
            tempFile = File.createTempFile("tmp_b64", "tompx");

            try (ByteString.Output o = ByteString.newOutput()) {
                log.trace("{}: uploadFile; encoding file to base64", logId);
//                OutputStream os = Base64.getEncoder().wrap(o);
                file.transferTo(o);

                log.trace("{}: uploadFile; encoded file to base64", logId);

                StorageOuterClass.File fileOut = StorageOuterClass.File.newBuilder().setName(fileInfo.getFileName()).setLength(
                        fileInfo.getFileSize()).setContent(o.toByteString()).build();

                log.trace("{}: uploadFile; constructed file for request", logId);

                StorageOuterClass.Request request =
                        StorageOuterClass.Request.newBuilder().setBrowser(CLIENT_IDENTIFIER).setIp(ip).setUserGroupId(userGroupIds).setUserRoleIds(userRoleIds).setUserId(userId).build();

                log.trace("{}: uploadFile; constructed metadata for request", logId);

                StorageOuterClass.UploadFileRequest ufr = StorageOuterClass.UploadFileRequest.newBuilder().setFile(fileOut).setRequest(request).build();
                log.trace("{}: uploadFile; constructed request", logId);

                log.trace("{}: uploadFile; starting to write to server", logId);
                upload.write(ufr);
                log.trace("{}: uploadFile; finished writing to server", logId);
                upload.halfClose();
                log.trace("{}: uploadFile; closed client side stream haflWay. Waiting to read response", logId);
                if (upload.hasNext()) {
                    log.trace("{}: uploadFile; reading the response", logId);
                    StorageOuterClass.UploadFileResponse response = upload.read();
                    log.trace("{}: uploadFile; completed reading the response", logId);
                    log.debug("{}: UploadFileResponse: {}", logId, response);
                    return response.getPath().getValue();
                }
            }
            log.trace("{}: uploadFile; No response returning empty response", logId);
        } catch (IOException | InterruptedException | StatusException e) {
            tempFile.delete();
            log.error("{}: Error while uploading the file: {}", logId, e.getMessage(), e);
            throw new RuntimeException(e);
        }
        return null;
    }

    /**
     * Downloads file from doc srv in blocking io fashion.
     *
     * @param fileUrl the path of the file requested for download.
     * @return the {@code ByteBuffer) of the file or {@code null} if request failed.
     */
    public File downloadFile(String logId, String fileUrl, String ip, String userId, String userRoleIds, String userGroupIds) {
        log.debug("{}: downloadFile; fileUrl: {}", logId, fileUrl);
        log.trace("{}: downloadFile; check login status", logId);
        log.debug("{}: uploadFile; ip: {}", logId, ip);
        log.debug("{}: uploadFile; userId: {}", logId, userId);
        log.debug("{}: uploadFile; userRoleIds: {}", logId, userRoleIds);
        log.debug("{}: uploadFile; userGroupIds: {}", logId, userGroupIds);
        checkLoginStatus(logId);


        BearerToken bt = new BearerToken(token);
        log.trace("{}: downloadFile; constructed bearer", logId);
        StorageGrpc.StorageBlockingV2Stub stub = StorageGrpc.newBlockingV2Stub(channel).withCallCredentials(bt);
        log.trace("{}: downloadFile; created stub", logId);

        StorageOuterClass.Request requestMeta =
                StorageOuterClass.Request.newBuilder().setBrowser(CLIENT_IDENTIFIER).setIp(ip).setUserGroupId(userGroupIds).setUserRoleIds(userRoleIds).setUserId(userId).build();
        log.trace("{}: uploadFile; constructed metadata for request", logId);

        final StorageOuterClass.DownloadFileRequest request = StorageOuterClass.DownloadFileRequest.newBuilder()
                .setPaths(StorageOuterClass.PathCollection.newBuilder()
                        .addPath(fileUrl).build()).setRequest(requestMeta)
                .build();
        log.trace("{}: downloadFile; created request", logId);
        log.debug("{}: downloadFile; request: {}", logId, request);


        log.trace("{}: downloadFile; downloading the file", logId);

        try {
            final BlockingClientCall<?, StorageOuterClass.DownloadFileResponse> download = stub.download(request);

            StorageOuterClass.DownloadFileResponse response = null;
            log.debug("{}: downloadFile; reading response from server", logId);

//            log.trace("{}: uploadFile; decoding file to base64", logId);
            File tempFile = null;
            while (download.hasNext()) {
                response = download.read();
                if (!response.getFileName().isBlank()) {
                    tempFile = File.createTempFile("tmp_b64", response.getFileName());
                } else {
                    try (FileOutputStream fos = new FileOutputStream(tempFile, true);
                         InputStream os = response.getContent().newInput()) {
                        os.transferTo(fos);
                    }
                    log.trace("{}: uploadFile; decoded file to base64", logId);
                }
            }

            log.debug("{}: downloadFile; read response from server", logId);


            return tempFile;
        } catch (Exception e) {
            log.error("{}: Error while downloading the file: {}", logId, e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Downloads file from doc srv in blocking io fashion.
     *
     * @param fileId the UUID of the file requested for download.
     * @return the {@code ByteBuffer) of the file or {@code null} if request failed.
     */
    public File downloadFileId(String logId, String fileId, String ip, String userId, String userRoleIds, String userGroupIds) {
        log.debug("{}: downloadFile; fileId: {}", logId, fileId);
        log.trace("{}: downloadFile; check login status", logId);
        log.debug("{}: uploadFile; ip: {}", logId, ip);
        log.debug("{}: uploadFile; userId: {}", logId, userId);
        log.debug("{}: uploadFile; userRoleIds: {}", logId, userRoleIds);
        log.debug("{}: uploadFile; userGroupIds: {}", logId, userGroupIds);
        checkLoginStatus(logId);


        BearerToken bt = new BearerToken(token);
        log.trace("{}: downloadFile; constructed bearer", logId);
        StorageGrpc.StorageBlockingV2Stub stub = StorageGrpc.newBlockingV2Stub(channel).withCallCredentials(bt);
        log.trace("{}: downloadFile; created stub", logId);

        StorageOuterClass.Request requestMeta =
                StorageOuterClass.Request.newBuilder().setBrowser(CLIENT_IDENTIFIER).setIp(ip).setUserGroupId(userGroupIds).setUserRoleIds(userRoleIds).setUserId(userId).build();
        log.trace("{}: uploadFile; constructed metadata for request", logId);

        final StorageOuterClass.DownloadFileRequest request = StorageOuterClass.DownloadFileRequest.newBuilder()
                .setIds(StorageOuterClass.IdCollection.newBuilder()
                        .addId(fileId).build()).setRequest(requestMeta)
                .build();
        log.trace("{}: downloadFile; created request", logId);
        log.debug("{}: downloadFile; request: {}", logId, request);


        log.trace("{}: downloadFile; downloading the file", logId);

        try {
            final BlockingClientCall<?, StorageOuterClass.DownloadFileResponse> download = stub.download(request);

            StorageOuterClass.DownloadFileResponse response = null;
            log.debug("{}: downloadFile; reading response from server", logId);

//            log.trace("{}: uploadFile; decoding file to base64", logId);
            File tempFile = null;
            while (download.hasNext()) {
                response = download.read();
                if (!response.getFileName().isBlank()) {
                    tempFile = File.createTempFile("tmp_b64", response.getFileName());
                } else {
                    try (FileOutputStream fos = new FileOutputStream(tempFile, true);
                         InputStream os = response.getContent().newInput()) {
                        os.transferTo(fos);
                    }
                    log.trace("{}: uploadFile; decoded file to base64", logId);
                }
            }

            log.debug("{}: downloadFile; read response from server", logId);


            return tempFile;
        } catch (Exception e) {
            log.error("{}: Error while downloading the file: {}", logId, e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Save the file in DB.
     *
     * @param fileUrl  the path of the file requested to be saved in DB.
     * @param fileName readable file name.
     * @param fileId   the id of the file
     * @param objectId the uuid of the outdoc table.
     * @return The id of the saved file {@code null} if request failed.
     */
    public String saveFile(String logId, String fileUrl, String fileId, String objectId, String fileName, String ip, String userId, String userRoleIds, String userGroupIds) {
        log.debug("{}: saveFile; fileUrl: {}", logId, fileUrl);
        log.trace("{}: saveFile; check login status", logId);
        log.debug("{}: uploadFile; ip: {}", logId, ip);
        log.debug("{}: uploadFile; userId: {}", logId, userId);
        log.debug("{}: uploadFile; userRoleIds: {}", logId, userRoleIds);
        log.debug("{}: uploadFile; userGroupIds: {}", logId, userGroupIds);
        checkLoginStatus(logId);


        BearerToken bt = new BearerToken(token);
        log.trace("{}: saveFile; constructed bearer", logId);
        StorageGrpc.StorageBlockingV2Stub stub = StorageGrpc.newBlockingV2Stub(channel).withCallCredentials(bt);
        log.trace("{}: saveFile; created stub", logId);


        log.trace("{}: saveFile; created request", logId);

        StorageOuterClass.Request requestMeta =
                StorageOuterClass.Request.newBuilder().setBrowser(CLIENT_IDENTIFIER).setIp(ip).setUserGroupId(userGroupIds).setUserRoleIds(userRoleIds).setUserId(userId).build();
        log.trace("{}: uploadFile; constructed metadata for request", logId);


        final StorageOuterClass.SaveFile request = StorageOuterClass.SaveFile.newBuilder()
                .setPath(fileUrl)
                .setObjectId(objectId)
                .setObjectType(StorageOuterClass.ObjectType.OutDocument)
                .setName(fileName)
                .setId(fileId)
                .build();
        log.debug("{}: saveFile; request: {}", logId, request);


        log.trace("{}: saveFile; executing request", logId);
        final StorageOuterClass.SaveFileResponse response = stub.save(StorageOuterClass.SaveFileRequest.newBuilder()
                .addFiles(request).setRequest(requestMeta)
                .build());
        log.trace("{}: saveFile; executed request request", logId);
        log.debug("{}: saveFile; response: {}", logId, response);


        return response.getIdsList().getFirst();
    }

    private void checkLoginStatus(String logId) {
        log.trace("{}: channel.isShutdown(): {}", logId, channel.isShutdown());
        log.trace("{}: channel.isTerminated(): {}", logId, channel.isTerminated());
        log.trace("{}: channel.getState(true): {}", logId, channel.getState(true));
        //return new instance of token if token is not expired
        log.trace("{}: checkLoginStatus; check login status", logId);
        if (tokenValidity.isAfter(LocalDateTime.now().plusMinutes(INT_BUFF_MIN_PERIOD))) {
            log.trace("{}: checkLoginStatus; the token is still active: {}", logId, tokenValidity);
            return;
        }
        log.trace("{}: checkLoginStatus; the token expired at: {}", logId, tokenValidity);
        synchronized (token) {
            //if token is null or expired try to refresh by refreshToken
            if (refreshValidity.isAfter(LocalDateTime.now().plusMinutes(INT_BUFF_MIN_PERIOD))) {
                log.trace("{}: checkLoginStatus; the refresh token is still active: {}", logId, refreshValidity);
                refresh(logId);
            }
            log.trace("{}: checkLoginStatus; the refresh token expired at: {}", logId, refreshValidity);
            //if refresh token is expired or null try to login
            login(logId);
        }
    }

    private void login(String logId) {
        AuthenticationGrpc.AuthenticationBlockingStub stub = AuthenticationGrpc.newBlockingStub(channel);
        log.trace("{}: login; created stub", logId);

        AuthenticationOuterClass.TokenResponse tokenResponse = stub.signIn(AuthenticationOuterClass.SignInRequest.newBuilder().setUsername(username).setPassword(password).build());
        log.trace("{}: login; executed signIn", logId);

        extractToken(logId, tokenResponse);
        log.trace("{}: login; extracted token", logId);
    }


    private void refresh(String logId) {
        AuthenticationGrpc.AuthenticationBlockingStub stub = AuthenticationGrpc.newBlockingStub(channel);
        log.trace("{}: refresh; created stub", logId);

        AuthenticationOuterClass.TokenResponse tokenResponse = stub.refresh(AuthenticationOuterClass.RefreshRequest.newBuilder().setToken(refreshToken).build());
        log.trace("{}: refresh; executed refresh", logId);

        extractToken(logId, tokenResponse);
        log.trace("{}: refresh; extracted token", logId);
    }


    private void extractToken(String logId, AuthenticationOuterClass.TokenResponse tokenResponse) {
        this.token = tokenResponse.getAccessData().getToken();
        this.refreshToken = tokenResponse.getRefreshData().getToken();
        this.tokenValidity =
                LocalDateTime.ofEpochSecond(tokenResponse.getAccessData().getValidTo().getSeconds(), tokenResponse.getAccessData().getValidTo().getNanos(), OffsetDateTime.now().getOffset());
        log.trace("{}: extractToken; tokenValidity: {}", logId, tokenValidity);
        this.refreshValidity =
                LocalDateTime.ofEpochSecond(tokenResponse.getRefreshData().getValidTo().getSeconds(), tokenResponse.getRefreshData().getValidTo().getNanos(), OffsetDateTime.now().getOffset());
        log.trace("{}: extractToken; refreshValidity: {}", logId, refreshValidity);
    }
}
