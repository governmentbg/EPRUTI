package com.eprut.grpc.beans;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class FileUploadMetaInfo {
    private String fileName;
    private Long fileSize;
}
