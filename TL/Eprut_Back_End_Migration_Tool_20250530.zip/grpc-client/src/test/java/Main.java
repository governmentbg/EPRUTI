import com.eprut.grpc.DocServerManager;
import com.google.common.io.ByteSource;
import com.google.common.io.Files;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

public class Main {


    public static void main(String[] args) throws URISyntaxException, IOException {
        DocServerManager docServerManager = new DocServerManager("mrrbstorageservice.test.mapex.bg", 443, "eprut_migration", "");

        URL fileUrl = Main.class.getResource("test");
        URL fileUrlResult = Main.class.getResource("testResult");

        String logId = UUID.randomUUID().toString();
        Path filePath = Paths.get(fileUrl.toURI());
        File file = filePath.toFile();
        String downloadPath = "";
        if (filePath.toFile().exists()) {
            downloadPath = docServerManager.uploadFile(logId, file, "localhost", "c1908c2a-038a-4da5-bc1a-815d402baa6c", "", "");
        }
//        docServerManager.saveFile(logId, downloadPath, "localhost", "c1908c2a-038a-4da5-bc1a-815d402baa6c", "", "");
        File f = docServerManager.downloadFile(logId, downloadPath, "localhost", "c1908c2a-038a-4da5-bc1a-815d402baa6c", "", "");


        Path filePathResult = Paths.get(fileUrlResult.toURI());
        File fileResult = filePathResult.toFile();
        try (FileOutputStream fos = new FileOutputStream(fileResult)) {
            Files.copy(f, fos);
        }

        ByteSource checksum01 = Files.asByteSource(file);
        ByteSource checksum02 = Files.asByteSource(fileResult);

        System.out.println(checksum01 + file.getAbsolutePath());
        System.out.println(checksum02 + fileResult.getAbsolutePath());
        System.out.println("Equals: " + checksum01.contentEquals(checksum02));
    }

}
