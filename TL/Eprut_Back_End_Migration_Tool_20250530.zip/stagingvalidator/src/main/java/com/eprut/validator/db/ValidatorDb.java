package com.eprut.validator.db;

import com.eprut.db.beans.Address;
import com.eprut.db.beans.Customer;
import com.eprut.db.beans.OfficeInfo;
import com.eprut.db.beans.RegAct;
import com.eprut.db.beans.RegAppOneDocument;
import com.eprut.db.beans.RegAppTwoDocument;
import com.eprut.db.beans.RegContDocument;
import com.eprut.db.beans.RegObject;
import com.eprut.db.config.IpInfoConfig;
import com.eprut.db.impl.DatabaseManager;
import com.eprut.db.impl.WorkBean;
import com.eprut.validator.beans.CheckExistenceInfo;
import com.eprut.validator.constants.States;
import lombok.extern.slf4j.Slf4j;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.eprut.db.DBConnector.getConnection;

@Slf4j
public class ValidatorDb extends DatabaseManager {

    private static final String GET_REG_ACTS_BY_IMPORT_ID = """
            select *
            from staging.reg_act
            where imp_id = ?
            """;

    private static final String GET_REG_ACT_OBJECTS_BY_IMPORT_ID = """
            select *
            from staging.reg_actobject
            where imp_id = ?
            """;

    private static final String GET_ADDRESSES_BY_IMPORT_ID = """
            select *
            from staging.address
            where imp_id = ?
            """;

    private static final String GET_CUSTOMERS_BY_IMPORT_ID = """
            select *
            from staging.customer
            where imp_id = ?
            """;

    private static final String GET_APP_ONE_DOCS_BY_IMPORT_ID = """
            select *
            from staging.reg_app01_documents
            where imp_id = ?
            """;

    private static final String GET_APP_TWO_DOCS_BY_IMPORT_ID = """
            select *
            from staging.reg_app02_documents
            where imp_id = ?
            """;

    private static final String GET_CONTESTING_DOCUMENTS_BY_IMPORT_ID = """
            select *
            from staging.reg_cont_documents
            where imp_id = ?
            """;

    private static final String GET_REGISTER_CODE_BY_IMPORT_ID = """
            select *
            from staging.import
            where id = ?
            """;

    private static final String GET_REG_ACT_TYPES = """
            select *
            from staging.v_n_reg_act
            where lang_code = 'bg'
            """;

    private static final String UPDATE_REG_ACT_VALIDITY = """
            update staging.reg_act
            set is_valid = ?
            where id = ?
            """;

    private static final String UPDATE_REG_ACT_OBJECT_VALIDITY = """
            update staging.reg_actobject
            set is_valid = ?
            where id = ?
            """;

    private static final String UPDATE_CUSTOMER_VALIDITY = """
            update staging.customer
            set is_valid = ?
            where id = ?
            """;

    private static final String UPDATE_ADDRESS_VALIDITY = """
            update staging.address
            set is_valid = ?
            where id = ?
            """;

    private static final String UPDATE_REG_CONT_DOC_VALIDITY = """
            update staging.reg_cont_documents
            set is_valid = ?
            where id = ?
            """;

    private static final String UPDATE_APP_ONE_DOCUMENT_VALIDITY = """
            update staging.reg_app01_documents
            set is_valid = ?
            where id = ?
            """;

    private static final String UPDATE_APP_TWO_DOCUMENT_VALIDITY = """
            update staging.reg_app02_documents
            set is_valid = ?
            where id = ?
            """;

    private static final String GET_ANNOUNCEMENT_TYPE = """
            select *
            from admdata.nannouncementtype
            """;

    private static final String GET_STATUSES = """
            select * from admdata.nstatus
            """;

    private static final String GET_ADMINISTRATION_TYPES = """
            select * from admdata.nadministrationtype
            """;

    private static final String GET_EKATTE = """
            select * from bnd.ekatte
            """;

    private static final String GET_ISSUER = """
            select * from admdata.nissuer
            """;

    private static final String GET_PROVINCE = """
            select * from bnd.province
            """;

    private static final String GET_MUNICIPALITY = """
            select * from bnd.municipality
            """;

    private static final String GET_REGION = """
            select * from bnd.region
            """;

    private static final String GET_CUSTOMER_TYPES = """
            select * from admdata.ncusttype
            """;

    //качество на заявител
    private static final String GET_CUSTOMER_REGISTER = """
            select *
            from admdata.ncustomerregister
            where isvisible = true
            """;

    private static final String GET_IDENTIFIER_TYPE = """
            select * from regmigrate.ncustidenttype
            """;

    private static final String GET_COUNTRY = """
            select * from bnd.country
            """;

    private static final String GET_TERRITORY_TYPE = """
            select * from admdata.nterritorytype
            """;

    private static final String GET_BASE_DOC_CONTENTS = """
            select *
            from admdata.ngroupreldoccontent
            where rn_parentid is null
            """;

    private static final String GET_APPLICATION_DOC_TYPES = """
            select code, adm_id as id
            from admdata.ngroupreldoccontent
            where rn_parentid = ?
            union
            select code, rn_groupreldoccontent as id
            from admdata.nreldoccontent
            where rn_groupreldoccontent = ?;
            """;

    private static final String GET_APPLICATION_DOC_SUBTYPES = """
            select *
            from admdata.nreldoccontent;
            """;

    //returns if there are any error or warning messages
    private static final String HAS_ERROR_WARNING_MESSAGES = """
            select exists (
                select 1
                from staging.import_log il
                join staging.n_imp_msg_type nimt on il.msg_type_id = nimt.id
                where (nimt.code = 'WARNING' OR nimt.code = 'ERROR') and import_id = ?
            );
            """;

    private static final String CHECK_FOR_EXISTING_ACTS = """
            select * from kais.check_outdocactpublishedexists(?, ?, ?, ?, ?)
            """;

    private static final String GET_OFFICE_INFO = """
            select e.ekatte as ekatte, m.adm_id as mun, p.adm_id as province from bnd.ekatte e
            join bnd.municipality m on e.r_munid = m.adm_id
            join bnd.province p on m.r_provinceid = p.adm_id
            """;

    private static final String GET_OFFICE_ID_BY_MUN_AND_PROVINCE = """
            select uu_id from admdata.noffices
            where rn_provinceid = ? and rn_munid = ?
            """;

    private static final String GET_OFFICE_ID_BY_PROVINCE = """
            select uu_id from admdata.noffices
            where rn_provinceid = ? and rn_munid IS NULL
            """;

    private static final String GET_OFFICE_ID_BY_REGION = """
            select uu_id
            from admdata.noffices
            where rn_regionid = ?;
            """;

    private static final String GET_OFFICE_ID_BY_ADMINISTRATION_TYPE = """
            select uu_id from admdata.noffices
                        where rn_administrationtypeid = ?
            """;

    private static final String GET_OFFICE_UUID = """
            select uu_id from admdata.noffices where adm_id = ?
            """;

    private static final String GET_CHECK_UUIDS = """
            select ni.uu_id as issuer, dt.uu_id as doctype from staging.reg_act o
            left join admdata.nissuer ni ON ni.code = o.administrative_unit
            left join admdata.nbkdoctype dt ON dt.code = o.type
            where o.imp_id = ? and o.id = ?;
            """;

    /**
     * Get predefined work items.
     *
     * @param logId
     * @return work item.
     * @throws Exception
     */
    public List<WorkBean> getReadyToStart(String logId) throws Exception {
        return super.getReadyToStart(logId, States.DATA_UPLOADED.name());
    }

    @Override
    public WorkBean start(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.DATA_PREPARING.name(), IpInfoConfig.getSignature());
    }

    @Override
    public boolean checkIfNotStarted(String logId, WorkBean work) throws Exception {
        return checkIfNotStarted(logId, work, States.DATA_UPLOADED.name());
    }

    @Override
    public WorkBean finishedPreparing(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.DATA_VALIDATING.name());
    }

    @Override
    public WorkBean finish(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.TRANSFER_READY.name());
    }

    @Override
    public WorkBean error(String logId, WorkBean work) throws Exception {
        return changeStatusTo(logId, work, States.DATA_ERROR.name());
    }

    @Override
    public WorkBean error(String logId, WorkBean work, Exception e) throws Exception {
        return changeStatusToError(logId, work, States.DATA_ERROR.name(), e);
    }

    /**
     * Returns list of all reg acts for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegAct>
     * @throws Exception
     */
    public List<RegAct> getRegActsByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getRegActsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegAct> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REG_ACTS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegAct currentRegAct = new RegAct();
                        currentRegAct.setId(rs.getLong("id"));
                        currentRegAct.setImpId(rs.getLong("imp_id"));
                        currentRegAct.setExcelRow(rs.getInt("excel_row"));
                        currentRegAct.setOpId(rs.getLong("op_id"));
                        currentRegAct.setActNum(rs.getString("number"));
                        currentRegAct.setActType(rs.getString("type"));
                        Timestamp actDate = rs.getTimestamp("act_date");
                        if (actDate != null) {
                            currentRegAct.setActDate(actDate.toLocalDateTime());
                        }
                        Timestamp messageDate = rs.getTimestamp("message_date");
                        if (messageDate != null) {
                            currentRegAct.setMessageDate(messageDate.toLocalDateTime());
                        }
                        currentRegAct.setMessageType(rs.getString("message_type"));
                        Timestamp issuedDate = rs.getTimestamp("issued_date");
                        if (issuedDate != null) {
                            currentRegAct.setIssuedDate(issuedDate.toLocalDateTime());
                        }
                        currentRegAct.setStatus(rs.getString("status"));
                        Timestamp changeDate = rs.getTimestamp("change_date");
                        if (changeDate != null) {
                            currentRegAct.setChangeDate(changeDate.toLocalDateTime());
                        }
                        Timestamp validityDate = rs.getTimestamp("validity_date");
                        if (validityDate != null) {
                            currentRegAct.setValidityDate(validityDate.toLocalDateTime());
                        }
                        currentRegAct.setFactReason(rs.getString("fact_reason"));
                        currentRegAct.setLegalReason(rs.getString("legal_reason"));
                        currentRegAct.setAdministration(rs.getString("administration"));
                        currentRegAct.setAdministrativeUnit(rs.getString("administrative_unit"));
                        currentRegAct.setAdmPopular(rs.getString("adm_popular"));
                        currentRegAct.setObjectIdentification(rs.getString("object_identification"));
                        currentRegAct.setIsValid(rs.getBoolean("is_valid")); //todo check in db
                        result.add(currentRegAct);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegActsByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegActsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all reg act objects for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegObject>
     * @throws Exception
     */
    public List<RegObject> getRegActObjectsByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getRegActObjectsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegObject> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REG_ACT_OBJECTS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegObject currentRegObject = new RegObject();
                        currentRegObject.setId(rs.getLong("id"));
                        currentRegObject.setImpId(rs.getLong("imp_id"));
                        currentRegObject.setOpId(rs.getLong("op_id"));
                        currentRegObject.setExcelRow(rs.getInt("excel_row"));
                        currentRegObject.setRegActId(rs.getLong("reg_act_id"));
                        currentRegObject.setCadastre(rs.getString("cadastre"));
                        currentRegObject.setLocalPlace(rs.getString("local_place"));
                        currentRegObject.setRegulationDistrict(rs.getString("regulation_district"));
                        currentRegObject.setUpi(rs.getString("upi"));
                        currentRegObject.setPlanRegion(rs.getString("plan_region"));
                        currentRegObject.setPlanNumber(rs.getString("plan_number"));
                        currentRegObject.setKvsTerritory(rs.getString("kvs_territory"));
                        currentRegObject.setKvsNumber(rs.getString("kvs_number"));
                        currentRegObject.setTerritoryType(rs.getString("teritory_type"));
                        currentRegObject.setProtectedTerritory(rs.getString("protected_teritory"));
                        currentRegObject.setDescription(rs.getString("description"));
                        currentRegObject.setAddressId(rs.getLong("adress_id"));
                        currentRegObject.setIsValid(rs.getBoolean("is_valid"));
                        result.add(currentRegObject);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegActObjectsByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegActObjectsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all reg act addresses for the current import id.
     *
     * @param logId
     * @param work
     * @return Map<Long, Address>
     * @throws Exception
     */
    public Map<Long, Address> getRegActAddressesByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getRegActObjectAddressByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<Long, Address> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ADDRESSES_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        Address currentAddress = new Address();
                        currentAddress.setId(rs.getLong("id"));
                        currentAddress.setImportId(rs.getLong("imp_id"));
                        currentAddress.setExcelRow(rs.getInt("excel_row"));
                        currentAddress.setOpId(rs.getLong("op_id"));
                        currentAddress.setCountry(rs.getString("country"));
                        currentAddress.setDistrict(rs.getString("district"));
                        currentAddress.setMunicipality(rs.getString("municipality"));
                        currentAddress.setSettlement(rs.getString("settlement"));
                        currentAddress.setVillage(rs.getString("village"));
                        currentAddress.setRegion(rs.getString("region"));
                        currentAddress.setFloor(rs.getString("floor"));
                        currentAddress.setFlatEntrance(rs.getString("flatentrance"));
                        currentAddress.setApartment(rs.getString("apartment"));
                        currentAddress.setSquareName(rs.getString("squarename"));
                        currentAddress.setSquareNum(rs.getString("squarenum"));
                        currentAddress.setAppComplexName(rs.getString("appcomplexname"));
                        currentAddress.setAppComplexNum(rs.getString("appcomplexnum"));
                        currentAddress.setQuarter(rs.getString("quarter"));
                        currentAddress.setStreetName(rs.getString("streetname"));
                        currentAddress.setStreetNum(rs.getString("streetnum"));
                        currentAddress.setFlatNumber(rs.getString("flatnum"));
                        currentAddress.setOtherluname(rs.getString("otherluname"));
                        currentAddress.setOtherlunum(rs.getString("otherlunum"));
                        currentAddress.setAddrPlaceName(rs.getString("addrplacename"));
                        currentAddress.setIsValid(rs.getBoolean("is_valid"));
                        result.put(currentAddress.getId(), currentAddress);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegActObjectAddressByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegActObjectAddressByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all reg act customers for the current import id.
     *
     * @param logId
     * @param work
     * @return List<Customers>
     * @throws Exception
     */
    public List<Customer> getRegActCustomersByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getRegActCustomersByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<Customer> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_CUSTOMERS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        Customer currentCustomer = new Customer();
                        currentCustomer.setId(rs.getLong("id"));
                        currentCustomer.setImpId(rs.getLong("imp_id"));
                        currentCustomer.setExcelRow(rs.getInt("excel_row"));
                        currentCustomer.setOpId(rs.getLong("op_id"));
                        currentCustomer.setRegActId(rs.getLong("reg_act_id"));
                        currentCustomer.setIdentifierType(rs.getString("identifier_type"));
                        currentCustomer.setIdentifier(rs.getString("identifier"));
                        currentCustomer.setCustomerType(rs.getString("customer_type"));
                        currentCustomer.setUnitName(rs.getString("unit_name"));
                        currentCustomer.setFirstName(rs.getString("first_name"));
                        currentCustomer.setMiddleName(rs.getString("middle_name"));
                        currentCustomer.setLastName(rs.getString("last_name"));
                        currentCustomer.setEmail(rs.getString("email"));
                        currentCustomer.setPhone(rs.getString("phone"));
                        currentCustomer.setCapacity(rs.getString("capacity"));
                        currentCustomer.setAddressId(rs.getLong("adress_id"));
                        currentCustomer.setIsValid(rs.getBoolean("is_valid"));
                        result.add(currentCustomer);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegActCustomersByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegActCustomersByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all reg act application one documents for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegAppOneDocument>
     * @throws Exception
     */
    public List<RegAppOneDocument> getRegActAppOneDocsByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getRegActAppOneDocsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegAppOneDocument> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_APP_ONE_DOCS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegAppOneDocument currentRegAppOneDocument = new RegAppOneDocument();
                        currentRegAppOneDocument.setId(rs.getLong("id"));
                        currentRegAppOneDocument.setImpId(rs.getLong("imp_id"));
                        currentRegAppOneDocument.setExcelRow(rs.getInt("excel_row"));
                        currentRegAppOneDocument.setOpId(rs.getLong("op_id"));
                        currentRegAppOneDocument.setRegActId(rs.getLong("reg_act_id"));
                        currentRegAppOneDocument.setDocumentId(rs.getLong("document_id"));
                        currentRegAppOneDocument.setType(rs.getString("type"));
                        currentRegAppOneDocument.setSubType(rs.getString("subtype"));
                        currentRegAppOneDocument.setIsValid(rs.getBoolean("is_valid"));
                        result.add(currentRegAppOneDocument);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegActAppOneDocsByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegActAppOneDocsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all reg act application two documents for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegAppTwoDocument>
     * @throws Exception
     */
    public List<RegAppTwoDocument> getRegActAppTwoDocsByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getRegActAppTwoDocsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegAppTwoDocument> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_APP_TWO_DOCS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegAppTwoDocument currentRegAppOneDocument = new RegAppTwoDocument();
                        currentRegAppOneDocument.setId(rs.getLong("id"));
                        currentRegAppOneDocument.setImpId(rs.getLong("imp_id"));
                        currentRegAppOneDocument.setExcelRow(rs.getInt("excel_row"));
                        currentRegAppOneDocument.setOpId(rs.getLong("op_id"));
                        currentRegAppOneDocument.setRegActId(rs.getLong("reg_act_id"));
                        currentRegAppOneDocument.setDocumentId(rs.getLong("document_id"));
                        currentRegAppOneDocument.setType(rs.getString("type"));
                        currentRegAppOneDocument.setSubType(rs.getString("subtype"));
                        currentRegAppOneDocument.setIsValid(rs.getBoolean("is_valid"));
                        result.add(currentRegAppOneDocument);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegActAppTwoDocsByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegActAppTwoDocsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Returns list of all reg act contesting documents for the current import id.
     *
     * @param logId
     * @param work
     * @return List<RegContDocument>
     * @throws Exception
     */
    public List<RegContDocument> getRegActContestingDocsByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getRegActContestingDocsByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<RegContDocument> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_CONTESTING_DOCUMENTS_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        RegContDocument contDocument = new RegContDocument();
                        contDocument.setId(rs.getLong("id"));
                        contDocument.setImpId(rs.getLong("imp_id"));
                        contDocument.setExcelRow(rs.getInt("excel_row"));
                        contDocument.setOpId(rs.getLong("op_id"));
                        contDocument.setRegActId(rs.getLong("reg_act_id"));
                        contDocument.setDocumentId(rs.getLong("document_id"));
                        contDocument.setDescription(rs.getString("description"));
                        contDocument.setIsValid(rs.getBoolean("is_valid"));
                        result.add(contDocument);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegActContestingDocsByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegActContestingDocsByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Get register code by import id.
     *
     * @param logId
     * @param work
     * @return String
     * @throws Exception
     */
    public String getRegisterCodeByImportId(String logId, WorkBean work) throws Exception {
        log.info("{}: getRegisterCodeByImportId - started", logId);
        log.trace("{}: work: {}", logId, work);
        String result = null;
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REGISTER_CODE_BY_IMPORT_ID)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        result = rs.getString("register_code");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegisterCodeByImportId - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegisterCodeByImportId - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types, mapped by register act code.
     *
     * @param logId
     * @param work
     * @return Map<String, String>
     * @throws Exception
     */
    public Map<String, String> getRegActTypes(String logId, WorkBean work)
            throws Exception {
        log.info("{}: getRegActTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, String> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REG_ACT_TYPES)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getString("description"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegActTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegActTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     * @throws Exception
     */
    public List<String> getAnnouncementTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getAnnouncementTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ANNOUNCEMENT_TYPE)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getAnnouncementTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getAnnouncementTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     * @throws Exception
     */
    public List<String> getStatuses(String logId, WorkBean work) throws Exception {
        log.info("{}: getStatuses - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_STATUSES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getStatuses - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getStatuses - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     * @throws Exception
     */
    public List<String> getAdministrationTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getGetAdministrationTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ADMINISTRATION_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getGetAdministrationTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getGetAdministrationTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     * @throws Exception
     */
    public List<String> getEkatte(String logId, WorkBean work) throws Exception {
        log.info("{}: getEkatte - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_EKATTE)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("ekatte"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getEkatte - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getEkatte - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     * @throws Exception
     */
    public List<String> getIssuer(String logId, WorkBean work) throws Exception {
        log.info("{}: getIssuer - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_ISSUER)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getIssuer - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getIssuer - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     * @throws Exception
     */
    public List<String> getProvince(String logId, WorkBean work) throws Exception {
        log.info("{}: getProvince - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_PROVINCE)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("nsicode"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getProvince - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getProvince - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     * @throws Exception
     */
    public List<String> getMunicipality(String logId, WorkBean work) throws Exception {
        log.info("{}: getMunicipality - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_MUNICIPALITY)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("nsicode"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getMunicipality - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getMunicipality - finished", logId);
        }
        return result;
    }

    /**
     * Get all ids of region nomenclatures, mapped by region nsicode.
     *
     * @param logId
     * @param work
     * @return Map<String, Long>
     * @throws Exception
     */
    public Map<String, Long> getRegions(String logId, WorkBean work) throws Exception {
        log.info("{}: getRegions - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_REGION)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("nsicode"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getRegions - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getRegions - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     * @throws Exception
     */
    public List<String> getTerritoryType(String logId, WorkBean work) throws Exception {
        log.info("{}: getTerritoryType - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_TERRITORY_TYPE)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getTerritoryType - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getTerritoryType - finished", logId);
        }
        return result;
    }

    /**
     * Get base document content types ids, mapped by code.
     *
     * @param logId
     * @param work
     * @return List<String>
     * @throws Exception
     */
    public Map<String, Long> getBaseDocContentTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getBaseDocContentTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_BASE_DOC_CONTENTS)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getBaseDocContentTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getBaseDocContentTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get application document types ids, mapped by code.
     *
     * @param logId
     * @param work
     * @param appDocTypeId
     * @return List<String>
     * @throws Exception
     */
    public Map<String, Long> getApplicationDocTypes(String logId, WorkBean work, Long appDocTypeId) throws Exception {
        log.info("{}: getApplicationDocTypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: appDocTypeId: {}", logId, appDocTypeId);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_APPLICATION_DOC_TYPES)) {
                int i = 1;
                cs.setLong(i++, appDocTypeId);
                cs.setLong(i++, appDocTypeId);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getApplicationDocTypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getApplicationDocTypes - finished", logId);
        }
        return result;
    }

    /**
     * Get application document subtypes codes, mapped by docTypeId.
     *
     * @param logId
     * @param work
     * @return Map<Long, List < String>>
     * @throws Exception
     */
    public Map<Long, List<String>> getApplicationDocSubtypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getApplicationDocSubtypes - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<Long, List<String>> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_APPLICATION_DOC_SUBTYPES)) {
                int i = 1;
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.computeIfAbsent(rs.getLong("rn_groupreldoccontent"), k -> new ArrayList<>()).add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getApplicationDocSubtypes - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getApplicationDocSubtypes - finished", logId);
        }
        return result;
    }

    /**
     * Get customer types, mapped by code.
     *
     * @param logId
     * @param work
     * @return List<String>
     * @throws Exception
     */
    public Map<String, Long> getCustomerTypes(String logId, WorkBean work) throws Exception {
        log.info("{}: getApplicant - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, Long> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_CUSTOMER_TYPES)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.put(rs.getString("code"), rs.getLong("adm_id"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getApplicant - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getApplicant - finished", logId);
        }
        return result;
    }

    /**
     * Get customer register (качество на заявител), mapped by customer type id.
     *
     * @param logId
     * @param work
     * @return List<String>
     * @throws Exception
     */
    public Map<Long, List<String>> getCustomerRegister(String logId, WorkBean work) throws Exception {
        log.info("{}: getApplicant - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<Long, List<String>> result = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_CUSTOMER_REGISTER)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.computeIfAbsent(rs.getLong("rn_custtypeid"), k -> new ArrayList<>()).add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getApplicant - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getApplicant - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     * @throws Exception
     */
    public List<String> getIdentifierType(String logId, WorkBean work) throws Exception {
        log.info("{}: getIdentifierType - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_IDENTIFIER_TYPE)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getIdentifierType - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getIdentifierType - finished", logId);
        }
        return result;
    }

    /**
     * Get register act types by register code.
     *
     * @param logId
     * @param work
     * @return List<String>
     * @throws Exception
     */
    public List<String> getCountry(String logId, WorkBean work) throws Exception {
        log.info("{}: getCountry - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<String> result = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_COUNTRY)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        result.add(rs.getString("code"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getCountry - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getCountry - finished", logId);
        }
        return result;
    }

    /**
     * Change validity of act.
     *
     * @param logId
     * @param work
     * @param regAct
     * @throws Exception
     */
    public void updateRegActValidity(String logId, WorkBean work, RegAct regAct) throws Exception {
        log.info("{}: updateRegActValidity - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: regAct: {}", logId, regAct);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(UPDATE_REG_ACT_VALIDITY)) {
                int i = 1;
                cs.setBoolean(i++, false);
                cs.setLong(i++, regAct.getId());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Problem with updating reg act validity.");
                }
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: updateRegActValidity - error", logId, e);
            throw e; //todo ?
        } finally {
            log.info("{}: updateRegActValidity - finished", logId);
        }
    }

    /**
     * Change validity of act.
     *
     * @param logId
     * @param work
     * @param regObject
     * @throws Exception
     */
    public void updateRegActObjectValidity(String logId, WorkBean work, RegObject regObject) throws Exception {
        log.info("{}: updateRegActObjectValidity - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: regAct: {}", logId, regObject);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(UPDATE_REG_ACT_OBJECT_VALIDITY)) {
                int i = 1;
                cs.setBoolean(i++, false);
                cs.setLong(i++, regObject.getId());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Problem with updating reg act object validity.");
                }
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: updateRegActObjectValidity - error", logId, e);
            throw e; //todo ?
        } finally {
            log.info("{}: updateRegActObjectValidity - finished", logId);
        }
    }

    /**
     * Change validity of act.
     *
     * @param logId
     * @param work
     * @param customer
     * @throws Exception
     */
    public void updateCustomerValidity(String logId, WorkBean work, Customer customer) throws Exception {
        log.info("{}: updateCustomerValidity - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: regAct: {}", logId, customer);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(UPDATE_CUSTOMER_VALIDITY)) {
                int i = 1;
                cs.setBoolean(i++, false);
                cs.setLong(i++, customer.getId());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Problem with updating customer validity.");
                }
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: updateCustomerValidity - error", logId, e);
            throw e; //todo?
        } finally {
            log.info("{}: updateCustomerValidity - finished", logId);
        }
    }

    /**
     * Change validity of act.
     *
     * @param logId
     * @param work
     * @param address
     * @throws Exception
     */
    public void updateAddressValidity(String logId, WorkBean work, Address address) throws Exception {
        log.info("{}: updateAddressValidity - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: regAct: {}", logId, address);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(UPDATE_ADDRESS_VALIDITY)) {
                int i = 1;
                cs.setBoolean(i++, false);
                cs.setLong(i++, address.getId());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Problem with updating address validity.");
                }
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: updateAddressValidity - error", logId, e);
            throw e; //todo?
        } finally {
            log.info("{}: updateAddressValidity - finished", logId);
        }
    }

    /**
     * Change validity of contesting doc.
     *
     * @param logId
     * @param work
     * @param contDocument
     * @throws Exception
     */
    public void updateContestingValidity(String logId, WorkBean work, RegContDocument contDocument) throws Exception {
        log.info("{}: updateContestingValidity - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: contDocument: {}", logId, contDocument);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(UPDATE_REG_CONT_DOC_VALIDITY)) {
                int i = 1;
                cs.setBoolean(i++, false);
                cs.setLong(i++, contDocument.getId());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Problem with updating contesting validity.");
                }
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: updateContestingValidity - error", logId, e);
            throw e; //todo?
        } finally {
            log.info("{}: updateContestingValidity - finished", logId);
        }
    }

    /**
     * Change validity of application one doc.
     *
     * @param logId
     * @param work
     * @param appOneDocument
     * @throws Exception
     */
    public void updateAppOneDocumentValidity(String logId, WorkBean work, RegAppOneDocument appOneDocument) throws Exception {
        log.info("{}: updateAppOneDocumentValidity - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: appOneDocument: {}", logId, appOneDocument);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(UPDATE_APP_ONE_DOCUMENT_VALIDITY)) {
                int i = 1;
                cs.setBoolean(i++, false);
                cs.setLong(i++, appOneDocument.getId());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Problem with updating application one document validity.");
                }
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: updateAppOneDocumentValidity - error", logId, e);
            throw e; //todo?
        } finally {
            log.info("{}: updateAppOneDocumentValidity - finished", logId);
        }
    }

    /**
     * Change validity of application two doc.
     *
     * @param logId
     * @param work
     * @param appTwoDocument
     * @throws Exception
     */
    public void updateAppTwoDocumentValidity(String logId, WorkBean work, RegAppTwoDocument appTwoDocument) throws Exception {
        log.info("{}: updateAppTwoDocumentValidity - started", logId);
        log.trace("{}: work: {}", logId, work);
        log.trace("{}: appTwoDocument: {}", logId, appTwoDocument);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(UPDATE_APP_TWO_DOCUMENT_VALIDITY)) {
                int i = 1;
                cs.setBoolean(i++, false);
                cs.setLong(i++, appTwoDocument.getId());
                if (cs.executeUpdate() != 1) {
                    throw new SQLException("Problem with updating application two document validity.");
                }
                c.commit();
            }
        } catch (Exception e) {
            log.error("{}: updateAppTwoDocumentValidity - error", logId, e);
            throw e; //todo?
        } finally {
            log.info("{}: updateAppTwoDocumentValidity - finished", logId);
        }
    }

    /**
     * Returns if there are any error/warning messages for import.
     *
     * @param logId
     * @param work
     * @return Boolean
     * @throws Exception
     */
    public Boolean hasErrorWarningMessages(String logId, WorkBean work) throws Exception {
        log.info("{}: hasErrorWarningMessages - started", logId);
        log.trace("{}: work: {}", logId, work);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(HAS_ERROR_WARNING_MESSAGES)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        return rs.getBoolean(1);
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: hasErrorWarningMessages - error", logId, e);
            throw e;
        } finally {
            log.info("{}: hasErrorWarningMessages - finished", logId);
        }
        return false;
    }

    /**
     * Returns if there are any error/warning messages for import.
     *
     * @param logId
     * @param work
     * @return Long
     * @throws Exception
     */
    public Long checkForExistingActs(String logId, WorkBean work, RegAct regAct, UUID pofficeid, UUID pissuerid, UUID pdoctypeid) throws Exception {
        log.info("{}: checkForExistingActs - started", logId);
        log.trace("{}: work: {}", logId, work);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(CHECK_FOR_EXISTING_ACTS)) {
                int i = 1;
                cs.setString(i++, regAct.getActNum());
                cs.setTimestamp(i++, Timestamp.valueOf(regAct.getActDate()));
                cs.setObject(i++, pofficeid);
                cs.setObject(i++, pissuerid);
                cs.setObject(i++, pdoctypeid);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        return rs.getLong("pexists");
                    }
                }
            }

        } catch (Exception e) {
            log.error("{}: checkForExistingActs - error", logId, e);
            String message = e.getMessage();
            final int BEGIN_INDEX = 7;
            String trimmedMessage = message.substring(BEGIN_INDEX).split("!")[0];
            logWarningMessage(logId, work, "За Акт с номер: " + regAct.getActNum() + " : " + trimmedMessage + "!");
        } finally {
            log.info("{}: checkForExistingActs - finished", logId);
        }
        return null;
    }

    /**
     * Returns mun_id and province_id for each ekatte.
     *
     * @param logId
     * @param work
     * @return Map<String, OfficeInfo>
     * @throws Exception
     */
    public Map<String, OfficeInfo> getOfficeInfoByEkatte(String logId, WorkBean work) throws Exception {
        log.info("{}: getOfficeInfo - started", logId);
        log.trace("{}: work: {}", logId, work);
        Map<String, OfficeInfo> officeInfo = new HashMap<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_OFFICE_INFO)) {
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    while (rs.next()) {
                        officeInfo.put(rs.getString("ekatte"), new OfficeInfo(rs.getLong("mun"), rs.getLong("province")));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getOfficeInfo - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getOfficeInfo - finished", logId);
        }
        return officeInfo;
    }

    /**
     * Returns id for office by municipality id and province id.
     *
     * @param logId
     * @param work
     * @return String
     * @throws Exception
     */
    public String getOfficeIdByMunAndProvince(String logId, WorkBean work, Long munId, Long provinceId) throws Exception {
        log.info("{}: getOfficeIdByMunAndProvince - started", logId);
        log.trace("{}: work: {}", logId, work);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_OFFICE_ID_BY_MUN_AND_PROVINCE)) {
                int i = 1;
                cs.setLong(i++, provinceId);
                cs.setObject(i++, munId, Types.BIGINT);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        return rs.getString("uu_id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getOfficeIdByMunAndProvince - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getOfficeIdByMunAndProvince - finished", logId);
        }
        return null;
    }

    /**
     * Returns id for office by province id.
     *
     * @param logId
     * @param work
     * @return String
     * @throws Exception
     */
    public String getOfficeIdByProvince(String logId, WorkBean work, Long provinceId) throws Exception {
        log.info("{}: getOfficeIdByProvince - started", logId);
        log.trace("{}: work: {}", logId, work);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_OFFICE_ID_BY_PROVINCE)) {
                int i = 1;
                cs.setLong(i++, provinceId);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        return rs.getString("uu_id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getOfficeIdByProvince - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getOfficeIdByProvince - finished", logId);
        }
        return null;
    }

    /**
     * Returns id for office by region id.
     *
     * @param logId
     * @param work
     * @return String
     * @throws Exception
     */
    public String getOfficeIdByRegion(String logId, WorkBean work, Long provinceId) throws Exception {
        log.info("{}: getOfficeIdByRegion - started", logId);
        log.trace("{}: work: {}", logId, work);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_OFFICE_ID_BY_REGION)) {
                int i = 1;
                cs.setLong(i++, provinceId);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        return rs.getString("uu_id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getOfficeIdByRegion - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getOfficeIdByRegion - finished", logId);
        }
        return null;
    }

    /**
     * Returns id for office by administration type.
     *
     * @param logId
     * @param work
     * @return String
     * @throws Exception
     */
    public String getOfficeIdByAdministrationType(String logId, WorkBean work, Long admId) throws Exception {
        log.info("{}: getOfficeIdByAdministrationType - started", logId);
        log.trace("{}: work: {}", logId, work);
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_OFFICE_ID_BY_ADMINISTRATION_TYPE)) {
                int i = 1;
                cs.setLong(i++, admId);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        return rs.getString("uu_id");
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getOfficeIdByAdministrationType - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getOfficeIdByAdministrationType - finished", logId);
        }
        return null;
    }

    /**
     * Returns mun_id and province_id for each ekatte.
     *
     * @param logId
     * @param work
     * @return CheckExistenceInfo
     * @throws Exception
     */
    public CheckExistenceInfo getCheckUUDIs(String logId, WorkBean work, Long regId) throws Exception {
        log.info("{}: getCheckUUDIs - started", logId);
        log.trace("{}: work: {}", logId, work);
        List<CheckExistenceInfo> uuids = new ArrayList<>();
        try (Connection c = getConnection()) {
            try (CallableStatement cs = c.prepareCall(GET_CHECK_UUIDS)) {
                int i = 1;
                cs.setLong(i++, work.getId().longValue());
                cs.setLong(i++, regId);
                cs.execute();
                try (ResultSet rs = cs.getResultSet()) {
                    if (rs.next()) {
                        return new CheckExistenceInfo((UUID) rs.getObject("issuer"), (UUID) rs.getObject("doctype"));
                    }
                }
            }
        } catch (Exception e) {
            log.error("{}: getCheckUUDIs - error", logId, e);
            throw e;
        } finally {
            log.info("{}: getCheckUUDIs - finished", logId);
        }
        return null;
    }
}
