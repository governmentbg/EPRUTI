package com.eprut.validator;

import com.eprut.db.DBConnector;
import com.eprut.db.config.IpInfoConfig;
import com.eprut.validator.constants.States;
import com.eprut.validator.db.ValidatorDb;
import com.eprut.validator.worker.ValidatorWorker;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import lombok.extern.slf4j.Slf4j;
import tl.abstractWorkers.AbstractQueueWorker;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

@Slf4j
public class ValidatorWrapper implements ServletContextListener {


    private final int nThreads;
    private final long initialDelay;
    private final long periodOfWaitTime;
    private DataSource dataSource;
    private ValidatorDb database;

    private String jndiName;
    private AbstractQueueWorker worker;

    /**
     * Initialzation of worker for extracting xml from the zip; validating the content; loading it into db.
     *
     * @throws Exception
     */
    public ValidatorWrapper() throws Exception {
        Properties env = new Properties();
        try {
            env.load(ValidatorWrapper.class.getClassLoader().getResourceAsStream("default.properties"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        this.nThreads = Integer.parseInt(env.getProperty("worker.threads"));
        this.initialDelay = Long.parseLong(env.getProperty("worker.initialWaitTime"));
        this.periodOfWaitTime = Long.parseLong(env.getProperty("worker.periodOfWaitTime"));
        jndiName = env.getProperty("jndi.name");


        dataSource = DBConnector.initDataSource(jndiName);
        database = new ValidatorDb();

        worker = new ValidatorWorker(nThreads, initialDelay, periodOfWaitTime, TimeUnit.MINUTES, database);
    }


    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContextListener.super.contextInitialized(sce);
        IpInfoConfig ipInfoConfig = new IpInfoConfig();
        try {
            ipInfoConfig.onApplicationEvent();
            try (Connection connDocStore = DBConnector.getConnection()) {
                database.notifyDbServerIsUp(connDocStore, IpInfoConfig.getSignature(), States.DATA_ERROR.name(), States.DATA_UPLOADED.name(), States.DATA_PREPARING.name(),
                        States.DATA_VALIDATING.name());
                if (connDocStore == null) {
                    log.error("can not open db connection Error while notifying the server is UP to the DB");
                }
                connDocStore.commit();
            } catch (SQLException e) {
                log.error("Error while notifying the server is UP to the DB", e);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        try {
            worker.destroy();
        } catch (Exception e) {
            log.error("Error while destroying context", e);
        }
    }


}
