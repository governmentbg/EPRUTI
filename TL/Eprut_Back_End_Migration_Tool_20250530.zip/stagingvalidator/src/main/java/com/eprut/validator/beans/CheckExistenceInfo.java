package com.eprut.validator.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

import java.util.UUID;

@Data
@ToString
@AllArgsConstructor
public class CheckExistenceInfo {
    private UUID pissueridUUID;
    private UUID pdoctypeidUUID;
}
