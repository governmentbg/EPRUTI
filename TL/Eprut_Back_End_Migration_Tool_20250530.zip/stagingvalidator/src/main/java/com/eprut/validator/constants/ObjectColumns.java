package com.eprut.validator.constants;

import lombok.Getter;

@Getter
public enum ObjectColumns implements IColumnsEnum {
    NUM_ACT("Номер на акта"),                                       //Номер на акта
    CADIDENT("Кадастрален идентификатор"),                          //Кадастрален идентификатор
    LOCAL_PLACE("Местност"),                                        //Местност
    REG_DISTRICT("Квартал по регулация"),                           //Квартал по регулация
    UPI("УПИ"),                                                     //УПИ
    CAD_REGION("Планоснимачен район"),                              //Планоснимачен район
    CAD_NUMBER("Планоснимачен номер"),                              //Планоснимачен номер
    RPM_PLACENAME("Местност КВС"),                                  //Местност КВС
    RPM_NUMBER("Номер КВС"),                                        //Номер КВС
    TERRITORY_TYPE("Вид територия"),                                //Вид територия
    PROTECTED_AREA("Защитена територия"),                           //Защитена територия
    ADDITIONAL_DESCRIPTION("Допълнително описание на обекта");      //Допълнително описание на обекта

    private final String columnName;

    ObjectColumns(String columnName) {
        this.columnName = columnName;
    }
}
