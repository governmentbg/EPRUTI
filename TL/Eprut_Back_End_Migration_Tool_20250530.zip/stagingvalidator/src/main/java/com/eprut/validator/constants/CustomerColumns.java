package com.eprut.validator.constants;

import lombok.Getter;

@Getter
public enum CustomerColumns implements IColumnsEnum {
    NUM_ACT("Номер на акта"),               //Номер на акта
    CUST_TYPE("Вид на заявителя"),          //Вид на заявителя
    CUST_QUALITY("Качество на заявителя"),  //Качество на заявителя
    ID_TYPE("Вид на идентификатора"),       //Вид на идентификатора
    PUBLIC_ID("Публичен идентификатор"),    //Публичен идентификатор
    CUST_ALIAS("Наименование"),             //Наименование - отключено при избор Булстат/ЕИК от поле Вид на идентификатор
    FIRSTNAME("Име"),                       //Име
    SURNAME("Презиме"),                     //Презиме
    LASTNAME("Фамилия"),                    //Фамилия
    EMAIL("Електронен адрес"),              //Имейл
    PHONE("Телефон");                       //Телефон

    private final String columnName;

    CustomerColumns(String columnName) {
        this.columnName = columnName;
    }
}
