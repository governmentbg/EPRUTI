package com.eprut.validator.constants;

import lombok.Getter;

@Getter
public enum AddressColumns implements IColumnsEnum {
    COUNTRY("Държава"),                           //Държава
    DISTRICT("Област"),                           //Област
    MUNICIPALITY("Община"),                       //Община
    SETTLEMENT("Населено място"),                 //Населено място
    REGION("Район"),                              //Район - ЕКАТТЕ
    VILLAGE("Селищно образувание");               //Селищно образувание

    private final String columnName;

    AddressColumns(String columnName) {
        this.columnName = columnName;
    }
}
