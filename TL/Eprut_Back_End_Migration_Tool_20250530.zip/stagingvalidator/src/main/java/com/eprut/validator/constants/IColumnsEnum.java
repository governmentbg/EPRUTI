package com.eprut.validator.constants;

public interface IColumnsEnum {
    /**
     * Get name of column.
     * @return String
     */
    String getColumnName();
}
