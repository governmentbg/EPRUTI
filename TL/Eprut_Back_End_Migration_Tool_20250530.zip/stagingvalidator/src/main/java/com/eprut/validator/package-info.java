/**
 * Project: eprut
 * Module: com.eprut.validator
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Модул за валидация на данни.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.validator;
