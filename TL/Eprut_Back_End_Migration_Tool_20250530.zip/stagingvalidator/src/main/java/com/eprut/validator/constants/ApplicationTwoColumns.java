package com.eprut.validator.constants;

import lombok.Getter;

@Getter
public enum ApplicationTwoColumns implements IColumnsEnum {
    NUM_ACT("Номер на акта"),                                                                            //Номер на акта
    DOC_TYPE("Вид на акта"),                                                                             //Вид на акта
    APPLICATION_TWO_DOCUMENT_COPIES("Приложения 2 (Копия на документи (административни актове, становища и други), " +
                    "които са основание за издаване на административния)"),                                         //Приложения 2
    SUBCATEGORY_FOR_APPROVED_INVESTMENT_PLAN("Подкатегория само при одобрен инвестиционен проект"),      //Подкатегория само при одобрен инвестиционен проект
    FILE_NAME("Име на файл");                                                                            //Име на файл

    private final String columnName;

    ApplicationTwoColumns(String columnName) {
        this.columnName = columnName;
    }
}
