/**
 * Project: eprut
 * Module: com.eprut.validator.beans
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Структури от данни за временно съхранение на валидиращите данни.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.validator.beans;
