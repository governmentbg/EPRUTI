package com.eprut.validator.constants;

import lombok.Getter;

@Getter
public enum ApplicationOneColumns implements IColumnsEnum {
    NUM_ACT("Номер на акта"),                                      //Номер на акта
    DOC_TYPE("Вид на акта"),                                       //Вид на акта
    LAYOUT_PLANS_PROJECTS("Проекти на устройствени планове"),      //Проекти на устройствени планове
    APPLICATION_ONE_SUBCATEGORY("Приложения 1 (подкатегория)"),    //Приложения 1 (подкатегория)
    FILE_NAME("Име на файл");                                      //Име на файл

    private final String columnName;

    ApplicationOneColumns(String columnName) {
        this.columnName = columnName;
    }
}
