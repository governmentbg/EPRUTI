package com.eprut.validator.worker;

import com.eprut.db.beans.Address;
import com.eprut.db.beans.Customer;
import com.eprut.db.beans.ILogInfo;
import com.eprut.db.beans.OfficeInfo;
import com.eprut.db.beans.RegAct;
import com.eprut.db.beans.RegAppOneDocument;
import com.eprut.db.beans.RegAppTwoDocument;
import com.eprut.db.beans.RegContDocument;
import com.eprut.db.beans.RegObject;
import com.eprut.db.constants.Nomenclatures;
import com.eprut.db.impl.WorkBean;
import com.eprut.validator.beans.CheckExistenceInfo;
import com.eprut.validator.constants.ActColumns;
import com.eprut.validator.constants.ApplicationOneColumns;
import com.eprut.validator.constants.IColumnsEnum;
import com.eprut.validator.db.ValidatorDb;
import lombok.extern.slf4j.Slf4j;
import tl.abstractWorkers.AbstractQueueWorker;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

@Slf4j
public class ValidatorWorker extends AbstractQueueWorker<WorkBean> {

    private ValidatorDb database;

    //Код на статус "Оспорен"
    private static final String CONTESTING_CODE = "4";
    private static final String APPLICATION_ONE_CODE = "3";
    private static final String APPLICATION_TWO_CODE = "4";
    private static final String ACCEPTED_INVEST_PROJECT_CODE = "48";
    private static final String PROVINCE_ADMINISTRATION_CODE = "4";
    private static final String MUNICIPALITY_ADMINISTRATION_CODE = "5";
    private static final String REGION_ADMINISTRATION_CODE = "6";
    private static final String COUNTRY_CODE = "1";

    private static final String EXCEL_IMPORT_TYPE = "EXCEL";
    private static final String XML_IMPORT_TYPE = "XML";

    private static final String REQUIRED_FIELD_MESSAGE_EXCEL =
            "В %s: на ред %d: Полето \"%s\" е задължително. Моля въведете валидна стойност.";

    //Номенклатури
    private Map<String, String> actTypes;
    private List<String> actMessageTypes;
    private List<String> actStatusTypes;
    private List<String> actAdministrationTypes;
    private List<String> ekatte;
    private List<String> actAdministrativeUnits;
    private List<String> territoryTypes;
    private List<String> countries;
    private List<String> provinces;
    private List<String> municipalities;
    private List<String> ekattes;
    private Map<String, Long> regions;
    private Map<String, Long> custTypes;
    private Map<Long, List<String>> custRegister;
    private List<String> identifierTypes;
    private Map<String, Long> baseGroupDocContents;
    private Map<String, Long> applicationOneTypes;
    private Map<String, Long> applicationTwoTypes;
    private Map<Long, List<String>> applicationDocSubtypes;
    private Map<String, OfficeInfo> officeInfo;

    /**
     * Initialize abstract que with some number of threads and delays.
     *
     * @param nThreads             number of treads
     * @param initialDelay         delay in see {@link  TimeUnit}.
     * @param periodOfQueueRefresh refresh period in see {@link  TimeUnit}.
     * @param timeUnit             time unit.
     */
    public ValidatorWorker(int nThreads, Long initialDelay, Long periodOfQueueRefresh,
                           TimeUnit timeUnit, ValidatorDb database) {
        super(nThreads, initialDelay, periodOfQueueRefresh, timeUnit);
        this.database = database;
    }

    @Override
    protected void updateWorkerQueue() {
        String logId = UUID.randomUUID().toString();
        try {
            database.getReadyToStart(logId).stream().distinct().filter(e -> !queue.contains(e)).forEach(queue::addLast);
        } catch (Exception e) {
            log.error("{}: updateWorkerQueue error", logId, e);
        }
    }

    @Override
    protected void workerExecutedMethod(String logId, WorkBean firstElementFromQueue) {
        boolean doWork = true;
        try {
            if (database.checkIfNotStarted(logId, firstElementFromQueue)) {
                try {
                    database.start(logId, firstElementFromQueue);
                } catch (Exception e) {
                    if (database.checkIfNotStarted(logId, firstElementFromQueue)) {
                        throw e;
                    } else {
                        doWork = false;
                    }
                }
                if (doWork) {
                    //Зареждане на всички номенклатури, които ще използваме.
                    loadNomenclatures(logId, firstElementFromQueue);

                    List<RegAct> regActs = database.getRegActsByImportId(logId, firstElementFromQueue);

                    if (regActs.isEmpty()) {
                        String errorMsg = "Няма актове за валидиране.";
                        database.logErrorMessage(logId, firstElementFromQueue, errorMsg);
                        throw new IllegalArgumentException(errorMsg);
                    }

                    String registerCode = database.getRegisterCodeByImportId(logId, firstElementFromQueue);
                    List<RegObject> regObjects = database.getRegActObjectsByImportId(logId, firstElementFromQueue);
                    Map<Long, Address> addresses = database.getRegActAddressesByImportId(logId, firstElementFromQueue);
                    List<Customer> customers = database.getRegActCustomersByImportId(logId, firstElementFromQueue);
                    List<RegContDocument> contDocuments =
                            database.getRegActContestingDocsByImportId(logId, firstElementFromQueue);
                    List<RegAppOneDocument> appOneDocuments =
                            database.getRegActAppOneDocsByImportId(logId, firstElementFromQueue);
                    List<RegAppTwoDocument> appTwoDocuments =
                            database.getRegActAppTwoDocsByImportId(logId, firstElementFromQueue);

                    database.finishedPreparing(logId, firstElementFromQueue);

                    Map<Long, RegAct> validRegActs =
                            validateRegActs(logId, firstElementFromQueue, regActs);
                    database.logInfoMessage(logId, firstElementFromQueue,
                            "Брой валидни актове: " + validRegActs.size());

                    List<Long> validRegObjects =
                            validateRegObjects(logId, firstElementFromQueue, validRegActs, regObjects, addresses);
                    database.logInfoMessage(logId, firstElementFromQueue,
                            "Брой валидни обекти: " + validRegObjects.size());

                    List<Long> validCustomers =
                            validateCustomers(logId, firstElementFromQueue, validRegActs, customers, addresses);
                    database.logInfoMessage(logId, firstElementFromQueue,
                            "Брой валидни заявители/възложители: " + validCustomers.size());

                    List<Long> validContestings =
                            validateContestings(logId, firstElementFromQueue, validRegActs, contDocuments);
                    database.logInfoMessage(logId, firstElementFromQueue,
                            "Брой валидни документи за \"Оспорване\": " + validContestings.size());

                    List<Long> validAppOneDocuments =
                            validateAppOneDocuments(logId, firstElementFromQueue, validRegActs, appOneDocuments);
                    database.logInfoMessage(logId, firstElementFromQueue,
                            "Брой валидни документи за \"Приложение 1\": " + validAppOneDocuments.size());

                    List<Long> validAppTwoDocuments =
                            validateAppTwoDocuments(logId, firstElementFromQueue, validRegActs, appTwoDocuments);
                    database.logInfoMessage(logId, firstElementFromQueue,
                            "Брой валидни документи за \"Приложение 2\": " + validAppTwoDocuments.size());

                    checkIfRegActExists(logId, firstElementFromQueue, regActs);

                    //finish

                    if (database.hasErrorWarningMessages(logId, firstElementFromQueue)) {
                        throw new Exception("Открити са грешки или предупреждения при валидация.");
                    }

                    database.finish(logId, firstElementFromQueue);
                }
            }
        } catch (Exception e) {
            try {
                database.error(logId, firstElementFromQueue, e);
            } catch (Exception ex) {
                try {
                    database.logErrorMessage(logId, firstElementFromQueue,
                            "Възникна грешка при опит за стартиране на оброботка.", ex);
                } catch (Exception e1) {
                    //ignore.
                }
                this.workerExceptionHandling(logId, firstElementFromQueue, ex);
            }
        }
    }

    private void loadNomenclatures(String logId, WorkBean work) throws Exception {
        actTypes = database.getRegActTypes(logId, work);
        actMessageTypes = database.getAnnouncementTypes(logId, work);
        actStatusTypes = database.getStatuses(logId, work);
        actAdministrationTypes = database.getAdministrationTypes(logId, work);
        ekatte = database.getEkatte(logId, work);
        actAdministrativeUnits = database.getIssuer(logId, work);
        territoryTypes = database.getTerritoryType(logId, work);
        countries = database.getCountry(logId, work);
        provinces = database.getProvince(logId, work);
        municipalities = database.getMunicipality(logId, work);
        ekattes = database.getEkatte(logId, work);
        regions = database.getRegions(logId, work);
        custTypes = database.getCustomerTypes(logId, work);
        custRegister = database.getCustomerRegister(logId, work);
        identifierTypes = database.getIdentifierType(logId, work);
        baseGroupDocContents = database.getBaseDocContentTypes(logId, work);
        applicationOneTypes =
                database.getApplicationDocTypes(logId, work, baseGroupDocContents.get(APPLICATION_ONE_CODE));
        applicationTwoTypes =
                database.getApplicationDocTypes(logId, work, baseGroupDocContents.get(APPLICATION_TWO_CODE));
        applicationDocSubtypes = database.getApplicationDocSubtypes(logId, work);
        officeInfo = database.getOfficeInfoByEkatte(logId, work);
    }

    private Map<Long, RegAct> validateRegActs(String logId, WorkBean work, List<RegAct> regActs)
            throws Exception {
        Map<Long, RegAct> updatedRegActs = new HashMap<>();
        for (RegAct regAct : regActs) {
            boolean isInvalid = false;

            //Вид на акт е задължително поле, за да можем да проверим дали имаме такъв акт, вкаран в системата.
            String regActType = regAct.getActType();
            if (regActType == null) {
                isInvalid = true;
                logRequiredFieldWarningMessage(logId, work, database, regAct, ActColumns.ACT_TYPE, null);
            }

            //Номер на акт е задължително поле, за да можем да проверим дали имаме такъв акт, вкаран в системата.
            String regActNum = regAct.getActNum();
            if (regActNum == null) {
                isInvalid = true;
                logRequiredFieldWarningMessage(logId, work, database, regAct, ActColumns.NUM_ACT, null);
            }

            String regActAdministrationType = regAct.getAdministration();
            String regActEkatte = regAct.getAdmPopular();
            List<String> administrationTypesWithEkatte =
                    Arrays.asList(PROVINCE_ADMINISTRATION_CODE, MUNICIPALITY_ADMINISTRATION_CODE);
            if (regActAdministrationType != null && administrationTypesWithEkatte.contains(regActAdministrationType)) {
                if (regActEkatte != null && !ekatte.contains(regActEkatte)) {
                    isInvalid = true;
                    String additionalMessage = "Невалиден ЕКАТТЕ код.";
                    logInvalidNomenclatureWarningMessage(logId, work, database, regAct, ActColumns.TERRITORY,
                            additionalMessage, null);
                }
            } else if (regActAdministrationType != null &&
                    regActAdministrationType.equals(REGION_ADMINISTRATION_CODE)) {
                if (regActEkatte != null && !regions.containsKey(regActEkatte)) {
                    isInvalid = true;
                    String additionalMessage = "Невалиден НСИ код.";
                    logInvalidNomenclatureWarningMessage(logId, work, database, regAct, ActColumns.TERRITORY,
                            additionalMessage, null);
                }
            } else if (regActEkatte != null) {
                isInvalid = true;
                String additionalMessage =
                        "Въвежда се само за \"Областна администрация\", \"Общинска администрация\" и \"Районна администрация\".";
                logInvalidNomenclatureWarningMessage(logId, work, database, regAct, ActColumns.TERRITORY,
                        additionalMessage,
                        null);
            }

            if (isInvalid) {
                regAct.setIsValid(false);
                database.updateRegActValidity(logId, work, regAct);
                //continue;
            }

            updatedRegActs.put(regAct.getId(), regAct);
        }

        return updatedRegActs;
    }

    private List<Long> validateRegObjects(String logId, WorkBean work, Map<Long, RegAct> regActs,
                                          List<RegObject> regObjects, Map<Long, Address> addresses)
            throws Exception {
        List<Long> validRegObjects = new ArrayList<>();
        for (RegObject regObject : regObjects) {
            boolean isInvalid = false;

            //Ако актът, към който е вързан обекта, не е валиден, то няма смисъл да продължаваме надолу с проверката?
            Long regActId = regObject.getRegActId();
            RegAct regAct = regActs.get(regActId);
            if (!regAct.getIsValid()) {
                database.updateRegActObjectValidity(logId, work, regObject);
                String additionalMessage = "Обектът е свързан към невалиден акт.";
                logWarningMessage(logId, work, database, regObject, additionalMessage, regAct);
                continue;
            }

            //Проверка на валидност на адрес.
            if (regObject.getAddressId() != null) {
                boolean isAddressValid =
                        validateAddress(logId, work, regAct, regObject, addresses.get(regObject.getAddressId()));
                if (!isAddressValid) {
                    isInvalid = true;
                    String additionalMessage = "Въведеният адрес е невалиден.";
                    logWarningMessage(logId, work, database, regObject, additionalMessage, regAct);
                }
            }

            if (isInvalid) {
                database.updateRegActObjectValidity(logId, work, regObject);
                continue;
            }

            validRegObjects.add(regObject.getId());
        }

        return validRegObjects;
    }

    private List<Long> validateCustomers(String logId, WorkBean work, Map<Long, RegAct> regActs,
                                         List<Customer> customers,
                                         Map<Long, Address> addresses)
            throws Exception {
        List<Long> validCustomers = new ArrayList<>();

        for (Customer customer : customers) {
            boolean isInvalid = false;

            //Ако актът, към който е вързан заявител/възложител, не е валиден, то няма смисъл да продължаваме надолу с проверката?
            Long regActId = customer.getRegActId();
            RegAct regAct = regActs.get(regActId);
            if (!regAct.getIsValid()) {
                database.updateCustomerValidity(logId, work, customer);
                String additionalMessage = "Заявител/Възложителят е свързан към невалиден акт.";
                logWarningMessage(logId, work, database, customer, additionalMessage, regAct);
                continue;
            }

            if (customer.getCapacity() != null && customer.getCustomerType() == null) {
                database.updateCustomerValidity(logId, work, customer);
                String additionalMessage = "Заявител/Възложителят не може да има качество без да има \"Вид на заявител\".";
                logWarningMessage(logId, work, database, customer, additionalMessage, regAct);
                continue;
            }

            if (customer.getCustomerType() != null) {
                if (customer.getCustomerType().equals(COUNTRY_CODE) && customer.getCapacity() != null) {
                    database.updateCustomerValidity(logId, work, customer);
                    String additionalMessage = "Заявител/Възложителят не може да има качество, когато видът на заявителя е \"Държавата\".";
                    logWarningMessage(logId, work, database, customer, additionalMessage, regAct);
                    continue;
                }
            }

            //Проверка на валидност на адрес.
            if (customer.getAddressId() != null) {
                boolean isAddressValid =
                        validateAddress(logId, work, regAct, customer, addresses.get(customer.getAddressId()));
                if (!isAddressValid) {
                    isInvalid = true;
                    String additionalMessage = "Въведеният адрес е невалиден.";
                    logWarningMessage(logId, work, database, customer, additionalMessage, regAct);
                }
            }

            if (isInvalid) {
                database.updateCustomerValidity(logId, work, customer);
                continue;
            }

            validCustomers.add(customer.getId());
        }

        return validCustomers;
    }

    private Boolean validateAddress(String logId, WorkBean work, RegAct regAct, ILogInfo object, Address address)
            throws Exception {
        boolean isInvalid = false;

//        //Проверка на валидност на номенклатура за "Държава".
//        String country = address.getCountry();
//        if (!isNomenclatureValid(logId, work, database, address, country, AddressColumns.COUNTRY,
//                countries::contains, regAct)) {
//            isInvalid = true;
//        }
//
//        //Проверка на валидност на номенклатура за "Област".
//        String province = address.getDistrict();
//        if (!isNomenclatureValid(logId, work, database, address, province, AddressColumns.DISTRICT,
//                provinces::contains, regAct)) {
//            isInvalid = true;
//        }
//
//        //Проверка на валидност на номенклатура за "Община".
//        String municipality = address.getMunicipality();
//        if (!isNomenclatureValid(logId, work, database, address, municipality, AddressColumns.MUNICIPALITY,
//                municipalities::contains, regAct)) {
//            isInvalid = true;
//        }

        String settlement = address.getSettlement();
        String village = address.getVillage();

        //Проверка дали са въведени и двете - населено място и селищно образувание.
        if (settlement != null && village != null) {
            isInvalid = true;
            String additionalMessage = String.format(
                    "За %s са въведени невалидни стойности - позволено е въвеждането само в една колона (Населено място или Селищно образувание).",
                    address.getLabel());
            logWarningMessage(logId, work, database, object, additionalMessage, regAct);
        }

        //Проверка на валидност на номенклатура за "Населено място".
//        if (!isNomenclatureValid(logId, work, database, address, settlement, AddressColumns.SETTLEMENT,
//                ekattes::contains, regAct)) {
//            isInvalid = true;
//        }
//
//        //Проверка на валидност на номенклатура за "Селищно образувание".
//        if (!isNomenclatureValid(logId, work, database, address, village, AddressColumns.VILLAGE, ekattes::contains,
//                regAct)) {
//            isInvalid = true;
//        }
//
//        //Проверка на валидност на номенклатура за "Район".
//        String region = address.getRegion();
//        if (!isNomenclatureValid(logId, work, database, address, region, AddressColumns.REGION, regions::containsKey,
//                regAct)) {
//            isInvalid = true;
//        }

        if (isInvalid) {
            database.updateAddressValidity(logId, work, address);
            return false;
        }

        return true;
    }

    private List<Long> validateContestings(String logId, WorkBean work, Map<Long, RegAct> regActs,
                                           List<RegContDocument> contDocuments)
            throws Exception {
        List<Long> validContestings = new ArrayList<>();
        for (RegContDocument contDocument : contDocuments) {
            boolean isInvalid = false;

            //Ако актът, към който е вързано оспорването, не е валиден, то няма смисъл да продължаваме надолу с проверката?
            Long regActId = contDocument.getRegActId();
            RegAct regAct = regActs.get(regActId);
            if (!regAct.getIsValid()) {
                database.updateContestingValidity(logId, work, contDocument);
                String additionalMessage = "Оспорването е свързано към невалиден акт.";
                logWarningMessage(logId, work, database, contDocument, additionalMessage, regAct);
                continue;
            }

            if (!Objects.equals(regAct.getStatus(), CONTESTING_CODE)) {
                isInvalid = true;
                String additionalMessage = "Актът, свързан с оспорването, е с невалиден статус: " + regAct.getStatus();
                logWarningMessage(logId, work, database, contDocument, additionalMessage, regAct);
            }

            //todo shte ima i drugi proverki

            if (isInvalid) {
                database.updateContestingValidity(logId, work, contDocument);
                continue;
            }

            validContestings.add(contDocument.getId());
        }
        return validContestings;
    }

    //todo кое точно трябва да валидираме?
    private List<Long> validateAppOneDocuments(String logId, WorkBean work, Map<Long, RegAct> regActs,
                                               List<RegAppOneDocument> appOneDocuments)
            throws Exception {
        List<Long> validAppOneDocuments = new ArrayList<>();
        for (RegAppOneDocument appOneDocument : appOneDocuments) {
            boolean isInvalid = false;

            //Ако актът, към който е вързано Приложение 1, не е валиден, то няма смисъл да продължаваме надолу с проверката?
            Long regActId = appOneDocument.getRegActId();
            RegAct regAct = regActs.get(regActId);
            if (!regAct.getIsValid()) {
                database.updateAppOneDocumentValidity(logId, work, appOneDocument);
                String additionalMessage = "Приложението е свързано към невалиден акт.";
                logWarningMessage(logId, work, database, appOneDocument, additionalMessage, regAct);
                continue;
            }

            //Полето е задължително в базата
            String appOneSubtype = appOneDocument.getSubType();
            if (appOneSubtype == null) {
                isInvalid = true;
                logRequiredFieldWarningMessage(logId, work, database, appOneDocument,
                        ApplicationOneColumns.APPLICATION_ONE_SUBCATEGORY, regAct);
            }

            if (isInvalid) {
                database.updateAppOneDocumentValidity(logId, work, appOneDocument);
                continue;
            }

            validAppOneDocuments.add(appOneDocument.getId());
        }
        return validAppOneDocuments;
    }

    private List<Long> validateAppTwoDocuments(String logId, WorkBean work, Map<Long, RegAct> regActs,
                                               List<RegAppTwoDocument> appTwoDocuments)
            throws Exception {
        List<Long> validAppTwoDocuments = new ArrayList<>();
        for (RegAppTwoDocument appTwoDocument : appTwoDocuments) {
            boolean isInvalid = false;

            //Ако актът, към който е вързано Приложение 2, не е валиден, то няма смисъл да продължаваме надолу с проверката?
            Long regActId = appTwoDocument.getRegActId();
            RegAct regAct = regActs.get(regActId);
            if (!regAct.getIsValid()) {
                database.updateAppTwoDocumentValidity(logId, work, appTwoDocument);
                String additionalMessage = "Приложението е свързано към невалиден акт.";
                logWarningMessage(logId, work, database, appTwoDocument, additionalMessage, regAct);
                continue;
            }

            String appTwoType = appTwoDocument.getType();
            String appTwoSubtype = appTwoDocument.getSubType();

            if (appTwoSubtype != null && (appTwoType == null || !appTwoType.equals(ACCEPTED_INVEST_PROJECT_CODE))) {
                isInvalid = true;
                String additionalMessage =
                        "Приложението има зададен подтип. Подтипът се задава само при \"Одобрен инвестиционен проект\".";
                logWarningMessage(logId, work, database, appTwoDocument, additionalMessage, regAct);
            }


            if (isInvalid) {
                database.updateAppTwoDocumentValidity(logId, work, appTwoDocument);
                continue;
            }

            validAppTwoDocuments.add(appTwoDocument.getId());
        }

        return validAppTwoDocuments;
    }

    private <T extends IColumnsEnum> void logRequiredFieldWarningMessage(String logId, WorkBean work, ValidatorDb db,
                                                                         ILogInfo obj, T column,
                                                                         @Nullable RegAct validRegAct)
            throws Exception {
        String columnName = column.getColumnName();
        String importType = work.getImportType();
        boolean isXml = XML_IMPORT_TYPE.equals(importType);

        String entityLabel = obj.getLabel();
        int excelRow = obj.getExcelRow();

        String message = "";

        if (isXml) {
            String actType = "";
            String actNum = "";

            if (obj instanceof RegAct regAct) {
                actType = regAct.getActType() != null ? actTypes.get(regAct.getActType()) : "Няма въведен вид";
                actNum = regAct.getActNum() != null ? regAct.getActNum() : "Няма въведен номер";
            } else if (validRegAct != null) {
                actType =
                        validRegAct.getActType() != null ? actTypes.get(validRegAct.getActType()) : "Няма въведен вид";
                actNum = validRegAct.getActNum() != null ? validRegAct.getActNum() : "Няма въведен номер";
            }

            message = String.format(
                    "В %s: За акт \"%s\"/%s: Полето \"%s\" е задължително. Моля въведете валидна стойност.",
                    entityLabel, actType, actNum, columnName);
        } else {
            message = String.format("В %s: на ред %d: Полето \"%s\" е задължително. Моля въведете валидна стойност.",
                    entityLabel, excelRow, columnName);
        }

        db.logWarningMessage(logId, work, message);
    }

    private <T extends IColumnsEnum> void logInvalidNomenclatureWarningMessage(String logId, WorkBean work,
                                                                               ValidatorDb db,
                                                                               ILogInfo obj, T column,
                                                                               String additionalMessage,
                                                                               @Nullable RegAct validRegAct)
            throws Exception {
        String columnName = column.getColumnName();
        String importType = work.getImportType();
        boolean isXml = XML_IMPORT_TYPE.equals(importType);

        String entityLabel = obj.getLabel();
        int excelRow = obj.getExcelRow();

        String message = "";

        if (isXml) {
            String actType = "";
            String actNum = "";

            if (obj instanceof RegAct regAct) {
                actType = regAct.getActType() != null ? actTypes.get(regAct.getActType()) : "Няма въведен вид";
                actNum = regAct.getActNum() != null ? regAct.getActNum() : "Няма въведен номер";
            } else if (validRegAct != null) {
                actType =
                        validRegAct.getActType() != null ? actTypes.get(validRegAct.getActType()) : "Няма въведен вид";
                actNum = validRegAct.getActNum() != null ? validRegAct.getActNum() : "Няма въведен номер";
            }

            message =
                    String.format("В %s: За акт \"%s\"/%s: Невалидна стойност на номенклатура в колона \"%s\". %s",
                            entityLabel, actType, actNum, columnName, additionalMessage);
        } else {
            message = String.format("В %s: на ред %d: Невалидна стойност на номенклатура в колона \"%s\". %s",
                    entityLabel, excelRow, columnName, additionalMessage);
        }

        db.logWarningMessage(logId, work, message);
    }

    private <T extends IColumnsEnum> void logWarningMessage(String logId, WorkBean work, ValidatorDb db,
                                                            ILogInfo obj, String additionalMessage,
                                                            @Nullable RegAct validRegAct)
            throws Exception {
        String importType = work.getImportType();
        boolean isXml = XML_IMPORT_TYPE.equals(importType);

        String entityLabel = obj.getLabel();
        int excelRow = obj.getExcelRow();

        String message = "";

        if (isXml) {
            String actType = "";
            String actNum = "";

            if (obj instanceof RegAct regAct) {
                actType = regAct.getActType() != null ? actTypes.get(regAct.getActType()) : "Няма въведен вид";
                actNum = regAct.getActNum() != null ? regAct.getActNum() : "Няма въведен номер";
            } else if (validRegAct != null) {
                actType =
                        validRegAct.getActType() != null ? actTypes.get(validRegAct.getActType()) : "Няма въведен вид";
                actNum = validRegAct.getActNum() != null ? validRegAct.getActNum() : "Няма въведен номер";
            }

            message = String.format("В %s: За акт \"%s\"/%s: %s", entityLabel, actType, actNum, additionalMessage);
        } else {
            message = String.format("В %s: на ред %d: %s", entityLabel, excelRow, additionalMessage);
        }

        db.logWarningMessage(logId, work, message);
    }

    private <T extends IColumnsEnum> boolean isNomenclatureValid(String logId, WorkBean work, ValidatorDb db,
                                                                 ILogInfo obj,
                                                                 String fieldValue, T column,
                                                                 @Nullable Predicate<String> nomenclatures,
                                                                 @Nullable RegAct validRegAct)
            throws Exception {
        if (fieldValue != null && nomenclatures != null && !nomenclatures.test(fieldValue)) {
            logInvalidNomenclatureWarningMessage(logId, work, db, obj, column, "", validRegAct);

            return false;
        }
        return true;
    }

    private void checkIfRegActExists(String logId, WorkBean work, List<RegAct> regActs) throws Exception {
        for (RegAct regAct : regActs) {
            UUID rnOfficeUUID;
            if (regAct.getAdministration().equals(Nomenclatures.PROVINCE_ADMINISTRATION.getCode())) {
                OfficeInfo office = officeInfo.get(regAct.getAdmPopular());
                rnOfficeUUID = UUID.fromString(database.getOfficeIdByProvince(logId, work, office.getProvinceId()));
            } else if (regAct.getAdministration().equals(Nomenclatures.MUNICIPALITY_ADMINISTRATION.getCode())) {
                OfficeInfo office = officeInfo.get(regAct.getAdmPopular());
                rnOfficeUUID = UUID.fromString(database.getOfficeIdByMunAndProvince(logId, work, office.getMunId(),
                        office.getProvinceId()));
            } else if (regAct.getAdministration().equals(Nomenclatures.REGION_ADMINISTRATION.getCode())) {
                Long regionId = regions.get(regAct.getAdmPopular());
                rnOfficeUUID = UUID.fromString(database.getOfficeIdByRegion(logId, work, regionId));
            } else {
                rnOfficeUUID = UUID.fromString(database.getOfficeIdByAdministrationType(logId, work,
                        Long.valueOf(regAct.getAdministration())));
            }

            CheckExistenceInfo check = database.getCheckUUDIs(logId, work, regAct.getId());

            Long isPresent = database.checkForExistingActs(logId, work, regAct, rnOfficeUUID, check.getPissueridUUID(),
                    check.getPdoctypeidUUID());

            if (isPresent != null && isPresent == 1) {
                String additionalMessage =
                        "Документът съществува в регистъра. Не можете да прикачвате вече публикувани документи за съответния вид на акт, номер на акт, дата, администрация и административен орган.";
                logWarningMessage(logId, work, database, regAct, additionalMessage, null);
            }

        }
    }

    @Override
    protected void workerExceptionHandling(String logId, WorkBean firstElementFromQueue, Exception e) {
        log.error("{} - ValidatorWorker with WorkBean : {} ERROR {}", logId, firstElementFromQueue, e, e);
    }

    @Override
    protected void workerStarted(String logId, WorkBean firstElementFromQueue) {
        log.debug("{} - ValidatorWorker with WorkBean : {} has STARTED working", logId, firstElementFromQueue);
    }

    @Override
    protected void workerFinished(String logId, WorkBean firstElementFromQueue) {
        log.debug("{} - ValidatorWorker with WorkBean : {} has FINISHED working", logId, firstElementFromQueue);
    }
}