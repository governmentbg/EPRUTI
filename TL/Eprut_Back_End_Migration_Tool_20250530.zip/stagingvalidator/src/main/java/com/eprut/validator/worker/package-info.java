/**
 * Project: eprut
 * Module: com.eprut.validator.worker
 * File: package-info
 * <p>
 * Created By dbyalev on 13.5.2025 г.
 * Description: Логика за обработка на данните за валидация.
 * <p>
 * © 2025 dbyalev. All right reserved.
 */
package com.eprut.validator.worker;
