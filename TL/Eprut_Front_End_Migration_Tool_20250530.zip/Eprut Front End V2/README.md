# EPRUT.Web

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 18.0.0.

## Development server

Run `npm install` to install the required packages before launching a dev server.
Run `ng serve --proxy-config proxy.conf.json --configuration development or npm start` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test --code-coverage or npm run test` to execute the unit tests with code coverage via [Karma](https://karma-runner.github.io).
Run `ng test --no-watch --code-coverage` to execute the unit tests with code coverage and the browser will automatically close after the unit tests have finished.
After the test has finished it's proccess check the newly created coverage folder and open the first index.html to see the level of coverage for each individual module in the application.

## Deployment

To deploy the application, follow these steps:
1. Build the project using `npm run build-dev or ng build --base-href /import/`.
2. Copy the contents of the `dist/` directory to your web server.
3. Configure your web server to serve the application.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
