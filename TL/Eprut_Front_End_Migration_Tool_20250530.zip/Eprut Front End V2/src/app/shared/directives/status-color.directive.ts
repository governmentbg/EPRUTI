import { Directive, ElementRef, Input, OnChanges, Renderer2, SimpleChanges } from '@angular/core';
import { StatusCodes } from '@shared/enums/status-codes';
import { ERROR_STATUSES } from '@shared/components/progressbar/progressbar.component';

@Directive({
  selector: '[appStatusColor]',
  standalone: true
})
export class StatusColorDirective implements OnChanges {

  @Input() statusCode: string;

  errorCodes: Set<StatusCodes> = ERROR_STATUSES;
  successCode: string = StatusCodes.TRANSFER_DONE;

  constructor(private _el: ElementRef, private _renderer: Renderer2) { }

  ngOnChanges(changes: SimpleChanges): void {
    let color: string;

    if (changes['statusCode']) {
      if (this.errorCodes.has(this.statusCode as StatusCodes)) {
        color = '#ab3030';
      } else if (this.statusCode === this.successCode) {
        color = '#30ab42';
      } else if (this.statusCode ===  StatusCodes.TRANSFER_READY) {
        color = '#2E6DA4';
      }
    }

    this._renderer.removeClass(this._el.nativeElement, color);
    this._renderer.setStyle(this._el.nativeElement, 'color', color);
  }
}
