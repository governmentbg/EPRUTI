import { StatusColorDirective } from './status-color.directive';
import { ElementRef, Renderer2 } from '@angular/core';
import { TestBed } from '@angular/core/testing';

describe('StatusColorDirective', () => {
  let elementRef: ElementRef;
  let renderer: Renderer2;
  let directive: StatusColorDirective;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        StatusColorDirective,
        { provide: ElementRef, useValue: { nativeElement: document.createElement('div') } },
        { provide: Renderer2, useValue: jasmine.createSpyObj('Renderer2', ['setStyle', 'removeClass']) }
      ]
    });

    elementRef = TestBed.inject(ElementRef);
    renderer = TestBed.inject(Renderer2);
    directive = TestBed.inject(StatusColorDirective);
  });

  it('should create an instance', () => {
    expect(directive).toBeTruthy();
  });

  it('should set color to red for error codes', () => {
    directive.statusCode = 'EX_ERROR';
    directive.ngOnChanges({ statusCode: { currentValue: 'EX_ERROR', previousValue: null, firstChange: true, isFirstChange: () => true } });
    expect(renderer.setStyle).toHaveBeenCalledWith(elementRef.nativeElement, 'color', '#ab3030');
  });

  it('should set color to green for success code', () => {
    directive.statusCode = 'TRANSFER_DONE';
    directive.ngOnChanges({ statusCode: { currentValue: 'TRANSFER_DONE', previousValue: null, firstChange: true, isFirstChange: () => true } });
    expect(renderer.setStyle).toHaveBeenCalledWith(elementRef.nativeElement, 'color', '#30ab42');
  });

  it('should set color to yellow for TRANSFER_READY status', () => {
    directive.statusCode = 'TRANSFER_READY';
    directive.ngOnChanges({ statusCode: { currentValue: 'TRANSFER_READY', previousValue: null, firstChange: true, isFirstChange: () => true } });
    expect(renderer.setStyle).toHaveBeenCalledWith(elementRef.nativeElement, 'color', '#c1b207');
  });
});