import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BreadcrumbComponent } from './breadcrumb.component';
import { NavigationEnd, Router } from '@angular/router';
import { MenuService } from '@core/bootstrap/menu.service';
import { TranslateModule } from '@ngx-translate/core';
import { of, Subject } from 'rxjs';
import { ChangeDetectorRef } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RegistersService } from 'app/routes/registers/registers.service';
import { SettingsService } from '@core';
import { DisplayValueWithCodeModel } from '@shared/models/display-value-with-code-model';

describe('BreadcrumbComponent', () => {
  let component: BreadcrumbComponent;
  let fixture: ComponentFixture<BreadcrumbComponent>;
  let menuServiceStub: Partial<MenuService>;
  let routerEventsSubject: Subject<any>;

  beforeEach(async () => {
    routerEventsSubject = new Subject<any>();

    menuServiceStub = {
      change: () => of([]),
      getLevel: (routes: string[], isSubMenu: boolean) => []
    };

    await TestBed.configureTestingModule({
      imports: [
        BreadcrumbComponent,
        TranslateModule.forRoot(),
        HttpClientTestingModule
      ],
      providers: [
        { provide: Router, useValue: { events: routerEventsSubject.asObservable() } },
        { provide: MenuService, useValue: menuServiceStub },
        RegistersService,
        SettingsService,
        ChangeDetectorRef
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should generate breadcrumb on init', () => {
    spyOn(component, 'genBreadcrumb');
    component.ngOnInit();
    expect(component.genBreadcrumb).toHaveBeenCalled();
  });

  it('should unsubscribe on destroy', () => {
    spyOn(component['_unsubscribeAll'], 'next');
    spyOn(component['_unsubscribeAll'], 'complete');
    component.ngOnDestroy();
    expect(component['_unsubscribeAll'].next).toHaveBeenCalled();
    expect(component['_unsubscribeAll'].complete).toHaveBeenCalled();
  });

  it('should track by nav item', () => {
    const item = 'test';
    const index = 1;
    expect(component.trackByNavItem(index, item)).toBe(item);
  });

  it('should set breadcrumbTitle to register description when register is available', () => {
    const registerBreadcrumb: DisplayValueWithCodeModel = { id: 1, code: 'testCode', description: 'testDescription' };
    spyOn(component['_registersService'], 'getRegisterDescription').and.returnValue(of(registerBreadcrumb));
    component.registerCode = 'testCode';
    component.genBreadcrumb();
    expect(component.breadcrumbTitle).toBe(registerBreadcrumb.description);
  });

  it('should call genBreadcrumb on NavigationEnd event', () => {
    const event = new NavigationEnd(1, '/test', '/test');
    spyOn(component, 'genBreadcrumb');
    component.ngOnInit();
    routerEventsSubject.next(event);
    expect(component.genBreadcrumb).toHaveBeenCalled();
  });
});
