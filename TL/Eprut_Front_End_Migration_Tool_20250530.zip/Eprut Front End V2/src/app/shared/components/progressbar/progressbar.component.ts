import { CommonModule } from '@angular/common';
import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { ProgressBarModule } from 'primeng/progressbar';
import { ProgressGroupModel } from '@shared/models/progress-group-model';
import { StatusCodes } from '@shared/enums/status-codes';

export const ERROR_STATUSES = new Set([
  StatusCodes.IMP_ERROR,
  StatusCodes.EX_ERROR,
  StatusCodes.XML_ERROR,
  StatusCodes.DATA_ERROR,
  StatusCodes.TRANSFER_ERROR
]);

export const PROGRESS_GROUPS: ProgressGroupModel[] = [
  {
    statusCodes: [StatusCodes.IMP_ERROR],
    startPercentage: 0,
    endPercentage: 0
  },
  {
    statusCodes: [StatusCodes.EX_UPLOADED, StatusCodes.XML_UPLOADED],
    startPercentage: 0,
    endPercentage: 12.5
  },
  {
    statusCodes: [StatusCodes.EX_PREPARING, StatusCodes.XML_PREPARING],
    startPercentage: 12.5,
    endPercentage: 25
  },
  {
    statusCodes: [StatusCodes.EX_ERROR, StatusCodes.XML_ERROR],
    startPercentage: 0,
    endPercentage: 0
  },
  {
    statusCodes: [StatusCodes.EX_WORKING, StatusCodes.XML_WORKING],
    startPercentage: 37.5,
    endPercentage: 50
  },
  {
    statusCodes: [StatusCodes.DATA_UPLOADED],
    startPercentage: 62.5,
    endPercentage: 75
  },
  {
    statusCodes: [StatusCodes.DATA_PREPARING],
    startPercentage: 75,
    endPercentage: 87.5
  },
  {
    statusCodes: [StatusCodes.DATA_VALIDATING, StatusCodes.DATA_ERROR],
    startPercentage: 87.5,
    endPercentage: 100
  },
  {
    statusCodes: [StatusCodes.TRANSFER_READY],
    startPercentage: 100,
    endPercentage: 100
  },
  {
    statusCodes: [StatusCodes.TRANSFER_ACCEPTED],
    startPercentage: 0,
    endPercentage: 25
  },
  {
    statusCodes: [StatusCodes.TRANSFER_PREPARING],
    startPercentage: 25,
    endPercentage: 50
  },
  {
    statusCodes: [StatusCodes.TRANSFER_WORKING],
    startPercentage: 50,
    endPercentage: 100
  },
  {
    statusCodes: [StatusCodes.TRANSFER_ERROR, StatusCodes.TRANSFER_DONE],
    startPercentage: 100,
    endPercentage: 100
  }
];

@Component({
  selector: 'app-progressbar',
  standalone: true,
  imports: [
    CommonModule,
    ProgressBarModule
  ],
  templateUrl: './progressbar.component.html',
  styleUrl: './progressbar.component.scss'
})
export class ProgressbarComponent implements OnChanges, OnInit {

  @Input() statusCode: string;
  @Input() uploadDate: string;
  @Input() target: number;

  value: number = 0;
  valueColor: string = '#2E6DA4';
  showErrorIcon: boolean = false;
  showTransferDoneIcon: boolean = false;
  showTransferReadyIcon: boolean = false;

  interval: any

  constructor() {}

  ngOnInit(): void {
    if (ERROR_STATUSES.has(this.statusCode as StatusCodes)) {
      this.showErrorIcon = true;
      this.valueColor = '#ab3030';
    } else if (this.statusCode === StatusCodes.TRANSFER_DONE) {
      this.showTransferDoneIcon = true;
      this.valueColor = '#30ab42'; 
    } else if (this.statusCode === StatusCodes.TRANSFER_READY) {
      this.showTransferReadyIcon = true;
      this.valueColor = '#2E6DA4';
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['target'] && changes['target'].currentValue != null) {
      const newTarget: number = changes['target'].currentValue;

      if (newTarget <= this.value) {
        return;
      }

      const uploadTime = new Date(this.uploadDate);
      const now = new Date();
      const diffMs = now.getTime() - uploadTime.getTime();
      const twoHoursMs = 2 * 60 * 60 * 1000;

      if (diffMs > twoHoursMs || this.showErrorIcon || this.showTransferDoneIcon || this.showTransferReadyIcon) {
        this.value = newTarget;
      } else {
        this.animateProgress(newTarget, 10000);
      }
    }
  }

  animateProgress(target: number, duration: number): void {
    if (this.interval) {
      clearInterval(this.interval);
    }
    
    let animatedValue = this.value;
    const delta = target - animatedValue;
    const incrementMs = 1000;
    const steps = duration / incrementMs;
    const stepIncrement = delta / steps;
    let currentStep = 0;
    
    this.interval = setInterval(() => {
      currentStep++;
      animatedValue += stepIncrement;
      this.value = currentStep < steps ? Math.ceil(animatedValue) : target;
      if (currentStep >= steps) {
        clearInterval(this.interval);
      }
    }, incrementMs);
  }
}
