import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ErrorCodeComponent } from './error-code.component';
import { TranslateModule } from '@ngx-translate/core';
import { MatButtonModule } from '@angular/material/button';
import { RouterTestingModule } from '@angular/router/testing';

describe('ErrorCodeComponent', () => {
  let component: ErrorCodeComponent;
  let fixture: ComponentFixture<ErrorCodeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, MatButtonModule, ErrorCodeComponent, TranslateModule.forRoot()],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the correct code, title, and message', () => {
    component.code = '404';
    component.title = 'Not Found';
    component.message = 'The page you are looking for does not exist.';
    fixture.detectChanges();

    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.matero-error-code').textContent).toContain('404');
    expect(compiled.querySelector('.matero-error-title').textContent).toContain('Not Found');
    expect(compiled.querySelector('.matero-error-message').textContent).toContain('The page you are looking for does not exist.');
  });
});
