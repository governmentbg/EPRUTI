import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LoadingService } from './loading.service';

describe('LoadingService', () => {
    let service: LoadingService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [LoadingService]
        });
        service = TestBed.inject(LoadingService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should show the loading bar', () => {
        service.show();
        service.show$.subscribe(show => {
            expect(show).toBeTrue();
        });
    });

    it('should hide the loading bar', () => {
        service.hide();
        service.show$.subscribe(show => {
            expect(show).toBeFalse();
        });
    });

    it('should set auto mode', () => {
        service.setAutoMode(false);
        service.auto$.subscribe(auto => {
            expect(auto).toBeFalse();
        });
    });

    it('should set mode', () => {
        service.setMode('determinate');
        service.mode$.subscribe(mode => {
            expect(mode).toBe('determinate');
        });
    });

    it('should set progress', () => {
        service.setProgress(50);
        service.progress$.subscribe(progress => {
            expect(progress).toBe(50);
        });
    });

    it('should not set progress out of range', () => {
        spyOn(console, 'error');
        service.setProgress(150);
        expect(console.error).toHaveBeenCalledWith('Progress value must be between 0 and 100!');
    });

    it('should set loading status for a URL', () => {
        service._setLoadingStatus(true, 'test-url');
        service.show$.subscribe(show => {
            expect(show).toBeTrue();
        });
    });

    it('should clear loading status for a URL', () => {
        service._setLoadingStatus(true, 'test-url');
        service._setLoadingStatus(false, 'test-url');
        service.show$.subscribe(show => {
            expect(show).toBeFalse();
        });
    });

    it('should not set loading status without URL', () => {
        spyOn(console, 'error');
        service._setLoadingStatus(true, '');
        expect(console.error).toHaveBeenCalledWith('The request URL must be provided!');
    });
});
