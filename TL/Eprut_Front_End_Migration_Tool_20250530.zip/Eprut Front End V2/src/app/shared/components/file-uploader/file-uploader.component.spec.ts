import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FileUploaderComponent } from './file-uploader.component';
import { MatSnackBarModule, MatSnackBar } from '@angular/material/snack-bar';
import { TranslateModule } from '@ngx-translate/core';
import { RegistersService } from 'app/routes/registers/registers.service';
import { of, Subject, throwError } from 'rxjs';

describe('FileUploaderComponent', () => {
  let component: FileUploaderComponent;
  let fixture: ComponentFixture<FileUploaderComponent>;
  let registersService: jasmine.SpyObj<RegistersService>;
  let snackBar: MatSnackBar;

  beforeEach(async () => {
    registersService = jasmine.createSpyObj('RegistersService', ['submitFile', 'refreshFiles$']);
    registersService.refreshFiles$ = new Subject();
    await TestBed.configureTestingModule({
      imports: [FileUploaderComponent, MatSnackBarModule, TranslateModule.forRoot()],
      providers: [{ provide: RegistersService, useValue: registersService }]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FileUploaderComponent);
    component = fixture.componentInstance;
    snackBar = TestBed.inject(MatSnackBar);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should handle file change', () => {
    const file = new File([''], 'test.zip', { type: 'application/zip' });
    const event = { target: { files: [file] } };
    spyOn(component, 'uploadFile');

    component.onFileChange(event as any);

    expect(component.uploadFile).toHaveBeenCalledWith(file);
  });

  it('should upload a valid file', () => {
    const file = new File([''], 'test.zip', { type: 'application/zip' });

    component.uploadFile(file);

    expect(component.selectedFile).toBe(file);
    expect(component.fileName()).toBe('test.zip');
    expect(component.uploadSuccess).toBeTrue();
    expect(component.uploadError).toBeFalse();
  });

  it('should show error for invalid file', () => {
    const file = new File([''], 'test.txt', { type: 'text/plain' });
    spyOn(snackBar, 'open');

    component.uploadFile(file);

    expect(component.uploadSuccess).toBeFalse();
    expect(component.uploadError).toBeTrue();
    expect(snackBar.open).toHaveBeenCalled();
  });

  it('should handle file submission error', () => {
    const file = new File([''], 'test.zip', { type: 'application/zip' });
    component.selectedFile = file;
    registersService.submitFile.and.returnValue(throwError(() => new Error('Error')));

    component.submitFile();

    expect(registersService.submitFile).toHaveBeenCalledWith(component.registerCode, file);
  });

  it('should handle file drop', () => {
    const file = new File([''], 'test.zip', { type: 'application/zip' });
    const event = { preventDefault: () => {}, dataTransfer: { files: [file] } } as unknown as DragEvent;
    spyOn(component, 'uploadFile');

    component.onFileDrop(event);

    expect(component.uploadFile).toHaveBeenCalledWith(file);
  });

  it('should handle drag over', () => {
    const event = { preventDefault: () => {} } as DragEvent;
    spyOn(event, 'preventDefault');

    component.onDragOver(event);

    expect(event.preventDefault).toHaveBeenCalled();
  });

  it('should return if file is not truthy on file change', () => {
    const event = { target: { files: [] } };
    spyOn(component, 'uploadFile');

    component.onFileChange(event as any);

    expect(component.uploadFile).not.toHaveBeenCalled();
  });

  it('should handle successful file submission', () => {
    const file = new File([''], 'test.zip', { type: 'application/zip' });
    component.selectedFile = file;
    registersService.submitFile.and.returnValue(of({ id: 1, statusId: 1, userId: 'test' }));
    spyOn(snackBar, 'open');
    spyOn(registersService.refreshFiles$, 'next');
    spyOn(component, 'removeFile');

    component.submitFile();

    expect(registersService.submitFile).toHaveBeenCalledWith(component.registerCode, file);
    expect(snackBar.open).toHaveBeenCalled();
    expect(registersService.refreshFiles$.next).toHaveBeenCalled();
    expect(component.removeFile).toHaveBeenCalled();
  });

  it('should remove file', () => {
    component.removeFile();

    expect(component.selectedFile).toBeNull();
    expect(component.fileName()).toBe('');
    expect(component.fileSize()).toBe(0);
    expect(component.uploadSuccess).toBeFalse();
    expect(component.uploadError).toBeFalse();
    expect(component.uploadProgress()).toBe(0);
  });
});
