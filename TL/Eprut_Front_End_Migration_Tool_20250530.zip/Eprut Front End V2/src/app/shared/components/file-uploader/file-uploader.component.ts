import { Component, ElementRef, inject, Input, OnDestroy, signal, ViewChild } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar } from '@angular/material/snack-bar';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { RegistersService } from 'app/routes/registers/registers.service';
import { Subject, takeUntil } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

@Component({
  selector: 'app-file-uploader',
  standalone: true,
  imports: [TranslateModule, MatIconModule, MatButtonModule],
  templateUrl: './file-uploader.component.html',
  styleUrl: './file-uploader.component.scss'
})
export class FileUploaderComponent implements OnDestroy {

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  private submitSubject: Subject<void> = new Subject<void>();

  @Input() registerCode: string;

  fileName = signal('');
  signatureFileName = signal('');
  fileSize = signal(0);
  signatureFileSize = signal(0);
  @ViewChild('fileInput') fileInput: ElementRef | undefined;
  @ViewChild('signatureFileInput') signatureFileInput: ElementRef | undefined;
  selectedFile: File | null = null;
  selectedSignatureFile: File | null = null;
  uploadSuccess: boolean = false;
  uploadSignatureSuccess: boolean = false;
  uploadError: boolean = false;
  uploadSignatureError: boolean = false;
  isFileUploading: boolean = false;

  constructor(
    private _registersService: RegistersService,
    private _translateService: TranslateService,
    private _snackBar: MatSnackBar
  ) {}

  ngAfterViewInit(): void {
    this.submitSubject.pipe(debounceTime(1000)).subscribe(() => this.submitFile());
  }

  onSubmitButtonClick(): void {
    this.isFileUploading = true;
    this.submitSubject.next();
  }

  onFileChange(event: any, type: 'file' | 'signature'): void {
    const file = event.target.files[0] as File | null;

    if (!file) {
      return;
    }

    this.uploadFile(file, type);
  }

  onFileDrop(event: DragEvent, type: 'file' | 'signature'): void {
    event.preventDefault();
    const file = event.dataTransfer?.files[0] as File | null;
    this.uploadFile(file, type);
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
  }

  uploadFile(file: File | null, type: 'file' | 'signature'): void {
    if (type === 'file') {   
      if (file && file.type.includes('zip')) {
        this.selectedFile = file;
        this.fileSize.set(Math.round(file.size / (1024 * 1024)));
  
        this.uploadSuccess = true;
        this.uploadError = false;
        this.fileName.set(file.name);
      } else {
        this.uploadSuccess = false;
        this.uploadError = true;
  
        const message = this._translateService.instant('registers.uploadFileError');
        const action = this._translateService.instant('common.close');
  
        this._snackBar.open(message, action, {
          duration: 3000,
          panelClass: 'error',
        });
      }
    } else {
        this.selectedSignatureFile = file;
        this.signatureFileSize.set(Math.round(file.size / (1024 * 1024)));
  
        this.uploadSignatureSuccess = true;
        this.uploadSignatureError = false;
        this.signatureFileName.set(file.name);
    }
  }

  submitFile(): void {
    if (this.selectedFile && this.selectedSignatureFile) {
      this._registersService.submitFile(this.registerCode, this.selectedFile, this.selectedSignatureFile)
        .pipe(
          takeUntil(this._unsubscribeAll)
        )
        .subscribe({
          next: () => {

            const message = this._translateService.instant('registers.importSuccess', { fileName: this.selectedFile?.name });
            const action = this._translateService.instant('common.close');

            this._snackBar.open(message, action, {
              duration: 3000,
            });

            this._registersService.refreshFiles$.next();
            this.removeFile('all');
            this.isFileUploading = false;
          },
          error: (e) => {
            this.removeFile('all');
            this.isFileUploading = false;
          }
        });
    }
  }

  removeFile(type: 'all' | 'file' | 'signature'): void {
    if (type === 'all') {
      this.selectedSignatureFile = null;
      this.signatureFileName.set('');
      this.signatureFileSize.set(0);
      this.uploadSignatureSuccess = false;
      this.uploadSignatureError = false;
      this.selectedFile = null;
      this.fileName.set('');
      this.fileSize.set(0);
      this.uploadSuccess = false;
      this.uploadError = false;
    } else if (type === 'file') {
      this.selectedFile = null;
      this.fileName.set('');
      this.fileSize.set(0);
      this.uploadSuccess = false;
      this.uploadError = false;
    } else if (type === 'signature') {
      this.selectedSignatureFile = null;
      this.signatureFileName.set('');
      this.signatureFileSize.set(0);
      this.uploadSignatureSuccess = false;
      this.uploadSignatureError = false;
    }
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
