import { TestBed } from '@angular/core/testing';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { MatPaginatorIntl } from '@angular/material/paginator';
import { PaginatorI18nService } from './paginator-i18n.service';

describe('PaginatorI18nService', () => {
  let service: PaginatorI18nService;
  let translateService: TranslateService;

  beforeEach(() => {
    const translateServiceStub = {
      onLangChange: {
        subscribe: (callback: (event: LangChangeEvent) => void) => {
          callback({ lang: 'en', translations: {} } as LangChangeEvent);
        },
      },
      instant: (key: string) => key,
    };

    TestBed.configureTestingModule({
      providers: [
        PaginatorI18nService,
        { provide: TranslateService, useValue: translateServiceStub },
      ],
    });

    service = TestBed.inject(PaginatorI18nService);
    translateService = TestBed.inject(TranslateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should initialize paginatorIntl with translated labels', () => {
    const paginatorIntl = service.getPaginatorIntl();
    expect(paginatorIntl.itemsPerPageLabel).toBe('paginator.items_per_page_label');
    expect(paginatorIntl.previousPageLabel).toBe('paginator.previous_page_label');
    expect(paginatorIntl.nextPageLabel).toBe('paginator.next_page_label');
    expect(paginatorIntl.firstPageLabel).toBe('paginator.first_page_label');
    expect(paginatorIntl.lastPageLabel).toBe('paginator.last_page_label');
  });

  it('should return correct range label', () => {
    const rangeLabel = service['getRangeLabel'](1, 10, 100);
    expect(rangeLabel).toBe('paginator.range_page_label_2');
  });

  it('should handle empty range correctly', () => {
    const rangeLabel = service['getRangeLabel'](1, 0, 0);
    expect(rangeLabel).toBe('paginator.range_page_label_1');
  });
});
