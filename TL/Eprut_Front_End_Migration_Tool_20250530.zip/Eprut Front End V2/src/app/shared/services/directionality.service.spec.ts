import { TestBed } from '@angular/core/testing';
import { AppDirectionality } from './directionality.service';
import { Direction } from '@angular/cdk/bidi';

describe('AppDirectionality', () => {
  let service: AppDirectionality;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AppDirectionality);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should have default direction as ltr', () => {
    expect(service.value).toBe('ltr');
  });

  it('should change direction and emit event', (done) => {
    service.change.subscribe((direction: Direction) => {
      expect(direction).toBe('rtl');
      done();
    });
    service.value = 'rtl';
  });

  it('should complete the change event on destroy', () => {
    const completeSpy = spyOn(service.change, 'complete');
    service.ngOnDestroy();
    expect(completeSpy).toHaveBeenCalled();
  });
});
