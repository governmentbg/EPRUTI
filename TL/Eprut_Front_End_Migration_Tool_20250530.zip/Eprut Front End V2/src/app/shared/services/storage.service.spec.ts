import { TestBed } from '@angular/core/testing';
import { LocalStorageService, MemoryStorageService } from './storage.service';

describe('LocalStorageService', () => {
  let service: LocalStorageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LocalStorageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set and get a value', () => {
    service.set('testKey', { data: 'testData' });
    expect(service.get('testKey')).toEqual({ data: 'testData' });
  });

  it('should check if a key exists', () => {
    service.set('testKey', { data: 'testData' });
    expect(service.has('testKey')).toBeTrue();
  });

  it('should remove a key', () => {
    service.set('testKey', { data: 'testData' });
    service.remove('testKey');
    expect(service.has('testKey')).toBeFalse();
  });

  it('should clear all keys', () => {
    service.set('testKey1', { data: 'testData1' });
    service.set('testKey2', { data: 'testData2' });
    service.clear();
    expect(service.has('testKey1')).toBeFalse();
    expect(service.has('testKey2')).toBeFalse();
  });
});

describe('MemoryStorageService', () => {
  let service: MemoryStorageService;

  beforeEach(() => {
    service = new MemoryStorageService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set and get a value', () => {
    service.set('testKey', { data: 'testData' });
    expect(service.get('testKey')).toEqual({ data: 'testData' });
  });

  it('should check if a key exists', () => {
    service.set('testKey', { data: 'testData' });
    expect(service.has('testKey')).toBeTrue();
  });

  it('should remove a key', () => {
    service.set('testKey', { data: 'testData' });
    service.remove('testKey');
    expect(service.has('testKey')).toBeFalse();
  });

  it('should clear all keys', () => {
    service.set('testKey1', { data: 'testData1' });
    service.set('testKey2', { data: 'testData2' });
    service.clear();
    expect(service.has('testKey1')).toBeFalse();
    expect(service.has('testKey2')).toBeFalse();
  });
});
