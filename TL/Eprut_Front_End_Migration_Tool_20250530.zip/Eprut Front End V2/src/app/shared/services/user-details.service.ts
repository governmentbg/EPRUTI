import { Injectable, Injector } from '@angular/core';
import { CrudService } from '@core/services/crud-service';
import { UserDetailsModel } from '@shared/models/user-details-model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService extends CrudService<UserDetailsModel> {

  constructor(injector: Injector) {
    super(injector);
  }

  getUserDetails(): Observable<UserDetailsModel> {
    return this.httpClient.get<UserDetailsModel>(`${this.APIUrl}`);
  }

  getResourceUrl(): string {
      return 'profile-details';
  }
  
  fromServerModel(json: any): UserDetailsModel {
    return new UserDetailsModel(json);
  }
}