import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { NomenclaturesService } from './nomenclatures.service';
import { DisplayValueWithCodeModel } from '@shared/models/display-value-with-code-model';

describe('NomenclaturesService', () => {
    let service: NomenclaturesService;
    let httpMock: HttpTestingController;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [NomenclaturesService]
        });
        service = TestBed.inject(NomenclaturesService);
        httpMock = TestBed.inject(HttpTestingController);
    });

    afterEach(() => {
        httpMock.verify();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should fetch file statuses', () => {
        const mockStatuses: DisplayValueWithCodeModel[] = [
            { id: 1, code: '1', description: 'Status1' },
            { id: 2, code: '2', description: 'Status2' }
        ];

        service.getFileStatuses().subscribe(statuses => {
            expect(statuses).toEqual(mockStatuses);
        });

        const req = httpMock.expectOne(`/import-api/import/registers/statuses`);
        expect(req.request.method).toBe('GET');
        req.flush(mockStatuses);
    });

    it('should update nFileStatuses$ observable', () => {
        const mockStatuses: DisplayValueWithCodeModel[] = [
            { id: 1, code: '1', description: 'Status1' },
            { id: 2, code: '2', description: 'Status2' }
        ];

        service.getFileStatuses().subscribe();

        const req = httpMock.expectOne(`/import-api/import/registers/statuses`);
        req.flush(mockStatuses);

        service.nFileStatuses$.subscribe(statuses => {
            expect(statuses).toEqual(mockStatuses);
        });
    });

    it('should return the correct resource URL', () => {
        const resourceUrl = service.getResourceUrl();
        expect(resourceUrl).toBe('/');
    });

    it('should convert server model to NomenclatureModel', () => {
        const serverModel = { id: 1, name: 'Test Nomenclature' };
        const nomenclatureModel = service.fromServerModel(serverModel);
        expect(nomenclatureModel).toEqual(jasmine.objectContaining({
            id: 1,
            name: 'Test Nomenclature'
        }));
    });
});
