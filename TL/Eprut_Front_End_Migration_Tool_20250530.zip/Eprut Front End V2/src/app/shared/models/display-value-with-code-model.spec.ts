import { DisplayValueWithCodeModel } from './display-value-with-code-model';

describe('DisplayValueWithCodeModel', () => {
  it('should create an instance with default values', () => {
    const model = new DisplayValueWithCodeModel();
    expect(model).toBeTruthy();
    expect(model.id).toBeUndefined();
    expect(model.description).toBeUndefined();
    expect(model.code).toBeUndefined();
  });

  it('should create an instance with provided values', () => {
    const init = { id: 1, description: 'Test Description', code: 'Test Code' };
    const model = new DisplayValueWithCodeModel(init);
    expect(model).toBeTruthy();
    expect(model.id).toBe(1);
    expect(model.description).toBe('Test Description');
    expect(model.code).toBe('Test Code');
  });

  it('should assign partial values', () => {
    const init = { description: 'Partial Description', code: 'Partial Code' };
    const model = new DisplayValueWithCodeModel(init);
    expect(model).toBeTruthy();
    expect(model.id).toBeUndefined();
    expect(model.description).toBe('Partial Description');
    expect(model.code).toBe('Partial Code');
  });
});