import { FileOutputModel } from './file-output-model';

describe('FileOutputModel', () => {
  it('should create an instance', () => {
    expect(new FileOutputModel()).toBeTruthy();
  });

  it('should assign values from the constructor', () => {
    const init = { id: 1, statusId: 2, userId: 'user123' };
    const model = new FileOutputModel(init);
    expect(model.id).toBe(1);
    expect(model.statusId).toBe(2);
    expect(model.userId).toBe('user123');
  });

  it('should assign partial values from the constructor', () => {
    const init = { id: 1 };
    const model = new FileOutputModel(init);
    expect(model.id).toBe(1);
    expect(model.statusId).toBeUndefined();
    expect(model.userId).toBeUndefined();
  });

  it('should handle empty constructor', () => {
    const model = new FileOutputModel();
    expect(model.id).toBeUndefined();
    expect(model.statusId).toBeUndefined();
    expect(model.userId).toBeUndefined();
  });
});
