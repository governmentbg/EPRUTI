import { UserDetailsModel } from './user-details-model';

describe('UserDetails', () => {
  it('should create an instance', () => {
    expect(new UserDetailsModel()).toBeTruthy();
  });
});
