import { DisplayValueModel } from './display-value-model';

describe('DisplayValueModel', () => {
  it('should create an instance with default values', () => {
    const model = new DisplayValueModel();
    expect(model).toBeTruthy();
    expect(model.id).toBeUndefined();
    expect(model.description).toBeUndefined();
  });

  it('should create an instance with provided values', () => {
    const init = { id: 1, description: 'Test Description' };
    const model = new DisplayValueModel(init);
    expect(model).toBeTruthy();
    expect(model.id).toBe(1);
    expect(model.description).toBe('Test Description');
  });

  it('should assign partial values', () => {
    const init = { description: 'Partial Description' };
    const model = new DisplayValueModel(init);
    expect(model).toBeTruthy();
    expect(model.id).toBeUndefined();
    expect(model.description).toBe('Partial Description');
  });
});
