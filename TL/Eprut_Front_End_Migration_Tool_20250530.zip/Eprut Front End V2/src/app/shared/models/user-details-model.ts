import { ApiModel } from "./api-model";

export class UserDetailsModel extends ApiModel<UserDetailsModel> {

    email: string;
    fullname: string;
    officename: string;
    department: string;
    position: string;

    constructor(init?: Partial<UserDetailsModel>) {
        super(UserDetailsModel);

        if (init) {
            Object.assign(this, init);
        }
    }
}
