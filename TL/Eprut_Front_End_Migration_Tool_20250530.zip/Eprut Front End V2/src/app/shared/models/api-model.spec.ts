import { DisplayValueModel } from './display-value-model';
import { DisplayValueWithCodeModel } from './display-value-with-code-model';
import { ApiModel } from './api-model';

class TestModel extends ApiModel<TestModel> {
  name!: string;
  displayValue!: DisplayValueModel;
  displayValueWithCode!: DisplayValueWithCodeModel;

  constructor(init?: Partial<TestModel>) {
    super(TestModel);
    if (init) {
      Object.assign(this, init);
    }
  }
}

describe('ApiModel', () => {
  it('should create an instance', () => {
    const model = new TestModel();
    expect(model).toBeTruthy();
  });

  it('should convert to API model', () => {
    const displayValue = new DisplayValueModel({ id: 1, description: 'Test Description' });
    const displayValueWithCode = new DisplayValueWithCodeModel({ id: 2, description: 'Test Description', code: 'Test Code' });
    const model = new TestModel({ id: 3, name: 'Test Name', displayValue, displayValueWithCode });

    const apiModel = model.convertToApi();

    expect(apiModel).toBeTruthy();
    expect(apiModel.id).toBe(3);
    expect(apiModel.name).toBe('Test Name');
    expect(apiModel.displayValueId).toBe(1);
    expect(apiModel.displayValueWithCodeId).toBe(2);
    expect(apiModel.displayValue).toBeUndefined();
    expect(apiModel.displayValueWithCode).toBeUndefined();
  });

  it('should handle missing display values', () => {
    const model = new TestModel({ id: 3, name: 'Test Name' });

    const apiModel = model.convertToApi();

    expect(apiModel).toBeTruthy();
    expect(apiModel.id).toBe(3);
    expect(apiModel.name).toBe('Test Name');
    expect(apiModel.displayValueId).toBeUndefined();
    expect(apiModel.displayValueWithCodeId).toBeUndefined();
  });
});