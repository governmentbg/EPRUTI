export class ProgressGroupModel {

    statusCodes: string[];
    startPercentage: number;
    endPercentage: number;

    constructor(init?: Partial<ProgressGroupModel>) {
        Object.assign(this, init);
    }
}
