import { ProgressGroupModel } from './progress-group-model';

describe('ProgressGroupModel', () => {
  it('should create an instance', () => {
    expect(new ProgressGroupModel()).toBeTruthy();
  });
});
