import { Routes } from '@angular/router';
import { authGuard } from '@core';
import { AdminLayoutComponent } from '@theme/admin-layout/admin-layout.component';
import { RegistersComponent } from './routes/registers/registers/registers.component';
import { Error403Component } from './routes/sessions/403.component';
import { Error404Component } from './routes/sessions/404.component';
import { Error500Component } from './routes/sessions/500.component';

export const routes: Routes = [
  {
    path: '',
    component: AdminLayoutComponent,
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    children: [
      { path: '', redirectTo: 'registers', pathMatch: 'full' },
      { 
        path: 'registers',
        loadChildren: () => import('./routes/registers/registers.module').then(m => m.RegistersModule),
        data: { 
          breadcrumb: 'menu.registersBreadcrumb' 
        }
      },
      { path: '403', component: Error403Component },
      { path: '404', component: Error404Component },
      { path: '500', component: Error500Component },
    ],
  },
  { path: '**', redirectTo: 'registers' },
];
