import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { CrudService } from './crud-service';
import { Injector } from '@angular/core';
import { ApiModel } from '@shared/models/api-model';
import { HttpErrorResponse } from '@angular/common/http';

class TestModel extends ApiModel<TestModel> {
  name: string;

  constructor(input: { id: number, name: string }) {
      super(TestModel);
      this.id = input.id;
      this.name = input.name;
  }

  override convertToApi() {
      const res = super.convertToApi();
      res.id = this.id;
      return res;
  }
}

class TestRequestService extends CrudService<TestModel> {

    getBaseResourceUrl(): string {
        return super.getResourceUrl();
    }

    getBaseFromServerModel(json: any): TestModel {
        return super.fromServerModel(json);
    }

    getResourceUrl(): string {
        return 'test-resource';
    }

    getAPIUrl(): string {
        return this.APIUrl;
    }

    fromServerModel(json: any): TestModel {
        return new TestModel({
            id: json.id,
            name: json.name
        });
    }
}

describe('CrudService', () => {
    let service: TestRequestService;
    let httpMock: HttpTestingController;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [TestRequestService, Injector]
        });

        service = TestBed.inject(TestRequestService);
        httpMock = TestBed.inject(HttpTestingController);
    });

    afterEach(() => {
        httpMock.verify();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should get list of items', () => {
        const dummyItems: TestModel[] = [new TestModel({ id: 1, name: 'Test1' }), new TestModel({ id: 2, name: 'Test2' })];

        service.getList().subscribe(items => {
            expect(items.length).toBe(2);
            expect(items).toEqual(dummyItems);
        });

        const req = httpMock.expectOne(service.getAPIUrl());
        expect(req.request.method).toBe('GET');
        req.flush(dummyItems);
    });

    it('should get a single item', () => {
        const dummyItem = new TestModel({ id: 1, name: 'Test1' });

        service.get(1).subscribe(item => {
            expect(item).toEqual(dummyItem);
        });

        const req = httpMock.expectOne(`${service.getAPIUrl()}/1`);
        expect(req.request.method).toBe('GET');
        req.flush(dummyItem);
    });

    it('should create an item', () => {
        const dummyItem = new TestModel({ id: 1, name: 'Test1' });

        service.create(dummyItem).subscribe(item => {
            expect(item.id).toEqual(undefined);
            expect(item.name).toEqual(dummyItem.name);
        });

        const req = httpMock.expectOne(service.getAPIUrl());
        expect(req.request.method).toBe('POST');
        req.flush(dummyItem);
    });

    it('should update an item', () => {
        const dummyItem = new TestModel({ id: 1, name: 'Test1' });

        service.update(1, dummyItem).subscribe(item => {
          expect(item.id).toEqual(undefined);
          expect(item.name).toEqual(dummyItem.name);
        });

        const req = httpMock.expectOne(`${service.getAPIUrl()}/1`);
        expect(req.request.method).toBe('PUT');
        req.flush(dummyItem);
    });

    it('should delete an item', () => {
        const dummyItem = new TestModel({ id: 1, name: 'Test1' });

        service.delete(1).subscribe(item => {
            expect(item).toEqual(dummyItem);
        });

        const req = httpMock.expectOne(`${service.getAPIUrl()}/1`);
        expect(req.request.method).toBe('DELETE');
        req.flush(dummyItem);
    });

    it('should handle errors', () => {
        const errorResponse = new HttpErrorResponse({
            error: 'test 404 error',
            status: 404,
            statusText: 'Not Found'
        });

        service.getList().subscribe(
            () => fail('expected an error, not items'),
            error => {
                expect(error.status).toBe(404);
            }
        );

        const req = httpMock.expectOne(service.getAPIUrl());
        req.flush('test 404 error', { status: 404, statusText: 'Not Found' });
    });
    
    it('should return empty data$ observable initially', (done) => {
        service.data$.subscribe(items => {
            expect(items).toEqual([]);
            done();
        });
    });

    it('should return null item$ observable initially', (done) => {
        service.item$.subscribe(item => {
            expect(item).toBeNull();
            done();
        });
    });

    it('should return false loading$ observable initially', (done) => {
        service.loading$.subscribe(loading => {
            expect(loading).toBeFalse();
            done();
        });
    });

    it('should return resource URL', () => {
        expect(service.getResourceUrl()).toBe('test-resource');
    });

    it('should convert from server model', () => {
        const json = { id: 1, name: 'Test1' };
        const model = service.fromServerModel(json);

        expect(model.id).toBe(1);
        expect(model.name).toBe('Test1');
    });

    it('should throw error for base getResourceUrl', () => {
        expect(() => service.getBaseResourceUrl()).toThrowError('Method not implemented.');
    });

    it('should throw error for base fromServerModel', () => {
        expect(() => service.getBaseFromServerModel({})).toThrowError('Method not implemented.');
    });

    it('should handle errors on getList', () => {
        const errorResponse = new HttpErrorResponse({
            error: 'test 500 error',
            status: 500,
            statusText: 'Internal Server Error',
            url: service.getAPIUrl()
        });

        spyOn(service as any, 'handleError').and.callThrough();

        service.getList().subscribe(
            () => fail('expected an error, not items'),
            error => {
                expect(error.status).toBe(500);
                expect((service as any).handleError).toHaveBeenCalledWith(jasmine.objectContaining({
                    status: 500,
                    statusText: 'Internal Server Error',
                    url: service.getAPIUrl()
                }));
            }
        );

        const req = httpMock.expectOne(service.getAPIUrl());
        req.flush('test 500 error', { status: 500, statusText: 'Internal Server Error' });
    });

    it('should handle errors on get', () => {
        const errorResponse = new HttpErrorResponse({
            error: 'test 500 error',
            status: 500,
            statusText: 'Internal Server Error',
            url: `${service.getAPIUrl()}/1`
        });

        spyOn(service as any, 'handleError').and.callThrough();

        service.get(1).subscribe(
            () => fail('expected an error, not item'),
            error => {
                expect(error.status).toBe(500);
                expect((service as any).handleError).toHaveBeenCalledWith(jasmine.objectContaining({
                    status: 500,
                    statusText: 'Internal Server Error',
                    url: `${service.getAPIUrl()}/1`
                }));
            }
        );

        const req = httpMock.expectOne(`${service.getAPIUrl()}/1`);
        req.flush('test 500 error', { status: 500, statusText: 'Internal Server Error' });
    });

    it('should handle errors on create', () => {
        const errorResponse = new HttpErrorResponse({
            error: 'test 500 error',
            status: 500,
            statusText: 'Internal Server Error',
            url: service.getAPIUrl()
        });

        spyOn(service as any, 'handleError').and.callThrough();

        const dummyItem = new TestModel({ id: 1, name: 'Test1' });

        service.create(dummyItem).subscribe(
            () => fail('expected an error, not item'),
            error => {
                expect(error.status).toBe(500);
                expect((service as any).handleError).toHaveBeenCalledWith(jasmine.objectContaining({
                    status: 500,
                    statusText: 'Internal Server Error',
                    url: service.getAPIUrl()
                }));
            }
        );

        const req = httpMock.expectOne(service.getAPIUrl());
        req.flush('test 500 error', { status: 500, statusText: 'Internal Server Error' });
    });

    it('should handle errors on update', () => {
        const errorResponse = new HttpErrorResponse({
            error: 'test 500 error',
            status: 500,
            statusText: 'Internal Server Error',
            url: `${service.getAPIUrl()}/1`
        });

        spyOn(service as any, 'handleError').and.callThrough();

        const dummyItem = new TestModel({ id: 1, name: 'Test1' });

        service.update(1, dummyItem).subscribe(
            () => fail('expected an error, not item'),
            error => {
                expect(error.status).toBe(500);
                expect((service as any).handleError).toHaveBeenCalledWith(jasmine.objectContaining({
                    status: 500,
                    statusText: 'Internal Server Error',
                    url: `${service.getAPIUrl()}/1`
                }));
            }
        );

        const req = httpMock.expectOne(`${service.getAPIUrl()}/1`);
        req.flush('test 500 error', { status: 500, statusText: 'Internal Server Error' });
    });

    it('should handle errors on delete', () => {
        const errorResponse = new HttpErrorResponse({
            error: 'test 500 error',
            status: 500,
            statusText: 'Internal Server Error',
            url: `${service.getAPIUrl()}/1`
        });

        spyOn(service as any, 'handleError').and.callThrough();

        service.delete(1).subscribe(
            () => fail('expected an error, not item'),
            error => {
                expect(error.status).toBe(500);
                expect((service as any).handleError).toHaveBeenCalledWith(jasmine.objectContaining({
                    status: 500,
                    statusText: 'Internal Server Error',
                    url: `${service.getAPIUrl()}/1`
                }));
            }
        );

        const req = httpMock.expectOne(`${service.getAPIUrl()}/1`);
        req.flush('test 500 error', { status: 500, statusText: 'Internal Server Error' });
    });
});
