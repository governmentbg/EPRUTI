import { HttpClient } from '@angular/common/http';
import { Injectable, OnDestroy } from '@angular/core';
import { Subject, takeUntil, map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TemplateDownloadService implements OnDestroy {

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  private _fileConfig: any

  constructor(private _http: HttpClient) {
    this.loadFileConfig();
  }

  downloadFile(code: string) {
    if (this._fileConfig && this._fileConfig[code]) {
      const fileName = this._fileConfig[code]['excel'];

      if (fileName) {
        const fileUrl = `assets/excels/${fileName}`;
        return this._http.get(fileUrl, { responseType: 'blob' }).pipe(
          map(blob => ({ blob, fileName }))
        );
      }
    }

    return null;
  }

  downloadXsdTemplates(): Observable<Blob> {
    return this._http.get('assets/xsd/xsd-xml.zip', {
      responseType: 'blob'
    });
  }

  private loadFileConfig() {
    this._http.get('assets/fileConfig.json').pipe(takeUntil(this._unsubscribeAll)).subscribe(config => {
      this._fileConfig = config;
    });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
