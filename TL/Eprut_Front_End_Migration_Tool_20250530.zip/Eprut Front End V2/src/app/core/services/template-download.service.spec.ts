import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { TemplateDownloadService } from './template-download.service';

describe('TemplateDownloadService', () => {
  let service: TemplateDownloadService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [TemplateDownloadService]
    });
    service = TestBed.inject(TemplateDownloadService);
    httpMock = TestBed.inject(HttpTestingController);

    const req = httpMock.expectOne('assets/fileConfig.json');
    req.flush({});
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should load file config on initialization', () => {
    const mockConfig = { 'code1': { 'excel': 'file1.xlsx', 'xml': 'file1.xml' } };
    service['loadFileConfig']();
    const req = httpMock.expectOne('assets/fileConfig.json');
    expect(req.request.method).toBe('GET');
    req.flush(mockConfig);
    expect(service['_fileConfig']).toEqual(mockConfig);
  });

  it('should return file blob and name when downloadFile is called with valid code and type', () => {
    const mockConfig = { 'code1': { 'excel': 'file1.xlsx', 'xml': 'file1.xml' } };
    service['_fileConfig'] = mockConfig;
    const mockBlob = new Blob([''], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });

    service.downloadFile('code1', 'excel').subscribe(response => {
      expect(response.blob).toEqual(mockBlob);
      expect(response.fileName).toBe('file1.xlsx');
    });

    const req = httpMock.expectOne('assets/excels/file1.xlsx');
    expect(req.request.method).toBe('GET');
    req.flush(mockBlob);
  });

  it('should return null when downloadFile is called with invalid code', () => {
    const result = service.downloadFile('invalidCode', 'excel');
    expect(result).toBeNull();
  });
});
