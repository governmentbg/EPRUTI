import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Injector } from '@angular/core';
import { BaseRequestService } from './base-request-service';
import { ApiModel } from '@shared/models/api-model';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

class TestModel extends ApiModel<TestModel> {
    name: string;

    constructor(input: { id: number, name: string }) {
        super(TestModel);
        this.id = input.id;
        this.name = input.name;
    }

    convertToApi() {
        return {
            id: this.id,
            name: this.name
        };
    }
}

class TestRequestService extends BaseRequestService<TestModel> {
    getResourceUrl(): string {
        return 'test-resource';
    }
    fromServerModel(json: any): TestModel {
        return new TestModel(json);
    }
    getAPIPrefix(): string {
        return this.APIPrefix;
    }
    getAPIUrl(): string {
        return this.APIUrl;
    }
    override getResourceUrlWithParams(): string {
        return super.getResourceUrlWithParams();
    }
    override handleError(error: HttpErrorResponse): Observable<never> {
        return super.handleError(error);
    }
}

describe('BaseRequestService', () => {
    let service: TestRequestService;
    let httpMock: HttpTestingController;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [Injector]
        });

        const injector = TestBed.inject(Injector);
        service = new TestRequestService(injector);
        httpMock = TestBed.inject(HttpTestingController);
    });

    afterEach(() => {
        httpMock.verify();
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
        expect(service.getAPIPrefix()).toBe('/import-api/');
    });

    it('should return API prefix', () => {
        expect(service.getAPIPrefix()).toBe('/import-api/');
    });

    it('should return API URL', () => {
        expect(service.getAPIUrl()).toBe('/import-api/test-resource');
    });

    it('should convert entity to server model', () => {
        const entity = new TestModel({ id: 1, name: 'Test Name' });
        const serverModel = service.toServerModel(entity);
        expect(serverModel).toEqual({ id: undefined, name: 'Test Name' });
    });

    it('should return empty string for getResourceUrlWithParams', () => {
        expect(service.getResourceUrlWithParams()).toBe('');
    });

    it('should handle error', () => {
        const errorResponse = new HttpErrorResponse({
            error: 'test 404 error',
            status: 404, statusText: 'Not Found'
        });

        service.handleError(errorResponse).subscribe({
            error: error => {
                expect(error).toBe('test 404 error');
            }
        });
    });
});
