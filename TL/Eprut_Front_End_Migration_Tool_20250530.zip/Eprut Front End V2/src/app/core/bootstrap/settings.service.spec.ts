import { TestBed } from '@angular/core/testing';
import { MediaMatcher } from '@angular/cdk/layout';
import { DOCUMENT } from '@angular/common';
import { BehaviorSubject } from 'rxjs';

import { SettingsService } from './settings.service';
import { AppDirectionality, LocalStorageService } from '@shared';
import { AppSettings, defaults } from '../settings';

describe('SettingsService', () => {
  let service: SettingsService;
  let localStorageService: jasmine.SpyObj<LocalStorageService>;
  let mediaMatcher: jasmine.SpyObj<MediaMatcher>;
  let document: Document;
  let dir: AppDirectionality;

  beforeEach(() => {
    const localStorageSpy = jasmine.createSpyObj('LocalStorageService', ['get', 'set', 'remove']);
    const mediaMatcherSpy = jasmine.createSpyObj('MediaMatcher', ['matchMedia']);
    const dirSpy = jasmine.createSpyObj('AppDirectionality', [], { value: 'ltr' });

    const mockDocument = {
      querySelector: jasmine.createSpy('querySelector').and.returnValue({ dir: 'ltr' })
    };

    TestBed.configureTestingModule({
      providers: [
        SettingsService,
        { provide: LocalStorageService, useValue: localStorageSpy },
        { provide: MediaMatcher, useValue: mediaMatcherSpy },
        { provide: DOCUMENT, useValue: mockDocument },
        { provide: AppDirectionality, useValue: dirSpy }
      ]
    });

    service = TestBed.inject(SettingsService);
    localStorageService = TestBed.inject(LocalStorageService) as jasmine.SpyObj<LocalStorageService>;
    mediaMatcher = TestBed.inject(MediaMatcher) as jasmine.SpyObj<MediaMatcher>;
    document = TestBed.inject(DOCUMENT);
    dir = TestBed.inject(AppDirectionality);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get default options if no stored options', () => {
    localStorageService.get.and.returnValue(null);
    expect(service.options).toEqual(defaults);
  });

  it('should set and get options', () => {
    const options: AppSettings = { ...defaults, theme: 'light' };
    service.setOptions(options);
    expect(service.options).toEqual(options);
    expect(localStorageService.set).toHaveBeenCalledWith("ng-matero-settings", options);
  });

  it('should reset options', () => {
    service.reset();
    expect(localStorageService.remove).toHaveBeenCalledWith("ng-matero-settings");
  });

  it('should set language', () => {
    const lang = 'en';
    service.setLanguage(lang);
    expect(service.options.language).toBe(lang);
    expect(localStorageService.set).toHaveBeenCalledWith("ng-matero-settings", service.options);
  });

  it('should set direction', () => {
    service.setDirection();
    expect(dir.value).toBe(service.options.dir);
    expect(document.querySelector('html')!.dir).toBe(service.options.dir);
  });

  it('should set theme', () => {
    service.setTheme();
    expect(service.themeColor).toBe(service.getThemeColor());
  });
});
