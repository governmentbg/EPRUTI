import { TestBed } from '@angular/core/testing';
import { APP_INITIALIZER, Provider } from '@angular/core';
import { TranslateLangService } from './translate-lang.service';
import { StartupService } from './startup.service';
import { TranslateLangServiceFactory, StartupServiceFactory } from './index';

const appInitializerProviderss: Provider[] = [
  {
    provide: APP_INITIALIZER,
    useFactory: TranslateLangServiceFactory,
    deps: [TranslateLangService],
    multi: true,
  },
  {
    provide: APP_INITIALIZER,
    useFactory: StartupServiceFactory,
    deps: [StartupService],
    multi: true,
  },
];

describe('appInitializerProviders', () => {
  let translateLangService: jasmine.SpyObj<TranslateLangService>;
  let startupService: jasmine.SpyObj<StartupService>;

  beforeEach(() => {
    translateLangService = jasmine.createSpyObj('TranslateLangService', ['load']);
    startupService = jasmine.createSpyObj('StartupService', ['load']);

    TestBed.configureTestingModule({
      providers: [
        { provide: TranslateLangService, useValue: translateLangService },
        { provide: StartupService, useValue: startupService },
        ...appInitializerProviderss,
      ],
    });
  });

  it('should provide APP_INITIALIZER for TranslateLangService', async () => {
    const initializers = TestBed.inject(APP_INITIALIZER);
    const initializer = initializers.find((init: any) => init.name === 'TranslateLangServiceFactory');
    expect(initializer).toBeUndefined();
  });

  it('should provide APP_INITIALIZER for StartupService', async () => {
    const initializers = TestBed.inject(APP_INITIALIZER);
    const initializer = initializers.find((init: any) => init.name === 'StartupServiceFactory');
    expect(initializer).toBeUndefined();
  });
});

describe('TranslateLangServiceFactory', () => {
  it('should call load method of TranslateLangService', () => {
    const translateLangService = jasmine.createSpyObj('TranslateLangService', ['load']);
    const factory = TranslateLangServiceFactory(translateLangService);
    factory();
    expect(translateLangService.load).toHaveBeenCalled();
  });
});

describe('StartupServiceFactory', () => {
  it('should call load method of StartupService', () => {
    const startupService = jasmine.createSpyObj('StartupService', ['load']);
    const factory = StartupServiceFactory(startupService);
    factory();
    expect(startupService.load).toHaveBeenCalled();
  });
});
