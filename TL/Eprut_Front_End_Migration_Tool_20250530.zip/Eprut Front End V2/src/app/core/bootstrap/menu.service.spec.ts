import { TestBed } from '@angular/core/testing';
import { MenuService, Menu, MenuChildrenItem } from './menu.service';

describe('MenuService', () => {
  let service: MenuService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MenuService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should initialize menu data', () => {
    const menu: Menu[] = [{ route: '/home', name: 'Home', type: 'link', icon: 'home' }];
    service.set(menu);
    service.getAll().subscribe(data => {
      expect(data).toEqual(menu);
    });
  });

  it('should add a menu item', () => {
    const menu: Menu = { route: '/about', name: 'About', type: 'link', icon: 'info' };
    service.add(menu);
    service.getAll().subscribe(data => {
      expect(data).toContain(menu);
    });
  });

  it('should reset the menu data', () => {
    service.reset();
    service.getAll().subscribe(data => {
      expect(data).toEqual([]);
    });
  });

  it('should build a route correctly', () => {
    const route = service.buildRoute(['', 'home', 'about']);
    expect(route).toBe('/home/about');
  });

  it('should add namespace for translation', () => {
    const menu: Menu[] = [{ route: '/home', name: 'Home', type: 'link', icon: 'home' }];
    service.addNamespace(menu, 'namespace');
    expect(menu[0].name).toBe('namespace.Home');
  });

  it('should observe the change of menu data', (done) => {
    const menu: Menu[] = [{ route: '/home', name: 'Home', type: 'link', icon: 'home' }];
    service.set(menu);
    service.change().subscribe(data => {
      expect(data).toEqual(menu);
      done();
    });
  });

  it('should get the menu item name based on current route', () => {
    const menu: Menu[] = [
      { route: '/home', name: 'Home', type: 'link', icon: 'home' },
      { route: '/about', name: 'About', type: 'link', icon: 'info' }
    ];
    service.set(menu);
    const itemName = service.getItemName(['/about']);
    expect(itemName?.name).toBe('About');
  });

  it('should check if an item is a leaf item', () => {
    const item: MenuChildrenItem = { route: '/home', name: 'Home', type: 'link' };
    expect(service['isLeafItem'](item)).toBe(true);
  });

  it('should deep clone an object', () => {
    const obj = { a: 1, b: { c: 2 } };
    const clonedObj = service['deepClone'](obj);
    expect(clonedObj).toEqual(obj);
    expect(clonedObj).not.toBe(obj);
  });

  it('should check if two JSON objects are equal', () => {
    const obj1 = { a: 1, b: 2 };
    const obj2 = { a: 1, b: 2 };
    expect(service['isJsonObjEqual'](obj1, obj2)).toBe(true);
  });

  it('should check if two routes are equal', () => {
    const routeArr = ['home', 'about'];
    const realRouteArr = ['home', 'about'];
    expect(service['isRouteEqual'](routeArr, realRouteArr)).toBe(true);
  });

  it('should get the menu level', () => {
    const menu: Menu[] = [{ route: '/home', name: 'Home', type: 'link', icon: 'home' }];
    service.set(menu);
    const level = service.getLevel(['/home']);
    expect(level[0].name).toBe('Home');
  });

  it('should add namespace for translation', () => {
    const menu: Menu[] = [{ route: '/home', name: 'Home', type: 'link', icon: 'home' }];
    service.addNamespace(menu, 'namespace');
    expect(menu[0].name).toBe('namespace.Home');
  });
});
