import { Injectable, inject } from '@angular/core';
import { AuthService, User } from '@core/authentication';
import { tap } from 'rxjs';
import { Menu, MenuService } from './menu.service';

@Injectable({
  providedIn: 'root',
})
export class StartupService {
  private readonly authService = inject(AuthService);
  private readonly menuService = inject(MenuService);

  load() {
    return new Promise<void>((resolve, reject) => {
      this.authService
        .menu()
        .pipe(
          tap(menu => this.setMenu(menu) )
        )
        .subscribe({
          next: () => resolve(),
          error: () => resolve(),
        });
    });
  }

  private setMenu(menu: Menu[]) {
    this.menuService.addNamespace(menu, 'menu');
    this.menuService.set(menu);
  }
}
