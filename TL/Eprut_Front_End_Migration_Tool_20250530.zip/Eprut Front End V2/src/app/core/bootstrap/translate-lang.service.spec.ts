import { TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { of, throwError } from 'rxjs';
import { TranslateLangService } from './translate-lang.service';
import { SettingsService } from './settings.service';

describe('TranslateLangService', () => {

  let service: TranslateLangService;
  let translateServiceSpy: jasmine.SpyObj<TranslateService>;
  let settingsServiceSpy: jasmine.SpyObj<SettingsService>;

  beforeEach(() => {
    const translateSpy = jasmine.createSpyObj('TranslateService', ['setDefaultLang', 'use']);
    const settingsSpy = jasmine.createSpyObj('SettingsService', ['setLanguage']);

    TestBed.configureTestingModule({
      providers: [
        { provide: TranslateService, useValue: translateSpy },
        { provide: SettingsService, useValue: settingsSpy },
      ],
    });

    translateServiceSpy = TestBed.inject(TranslateService) as jasmine.SpyObj<TranslateService>;
    settingsServiceSpy = TestBed.inject(SettingsService) as jasmine.SpyObj<SettingsService>;
    service = TestBed.inject(TranslateLangService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should load default language successfully', (done) => {
    const defaultLang = 'bg';
    translateServiceSpy.use.and.returnValue(of(null));

    service.load().then(() => {
      expect(settingsServiceSpy.setLanguage).toHaveBeenCalledWith(defaultLang);
      expect(translateServiceSpy.setDefaultLang).toHaveBeenCalledWith(defaultLang);
      expect(translateServiceSpy.use).toHaveBeenCalledWith(defaultLang);
      done();
    });
  });
});
