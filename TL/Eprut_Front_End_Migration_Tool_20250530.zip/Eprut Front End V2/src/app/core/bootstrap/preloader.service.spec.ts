import { TestBed } from '@angular/core/testing';
import { DOCUMENT } from '@angular/common';
import { PreloaderService } from './preloader.service';

describe('PreloaderService', () => {
  let service: PreloaderService;
  let document: Document;

  beforeEach(() => {
    document = window.document;

    TestBed.configureTestingModule({
      providers: [
        PreloaderService,
        { provide: DOCUMENT, useValue: document }
      ]
    });
    service = TestBed.inject(PreloaderService);
    document = TestBed.inject(DOCUMENT);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('hide', () => {
    let element: HTMLElement;

    beforeEach(() => {
      element = document.createElement('div');
      element.id = 'globalLoader';
      document.body.appendChild(element);
    });

    afterEach(() => {
      document.body.removeChild(element);
    });

    it('should add global-loader-fade-out class if element is not hidden', () => {
      service.hide();
      expect(element.className).toContain('global-loader-fade-out');
    });

    it('should add global-loader-hidden class after transitionend event', () => {
      service.hide();
      element.dispatchEvent(new Event('transitionend'));
      expect(element.className).toContain('global-loader-hidden');
    });

    it('should not add global-loader-fade-out class if element is already hidden', () => {
      element.className = 'global-loader-hidden';
      service.hide();
      expect(element.className).not.toContain('global-loader-fade-out');
    });
  });
});
