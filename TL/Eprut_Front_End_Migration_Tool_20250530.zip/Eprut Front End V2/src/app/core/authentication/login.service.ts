import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { map } from 'rxjs';

import { Menu } from '@core';
import { Token, User } from './interface';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  protected readonly http = inject(HttpClient);
  
  refresh(params: Record<string, any>) {
    return this.http.post<Token>('/auth/refresh', params);
  }

  menu() {
    return this.http.get<{ menu: Menu[] }>('assets/menu.json').pipe(map(res => res.menu ));
  }
}
