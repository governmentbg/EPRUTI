import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import * as jwt from 'jwt-decode';

export const authGuard = (route?: ActivatedRouteSnapshot, state?: RouterStateSnapshot) => {

  const cookie = inject(CookieService);

  const token = cookie.get('j');

  if (!token) {
    window.location.href = '/Login';
  }

  try {
    const decoded: any = jwt.jwtDecode(token);

    if (!decoded.exp || Date.now() >= decoded.exp * 1000) {
      window.location.href = '/Login';
    }
  } catch {
    window.location.href = '/Login';
  }

  return true;
};
