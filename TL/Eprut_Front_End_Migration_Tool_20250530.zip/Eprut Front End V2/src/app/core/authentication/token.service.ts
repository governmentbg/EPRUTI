import { Injectable, OnDestroy, inject } from '@angular/core';
import { BehaviorSubject, Subject, Subscription, share, timer } from 'rxjs';

import { BaseToken } from './token';
import { CookieService } from 'ngx-cookie-service';
import * as jwt from 'jwt-decode';

@Injectable({
  providedIn: 'root',
})
export class TokenService implements OnDestroy {
  private readonly key = 'j';

  private readonly cookie = inject(CookieService);

  private readonly change$ = new BehaviorSubject<BaseToken | undefined>(undefined);
  private readonly refresh$ = new Subject<BaseToken | undefined>();

  private timer$?: Subscription;

  private get token(): any {
    return this.cookie.get(this.key);
  }

  change() {
    return this.change$.pipe(share());
  }

  refresh() {
    this.buildRefresh();

    return this.refresh$.pipe(share());
  }

  valid() {
    if (this.token) {
      try {
        const decoded: any = jwt.jwtDecode(this.token);

        if (!decoded.exp || Date.now() >= decoded.exp * 1000) {
          this.cookie.delete(this.key);
          return false;
        }

        return true;
      } catch (e) {
        this.cookie.delete(this.key);
        return false;
      } 
    }

    return false;
  }

  clear() {
    this.cookie.delete(this.key);
  }

  getBearerToken() {
    return this.token
      ? `Bearer ${this.token}`
      : '';
  }

  getRefreshToken() {
    return this.token?.refresh_token;
  }

  ngOnDestroy(): void {
    this.clearRefresh();
  }

  private buildRefresh() {
    this.clearRefresh();

    if (this.token?.needRefresh()) {
      this.timer$ = timer(this.token.getRefreshTime() * 1000).subscribe(() => {
        this.refresh$.next(this.token);
      });
    }
  }

  private clearRefresh() {
    if (this.timer$ && !this.timer$.closed) {
      this.timer$.unsubscribe();
    }
  }
}
