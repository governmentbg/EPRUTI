import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { AuthService, TokenService, authGuard } from '@core/authentication';

describe('authGuard', () => {
  let authService: jasmine.SpyObj<AuthService>;
  let router: jasmine.SpyObj<Router>;

  beforeEach(() => {
    const authServiceSpy = jasmine.createSpyObj('AuthService', ['check']);
    const routerSpy = jasmine.createSpyObj('Router', ['parseUrl', 'createUrlTree']);

    TestBed.configureTestingModule({
      providers: [
        { provide: AuthService, useValue: authServiceSpy },
        { provide: Router, useValue: routerSpy },
      ],
    });

    authService = TestBed.inject(AuthService) as jasmine.SpyObj<AuthService>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;
  });

  it('should return true if the user is authenticated', () => {
    authService.check.and.returnValue(true);

    const result = TestBed.runInInjectionContext(() => authGuard());

    expect(result).toBeTrue();
  });

  it('should return the login URL if the user is not authenticated', () => {
    authService.check.and.returnValue(false);
    router.parseUrl.and.returnValue(router.createUrlTree(['/auth/login']));

    const result = TestBed.runInInjectionContext(() => authGuard());

    expect(result).toEqual(router.parseUrl('/auth/login'));
  });
});