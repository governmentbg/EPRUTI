import { Injectable, inject } from '@angular/core';
import { BehaviorSubject, catchError, iif, map, merge, Observable, of, share, switchMap, tap } from 'rxjs';
import { filterObject, isEmptyObject } from './helpers';
import { User } from './interface';
import { LoginService } from './login.service';
import { TokenService } from './token.service';
import { Menu, MenuService } from '@core/bootstrap/menu.service';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private readonly loginService = inject(LoginService);
  private readonly tokenService = inject(TokenService);
  private readonly menuService = inject(MenuService);

  private user$ = new BehaviorSubject<User>({});
  private change$ = merge(
    this.menuService.change()
  ).pipe(
    switchMap(() => this.assignUser()),
    share()
  );

  init() {
    return new Promise<void>(resolve => this.change$.subscribe(() => resolve()));
  }

  change() {
    return this.change$;
  }

  check() {
    return this.tokenService.valid();
  }

  refresh() {
    return this.loginService
      .refresh(filterObject({ refresh_token: this.tokenService.getRefreshToken() }))
      .pipe(
        catchError(() => of(undefined)),
        map(() => this.check())
      );
  }

  user() {
    return this.user$.pipe(share());
  }

  menu(): Observable<Menu[]> {
    return this.loginService.menu();
  }

  private assignUser() {
    if (!this.check()) {
      return of({}).pipe(tap(user => this.user$.next(user)));
    }

    if (!isEmptyObject(this.user$.getValue())) {
      return of(this.user$.getValue());
    }

    return null;
  }
}
