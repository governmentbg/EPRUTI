import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HTTP_INTERCEPTORS, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { ApiInterceptor } from './api-interceptor';

describe('ApiInterceptor', () => {
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;
  let toastrService: ToastrService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, ToastrModule.forRoot()],
      providers: [
        { provide: HTTP_INTERCEPTORS, useClass: ApiInterceptor, multi: true },
        ToastrService,
      ],
    });

    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
    toastrService = TestBed.inject(ToastrService);
    spyOn(toastrService, 'error').and.callThrough();
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should pass through non-API requests', () => {
    httpClient.get('/non-api-endpoint').subscribe(response => {
      expect(response).toBeTruthy();
    });

    const req = httpMock.expectOne('/non-api-endpoint');
    expect(req.request.method).toBe('GET');
    req.flush({ data: 'test' });
  });

  it('should handle API requests with success response', () => {
    httpClient.get('/api/test').subscribe(response => {
      expect(response).toBeTruthy();
    });

    const req = httpMock.expectOne('/api/test');
    expect(req.request.method).toBe('GET');
    req.flush({ code: 0, msg: 'success', data: {} });
  });
});
