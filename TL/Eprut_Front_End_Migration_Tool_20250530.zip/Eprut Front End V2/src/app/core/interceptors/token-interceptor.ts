import { HttpErrorResponse, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { TokenService } from '@core/authentication';
import { catchError, throwError } from 'rxjs';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  private readonly tokenService = inject(TokenService);

  intercept(req: HttpRequest<unknown>, next: HttpHandler) {
    if (this.tokenService.valid()) {
      return next
        .handle(
          req.clone({
            headers: req.headers.append('Authorization', this.tokenService.getBearerToken()),
            withCredentials: true,
          })
        )
        .pipe(
          catchError((error: HttpErrorResponse) => {
            if (error.status === 401) {
              // TODO
              // this.tokenService.clear();
            }
            return throwError(() => error);
          })
        );
    }

    return next.handle(req);
  }
}
