import { Component, OnInit, AfterViewInit, inject } from '@angular/core';
import { PreloaderService, SettingsService } from '@core';
import { RouterOutlet } from '@angular/router';
import { LoadingBarComponent } from '@shared/components/loading-bar/loading-bar.component';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-root',
  template: `
    <loading-bar [autoMode]="true"></loading-bar>
    <router-outlet />
  `,
  standalone: true,
  imports: [RouterOutlet, LoadingBarComponent],
})
export class AppComponent implements OnInit, AfterViewInit {
  private readonly preloader = inject(PreloaderService);
  private readonly settings = inject(SettingsService);
  private readonly cookie = inject(CookieService);

  ngOnInit() {
    if (!this.cookie.check('j')) {
      this.cookie.set('j', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiYXlvcmRhbm92YUBtcnJiLmdvdmVybm1lbnQuYmciLCJJZCI6IjE2OTQ2ZDhkLWE1NGQtNDU5NC05YzI1LWUyZTRjMDNhODVlOCIsIm5iZiI6MTc0NTUwMDAxNiwiZXhwIjoxNzc1NTAwMDE2LCJpYXQiOjE3NDU1MDAwMTYsImlzcyI6Im1hcGV4LmJnIiwiYXVkIjoiYWNjIn0.P12lc1Wzhe4Q86KOFO1OSxRyD8qyMBUZuzdznIgb1iI');
    }
    this.settings.setDirection();
    this.settings.setTheme();
  }

  ngAfterViewInit() {
    this.preloader.hide();
  }
}
