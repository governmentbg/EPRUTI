import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RegistersService } from './registers.service';
import { RegisterModel } from './register-model';
import { FileOutputModel } from '@shared/models/file-output-model';
import { PageableData } from './pageable-data';
import { FileModel } from './file-model';
import { DisplayValueWithCodeModel } from '@shared/models/display-value-with-code-model';
import { StatusChangeModel } from './status-change-model';
import { ImportJournalModel } from './import-journal-model';
import { ImportData } from './import-data';

describe('RegistersService', () => {
  let service: RegistersService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [RegistersService]
    });
    service = TestBed.inject(RegistersService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should submit a file', () => {
    const registerCode = 'testCode';
    const file = new File([''], 'testFile.txt');
    const mockResponse: FileOutputModel = { id: 1, statusId: 1, userId: 'test' };

    service.submitFile(registerCode, file).subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpMock.expectOne(`/import-api/import/registers/import-file/${registerCode}`);
    expect(req.request.method).toBe('POST');
    req.flush(mockResponse);
  });

  it('should get files with filters', () => {
    const registerCode = 'testCode';
    const filters = { startDate: '2021-01-01', endDate: '2021-12-31', statusCode: 'active' };
    const mockResponse: PageableData<FileModel> = { content: [], totalElements: 0, size: 5, pageNumber: 0 };

    service.getFiles(registerCode, filters).subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpMock.expectOne(req => req.url === `/import-api/import/registers/import-file/${registerCode}`);
    expect(req.request.method).toBe('GET');
    expect(req.request.params.get('startDate')).toBe(new Date(filters.startDate).toISOString());
    expect(req.request.params.get('endDate')).toBe(new Date(filters.endDate).toISOString());
    expect(req.request.params.get('statusCode')).toBe(filters.statusCode);
    req.flush(mockResponse);
  });

  it('should get files with statusCode as object', () => {
    const registerCode = 'testCode';
    const filters: { startDate?: string; endDate?: string; statusCode?: string } = { statusCode: 'TRANSFER_DONE' };
    const mockResponse: PageableData<FileModel> = { content: [], totalElements: 0, size: 5, pageNumber: 0 };

    service.getFiles(registerCode, filters).subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpMock.expectOne(req => req.url === `/import-api/import/registers/import-file/${registerCode}`);
    expect(req.request.method).toBe('GET');
    expect(req.request.params.get('statusCode')).toBe(filters.statusCode);
    req.flush(mockResponse);
  });

  it('should get files with statusCode as object with code property', () => {
    const registerCode = 'testCode';
    const filters = { statusCode: "TRANSFER_DONE" };
    const mockResponse: PageableData<FileModel> = { content: [], totalElements: 0, size: 5, pageNumber: 0 };

    service.getFiles(registerCode, filters).subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpMock.expectOne(req => req.url === `/import-api/import/registers/import-file/${registerCode}`);
    expect(req.request.method).toBe('GET');
    expect(req.request.params.get('statusCode')).toBe('TRANSFER_DONE');
    req.flush(mockResponse);
  });

  it('should get register normative acts', () => {
    const registerCode = 'testCode';
    const mockResponse: DisplayValueWithCodeModel[] = [{ code: 'act1', id: '1', description: 'Description 1' }];

    service.getRegisterNormativeActs(registerCode).subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpMock.expectOne(`/import-api/import/registers/${registerCode}/info`);
    expect(req.request.method).toBe('GET');
    req.flush(mockResponse);
  });

  it('should download journal', () => {
    const registerCode = 'testCode';
    const fileId = 1;
    const mockResponse = new Blob(['test'], { type: 'application/pdf' });

    service.downloadJournal(registerCode, fileId).subscribe(response => {
      expect(response.body).toEqual(mockResponse);
    });

    const req = httpMock.expectOne(`/import-api/import/registers/import-file/${registerCode}/details/${fileId}/download-journal`);
    expect(req.request.method).toBe('GET');
    expect(req.request.responseType).toBe('blob');
    req.flush(mockResponse);
  });

  it('should download with errors', () => {
    const registerCode = 'testCode';
    const fileId = 1;
    const mockResponse = new Blob(['test'], { type: 'application/pdf' });

    service.downloadWithErrors(registerCode, fileId).subscribe(response => {
      expect(response.body).toEqual(mockResponse);
    });

    const req = httpMock.expectOne(`/import-api/import/registers/import-file/${registerCode}/details/${fileId}/import-errors`);
    expect(req.request.method).toBe('GET');
    expect(req.request.responseType).toBe('blob');
    req.flush(mockResponse);
  });

  it('should start migration', () => {
    const registerCode = 'testCode';
    const fileId = 1;
    const mockResponse: StatusChangeModel = { statusId: 1, statusCode: 'test' } as StatusChangeModel;

    service.startMigration(registerCode, fileId).subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpMock.expectOne(`/import-api/import/registers/import-file/${registerCode}/details/${fileId}/import-migration`);
    expect(req.request.method).toBe('POST');
    req.flush(mockResponse);
  });

  it('should get statuses', () => {
    const mockResponse = [{ id:1, code: 'status1', description: 'Status 1' }];

    service.getStatuses().subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpMock.expectOne(`/import-api/import/registers/statuses`);
    expect(req.request.method).toBe('GET');
    req.flush(mockResponse);
  });

  it('should convert from server model', () => {
    const json = { id: 1, name: 'test' };
    const model = service.fromServerModel(json);
    expect(model).toEqual(new RegisterModel(json));
  });

  it('should get import journal', () => {
    const registerCode = 'testCode';
    const fileId = 1;
    const mockResponse: PageableData<ImportJournalModel> = { content: [], totalElements: 0, size: 5, pageNumber: 0 };

    service.getImportJournal(registerCode, fileId).subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpMock.expectOne(req => req.url === `/import-api/import/registers/import-file/${registerCode}/details/${fileId}/import-journal` && req.params.get('page') === '0' && req.params.get('size') === '5');
    expect(req.request.method).toBe('GET');
    req.flush(mockResponse);
  });

  it('should get import journal with sorting', () => {
    const registerCode = 'testCode';
    const fileId = 1;
    const sort: { field: string; direction: '' | 'asc' | 'desc' }[] = [{ field: 'date', direction: 'asc' }];
    const mockResponse: PageableData<ImportJournalModel> = { content: [], totalElements: 0, size: 5, pageNumber: 0 };

    service.getImportJournal(registerCode, fileId, 0, 5, sort).subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpMock.expectOne(req => req.url === `/import-api/import/registers/import-file/${registerCode}/details/${fileId}/import-journal` && req.params.get('page') === '0' && req.params.get('size') === '5' && req.params.get('sort') === 'date,asc');
    expect(req.request.method).toBe('GET');
    req.flush(mockResponse);
  });

  it('should get file data', () => {
    const registerCode = 'testCode';
    const importId = 1;
    const mockResponse: ImportData = { filename: 'test', size: 1, numActs: 1, numObjects: 1, numAttachedFiles: 1, hasErrors: false } as ImportData;

    service.getFileData(registerCode, importId).subscribe(response => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpMock.expectOne(`/import-api/import/registers/import-file/${registerCode}/details/${importId}`);
    expect(req.request.method).toBe('GET');
    req.flush(mockResponse);
  });
});
