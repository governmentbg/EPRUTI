import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FileListComponent } from './file-list.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { TranslateModule } from '@ngx-translate/core';
import { NomenclaturesService } from '@shared/nomenclatures/nomenclatures.service';
import { RegistersService } from '../../registers.service';
import { of, timer } from 'rxjs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { provideNativeDateAdapter } from '@angular/material/core';

describe('FileListComponent', () => {
  let component: FileListComponent;
  let fixture: ComponentFixture<FileListComponent>;
  let nomenclaturesServiceStub: Partial<NomenclaturesService>;
  let registersServiceStub: Partial<RegistersService>;
  let router: Router;

  beforeEach(async () => {
    nomenclaturesServiceStub = {
      getFileStatuses: () => of([])
    };

    registersServiceStub = {
      getFiles: () => of({ content: [], totalElements: 0, pageNumber: 0, size: 0 }),
      refreshFiles: of(null)
    };

    await TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
        MatTableModule,
        MatSortModule,
        MatPaginatorModule,
        MatSnackBarModule,
        TranslateModule.forRoot(),
        BrowserAnimationsModule,
        RouterTestingModule.withRoutes([]),
        FileListComponent
      ],
      providers: [
        { provide: NomenclaturesService, useValue: nomenclaturesServiceStub },
        { provide: RegistersService, useValue: registersServiceStub },
        { provide: ActivatedRoute, useValue: {} },
        provideNativeDateAdapter()
      ]
    }).compileComponents();

    router = TestBed.inject(Router);
    spyOn(router, 'navigate');
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FileListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize form group', () => {
    expect(component.formGroup).toBeDefined();
  });

  it('should call refresh on init', () => {
    spyOn(component, 'refresh');
    component.ngOnInit();
    expect(component.refresh).toHaveBeenCalled();
  });

  it('should submit form and refresh data', () => {
    spyOn(component, 'refresh');
    component.submit();
    expect(component.refresh).toHaveBeenCalled();
  });

  it('should change page and refresh data', () => {
    spyOn(component, 'refresh');
    const event = { pageIndex: 1, pageSize: 10 } as any;
    component.changePage(event);
    expect(component.refresh).toHaveBeenCalledWith(1, 10, component.formGroup.value, component.lastSavedSorting ? [{ field: component.lastSavedSorting.active, direction: component.lastSavedSorting.direction }] : null);
  });

  it('should change sort and refresh data', () => {
    spyOn(component, 'refresh');
    const event: { active: string; direction: '' | 'asc' | 'desc' } = { active: 'uploadDate', direction: 'asc' };
    component.changeSort(event);
    expect(component.refresh).toHaveBeenCalledWith(component.pageIndex, component.pageSize, component.formGroup.value, [{ field: 'uploadDate', direction: 'asc' }]);
  });

  it('should unsubscribe on destroy', () => {
    spyOn(component['_unsubscribeAll'], 'next');
    spyOn(component['_unsubscribeAll'], 'complete');
    component.ngOnDestroy();
    expect(component['_unsubscribeAll'].next).toHaveBeenCalled();
    expect(component['_unsubscribeAll'].complete).toHaveBeenCalled();
  });

  it('should reset form and refresh data', () => {
    spyOn(component, 'refresh');
    component.formGroup.setValue({ startDate: '2021-01-01', endDate: '2021-01-31', statusCode: { code: 'test', description: 'Test' } });
    component.reset();
    expect(component.formGroup.value).toEqual({ startDate: null, endDate: null, statusCode: null });
    expect(component.refresh).toHaveBeenCalled();
  });

  it('should navigate to file info', () => {
    const row = { id: 1 };
    component.showFileInfo(row);
    expect(router.navigate).toHaveBeenCalledWith(['details', 1], { relativeTo: component['_route'] });
  });

  it('should filter statuses correctly', () => {
    component.statuses = [
      { id: 1, code: 'TRANSFER_DONE', description: 'Transfer Done' },
      { id: 2, code: 'TRANSFER_READY', description: 'Transfer Ready' }
    ];
    let result = component['_filter']('Transfer Done');
    expect(result).toEqual([{ id: 1, code: 'TRANSFER_DONE', description: 'Transfer Done' }]);
  
    result = component['_filter']({ id: 1, code: 'TRANSFER_DONE', description: 'Transfer Done' });
    expect(result).toEqual([{ id: 1, code: 'TRANSFER_DONE', description: 'Transfer Done' }]);
  });

  it('should set and get form values from localStorage', () => {
    const formValues = { startDate: '2021-01-01', endDate: '2021-01-31', statusCode: { code: 'test', description: 'Test' } };
    localStorage.setItem('fileListFormValues', JSON.stringify(formValues));
    component.ngOnInit();
    expect(component.formGroup.value).toEqual(formValues);
  });

  it('should handle changes and start timer', () => {
    spyOn(component['_snackbar'], 'open');
    component.ngOnChanges({ duration: { currentValue: 5, previousValue: 0, firstChange: true, isFirstChange: () => true } });
    expect(component['_snackbar'].open).toHaveBeenCalled();
    expect(component.timerSubscription).toBeDefined();
  });

  it('should handle changes and stop timer', () => {
    spyOn(component.timerSubscription, 'unsubscribe');
    component.ngOnChanges({ duration: { currentValue: 0, previousValue: 5, firstChange: false, isFirstChange: () => false } });
    expect(component.timerSubscription.unsubscribe).toHaveBeenCalled();
  });
});
