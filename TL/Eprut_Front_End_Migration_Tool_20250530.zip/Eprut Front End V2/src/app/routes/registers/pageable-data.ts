export class PageableData<T> {

    content: T[];
    size: number;
    pageNumber: number;
    totalElements: number;
    statusCode?: string;
    isLast?: boolean;

    constructor(init?: Partial<PageableData<T>>, private ctor?: new (...args: any[]) => T) {

        Object.assign(this, init);

        if (init?.content) {
            this.content = init.content;
        } else {
            this.content = [];
        }
    }
}
