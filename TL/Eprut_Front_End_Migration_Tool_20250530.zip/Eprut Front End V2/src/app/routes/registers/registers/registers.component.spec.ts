import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { catchError } from 'rxjs/operators';

import { RegistersComponent } from './registers.component';
import { RegistersService } from '../registers.service';
import { SettingsService } from '@core';
import { LoadingService } from '@shared/components/loading-bar/loading.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('RegistersComponent', () => {
  let component: RegistersComponent;
  let fixture: ComponentFixture<RegistersComponent>;
  let registersService: jasmine.SpyObj<RegistersService>;
  let settingsService: jasmine.SpyObj<SettingsService>;

  beforeEach(async () => {
    const registersServiceSpy = jasmine.createSpyObj('RegistersService', ['getList']);
    const settingsServiceSpy = jasmine.createSpyObj('SettingsService', ['notify'], {
      notify: of({})
    });

    await TestBed.configureTestingModule({
      imports: [
        RegistersComponent,
        ReactiveFormsModule,
        FormsModule,
        MatDialogModule,
        MatSnackBarModule,
        RouterTestingModule,
        TranslateModule.forRoot(),
        MatIconModule,
        MatTooltipModule,
        MatTableModule,
        MatButtonModule,
        MatFormFieldModule,
        MatInputModule,
        BrowserAnimationsModule,
        HttpClientTestingModule
      ],
      providers: [
        { provide: RegistersService, useValue: registersServiceSpy },
        { provide: SettingsService, useValue: settingsServiceSpy },
        LoadingService
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(RegistersComponent);
    component = fixture.componentInstance;
    registersService = TestBed.inject(RegistersService) as jasmine.SpyObj<RegistersService>;
    settingsService = TestBed.inject(SettingsService) as jasmine.SpyObj<SettingsService>;

    registersService.getList.and.returnValue(of([]));

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize filterForm', () => {
    expect(component.filterForm).toBeDefined();
  });

  it('should call getList and populate dataSource on init', () => {
    expect(registersService.getList).toHaveBeenCalled();
    expect(component.dataSource).toEqual([]);
  });

  it('should reset filter form and apply filter', () => {
    component.filterForm.controls['registerName'].setValue('test');
    component.clearFilter();
    expect(component.filterForm.controls['registerName'].value).toBeNull();
  });

  it('should filter registers based on input', () => {
    component.dataSource = [{ description: 'test' }] as any;
    component.applyFilter('test');
    component.filteredRegisters$.subscribe(filtered => {
      expect(filtered.length).toBe(1);
    });
  });

  it('should open dialog on showNormActs', () => {
    const dialogSpy = spyOn(component['_dialog'], 'open');
    component.showNormActs(new Event('click'), {});
    expect(dialogSpy).toHaveBeenCalled();
  });

  it('should navigate on importFile', () => {
    const routerSpy = spyOn(component['_router'], 'navigate');
    component.importFile({ code: '123', description: 'test' });
    expect(routerSpy).toHaveBeenCalledWith(['import-file', '123'], { 
      relativeTo: component['_route'],
      state: { description: 'test' }
    });
  });

  it('should unsubscribe on destroy', () => {
    const unsubscribeSpy = spyOn(component['_unsubscribeAll'], 'next');
    component.ngOnDestroy();
    expect(unsubscribeSpy).toHaveBeenCalled();
  });

  it('should handle error and return empty observable on init', () => {
    const errorResponse = new Error('test error');
    registersService.getList.and.returnValue(throwError(errorResponse));
    component.ngOnInit();
    expect(registersService.getList).toHaveBeenCalled();
    component.filteredRegisters$.subscribe(registers => {
      expect(registers).toEqual([]);
    });
  });

  it('should handle error and log it in downloadFile', () => {
    const errorResponse = new Error('Download error');
    spyOn(component['_templateDownloadService'], 'downloadFile').and.returnValue(throwError(errorResponse));
    const consoleErrorSpy = spyOn(console, 'error');
    component.downloadFile(new Event('click'), '123', 'excel');
    expect(consoleErrorSpy).toHaveBeenCalledWith(errorResponse);
  });

  it('should download file on downloadFile', () => {
    const blob = new Blob(['test'], { type: 'application/octet-stream' });
    const response = { blob, fileName: 'test.xlsx' };
    spyOn(component['_templateDownloadService'], 'downloadFile').and.returnValue(of(response));
    const createObjectURLSpy = spyOn(window.URL, 'createObjectURL').and.returnValue('blob:url');
    const revokeObjectURLSpy = spyOn(window.URL, 'revokeObjectURL');
    const appendChildSpy = spyOn(document.body, 'appendChild');
    const removeChildSpy = spyOn(document.body, 'removeChild');

    component.downloadFile(new Event('click'), '123', 'excel');

    expect(component['_templateDownloadService'].downloadFile).toHaveBeenCalledWith('123', 'excel');
    expect(createObjectURLSpy).toHaveBeenCalledWith(blob);
    expect(appendChildSpy).toHaveBeenCalled();
    expect(removeChildSpy).toHaveBeenCalled();
    expect(revokeObjectURLSpy).toHaveBeenCalledWith('blob:url');
  });
});
