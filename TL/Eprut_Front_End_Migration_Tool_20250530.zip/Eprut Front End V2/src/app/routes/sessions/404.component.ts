import { Component } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { ErrorCodeComponent } from '@shared/components/error-code/error-code.component';

@Component({
  selector: 'app-error-404',
  template: `
    <error-code
      code="404"
      [title]="'common.pageNotFound' | translate"
      [message]="'common.pageNotFoundMessage' | translate"
    />
  `,
  standalone: true,
  imports: [ErrorCodeComponent, TranslateModule],
})
export class Error404Component {}
