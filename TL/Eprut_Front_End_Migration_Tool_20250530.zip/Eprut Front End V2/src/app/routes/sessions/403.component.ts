import { Component } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { ErrorCodeComponent } from '@shared/components/error-code/error-code.component';

@Component({
  selector: 'app-error-403',
  template: `
    <error-code
      code="403"
      [title]="'common.unauthorized' | translate"
      [message]="'common.unauthorizedMessage' | translate"
    />
  `,
  standalone: true,
  imports: [ErrorCodeComponent, TranslateModule],
})
export class Error403Component {}
