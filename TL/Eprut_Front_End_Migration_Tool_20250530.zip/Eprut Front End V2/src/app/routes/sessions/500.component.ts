import { Component } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { ErrorCodeComponent } from '@shared/components/error-code/error-code.component';

@Component({
  selector: 'app-error-500',
  template: `
    <error-code
      code="500"
      [title]="'common.internalServer' | translate"
      [message]="'common.internalServerMessage' | translate"
    />
  `,
  standalone: true,
  imports: [ErrorCodeComponent, TranslateModule],
})
export class Error500Component {}
