import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import screenfull from 'screenfull';

import { BrandingComponent } from '../widgets/branding.component';
import { TranslateComponent } from '../widgets/translate.component';
import { MatDividerModule } from '@angular/material/divider';
import { TranslateModule } from '@ngx-translate/core';
import { MatTooltipModule } from '@angular/material/tooltip';
import { TemplateDownloadService } from '@core/services/template-download.service';
import { Subject, takeUntil } from 'rxjs';
import { MatMenuModule } from '@angular/material/menu';
import { MtxPopoverModule } from '@ng-matero/extensions/popover';
import { UserDetailsService } from '@shared/services/user-details.service';
import { UserDetailsModel } from '@shared/models/user-details-model';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
  host: {
    class: 'matero-header',
  },
  encapsulation: ViewEncapsulation.None,
  standalone: true,
  imports: [
    MtxPopoverModule,
    MatMenuModule,
    MatTooltipModule,
    MatDividerModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    BrandingComponent,
    TranslateModule,
    TranslateComponent
  ],
})
export class HeaderComponent implements OnInit, OnDestroy {

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  
  profile: UserDetailsModel;

  constructor(
    private _userDetailsService: UserDetailsService,
    private _templateDownloadService: TemplateDownloadService
  ) {
  }

  ngOnInit(): void {
    this._userDetailsService.getUserDetails().pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: (res) => {
        this.profile = res;
      },
      error: (e) => {
        console.error(e);
      }
    });
  }

  toggleFullscreen(): void {
    if (screenfull.isEnabled) {
      screenfull.toggle();
    }
  }

  openUserGuide(): void {
    window.open('assets/files/user-guide-eprut.pdf', "_blank");
  }

  downloadXsdTemplates(): void {
    this._templateDownloadService.downloadXsdTemplates().pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: (res) => {
        const blob = new Blob([res], { type: 'application/zip' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'xsd-xml.zip';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      },
      error: (e) => {
        console.error(e);
      }
    });
  }

  logout(): void {
    window.location.href = '/ExternalLogout';
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(null);
    this._unsubscribeAll.complete();
  }
}
