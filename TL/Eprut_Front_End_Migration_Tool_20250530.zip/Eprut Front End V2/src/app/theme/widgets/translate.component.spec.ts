import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslateComponent } from './translate.component';
import { TranslateModule } from '@ngx-translate/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { CommonModule } from '@angular/common';

describe('TranslateComponent', () => {
  let component: TranslateComponent;
  let fixture: ComponentFixture<TranslateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CommonModule, MatButtonModule, MatIconModule, MatMenuModule, TranslateComponent, TranslateModule.forRoot()],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TranslateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should toggle language from bg to en', () => {
    component.useLanguage('bg');
    component.toggleLanguage();
    expect(component.activeLang).toBe('en');
  });

  it('should toggle language from en to bg', () => {
    component.useLanguage('en');
    component.toggleLanguage();
    expect(component.activeLang).toBe('bg');
  });

  it('should return correct label for bg', () => {
    const label = component.getLabel('bg');
    expect(label).toBe('Български');
  });

  it('should return correct label for en', () => {
    const label = component.getLabel('en');
    expect(label).toBe('English');
  });

  it('should return empty string for unknown language', () => {
    const label = component.getLabel('fr');
    expect(label).toBe('');
  });
});
