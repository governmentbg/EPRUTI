import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BrandingComponent } from './branding.component';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateModule } from '@ngx-translate/core';

describe('BrandingComponent', () => {
  let component: BrandingComponent;
  let fixture: ComponentFixture<BrandingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, BrandingComponent, TranslateModule.forRoot()],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the logo image', () => {
    const compiled = fixture.nativeElement;
    const logo = compiled.querySelector('.branding-logo');
    expect(logo).toBeTruthy();
    expect(logo.src).toContain('assets/images/logo.png');
  });

  it('should have showName input property set to true by default', () => {
    expect(component.showName).toBeTrue();
  });

  it('should update showName input property', () => {
    component.showName = false;
    fixture.detectChanges();
    expect(component.showName).toBeFalse();
  });
});
